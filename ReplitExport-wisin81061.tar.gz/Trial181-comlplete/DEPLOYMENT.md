# Deployment Guide

This document provides detailed instructions for deploying the Solana Payment System to various environments.

## Table of Contents

- [GitHub Deployment](#github-deployment)
- [Replit Deployment](#replit-deployment)
- [Cloud Hosting](#cloud-hosting)
- [Local Deployment](#local-deployment)
- [Environment Variables](#environment-variables)
- [Troubleshooting](#troubleshooting)

## GitHub Deployment

### 1. Fork or Clone the Repository

Fork this repository to your GitHub account or clone it to your local machine:

```bash
git clone https://github.com/yourusername/solana-payment-system.git
cd solana-payment-system
```

### 2. Configure GitHub Secrets (for GitHub Actions CI/CD)

If using GitHub Actions, configure the following secrets in your repository settings:

- `SOLANA_RECEIVER_PUBLIC_KEY`: Your Solana wallet public key
- `PORT`: (Optional) Port for the application
- Any additional environment variables needed

### 3. Configure GitHub Pages (Optional)

For static frontend hosting:

1. Go to your repository's Settings > Pages
2. Select the branch to deploy (usually `main` or `gh-pages`)
3. Set the folder to `/public`
4. Save the settings

### 4. Deploy Backend with GitHub Actions

Create a workflow file at `.github/workflows/deploy.yml`:

```yaml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Install dependencies
        run: npm ci
      - name: Deploy
        run: |
          # Your deployment steps here
          # Example: Deploy to Heroku, AWS, etc.
        env:
          # Add your environment variables here
          SOLANA_RECEIVER_PUBLIC_KEY: ${{ secrets.SOLANA_RECEIVER_PUBLIC_KEY }}
```

## Replit Deployment

### 1. Using Replit's Deployment Feature

1. In your Replit project, click on the **Deploy** tab
2. Configure your deployment settings
3. Click **Deploy to Production**

### 2. Using the Built-in Deployment Script

```bash
bash run-deploy.sh
```

This script will:
- Set the correct environment variables
- Start the server in production mode
- Configure any necessary caching

### 3. Handling Environment Variables

In Replit, add your environment variables in the Secrets tab:

1. Go to the **Secrets** tab in your Replit project
2. Add each environment variable as a separate secret
3. Ensure `SOLANA_RECEIVER_PUBLIC_KEY` is configured

## Cloud Hosting

### Heroku

1. Install Heroku CLI:
   ```bash
   npm install -g heroku
   ```

2. Login to Heroku:
   ```bash
   heroku login
   ```

3. Create a new Heroku app:
   ```bash
   heroku create your-app-name
   ```

4. Set environment variables:
   ```bash
   heroku config:set SOLANA_NETWORK=devnet
   heroku config:set SOLANA_MOCK_MODE=true
   heroku config:set SOLANA_RECEIVER_PUBLIC_KEY=your_key_here
   ```

5. Deploy to Heroku:
   ```bash
   git push heroku main
   ```

### AWS Elastic Beanstalk

1. Install AWS EB CLI
2. Initialize EB application:
   ```bash
   eb init
   ```
3. Create an environment:
   ```bash
   eb create my-environment
   ```
4. Set environment variables:
   ```bash
   eb setenv SOLANA_NETWORK=devnet SOLANA_MOCK_MODE=true SOLANA_RECEIVER_PUBLIC_KEY=your_key_here
   ```
5. Deploy:
   ```bash
   eb deploy
   ```

## Local Deployment

### Prerequisites

- Node.js (v18+)
- npm or yarn

### Steps

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/solana-payment-system.git
   cd solana-payment-system
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file:
   ```bash
   cp .env.example .env
   ```

4. Edit the `.env` file with your configuration

5. Start the server:
   ```bash
   node server-express.js
   ```

6. Access the application at `http://localhost:3000`

## Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `PORT` | Server port | No | 3000 |
| `NODE_ENV` | Environment | No | development |
| `SOLANA_NETWORK` | Solana network | Yes | devnet |
| `SOLANA_MOCK_MODE` | Enable mock mode | No | true |
| `SOLANA_RECEIVER_PUBLIC_KEY` | Wallet address | Yes* | - |

*Required in production, optional in development with mock mode enabled

## Troubleshooting

### Common Issues

1. **Port conflicts**
   - Error: `EADDRINUSE: address already in use`
   - Solution: Change the `PORT` environment variable

2. **Missing environment variables**
   - Error: `Required environment variable SOLANA_RECEIVER_PUBLIC_KEY is not set`
   - Solution: Make sure to set all required environment variables

3. **Connection issues with Solana network**
   - Error: `Failed to connect to Solana network`
   - Solution: 
     - Check your internet connection
     - Verify the `SOLANA_NETWORK` value
     - Try enabling mock mode for testing

4. **Deployment failures**
   - Check deployment logs for specific error messages
   - Verify that all environment variables are properly set
   - Ensure proper Node.js version compatibility

### Getting Help

If you encounter issues not covered here, please:
1. Check the GitHub Issues section
2. Open a new issue with detailed information about your problem
3. Include your environment, error messages, and steps to reproduce