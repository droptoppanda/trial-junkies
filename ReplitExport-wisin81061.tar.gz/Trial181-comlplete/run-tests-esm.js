/**
 * Run Solana Payment Tests (ESM version)
 * This script runs only the test component
 */

import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

// Get the directory name of the current module (equivalent to __dirname in CommonJS)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('Starting Solana payment tests...');

// Start the test process
const testProcess = spawn(process.execPath, [path.join(__dirname, 'ultra-minimal-test.js')], {
  stdio: 'inherit',
  detached: false
});

// Handle test process exit
testProcess.on('exit', (code) => {
  console.log(`Test process exited with code ${code}`);
  process.exit(code);
});

// Handle process termination
process.on('SIGINT', () => {
  console.log('Received SIGINT. Cleaning up...');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('Received SIGTERM. Cleaning up...');
  process.exit(0);
});