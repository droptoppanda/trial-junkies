import { 
  users, type User, type InsertUser,
  subscriptions, type Subscription, type InsertSubscription,
  automatedTrials, type AutomatedTrial, type InsertAutomatedTrial,
  virtualIdentities, type VirtualIdentity, type InsertVirtualIdentity,
  virtualCards, type VirtualCard, type InsertVirtualCard,
  environmentConfig, type EnvironmentConfig, type InsertEnvironmentConfig,
  setupEnvironmentSchema
} from "@shared/schema";

// Modify the interface with any CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  getUserByDiscordId(discordId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined>;
  getUserCount(): Promise<number>; // Added getUserCount method

  // Subscription methods
  getSubscription(id: number): Promise<Subscription | undefined>;
  getSubscriptionsByUserId(userId: number): Promise<Subscription[]>;
  getActiveSubscriptionByUserId(userId: number): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: number, data: Partial<InsertSubscription>): Promise<Subscription | undefined>;
  deactivateSubscription(id: number): Promise<Subscription | undefined>;

  // Admin methods
  getAllUsers(): Promise<User[]>;
  getAllSubscriptions(): Promise<Subscription[]>;

  // AI Trial methods
  getAutomatedTrial(id: number): Promise<AutomatedTrial | undefined>;
  getAutomatedTrialsByUserId(userId: number): Promise<AutomatedTrial[]>;
  createAutomatedTrial(trial: InsertAutomatedTrial): Promise<AutomatedTrial>;
  updateAutomatedTrial(id: number, data: Partial<InsertAutomatedTrial>): Promise<AutomatedTrial | undefined>;

  // Virtual Identity methods
  getVirtualIdentity(id: number): Promise<VirtualIdentity | undefined>;
  getVirtualIdentitiesByUserId(userId: number): Promise<VirtualIdentity[]>;
  createVirtualIdentity(identity: InsertVirtualIdentity): Promise<VirtualIdentity>;
  updateVirtualIdentity(id: number, data: Partial<InsertVirtualIdentity>): Promise<VirtualIdentity | undefined>;

  // Virtual Card methods
  getVirtualCard(id: number): Promise<VirtualCard | undefined>;
  getVirtualCardsByUserId(userId: number): Promise<VirtualCard[]>;
  createVirtualCard(card: InsertVirtualCard): Promise<VirtualCard>;
  updateVirtualCard(id: number, data: Partial<InsertVirtualCard>): Promise<VirtualCard | undefined>;
  
  // Environment Configuration methods
  getEnvironmentConfig(): Promise<any | undefined>;
  saveEnvironmentConfig(config: any): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private subscriptions: Map<number, Subscription>;
  private automatedTrials: Map<number, AutomatedTrial>;
  private virtualIdentities: Map<number, VirtualIdentity>;
  private virtualCards: Map<number, VirtualCard>;
  private environmentConfig: EnvironmentConfig | null = null;
  
  private userIdCounter: number;
  private subscriptionIdCounter: number;
  private automatedTrialIdCounter: number;
  private virtualIdentityIdCounter: number;
  private virtualCardIdCounter: number;

  constructor() {
    this.users = new Map();
    this.subscriptions = new Map();
    this.automatedTrials = new Map();
    this.virtualIdentities = new Map();
    this.virtualCards = new Map();

    this.userIdCounter = 1;
    this.subscriptionIdCounter = 1;
    this.automatedTrialIdCounter = 1;
    this.virtualIdentityIdCounter = 1;
    this.virtualCardIdCounter = 1;

    // Create a default admin user
    this.createUser({
      username: "admin",
      password: "admin123", // In production, this would be properly hashed
      is_admin: true,
      api_key: "admin-api-key-123",
      credits_remaining: 999
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.wallet_address === walletAddress,
    );
  }

  async getUserByDiscordId(discordId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.discord_id === discordId,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;

    // Ensure all nullable fields have proper values
    const user: User = {
      id,
      username: insertUser.username,
      password: insertUser.password,
      wallet_address: insertUser.wallet_address ?? null,
      discord_id: insertUser.discord_id ?? null, 
      discord_username: insertUser.discord_username ?? null,
      discord_access_token: insertUser.discord_access_token ?? null,
      discord_refresh_token: insertUser.discord_refresh_token ?? null,
      discord_token_expiry: insertUser.discord_token_expiry ?? null,
      is_admin: insertUser.is_admin ?? false,
      api_key: insertUser.api_key ?? null,
      credits_remaining: insertUser.credits_remaining ?? null
    };

    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) {
      return undefined;
    }

    const updatedUser: User = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

    async getUserCount(): Promise<number> {
    return this.users.size;
  }

  // Subscription methods
  async getSubscription(id: number): Promise<Subscription | undefined> {
    return this.subscriptions.get(id);
  }

  async getSubscriptionsByUserId(userId: number): Promise<Subscription[]> {
    return Array.from(this.subscriptions.values()).filter(
      (subscription) => subscription.user_id === userId,
    );
  }

  async getActiveSubscriptionByUserId(userId: number): Promise<Subscription | undefined> {
    return Array.from(this.subscriptions.values()).find(
      (subscription) => subscription.user_id === userId && subscription.active,
    );
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const id = this.subscriptionIdCounter++;

    // Ensure all nullable fields have proper values
    const subscription: Subscription = {
      id,
      user_id: insertSubscription.user_id,
      tier: insertSubscription.tier,
      price: insertSubscription.price,
      start_date: insertSubscription.start_date,
      end_date: insertSubscription.end_date,
      active: insertSubscription.active ?? null,
      transaction_signature: insertSubscription.transaction_signature ?? null,
      discord_role_id: insertSubscription.discord_role_id ?? null
    };

    this.subscriptions.set(id, subscription);
    return subscription;
  }

  async updateSubscription(id: number, data: Partial<InsertSubscription>): Promise<Subscription | undefined> {
    const subscription = await this.getSubscription(id);
    if (!subscription) {
      return undefined;
    }

    const updatedSubscription: Subscription = { ...subscription, ...data };
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }

  async deactivateSubscription(id: number): Promise<Subscription | undefined> {
    const subscription = await this.getSubscription(id);
    if (!subscription) {
      return undefined;
    }

    const updatedSubscription: Subscription = { ...subscription, active: false };
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }

  // Admin methods
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async getAllSubscriptions(): Promise<Subscription[]> {
    return Array.from(this.subscriptions.values());
  }

  // AI Trial methods
  async getAutomatedTrial(id: number): Promise<AutomatedTrial | undefined> {
    return this.automatedTrials.get(id);
  }

  async getAutomatedTrialsByUserId(userId: number): Promise<AutomatedTrial[]> {
    return Array.from(this.automatedTrials.values()).filter(
      (trial) => trial.user_id === userId,
    );
  }

  async createAutomatedTrial(insertTrial: InsertAutomatedTrial): Promise<AutomatedTrial> {
    const id = this.automatedTrialIdCounter++;

    const trial: AutomatedTrial = {
      id,
      user_id: insertTrial.user_id,
      service_name: insertTrial.service_name,
      status: insertTrial.status,
      created_at: insertTrial.created_at ?? new Date(),
      completed_at: insertTrial.completed_at ?? null,
      credentials: insertTrial.credentials ?? null,
      website_url: insertTrial.website_url,
      result_message: insertTrial.result_message ?? null,
      is_valid: insertTrial.is_valid ?? false,
      discord_message_id: insertTrial.discord_message_id ?? null
    };

    this.automatedTrials.set(id, trial);
    return trial;
  }

  async updateAutomatedTrial(id: number, data: Partial<InsertAutomatedTrial>): Promise<AutomatedTrial | undefined> {
    const trial = await this.getAutomatedTrial(id);
    if (!trial) {
      return undefined;
    }

    const updatedTrial: AutomatedTrial = { ...trial, ...data };
    this.automatedTrials.set(id, updatedTrial);
    return updatedTrial;
  }

  // Virtual Identity methods
  async getVirtualIdentity(id: number): Promise<VirtualIdentity | undefined> {
    return this.virtualIdentities.get(id);
  }

  async getVirtualIdentitiesByUserId(userId: number): Promise<VirtualIdentity[]> {
    return Array.from(this.virtualIdentities.values()).filter(
      (identity) => identity.user_id === userId,
    );
  }

  async createVirtualIdentity(insertIdentity: InsertVirtualIdentity): Promise<VirtualIdentity> {
    const id = this.virtualIdentityIdCounter++;

    const identity: VirtualIdentity = {
      id,
      user_id: insertIdentity.user_id,
      email: insertIdentity.email,
      username: insertIdentity.username,
      password: insertIdentity.password,
      first_name: insertIdentity.first_name ?? null,
      last_name: insertIdentity.last_name ?? null,
      birth_date: insertIdentity.birth_date ?? null,
      created_at: insertIdentity.created_at ?? new Date(),
      is_active: insertIdentity.is_active ?? true,
      virtual_card_id: insertIdentity.virtual_card_id ?? null,
      metadata: insertIdentity.metadata ?? null
    };

    this.virtualIdentities.set(id, identity);
    return identity;
  }

  async updateVirtualIdentity(id: number, data: Partial<InsertVirtualIdentity>): Promise<VirtualIdentity | undefined> {
    const identity = await this.getVirtualIdentity(id);
    if (!identity) {
      return undefined;
    }

    const updatedIdentity: VirtualIdentity = { ...identity, ...data };
    this.virtualIdentities.set(id, updatedIdentity);
    return updatedIdentity;
  }

  // Virtual Card methods
  async getVirtualCard(id: number): Promise<VirtualCard | undefined> {
    return this.virtualCards.get(id);
  }

  async getVirtualCardsByUserId(userId: number): Promise<VirtualCard[]> {
    return Array.from(this.virtualCards.values()).filter(
      (card) => card.user_id === userId,
    );
  }

  async createVirtualCard(insertCard: InsertVirtualCard): Promise<VirtualCard> {
    const id = this.virtualCardIdCounter++;

    const card: VirtualCard = {
      id,
      user_id: insertCard.user_id,
      card_number: insertCard.card_number,
      expiry_date: insertCard.expiry_date,
      cvv: insertCard.cvv,
      cardholder_name: insertCard.cardholder_name,
      created_at: insertCard.created_at ?? new Date(),
      is_active: insertCard.is_active ?? true,
      balance: insertCard.balance ?? "0",
      provider: insertCard.provider ?? null
    };

    this.virtualCards.set(id, card);
    return card;
  }

  async updateVirtualCard(id: number, data: Partial<InsertVirtualCard>): Promise<VirtualCard | undefined> {
    const card = await this.getVirtualCard(id);
    if (!card) {
      return undefined;
    }

    const updatedCard: VirtualCard = { ...card, ...data };
    this.virtualCards.set(id, updatedCard);
    return updatedCard;
  }

  // Environment Configuration methods
  async getEnvironmentConfig(): Promise<EnvironmentConfig | undefined> {
    return this.environmentConfig || undefined;
  }

  async saveEnvironmentConfig(config: any): Promise<void> {
    // Validate the config with setupEnvironmentSchema
    const validation = setupEnvironmentSchema.safeParse(config);
    
    if (!validation.success) {
      throw new Error(`Invalid environment configuration: ${JSON.stringify(validation.error.format())}`);
    }
    
    // Set ID to 1 if this is the first configuration or keep existing ID
    const id = this.environmentConfig?.id || 1;
    
    // Update the environment configuration
    this.environmentConfig = {
      id,
      solana_receiver_public_key: config.solana_receiver_public_key,
      mock_solana_verification: config.mock_solana_verification || false,
      enable_sms_verification: config.enable_sms_verification || false,
      sms_provider: config.sms_provider || null,
      sms_api_key: config.sms_api_key || null,
      sms_sender_id: config.sms_sender_id || null,
      enable_email_verification: config.enable_email_verification || false,
      email_provider: config.email_provider || null,
      email_api_key: config.email_api_key || null,
      email_sender: config.email_sender || null,
      enable_proxy: config.enable_proxy || false,
      proxy_provider: config.proxy_provider || null,
      proxy_api_key: config.proxy_api_key || null,
      proxy_country: config.proxy_country || null,
      database_type: config.database_type || "postgres",
      database_url: config.database_url || null,
      enable_web_scraping: config.enable_web_scraping || true,
      enable_captcha_solver: config.enable_captcha_solver || false,
      enable_discord_integration: config.enable_discord_integration || false,
      development_mode: config.development_mode || true,
      last_updated: new Date()
    };
  }
}

export const storage = new MemStorage();