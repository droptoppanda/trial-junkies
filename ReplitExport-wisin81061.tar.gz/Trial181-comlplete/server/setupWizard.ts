#!/usr/bin/env node
import inquirer from 'inquirer';
import chalk from 'chalk';
import figlet from 'figlet';
import { setupService } from './setupService';
import { z } from 'zod';
import { environmentSetupSchema } from '../shared/schema';

/**
 * CLI-based environment setup wizard
 * 
 * Helps users to configure the environment via command line interface
 */

type Config = z.infer<typeof environmentSetupSchema>;

// Display welcome message
console.log(
  chalk.cyan(
    figlet.textSync('TrialJunkies', { horizontalLayout: 'full' })
  )
);
console.log(chalk.green('Environment Setup Wizard\n'));

/**
 * Run setup wizard
 */
async function runWizard() {
  // Get current configuration
  let config = await setupService.getCurrentConfig();
  
  // Configure Solana
  await configureSolana(config);
  
  // Configure SMS verification
  await configureSmsVerification(config);
  
  // Configure email verification
  await configureEmailVerification(config);
  
  // Configure proxy
  await configureProxy(config);
  
  // Configure database
  await configureDatabase(config);
  
  // Configure features
  await configureFeatures(config);
  
  // Final confirmation
  const { confirm } = await inquirer.prompt({
    type: 'confirm',
    name: 'confirm',
    message: 'Save this configuration?',
    default: true
  });
  
  if (confirm) {
    const result = await setupService.saveEnvironmentConfig(config);
    if (result.success) {
      console.log(chalk.green('\n✓ Configuration saved successfully!'));
    } else {
      console.log(chalk.red(`\n✗ Error saving configuration: ${result.message}`));
    }
  } else {
    console.log(chalk.yellow('\nSetup cancelled. No changes were made.'));
  }
}

/**
 * Configure Solana settings
 * @param config Current configuration
 */
async function configureSolana(config: Config) {
  console.log(chalk.blue('\n--- Solana Configuration ---'));
  
  const solanaAnswers = await inquirer.prompt([
    {
      type: 'input',
      name: 'receiver_public_key',
      message: 'Solana receiver public key:',
      default: config.solana.receiver_public_key,
      validate: (input) => {
        if (!input && !config.solana.mock_verification) {
          return 'Public key is required when mock verification is disabled';
        }
        if (input && !/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(input)) {
          return 'Invalid Solana public key format';
        }
        return true;
      }
    },
    {
      type: 'list',
      name: 'network',
      message: 'Select Solana network:',
      choices: ['devnet', 'testnet', 'mainnet-beta'],
      default: config.solana.network
    },
    {
      type: 'confirm',
      name: 'mock_verification',
      message: 'Enable mock verification for testing?',
      default: config.solana.mock_verification
    }
  ]);
  
  config.solana = {
    ...config.solana,
    ...solanaAnswers
  };
}

/**
 * Configure SMS verification settings
 * @param config Current configuration
 */
async function configureSmsVerification(config: Config) {
  console.log(chalk.blue('\n--- SMS Verification Configuration ---'));
  
  const smsAnswers = await inquirer.prompt([
    {
      type: 'list',
      name: 'provider',
      message: 'Select SMS verification provider:',
      choices: ['mock', 'twilio', 'vonage'],
      default: config.sms_verification.provider
    },
    {
      type: 'confirm',
      name: 'mock_verification',
      message: 'Enable mock verification for testing?',
      default: config.sms_verification.mock_verification
    }
  ]);
  
  config.sms_verification.provider = smsAnswers.provider;
  config.sms_verification.mock_verification = smsAnswers.mock_verification;
  
  if (smsAnswers.provider !== 'mock' && !smsAnswers.mock_verification) {
    const { api_key } = await inquirer.prompt({
      type: 'input',
      name: 'api_key',
      message: `${smsAnswers.provider} API key:`,
      default: config.sms_verification.api_key || '',
      validate: (input) => input ? true : 'API key is required'
    });
    
    config.sms_verification.api_key = api_key;
  }
}

/**
 * Configure email verification settings
 * @param config Current configuration
 */
async function configureEmailVerification(config: Config) {
  console.log(chalk.blue('\n--- Email Verification Configuration ---'));
  
  const emailAnswers = await inquirer.prompt([
    {
      type: 'list',
      name: 'provider',
      message: 'Select email verification provider:',
      choices: ['mock', 'sendgrid', 'mailchimp'],
      default: config.email_verification.provider
    },
    {
      type: 'confirm',
      name: 'mock_verification',
      message: 'Enable mock verification for testing?',
      default: config.email_verification.mock_verification
    }
  ]);
  
  config.email_verification.provider = emailAnswers.provider;
  config.email_verification.mock_verification = emailAnswers.mock_verification;
  
  if (emailAnswers.provider !== 'mock' && !emailAnswers.mock_verification) {
    const { api_key } = await inquirer.prompt({
      type: 'input',
      name: 'api_key',
      message: `${emailAnswers.provider} API key:`,
      default: config.email_verification.api_key || '',
      validate: (input) => input ? true : 'API key is required'
    });
    
    config.email_verification.api_key = api_key;
  }
}

/**
 * Configure proxy settings
 * @param config Current configuration
 */
async function configureProxy(config: Config) {
  console.log(chalk.blue('\n--- Proxy Configuration ---'));
  
  const { enabled } = await inquirer.prompt({
    type: 'confirm',
    name: 'enabled',
    message: 'Enable proxy for web scraping?',
    default: config.proxy_configuration.enabled
  });
  
  config.proxy_configuration.enabled = enabled;
  
  if (enabled) {
    const proxyAnswers = await inquirer.prompt([
      {
        type: 'list',
        name: 'provider',
        message: 'Select proxy provider:',
        choices: ['mock', 'brightdata', 'oxylabs', 'smartproxy'],
        default: config.proxy_configuration.provider
      }
    ]);
    
    config.proxy_configuration.provider = proxyAnswers.provider;
    
    if (proxyAnswers.provider !== 'mock') {
      const { api_key } = await inquirer.prompt({
        type: 'input',
        name: 'api_key',
        message: `${proxyAnswers.provider} API key:`,
        default: config.proxy_configuration.api_key || '',
        validate: (input) => input ? true : 'API key is required'
      });
      
      config.proxy_configuration.api_key = api_key;
    }
  }
}

/**
 * Configure database settings
 * @param config Current configuration
 */
async function configureDatabase(config: Config) {
  console.log(chalk.blue('\n--- Database Configuration ---'));
  
  const { use_memory_storage } = await inquirer.prompt({
    type: 'confirm',
    name: 'use_memory_storage',
    message: 'Use in-memory storage? (Data will be lost on server restart)',
    default: config.database.use_memory_storage
  });
  
  config.database.use_memory_storage = use_memory_storage;
  
  if (!use_memory_storage) {
    console.log(chalk.yellow(
      'PostgreSQL database is configured with the DATABASE_URL environment variable.'
    ));
    // Check DATABASE_URL
    if (!process.env.DATABASE_URL) {
      console.log(chalk.red(
        'Warning: DATABASE_URL environment variable is not set.'
      ));
    } else {
      console.log(chalk.green('DATABASE_URL is configured correctly.'));
    }
  }
}

/**
 * Configure feature settings
 * @param config Current configuration
 */
async function configureFeatures(config: Config) {
  console.log(chalk.blue('\n--- Feature Configuration ---'));
  
  const featureAnswers = await inquirer.prompt([
    {
      type: 'confirm',
      name: 'solana_payments',
      message: 'Enable Solana payments?',
      default: config.features.solana_payments
    },
    {
      type: 'confirm',
      name: 'sms_verification',
      message: 'Enable SMS verification?',
      default: config.features.sms_verification
    },
    {
      type: 'confirm',
      name: 'virtual_cards',
      message: 'Enable virtual cards?',
      default: config.features.virtual_cards
    },
    {
      type: 'confirm',
      name: 'discord_integration',
      message: 'Enable Discord integration?',
      default: config.features.discord_integration
    }
  ]);
  
  config.features = {
    ...config.features,
    ...featureAnswers
  };
}

// ESM compatible check for direct execution
const isMainModule = import.meta.url.endsWith(process.argv[1]);

if (isMainModule) {
  runWizard()
    .catch(error => {
      console.error(chalk.red('Error running setup wizard:'), error);
      process.exit(1);
    });
}

export { runWizard };