/**
 * Enhanced Solana Payment Service
 * 
 * This service handles Solana blockchain payments, including:
 * - Creating payment requests
 * - Verifying transactions
 * - Managing wallet addresses
 * - Supporting mock mode for testing
 * - Comprehensive diagnostic reporting
 * 
 * Version: 2.0
 */

// Environment variables with fallbacks and validation
const MOCK_MODE = process.env.MOCK_SOLANA_VERIFICATION === 'true' || process.env.SOLANA_MOCK_MODE === 'true';
const SOLANA_RECEIVER_KEY = process.env.SOLANA_RECEIVER_PUBLIC_KEY || '';
const SOLANA_NETWORK = process.env.SOLANA_NETWORK || 'devnet';
const SOLANA_RPC_URL = process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com';

// Types
export interface PaymentRequest {
  paymentId: string;
  amount: number;
  receiverAddress: string;
  status: 'pending' | 'confirmed' | 'failed';
  createdAt: number;
  metadata?: Record<string, any>;
  network: string;
  mockMode: boolean;
  transactionId?: string;
  verifiedAt?: number;
  error?: string;
  attempts?: number;
}

export interface PaymentRequestInfo {
  paymentId: string;
  amount: number;
  receiverAddress: string;
  network: string;
  mockMode: boolean;
  instructions: string[];
  qrCodeData?: string;
}

export interface NetworkInfo {
  name: string;
  endpoint: string;
  mockMode: boolean;
  status: 'online' | 'offline' | 'unknown';
  lastChecked?: string;
}

export interface VerificationResult {
  success: boolean;
  verified?: boolean;
  amount?: number;
  receiverAddress?: string;
  transactionId?: string;
  timestamp?: string;
  mockMode?: boolean;
  error?: string;
  signatureInfo?: any;
  validations?: {
    addressMatch: boolean;
    amountMatch: boolean;
    confirmed: boolean;
  };
}

export interface PaymentStatus {
  success: boolean;
  paymentId?: string;
  status?: string;
  amount?: number;
  createdAt?: string;
  verifiedAt?: string | null;
  transactionId?: string | null;
  error?: string;
  attempts?: number;
  validations?: Record<string, boolean>;
}

export interface ConfigStatus {
  isConfigured: boolean;
  mockMode: boolean;
  network: string;
  receiverAddress?: string;
  receiverAddressValid: boolean;
  missingEnvVars: string[];
  validationErrors: string[];
  servicesAvailable: {
    rpc: boolean;
    verification: boolean;
    mock: boolean;
  };
}

/**
 * Enhanced Solana Payment Service class
 * Provides a comprehensive interface for handling Solana payments
 * with improved error reporting and diagnostics
 */
class SolanaPaymentService {
  private receiverAddress: string;
  private network: string;
  private rpcUrl: string;
  private transactions: Map<string, PaymentRequest>;
  private mockMode: boolean;
  private startupTime: number;
  private configErrors: string[] = [];
  private validationErrors: string[] = [];
  private networkStatus: 'online' | 'offline' | 'unknown' = 'unknown';
  private lastNetworkCheck: number = 0;
  private missingEnvVars: string[] = [];

  constructor() {
    this.startupTime = Date.now();
    this.receiverAddress = SOLANA_RECEIVER_KEY;
    this.network = SOLANA_NETWORK;
    this.rpcUrl = SOLANA_RPC_URL;
    this.transactions = new Map<string, PaymentRequest>();
    this.mockMode = MOCK_MODE;
    
    // Initialize and validate configuration
    this._initialize();
  }
  
  /**
   * Initialize the service and validate configuration
   * @private
   */
  private _initialize(): void {
    // Check for missing environment variables
    if (!process.env.SOLANA_RECEIVER_PUBLIC_KEY) {
      this.missingEnvVars.push('SOLANA_RECEIVER_PUBLIC_KEY');
    }
    
    if (!process.env.SOLANA_NETWORK) {
      this.missingEnvVars.push('SOLANA_NETWORK');
    }
    
    if (!process.env.SOLANA_RPC_URL) {
      this.missingEnvVars.push('SOLANA_RPC_URL');
    }
    
    // Validate receiver address if not in mock mode
    if (!this.mockMode && !this._validateSolanaAddress(this.receiverAddress)) {
      this.validationErrors.push(`Invalid Solana receiver address: "${this.receiverAddress}"`);
    }
    
    // Validate network value
    const validNetworks = ['mainnet-beta', 'mainnet', 'devnet', 'testnet'];
    if (!validNetworks.includes(this.network)) {
      this.validationErrors.push(`Invalid Solana network: "${this.network}". Valid options are: ${validNetworks.join(', ')}`);
    }
    
    // Log configuration 
    console.log(`[Solana Payment Service] Initialized at ${new Date(this.startupTime).toISOString()}`);
    console.log(`[Solana Payment Service] Network: ${this.network}`);
    console.log(`[Solana Payment Service] RPC URL: ${this.rpcUrl}`);
    console.log(`[Solana Payment Service] Mock mode: ${this.mockMode ? 'Enabled' : 'Disabled'}`);
    
    // Log status
    if (this.isConfigured()) {
      console.log(`[Solana Payment Service] Receiver address: ${this._maskAddress(this.receiverAddress)}`);
      console.log(`[Solana Payment Service] Status: Ready`);
    } else {
      console.warn('[Solana Payment Service] Status: Configuration incomplete');
      
      // Log configuration issues
      if (this.missingEnvVars.length > 0) {
        console.warn(`[Solana Payment Service] Missing environment variables: ${this.missingEnvVars.join(', ')}`);
      }
      
      if (this.validationErrors.length > 0) {
        console.warn(`[Solana Payment Service] Validation errors:\n- ${this.validationErrors.join('\n- ')}`);
      }
      
      // Provide helpful guidance
      if (!this.mockMode) {
        console.warn('[Solana Payment Service] Troubleshooting:');
        console.warn('1. Set SOLANA_RECEIVER_PUBLIC_KEY in your .env file to a valid Solana wallet address');
        console.warn('2. Ensure SOLANA_NETWORK is set to a valid network (mainnet-beta, devnet, testnet)');
        console.warn('3. Set SOLANA_RPC_URL to a valid Solana RPC endpoint');
        console.warn('4. Or enable mock mode by setting MOCK_SOLANA_VERIFICATION=true for testing');
      }
    }
  }
  
  /**
   * Get detailed configuration status with diagnostic information
   * @returns Configuration diagnostic status
   */
  public getConfigStatus(): ConfigStatus {
    return {
      isConfigured: this.isConfigured(),
      mockMode: this.mockMode,
      network: this.network,
      receiverAddress: this.mockMode ? this._maskAddress(this.receiverAddress) : this.receiverAddress,
      receiverAddressValid: this._validateSolanaAddress(this.receiverAddress),
      missingEnvVars: this.missingEnvVars,
      validationErrors: this.validationErrors,
      servicesAvailable: {
        rpc: this.networkStatus !== 'offline',
        verification: this.isConfigured(),
        mock: this.mockMode
      }
    };
  }
  
  /**
   * Get network endpoint and status based on selected network
   * @returns Network endpoint info
   */
  public getNetworkInfo(): NetworkInfo {
    const endpoints: Record<string, string> = {
      'mainnet-beta': 'https://api.mainnet-beta.solana.com',
      'mainnet': 'https://api.mainnet-beta.solana.com',
      'devnet': 'https://api.devnet.solana.com',
      'testnet': 'https://api.testnet.solana.com',
    };
    
    // Use custom RPC URL if provided, otherwise use default endpoints
    const endpoint = this.rpcUrl || endpoints[this.network] || endpoints.devnet;
    
    return {
      name: this.network,
      endpoint: endpoint,
      mockMode: this.mockMode,
      status: this.networkStatus,
      lastChecked: this.lastNetworkCheck ? new Date(this.lastNetworkCheck).toISOString() : undefined
    };
  }
  
  /**
   * Check if the service is properly configured
   * @returns Configuration status
   */
  public isConfigured(): boolean {
    // If in mock mode, we don't need a real receiver address
    if (this.mockMode) {
      return true;
    }
    
    return this._validateSolanaAddress(this.receiverAddress) && 
           this.validationErrors.length === 0;
  }
  
  /**
   * Create a payment request with enhanced metadata
   * @param amount - Amount in SOL
   * @param metadata - Payment metadata
   * @returns Payment request info
   */
  public createPaymentRequest(amount: number, metadata: Record<string, any> = {}): PaymentRequestInfo {
    // Validate amount
    if (!amount || typeof amount !== 'number' || amount <= 0) {
      throw new Error('Invalid payment amount. Must be a positive number.');
    }
    
    // Check configuration
    if (!this.isConfigured() && !this.mockMode) {
      throw new Error('Solana payment service is not properly configured. Check getConfigStatus() for details.');
    }
    
    // Generate a unique payment ID with prefix based on environment
    const prefix = this.mockMode ? 'mockpay_' : 'pay_';
    const paymentId = `${prefix}${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    
    // Store the payment request
    this.transactions.set(paymentId, {
      paymentId,
      amount,
      receiverAddress: this.receiverAddress,
      status: 'pending',
      createdAt: Date.now(),
      metadata: {
        ...metadata,
        network: this.network,
        timestamp: new Date().toISOString(),
        mockMode: this.mockMode
      },
      network: this.network,
      mockMode: this.mockMode,
      attempts: 0
    });
    
    // Build payment instructions
    const instructions = [
      `Send ${amount} SOL to ${this.receiverAddress}`,
      `Network: ${this.network}`,
      'Include the payment ID in the transaction memo',
      'Submit the transaction ID for verification'
    ];
    
    // In a real implementation, we would generate a QR code here
    // with the payment details for mobile wallet scanning
    const qrCodeData = this.mockMode ? 
      'mock:qrcode:data' : 
      `solana:${this.receiverAddress}?amount=${amount}&reference=${paymentId}&network=${this.network}`;
    
    return {
      paymentId,
      amount,
      receiverAddress: this.receiverAddress,
      network: this.network,
      mockMode: this.mockMode,
      instructions,
      qrCodeData
    };
  }
  
  /**
   * Verify a transaction with enhanced error reporting
   * @param transactionId - Solana transaction ID
   * @param expectedAmount - Expected amount in SOL
   * @param paymentId - Optional payment ID to verify
   * @returns Verification result
   */
  public async verifyTransaction(
    transactionId: string, 
    expectedAmount: number, 
    paymentId: string | null = null
  ): Promise<VerificationResult> {
    // Track verification attempt if we have a payment ID
    if (paymentId && this.transactions.has(paymentId)) {
      const payment = this.transactions.get(paymentId);
      if (payment) {
        payment.attempts = (payment.attempts || 0) + 1;
        this.transactions.set(paymentId, payment);
      }
    }
    
    // In mock mode, we simulate verification
    if (this.mockMode) {
      return this._mockVerifyTransaction(transactionId, expectedAmount, paymentId);
    }
    
    // Real verification would happen here using Solana web3.js
    // This would include:
    // 1. Fetching the transaction from the blockchain
    // 2. Validating the receiver address
    // 3. Confirming the amount
    // 4. Checking the transaction status
    
    try {
      // Here you would use @solana/web3.js to verify the transaction
      // For example:
      // const connection = new Connection(this.getNetworkInfo().endpoint);
      // const parsedTx = await connection.getParsedTransaction(transactionId, { commitment: 'confirmed' });
      
      // For now, we're not implementing real verification
      const errorMessage = 'Real transaction verification not implemented. Use mock mode for testing.';
      
      // Update payment status if we have a payment ID
      if (paymentId && this.transactions.has(paymentId)) {
        const payment = this.transactions.get(paymentId);
        if (payment) {
          payment.error = errorMessage;
          payment.status = 'failed';
          this.transactions.set(paymentId, payment);
        }
      }
      
      return {
        success: false,
        error: errorMessage,
        validations: {
          addressMatch: false,
          amountMatch: false,
          confirmed: false
        }
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error verifying transaction';
      console.error('[Solana Payment Service] Error verifying transaction:', errorMessage);
      
      // Update payment status if we have a payment ID
      if (paymentId && this.transactions.has(paymentId)) {
        const payment = this.transactions.get(paymentId);
        if (payment) {
          payment.error = errorMessage;
          this.transactions.set(paymentId, payment);
        }
      }
      
      return {
        success: false,
        error: errorMessage,
        validations: {
          addressMatch: false,
          amountMatch: false,
          confirmed: false
        }
      };
    }
  }
  
  /**
   * Enhanced mock transaction verification for testing with realistic behaviors
   * @param transactionId - Mock transaction ID
   * @param expectedAmount - Expected amount in SOL
   * @param paymentId - Optional payment ID to verify
   * @returns Mock verification result with detailed information
   * @private
   */
  private async _mockVerifyTransaction(
    transactionId: string, 
    expectedAmount: number, 
    paymentId: string | null = null
  ): Promise<VerificationResult> {
    console.log(`[Solana Payment Service] Processing mock verification for transaction: ${transactionId}`);
    
    // Simulate network delay (randomized to be realistic)
    const delay = 300 + Math.floor(Math.random() * 700); // 300-1000ms
    await new Promise(resolve => setTimeout(resolve, delay));
    
    // Check if the transaction ID looks valid
    if (!transactionId || typeof transactionId !== 'string' || transactionId.length < 10) {
      const errorMessage = 'Invalid transaction ID format';
      
      // Update payment status if we have a payment ID
      if (paymentId && this.transactions.has(paymentId)) {
        const payment = this.transactions.get(paymentId);
        if (payment) {
          payment.error = errorMessage;
          this.transactions.set(paymentId, payment);
        }
      }
      
      return {
        success: false,
        error: errorMessage,
        validations: {
          addressMatch: false,
          amountMatch: false,
          confirmed: false
        }
      };
    }
    
    // For mock verification, transaction IDs have special prefixes for testing different scenarios
    // - mock_valid_* : Successfully verified transactions
    // - mock_pending_* : Transactions still pending confirmation
    // - mock_invalid_* : Transactions that fail verification
    // - mock_error_* : Transactions that cause errors during verification
    
    let isValid = false;
    let isPending = false;
    let mockError = '';
    const validations = {
      addressMatch: false,
      amountMatch: false,
      confirmed: false
    };
    
    if (transactionId.startsWith('mock_valid')) {
      isValid = true;
      validations.addressMatch = true;
      validations.amountMatch = true;
      validations.confirmed = true;
    } else if (transactionId.startsWith('mock_pending')) {
      isPending = true;
      validations.addressMatch = true;
      validations.amountMatch = true;
    } else if (transactionId.startsWith('mock_invalid')) {
      // Invalid, but no error - just failed validation
      validations.addressMatch = Math.random() > 0.5; // Random validation failures
      validations.amountMatch = Math.random() > 0.5;
    } else if (transactionId.startsWith('mock_error')) {
      // Simulate specific errors for testing error handling
      mockError = 'Simulated blockchain error: Could not retrieve transaction data';
    } else {
      // Any other transaction ID is treated as not found
      mockError = 'Transaction not found on the blockchain';
    }
    
    // If we have a payment ID, update its status
    if (paymentId && this.transactions.has(paymentId)) {
      const payment = this.transactions.get(paymentId);
      if (payment) {
        payment.transactionId = transactionId;
        
        if (isValid) {
          payment.status = 'confirmed';
          payment.verifiedAt = Date.now();
        } else if (isPending) {
          payment.status = 'pending';
          payment.error = 'Transaction still pending confirmation';
        } else {
          payment.status = 'failed';
          payment.error = mockError || 'Transaction verification failed';
        }
        
        this.transactions.set(paymentId, payment);
      }
    }
    
    // Handle different scenarios based on transaction prefix
    if (isValid) {
      // Successfully verified transaction
      return {
        success: true,
        verified: true,
        amount: expectedAmount,
        receiverAddress: this.receiverAddress,
        transactionId,
        timestamp: new Date().toISOString(),
        mockMode: true,
        validations,
        signatureInfo: {
          confirmations: 32,
          slot: 12345678,
          blockTime: Math.floor(Date.now() / 1000) - 60, // 1 minute ago
        }
      };
    } else if (isPending) {
      // Pending transaction
      return {
        success: false,
        verified: false,
        error: 'Transaction is still pending confirmation',
        mockMode: true,
        validations,
        signatureInfo: {
          confirmations: 0,
          slot: 12345678,
          blockTime: Math.floor(Date.now() / 1000) - 10, // 10 seconds ago
        }
      };
    } else if (mockError) {
      // Error scenario
      return {
        success: false,
        error: mockError,
        mockMode: true,
        validations
      };
    } else {
      // Invalid transaction
      return {
        success: false,
        verified: false,
        error: 'Transaction verification failed',
        mockMode: true,
        validations,
        signatureInfo: {
          confirmations: 32,
          slot: 12345678,
          blockTime: Math.floor(Date.now() / 1000) - 120, // 2 minutes ago
        }
      };
    }
  }
  
  /**
   * Get enhanced payment status with validation details
   * @param paymentId - Payment ID to check
   * @returns Payment status with detailed information
   */
  public getPaymentStatus(paymentId: string): PaymentStatus {
    if (!this.transactions.has(paymentId)) {
      return {
        success: false,
        error: 'Payment not found'
      };
    }
    
    const payment = this.transactions.get(paymentId);
    if (!payment) {
      return {
        success: false,
        error: 'Payment data corrupted'
      };
    }
    
    return {
      success: true,
      paymentId,
      status: payment.status,
      amount: payment.amount,
      createdAt: new Date(payment.createdAt).toISOString(),
      verifiedAt: payment.verifiedAt ? new Date(payment.verifiedAt).toISOString() : null,
      transactionId: payment.transactionId || null,
      error: payment.error,
      attempts: payment.attempts || 0,
      validations: payment.status === 'confirmed' ? {
        addressMatch: true,
        amountMatch: true,
        confirmed: true
      } : undefined
    };
  }
  
  /**
   * Get all transactions (admin use only)
   * @returns All transactions in the system
   */
  public getAllTransactions(): PaymentRequest[] {
    return Array.from(this.transactions.values());
  }
  
  /**
   * Get enhanced receiver wallet information
   * @returns Detailed receiver wallet information
   */
  public getReceiverWallet() {
    const isValid = this._validateSolanaAddress(this.receiverAddress);
    
    return {
      address: this.receiverAddress,
      maskedAddress: this._maskAddress(this.receiverAddress),
      network: this.network,
      isValid,
      mockMode: this.mockMode,
      validationErrors: isValid ? [] : ['Invalid Solana address format']
    };
  }
  
  /**
   * Validate a Solana address format
   * @param address - Address to validate
   * @returns Is valid
   * @private
   */
  private _validateSolanaAddress(address: string): boolean {
    if (!address || typeof address !== 'string') {
      return false;
    }
    
    // Basic format check: 32-44 characters, alphanumeric
    // Real validation would use PublicKey from @solana/web3.js
    return /^[a-zA-Z0-9]{32,44}$/.test(address);
  }
  
  /**
   * Mask an address for display (privacy)
   * @param address - Address to mask
   * @returns Masked address
   * @private
   */
  private _maskAddress(address: string): string {
    if (!address || typeof address !== 'string') {
      return '';
    }
    
    if (address.length <= 8) {
      return address;
    }
    
    return `${address.substring(0, 4)}...${address.substring(address.length - 4)}`;
  }
  
  /**
   * Check network status (could actually ping the RPC endpoint)
   * @returns Whether the network is online
   */
  public async checkNetworkStatus(): Promise<boolean> {
    // In a real implementation, we would ping the RPC endpoint
    // For now, we just simulate a successful check in mock mode
    this.lastNetworkCheck = Date.now();
    
    if (this.mockMode) {
      this.networkStatus = 'online';
      return true;
    }
    
    // We would check the real network here
    // For example:
    // try {
    //   const connection = new Connection(this.getNetworkInfo().endpoint);
    //   await connection.getVersion();
    //   this.networkStatus = 'online';
    //   return true;
    // } catch (error) {
    //   this.networkStatus = 'offline';
    //   return false;
    // }
    
    // For now, assume network is online
    this.networkStatus = 'online';
    return true;
  }
  
  /**
   * Diagnostic method to check the full service health
   * @returns Diagnostic information about the service health
   */
  public async checkHealth(): Promise<Record<string, any>> {
    const networkStatus = await this.checkNetworkStatus();
    
    return {
      service: 'Solana Payment Service',
      version: '2.0',
      timestamp: new Date().toISOString(),
      uptime: Date.now() - this.startupTime,
      status: this.isConfigured() ? 'ready' : 'not_configured',
      config: this.getConfigStatus(),
      network: {
        name: this.network,
        status: this.networkStatus,
        lastChecked: new Date(this.lastNetworkCheck).toISOString(),
        online: networkStatus
      },
      storage: {
        transactions: this.transactions.size,
        pending: Array.from(this.transactions.values()).filter(tx => tx.status === 'pending').length,
        confirmed: Array.from(this.transactions.values()).filter(tx => tx.status === 'confirmed').length,
        failed: Array.from(this.transactions.values()).filter(tx => tx.status === 'failed').length
      }
    };
  }
}

// Create a singleton instance
const solanaPaymentService = new SolanaPaymentService();

// Export the service
export default solanaPaymentService;