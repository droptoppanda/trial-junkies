/**
 * Test file for service examples API
 */

import { serviceExamples, getServicesByCategory, getPopularServices, searchServices } from "../shared/serviceExamples";

/**
 * Run tests for service examples functionality
 */
export async function testServiceExamples() {
  console.log("=============================================");
  console.log("Testing Services Examples");
  console.log("=============================================\n");

  // Test 1: Check if serviceExamples array exists and has items
  console.log("Test 1: Checking service examples data");
  const servicesCount = serviceExamples.length;
  if (servicesCount > 0) {
    console.log(`✅ Service examples loaded: ${servicesCount} services found`);
    // List first 3 services
    console.log("Sample services:");
    for (let i = 0; i < Math.min(3, servicesCount); i++) {
      const service = serviceExamples[i];
      console.log(`  - ${service.name} (${service.category}): ${service.trialLength} trial`);
    }
  } else {
    console.log("❌ No service examples found");
  }
  console.log();

  // Test 2: Check getServicesByCategory function
  console.log("Test 2: Testing category filtering");
  const streamingServices = getServicesByCategory("streaming");
  if (streamingServices.length > 0) {
    console.log(`✅ Found ${streamingServices.length} streaming services`);
    // List streaming services
    console.log("Streaming services:");
    streamingServices.forEach(service => {
      console.log(`  - ${service.name}: ${service.trialLength} trial`);
    });
  } else {
    console.log("❌ No streaming services found");
  }
  console.log();

  // Test 3: Check getPopularServices function
  console.log("Test 3: Testing popular services");
  const popularServices = getPopularServices(3);
  if (popularServices.length > 0) {
    console.log(`✅ Found ${popularServices.length} popular services`);
    // List popular services
    console.log("Popular services:");
    popularServices.forEach(service => {
      console.log(`  - ${service.name} (popularity: ${service.popularity}): ${service.trialLength} trial`);
    });
  } else {
    console.log("❌ No popular services found");
  }
  console.log();

  // Test 4: Check searchServices function
  console.log("Test 4: Testing search functionality");
  const searchTerm = "netflix";
  const searchResults = searchServices(searchTerm);
  if (searchResults.length > 0) {
    console.log(`✅ Search for "${searchTerm}" returned ${searchResults.length} results`);
    // List search results
    console.log("Search results:");
    searchResults.forEach(service => {
      console.log(`  - ${service.name}: ${service.trialLength} trial`);
    });
  } else {
    console.log(`❌ No services found for search term "${searchTerm}"`);
  }
  console.log();

  console.log("All tests completed.");
  console.log("=============================================");
  
  return true;
}

// For direct execution
if (import.meta.url === import.meta.resolve('./testServices.ts')) {
  testServiceExamples().catch(err => {
    console.error('Service examples tests failed:', err);
    process.exit(1);
  });
}

export default testServiceExamples;