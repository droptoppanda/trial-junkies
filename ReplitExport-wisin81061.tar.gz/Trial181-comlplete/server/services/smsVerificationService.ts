import axios from 'axios';

/**
 * Enhanced SMS Verification Service
 * 
 * This service provides multi-provider support for SMS verification,
 * with automatic fallback between providers and improved error handling.
 */

// Types for provider responses
interface SmsActivateResponse {
  status: string;
  access_number?: string;
  activation_id?: string;
  error?: string;
}

interface SmspvaResponse {
  status: number;
  id?: string;
  number?: string;
  sms?: string;
  error?: string;
}

interface FiveSimResponse {
  id?: string;
  phone?: string;
  status?: string;
  sms?: Array<{ code: string }>;
  error?: string;
}

// Generic response interface for all operations
export interface SmsVerificationResponse {
  success: boolean;
  phoneNumber?: string;
  verificationId?: string;
  provider?: string;
  code?: string;
  error?: string;
}

// List of supported providers
export type SmsProvider = 'sms-activate' | 'smspva' | '5sim' | 'mock';

// Mapping of service names to provider-specific service codes
const serviceMapping: { [provider: string]: { [service: string]: string } } = {
  'sms-activate': {
    'discord': 'ds',
    'telegram': 'tg',
    'whatsapp': 'wa',
    'facebook': 'fb',
    'instagram': 'ig',
    'google': 'go',
    'twitter': 'tw',
    'microsoft': 'mm',
    'netflix': 'nf',
    'tiktok': 'tk',
    'uber': 'ub'
  },
  'smspva': {
    'discord': 'discord',
    'telegram': 'telegram',
    'whatsapp': 'whatsapp',
    'facebook': 'facebook',
    'instagram': 'instagram',
    'google': 'google',
    'twitter': 'twitter',
    'microsoft': 'microsoft',
    'netflix': 'netflix',
    'tiktok': 'tiktok',
    'uber': 'uber'
  },
  '5sim': {
    'discord': 'discord',
    'telegram': 'telegram',
    'whatsapp': 'whatsapp',
    'facebook': 'facebook',
    'instagram': 'instagram',
    'google': 'google',
    'twitter': 'twitter',
    'microsoft': 'microsoft',
    'netflix': 'netflix',
    'tiktok': 'tiktok',
    'uber': 'uber'
  }
};

// Enhanced SMS Verification class
export class EnhancedSmsVerification {
  private smsActivateKey: string;
  private smspvaKey: string;
  private fiveSimKey: string;
  private activeProviders: SmsProvider[] = [];
  
  constructor() {
    // Initialize API keys from environment variables
    this.smsActivateKey = process.env.SMS_ACTIVATE_API_KEY || '';
    this.smspvaKey = process.env.SMSPVA_API_KEY || '';
    this.fiveSimKey = process.env.FIVESIM_API_KEY || '';
    
    // Determine active providers based on available API keys
    if (this.smsActivateKey) this.activeProviders.push('sms-activate');
    if (this.smspvaKey) this.activeProviders.push('smspva');
    if (this.fiveSimKey) this.activeProviders.push('5sim');
    
    // Always add mock as a fallback
    this.activeProviders.push('mock');
  }
  
  /**
   * Get a phone number for verification using the optimal provider
   * @param service Service name to get a phone number for
   * @param country Country code (0 for any)
   */
  async getPhoneNumber(service: string, country: string = '0'): Promise<SmsVerificationResponse> {
    // Normalize service name to lowercase
    const normalizedService = service.toLowerCase();
    
    // Iterate through all active providers until successful
    for (const provider of this.activeProviders) {
      try {
        console.log(`Trying to get phone number with provider: ${provider}`);
        
        let result: SmsVerificationResponse;
        
        switch (provider) {
          case 'sms-activate':
            result = await this.getSmsActivateNumber(normalizedService, country);
            break;
          case 'smspva':
            result = await this.getSmspvaNumber(normalizedService, country);
            break;
          case '5sim':
            result = await this.getFiveSimNumber(normalizedService, country);
            break;
          case 'mock':
            result = await this.getMockNumber(normalizedService, country);
            break;
          default:
            continue;
        }
        
        if (result.success) {
          result.provider = provider;
          return result;
        }
        
        console.log(`Provider ${provider} failed: ${result.error}`);
      } catch (error: any) {
        console.error(`Error with provider ${provider}:`, error.message);
      }
    }
    
    return {
      success: false,
      error: 'All SMS providers failed to get a phone number'
    };
  }
  
  /**
   * Get verification code sent to the phone number
   * @param verificationId Verification ID from getPhoneNumber
   * @param service Service name
   * @param provider The provider that was used to get the phone number
   */
  async getVerificationCode(
    verificationId: string,
    service: string,
    provider?: string
  ): Promise<SmsVerificationResponse> {
    // Use the specified provider if available, otherwise try all providers
    const providersToTry = provider ? [provider as SmsProvider] : this.activeProviders;
    
    for (const currentProvider of providersToTry) {
      try {
        console.log(`Trying to get verification code with provider: ${currentProvider}`);
        
        let result: SmsVerificationResponse;
        
        switch (currentProvider) {
          case 'sms-activate':
            result = await this.getSmsActivateCode(verificationId);
            break;
          case 'smspva':
            result = await this.getSmspvaCode(verificationId, service);
            break;
          case '5sim':
            result = await this.getFiveSimCode(verificationId);
            break;
          case 'mock':
            result = await this.getMockCode(verificationId, service);
            break;
          default:
            continue;
        }
        
        if (result.success) {
          result.provider = currentProvider;
          return result;
        }
        
        console.log(`Provider ${currentProvider} failed: ${result.error}`);
      } catch (error: any) {
        console.error(`Error with provider ${currentProvider}:`, error.message);
      }
    }
    
    return {
      success: false,
      error: 'Failed to get verification code from any provider'
    };
  }
  
  /**
   * Get service code for the specified provider
   * @param provider SMS provider name
   * @param service Service name (e.g., 'discord', 'telegram')
   */
  private getServiceCode(provider: SmsProvider, service: string): string {
    const lowerService = service.toLowerCase();
    
    // Check if the service is supported by the provider
    if (serviceMapping[provider] && serviceMapping[provider][lowerService]) {
      return serviceMapping[provider][lowerService];
    }
    
    // If not found in mapping, just use the service name itself
    return lowerService;
  }
  
  /**
   * Get phone number from SMS-Activate
   */
  private async getSmsActivateNumber(service: string, country: string): Promise<SmsVerificationResponse> {
    if (!this.smsActivateKey) {
      return {
        success: false,
        error: 'SMS-Activate API key not configured'
      };
    }
    
    try {
      const serviceCode = this.getServiceCode('sms-activate', service);
      const url = `https://api.sms-activate.org/stubs/handler_api.php?api_key=${this.smsActivateKey}&action=getNumber&service=${serviceCode}&country=${country}`;
      
      const response = await axios.get(url);
      const data = response.data as string;
      
      // Parse the SMS-Activate response
      if (data.startsWith('ACCESS_NUMBER')) {
        // Format: ACCESS_NUMBER:12345:+1234567890
        const parts = data.split(':');
        if (parts.length >= 3) {
          const activationId = parts[1];
          const phoneNumber = parts[2];
          
          return {
            success: true,
            phoneNumber,
            verificationId: activationId
          };
        }
      }
      
      return {
        success: false,
        error: `SMS-Activate error: ${data}`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `SMS-Activate API error: ${error.message}`
      };
    }
  }
  
  /**
   * Get verification code from SMS-Activate
   */
  private async getSmsActivateCode(activationId: string): Promise<SmsVerificationResponse> {
    if (!this.smsActivateKey) {
      return {
        success: false,
        error: 'SMS-Activate API key not configured'
      };
    }
    
    try {
      // First, check the status
      const statusUrl = `https://api.sms-activate.org/stubs/handler_api.php?api_key=${this.smsActivateKey}&action=getStatus&id=${activationId}`;
      
      let maxAttempts = 10;
      while (maxAttempts > 0) {
        const response = await axios.get(statusUrl);
        const data = response.data as string;
        
        if (data.startsWith('STATUS_OK')) {
          // Format: STATUS_OK:123456
          const code = data.split(':')[1];
          
          return {
            success: true,
            code
          };
        }
        
        if (data === 'STATUS_WAIT_CODE') {
          // Wait and try again
          await new Promise(resolve => setTimeout(resolve, 5000));
          maxAttempts--;
          continue;
        }
        
        return {
          success: false,
          error: `SMS-Activate error: ${data}`
        };
      }
      
      return {
        success: false,
        error: 'SMS-Activate timeout waiting for verification code'
      };
    } catch (error: any) {
      return {
        success: false,
        error: `SMS-Activate API error: ${error.message}`
      };
    }
  }
  
  /**
   * Get phone number from SMSPVA
   */
  private async getSmspvaNumber(service: string, country: string): Promise<SmsVerificationResponse> {
    if (!this.smspvaKey) {
      return {
        success: false,
        error: 'SMSPVA API key not configured'
      };
    }
    
    try {
      const serviceCode = this.getServiceCode('smspva', service);
      const url = `https://smspva.com/priemnik.php?metod=get_number&country=${country}&service=${serviceCode}&apikey=${this.smspvaKey}`;
      
      const response = await axios.get(url);
      const data = response.data as SmspvaResponse;
      
      if (data.status === 1 && data.number && data.id) {
        return {
          success: true,
          phoneNumber: data.number,
          verificationId: data.id
        };
      }
      
      return {
        success: false,
        error: `SMSPVA error: ${data.error || 'Unknown error'}`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `SMSPVA API error: ${error.message}`
      };
    }
  }
  
  /**
   * Get verification code from SMSPVA
   */
  private async getSmspvaCode(id: string, service: string): Promise<SmsVerificationResponse> {
    if (!this.smspvaKey) {
      return {
        success: false,
        error: 'SMSPVA API key not configured'
      };
    }
    
    try {
      const serviceCode = this.getServiceCode('smspva', service);
      
      let maxAttempts = 10;
      while (maxAttempts > 0) {
        const url = `https://smspva.com/priemnik.php?metod=get_sms&country=ru&service=${serviceCode}&id=${id}&apikey=${this.smspvaKey}`;
        
        const response = await axios.get(url);
        const data = response.data as SmspvaResponse;
        
        if (data.status === 1 && data.sms) {
          // Extract the code from the SMS message
          // This is a simple extraction and may need to be adapted
          // based on the specific format of codes from different services
          const codeMatch = data.sms.match(/\d+/);
          if (codeMatch) {
            return {
              success: true,
              code: codeMatch[0]
            };
          }
        }
        
        if (data.status === 2) {
          // Status 2 means "waiting for SMS"
          await new Promise(resolve => setTimeout(resolve, 5000));
          maxAttempts--;
          continue;
        }
        
        return {
          success: false,
          error: `SMSPVA error: ${data.error || 'Unknown error'}`
        };
      }
      
      return {
        success: false,
        error: 'SMSPVA timeout waiting for verification code'
      };
    } catch (error: any) {
      return {
        success: false,
        error: `SMSPVA API error: ${error.message}`
      };
    }
  }
  
  /**
   * Get phone number from 5sim
   */
  private async getFiveSimNumber(service: string, country: string): Promise<SmsVerificationResponse> {
    if (!this.fiveSimKey) {
      return {
        success: false,
        error: '5sim API key not configured'
      };
    }
    
    try {
      const serviceCode = this.getServiceCode('5sim', service);
      const countryCode = country === '0' ? 'any' : country;
      
      const url = `https://5sim.net/v1/user/buy/activation/${countryCode}/any/${serviceCode}`;
      
      const response = await axios.get(url, {
        headers: {
          'Authorization': `Bearer ${this.fiveSimKey}`,
          'Accept': 'application/json'
        }
      });
      
      const data = response.data as FiveSimResponse;
      
      if (data.id && data.phone) {
        return {
          success: true,
          phoneNumber: data.phone,
          verificationId: data.id.toString()
        };
      }
      
      return {
        success: false,
        error: `5sim error: ${data.error || 'Unknown error'}`
      };
    } catch (error: any) {
      return {
        success: false,
        error: `5sim API error: ${error.message}`
      };
    }
  }
  
  /**
   * Get verification code from 5sim
   */
  private async getFiveSimCode(id: string): Promise<SmsVerificationResponse> {
    if (!this.fiveSimKey) {
      return {
        success: false,
        error: '5sim API key not configured'
      };
    }
    
    try {
      let maxAttempts = 10;
      while (maxAttempts > 0) {
        const url = `https://5sim.net/v1/user/check/${id}`;
        
        const response = await axios.get(url, {
          headers: {
            'Authorization': `Bearer ${this.fiveSimKey}`,
            'Accept': 'application/json'
          }
        });
        
        const data = response.data as FiveSimResponse;
        
        if (data.sms && data.sms.length > 0 && data.sms[0].code) {
          return {
            success: true,
            code: data.sms[0].code
          };
        }
        
        if (data.status === 'PENDING') {
          // Still waiting for the SMS
          await new Promise(resolve => setTimeout(resolve, 5000));
          maxAttempts--;
          continue;
        }
        
        return {
          success: false,
          error: `5sim error: ${data.error || 'Unknown error'}`
        };
      }
      
      return {
        success: false,
        error: '5sim timeout waiting for verification code'
      };
    } catch (error: any) {
      return {
        success: false,
        error: `5sim API error: ${error.message}`
      };
    }
  }
  
  /**
   * Get a mock phone number for testing
   */
  private async getMockNumber(service: string, country: string): Promise<SmsVerificationResponse> {
    // Generate a random phone number for testing
    const countryCode = country === '0' ? '+1' : `+${country}`;
    const randomNumber = Math.floor(10000000000 + Math.random() * 9000000000).toString();
    const phoneNumber = `${countryCode}${randomNumber.substring(1)}`;
    
    // Generate a random verification ID
    const verificationId = `mock_${service}_${Date.now()}`;
    
    return {
      success: true,
      phoneNumber,
      verificationId,
      provider: 'mock'
    };
  }
  
  /**
   * Get a mock verification code for testing
   */
  private async getMockCode(verificationId: string, service: string): Promise<SmsVerificationResponse> {
    // Generate a random verification code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Mock some delay to simulate waiting for SMS
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    return {
      success: true,
      code,
      provider: 'mock'
    };
  }
}

// Export an instance of the enhanced SMS verification service
export const enhancedSmsVerification = new EnhancedSmsVerification();