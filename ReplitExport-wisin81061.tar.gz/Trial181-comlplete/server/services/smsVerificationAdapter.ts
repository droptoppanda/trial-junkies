import { enhancedSmsVerification } from './smsVerificationService';

/**
 * SMS verification adapter for backward compatibility with the original API
 */
export const smsVerificationAdapter = {
  /**
   * Get a phone number for verification
   * @param service Service name to get a phone number for
   * @param country Country code (0 for any)
   */
  async getPhoneNumber(service: string, country: string): Promise<{
    success: boolean;
    phoneNumber?: string;
    verificationId?: string;
    error?: string;
  }> {
    const result = await enhancedSmsVerification.getPhoneNumber(service, country);
    
    // Map the result to match the original API response format
    if (result.success) {
      return {
        success: true,
        phoneNumber: result.phoneNumber,
        verificationId: result.verificationId
      };
    } else {
      return {
        success: false,
        error: result.error
      };
    }
  },

  /**
   * Get verification code sent to the phone number
   * @param verificationId Verification ID from getPhoneNumber
   * @param service Service name
   */
  async getVerificationCode(verificationId: string, service: string): Promise<{
    success: boolean;
    code?: string;
    error?: string;
  }> {
    // Extract provider from verification ID if it has the format "provider:id"
    let provider: string | undefined;
    if (verificationId.includes(':')) {
      const parts = verificationId.split(':');
      provider = parts[0];
      verificationId = parts[1];
    }
    
    const result = await enhancedSmsVerification.getVerificationCode(
      verificationId,
      service,
      provider
    );
    
    return result;
  },

  /**
   * Enhanced method: Get a phone number with provider information
   * This extends the original API with provider-specific information
   */
  async getPhoneNumberWithProvider(service: string, country: string): Promise<{
    success: boolean;
    phoneNumber?: string;
    verificationId?: string;
    provider?: string;
    error?: string;
  }> {
    return await enhancedSmsVerification.getPhoneNumber(service, country);
  }
};