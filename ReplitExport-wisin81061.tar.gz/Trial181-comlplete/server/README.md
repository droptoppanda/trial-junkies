# Trial Junkies Backend

This directory contains the backend code for the Trial Junkies application, built with Express and Node.js.

## Key Services

### SMS Verification Service
- Multi-provider support with automatic fallback
- Provider-agnostic API with adapter pattern
- Mock data support for development and testing

### CAPTCHA Solving Service
- Capsolver integration as primary solution
- Local OCR fallback using Tesseract.js
- Support for image-based and reCAPTCHA challenges

### Solana Payment Service
- Secure wallet generation and management
- Transaction processing and verification
- Mock mode for testing without real blockchain interactions

### Email Verification Service
- Disposable email generation
- Verification link extraction
- Support for custom domains with DKIM, SPF, and DMARC

### Proxy Management Service
- Intelligent proxy rotation
- Performance tracking and auto-banning of poor performers
- Support for residential and datacenter proxies

### Cloud LLM Service
- AI-powered workflow automation
- Integration with CrewAI/AutoGPT
- Text generation and search capabilities

## API Endpoints

### Authentication
- `/api/auth/register`: User registration
- `/api/auth/login`: User login
- `/api/auth/status`: Check authentication status

### Subscriptions
- `/api/subscriptions/active`: Get user's active subscription
- `/api/subscriptions/plans`: Get available subscription plans
- `/api/subscriptions/create`: Create a new subscription

### Trials
- `/api/trials`: Get all user's trials
- `/api/trials/create`: Create a new automated trial
- `/api/trials/:id`: Get details for a specific trial

### Crypto Payments
- `/api/crypto/payment`: Process a cryptocurrency payment
- `/api/crypto/status/:id`: Check payment status

### SMS Verification
- `/api/sms/number`: Get a phone number for verification
- `/api/sms/code`: Get verification code sent to a number

### CAPTCHA Solving
- `/api/captcha/solve`: Solve an image CAPTCHA
- `/api/captcha/recaptcha`: Solve a reCAPTCHA challenge

## System Architecture
The backend follows a modular architecture with service-specific adapters, enabling easy extension and third-party integrations. Error handling and logging are implemented throughout for improved reliability.