/**
 * Test script for Solana payment functionality
 * 
 * This script tests the Solana payment system by:
 * 1. Creating a payment request
 * 2. Generating a test wallet
 * 3. Processing a payment using message signature
 * 4. Verifying the payment status
 */

import { solanaPaymentService, SolanaPaymentService } from './solanaPaymentService';

async function runSolanaPaymentTests() {
  console.log('=== Starting Solana Payment Tests ===');
  
  // Enable mock mode for testing
  solanaPaymentService.enableMockMode();
  
  // Step 1: Create a payment request
  console.log('\n1. Creating payment request...');
  const amount = 1.5; // 1.5 SOL
  const createResponse = await solanaPaymentService.createPaymentRequest(amount);
  
  if (!createResponse.success) {
    console.error('Failed to create payment request:', createResponse.error);
    return;
  }
  
  console.log('Payment request created successfully:');
  console.log(createResponse.paymentRequest);
  
  // Step 2: Generate test wallet
  console.log('\n2. Generating test wallet...');
  const testWallet = SolanaPaymentService.generateWallet();
  console.log('Test wallet generated:');
  console.log('Public Key:', testWallet.publicKey);
  console.log('Secret Key:', testWallet.secretKey?.substring(0, 10) + '...');
  
  // Step 3: Get wallet balance
  console.log('\n3. Checking wallet balance...');
  const walletBalance = await solanaPaymentService.getWalletBalance(testWallet.publicKey);
  console.log(`Wallet balance: ${walletBalance} SOL`);
  
  // Step 4: Process payment with message signature
  console.log('\n4. Processing payment with message signature...');
  const paymentRequestId = createResponse.paymentRequest.id;
  const messageToSign = `Payment authorization for ${amount} SOL. Request ID: ${paymentRequestId}`;
  const mockSignature = 'mock_signature_' + Date.now();
  
  const processResponse = await solanaPaymentService.processPaymentWithSignature(
    paymentRequestId,
    testWallet.publicKey,
    mockSignature,
    messageToSign
  );
  
  if (!processResponse.success) {
    console.error('Failed to process payment:', processResponse.error);
    return;
  }
  
  console.log('Payment processed successfully:');
  console.log(processResponse.paymentRequest);
  console.log('Transaction signature:', processResponse.transactionSignature);
  
  // Step 5: Verify payment status
  console.log('\n5. Verifying payment status...');
  const txSignature = processResponse.transactionSignature!;
  const isConfirmed = await solanaPaymentService.checkTransactionStatus(txSignature);
  
  console.log(`Transaction status: ${isConfirmed ? 'Confirmed' : 'Pending'}`);
  
  // Step 6: Get all payment requests
  console.log('\n6. Getting all payment requests...');
  const allPayments = solanaPaymentService.getAllPaymentRequests();
  console.log(`Found ${allPayments.length} payment requests:`);
  allPayments.forEach((payment, index) => {
    console.log(`Payment ${index + 1}:`);
    console.log(`  ID: ${payment.id}`);
    console.log(`  Amount: ${payment.amount} SOL`);
    console.log(`  Status: ${payment.status}`);
    console.log(`  Transaction: ${payment.transactionSignature || 'N/A'}`);
  });
  
  console.log('\n=== Solana Payment Tests Completed Successfully ===');
}

// Run the tests
runSolanaPaymentTests().catch(error => {
  console.error('Error running Solana payment tests:', error);
});