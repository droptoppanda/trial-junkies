
import { smsVerificationAdapter } from './services/smsVerificationAdapter';

// Legacy configuration variables preserved for backward compatibility
const SMS_API_KEY = process.env.SMS_API_KEY || '';
const SMS_API_URL = process.env.SMS_API_URL || '';
const MOCK_SMS_API_URL = 'https://api.sms-verification-service.com';

/**
 * SMS verification service functions
 * This implementation now uses the enhanced SMS verification service
 * through the adapter pattern for backward compatibility
 */
export const smsVerification = {
  /**
   * Get a phone number for verification
   * @param service Service name to get a phone number for
   * @param country Country code (0 for any)
   */
  async getPhoneNumber(service: string, country: string): Promise<{
    success: boolean;
    phoneNumber?: string;
    verificationId?: string;
    error?: string;
  }> {
    console.log(`Getting phone number for service: ${service}, country: ${country}`);
    return await smsVerificationAdapter.getPhoneNumber(service, country);
  },

  /**
   * Get mock phone number for verification
   * fallback implementation if no API configured
   */
  async getMockPhoneNumber(service: string, country: string) {
    // This is kept for backward compatibility but no longer used directly
    return {
      success: true,
      phoneNumber: '+1234567890',
      verificationId: `verify_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`
    };
  },

  /**
   * Get verification code sent to the phone number
   * @param verificationId Verification ID from getPhoneNumber
   * @param service Service name
   */
  async getVerificationCode(verificationId: string, service: string): Promise<{
    success: boolean;
    code?: string;
    error?: string;
  }> {
    console.log(`Getting verification code for ID: ${verificationId}, service: ${service}`);
    return await smsVerificationAdapter.getVerificationCode(verificationId, service);
  },

  /**
   * Get mock verification code for phone number
   * fallback implementation if no API configured
   */
  async getMockVerificationCode(verificationId: string, service: string) {
    // This is kept for backward compatibility but no longer used directly
    return {
      success: true,
      code: Math.floor(100000 + Math.random() * 900000).toString()
    };
  },

  /**
   * Get a phone number with provider information
   * This is a new method that extends the original API
   */
  async getPhoneNumberWithProvider(service: string, country: string): Promise<{
    success: boolean;
    phoneNumber?: string;
    verificationId?: string;
    provider?: string;
    error?: string;
  }> {
    return await smsVerificationAdapter.getPhoneNumberWithProvider(service, country);
  }
};
