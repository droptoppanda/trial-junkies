import express from "express";

const app = express();
app.use(express.json());

app.get('/', (req, res) => {
  res.json({ message: 'Debug server is running!' });
});

// Add our subscription tiers endpoint to verify the changes
app.get("/api/subscriptions/tiers", (req, res) => {
  res.json({
    basic: {
      name: "Casual User",
      price: "0.1",
      features: [
        "Discord Basic Role",
        "Access to basic features",
        "Community support"
      ],
      notIncluded: [
        "Premium content access",
        "Private channels"
      ]
    },
    pro: {
      name: "Junkie Mode",
      price: "0.5",
      features: [
        "Discord Pro Role",
        "All Basic features",
        "Priority support",
        "Premium content access"
      ],
      notIncluded: [
        "Private 1:1 sessions"
      ],
      popular: true
    },
    enterprise: {
      name: "Overdose Plan",
      price: "2.0",
      features: [
        "Discord Enterprise Role",
        "All Pro features",
        "24/7 dedicated support",
        "All premium content",
        "Private 1:1 sessions"
      ],
      notIncluded: []
    }
  });
});

const port = 5000;
app.listen(port, '0.0.0.0', () => {
  console.log(`Debug server running on port ${port}`);
});