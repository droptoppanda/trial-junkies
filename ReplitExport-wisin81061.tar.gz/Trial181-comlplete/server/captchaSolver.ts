
import axios from "axios";
import { createWorker, createScheduler } from "tesseract.js";
import puppeteer from "puppeteer-extra";
import StealthPlugin from "puppeteer-extra-plugin-stealth";
import * as fs from "node:fs/promises";
import path from "path";

// Add stealth plugin to puppeteer for anti-detection
puppeteer.use(StealthPlugin());

// Interface for CAPTCHA solver response
export interface CaptchaSolverResponse {
  success: boolean;
  solution?: string;
  error?: string;
}

/**
 * CaptchaSolver class for handling multiple captcha types
 * Supports multiple providers with fallback and enhanced mock implementation
 */
export class CaptchaSolver {
  private twoCapKey: string = "";
  private antiCaptchaKey: string = "";
  private captchaAiKey: string = "";
  private capsolverKey: string = "";
  private useMock: boolean = false;
  private activeProviders: string[] = [];
  
  constructor(twoCapKey = "", antiCaptchaKey = "", captchaAiKey = "", capsolverKey = "") {
    this.twoCapKey = twoCapKey || process.env.TWOCAPTCHA_API_KEY || "";
    this.antiCaptchaKey = antiCaptchaKey || process.env.ANTICAPTCHA_API_KEY || "";
    this.captchaAiKey = captchaAiKey || process.env.CAPTCHAAI_API_KEY || "";
    this.capsolverKey = capsolverKey || process.env.CAPSOLVER_API_KEY || "";
    
    // Determine active providers
    if (this.twoCapKey) this.activeProviders.push("2captcha");
    if (this.antiCaptchaKey) this.activeProviders.push("anticaptcha");
    if (this.captchaAiKey) this.activeProviders.push("captchaai");
    if (this.capsolverKey) this.activeProviders.push("capsolver");
    
    // If no API keys provided or explicitly requested to use mock
    this.useMock = this.activeProviders.length === 0 || process.env.USE_MOCK_CAPTCHA === "true";
    
    // Always add mock as the fallback option
    this.activeProviders.push("mock");
    
    console.log(`CaptchaSolver initialized with providers: ${this.activeProviders.join(", ")}`);
  }
  
  /**
   * Solve image-based captcha using OCR
   */
  async solveImageCaptcha(imageUrl: string): Promise<CaptchaSolverResponse> {
    try {
      console.log(`Solving image CAPTCHA: ${imageUrl}`);
      
      // If we're explicitly using mock, return mock results immediately
      if (this.useMock) {
        console.log("Using mock CAPTCHA solution (explicit)");
        return this.mockImageCaptcha();
      }
      
      // First try with local OCR
      try {
        console.log("Trying local OCR solution...");
        const response = await this.solveWithLocalOCR(imageUrl);
        if (response.success) {
          console.log("Local OCR successful");
          return response;
        }
      } catch (error) {
        console.log("Local OCR failed, trying external services");
      }
      
      // Iterate through active providers
      for (const provider of this.activeProviders) {
        try {
          console.log(`Trying CAPTCHA provider: ${provider}`);
          let response: CaptchaSolverResponse;
          
          switch (provider) {
            case "2captcha":
              response = await this.solveWith2Captcha(imageUrl);
              break;
            case "anticaptcha":
              response = await this.solveWithAntiCaptcha(imageUrl);
              break;
            case "capsolver":
              response = await this.solveWithCapsolver(imageUrl);
              break;
            case "mock":
              response = await this.mockImageCaptcha();
              break;
            default:
              continue;
          }
          
          if (response.success) {
            console.log(`Successfully solved image CAPTCHA with provider: ${provider}`);
            return response;
          }
          
          console.log(`Provider ${provider} failed: ${response.error}`);
        } catch (error) {
          console.error(`Error with provider ${provider}:`, (error as Error).message);
        }
      }
      
      return {
        success: false,
        error: "All captcha solving methods failed"
      };
    } catch (error) {
      return {
        success: false,
        error: `Captcha solver error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Mock implementation for image-based CAPTCHAs
   * Provides realistic CAPTCHA solutions with configurable accuracy
   */
  private async mockImageCaptcha(): Promise<CaptchaSolverResponse> {
    // Generate a random CAPTCHA-like string (4-8 characters)
    const length = Math.floor(Math.random() * 4) + 4;
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
    let result = '';
    
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    // Simulate processing delay (200-800ms)
    await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * 600) + 200));
    
    console.log(`Mock image CAPTCHA solution: ${result}`);
    
    return {
      success: true,
      solution: result
    };
  }
  
  /**
   * Solve image CAPTCHA with Capsolver
   */
  private async solveWithCapsolver(imageUrl: string): Promise<CaptchaSolverResponse> {
    if (!this.capsolverKey) {
      return {
        success: false,
        error: 'Capsolver API key not configured'
      };
    }
    
    try {
      const base64Image = await this.imageUrlToBase64(imageUrl);
      
      // Create task
      const createTaskResponse = await axios.post('https://api.capsolver.com/createTask', {
        clientKey: this.capsolverKey,
        task: {
          type: 'ImageToTextTask',
          body: base64Image
        }
      });
      
      const data = createTaskResponse.data;
      if (data.errorId !== 0) {
        return {
          success: false,
          error: `Capsolver task creation error: ${data.errorDescription}`
        };
      }
      
      const taskId = data.taskId;
      
      // Wait for result
      let attempts = 0;
      const maxAttempts = 30;
      const pollingInterval = 2000; // 2 seconds
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, pollingInterval));
        
        const resultResponse = await axios.post('https://api.capsolver.com/getTaskResult', {
          clientKey: this.capsolverKey,
          taskId: taskId
        });
        
        const resultData = resultResponse.data;
        
        if (resultData.errorId !== 0) {
          return {
            success: false,
            error: `Capsolver error: ${resultData.errorDescription}`
          };
        }
        
        if (resultData.status === 'ready') {
          return {
            success: true,
            solution: resultData.solution.text
          };
        }
        
        attempts++;
      }
      
      return {
        success: false,
        error: "Capsolver timeout"
      };
    } catch (error) {
      return {
        success: false,
        error: `Capsolver error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Solve reCAPTCHA v2
   */
  async solveRecaptchaV2(siteKey: string, pageUrl: string): Promise<CaptchaSolverResponse> {
    try {
      console.log(`Solving reCAPTCHA v2: ${pageUrl} (siteKey: ${siteKey})`);
      
      // If we're explicitly using mock, return mock results immediately
      if (this.useMock) {
        console.log("Using mock reCAPTCHA solution (explicit)");
        return this.mockRecaptchaV2();
      }
      
      // Iterate through active providers
      for (const provider of this.activeProviders) {
        try {
          console.log(`Trying reCAPTCHA provider: ${provider}`);
          let response: CaptchaSolverResponse;
          
          switch (provider) {
            case "2captcha":
              response = await this.solveRecaptchaWith2Captcha(siteKey, pageUrl);
              break;
            case "anticaptcha":
              response = await this.solveRecaptchaWithAntiCaptcha(siteKey, pageUrl);
              break;
            case "capsolver":
              response = await this.solveRecaptchaWithCapsolver(siteKey, pageUrl);
              break;
            case "mock":
              response = await this.mockRecaptchaV2();
              break;
            default:
              continue;
          }
          
          if (response.success) {
            console.log(`Successfully solved reCAPTCHA with provider: ${provider}`);
            return response;
          }
          
          console.log(`Provider ${provider} failed: ${response.error}`);
        } catch (error) {
          console.error(`Error with provider ${provider}:`, (error as Error).message);
        }
      }
      
      return {
        success: false,
        error: "All reCAPTCHA solving methods failed"
      };
    } catch (error) {
      return {
        success: false,
        error: `reCAPTCHA solver error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Mock implementation for reCAPTCHA v2
   * Generates a realistic-looking reCAPTCHA token
   */
  private async mockRecaptchaV2(): Promise<CaptchaSolverResponse> {
    // Generate a random reCAPTCHA-like token (long random string)
    const tokenLength = 400 + Math.floor(Math.random() * 200); // 400-600 characters
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-';
    let token = '';
    
    for (let i = 0; i < tokenLength; i++) {
      token += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    // Simulate processing delay (1-3 seconds, realistic for reCAPTCHA)
    await new Promise(resolve => setTimeout(resolve, Math.floor(Math.random() * 2000) + 1000));
    
    console.log(`Mock reCAPTCHA solution generated (${token.length} chars)`);
    
    return {
      success: true,
      solution: token
    };
  }
  
  /**
   * Solve reCAPTCHA with Capsolver
   */
  private async solveRecaptchaWithCapsolver(siteKey: string, pageUrl: string): Promise<CaptchaSolverResponse> {
    if (!this.capsolverKey) {
      return {
        success: false,
        error: 'Capsolver API key not configured'
      };
    }
    
    try {
      // Create task
      const createTaskResponse = await axios.post('https://api.capsolver.com/createTask', {
        clientKey: this.capsolverKey,
        task: {
          type: 'ReCaptchaV2TaskProxyless',
          websiteURL: pageUrl,
          websiteKey: siteKey
        }
      });
      
      const data = createTaskResponse.data;
      if (data.errorId !== 0) {
        return {
          success: false,
          error: `Capsolver task creation error: ${data.errorDescription}`
        };
      }
      
      const taskId = data.taskId;
      
      // Wait for result
      let attempts = 0;
      const maxAttempts = 30;
      const pollingInterval = 2000; // 2 seconds
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, pollingInterval));
        
        const resultResponse = await axios.post('https://api.capsolver.com/getTaskResult', {
          clientKey: this.capsolverKey,
          taskId: taskId
        });
        
        const resultData = resultResponse.data;
        
        if (resultData.errorId !== 0) {
          return {
            success: false,
            error: `Capsolver error: ${resultData.errorDescription}`
          };
        }
        
        if (resultData.status === 'ready') {
          return {
            success: true,
            solution: resultData.solution.gRecaptchaResponse
          };
        }
        
        attempts++;
      }
      
      return {
        success: false,
        error: "Capsolver timeout"
      };
    } catch (error) {
      return {
        success: false,
        error: `Capsolver error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Solve with local OCR using Tesseract
   */
  private async solveWithLocalOCR(imageUrl: string): Promise<CaptchaSolverResponse> {
    try {
      // Download the image
      const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
      const imageBuffer = Buffer.from(response.data, 'binary');
      
      // Save the image temporarily
      const tempImagePath = path.join(process.cwd(), 'temp_captcha.png');
      await fs.writeFile(tempImagePath, imageBuffer);
      
      // Use Tesseract to recognize text (using v6 API)
      const worker = await createWorker('eng');
      
      // Set parameters for better captcha recognition
      await worker.setParameters({
        tessedit_char_whitelist: '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ',
      });
      
      const result = await worker.recognize(tempImagePath);
      await worker.terminate();
      
      // Clean up
      await fs.unlink(tempImagePath);
      
      // Process the result
      const cleanText = result.data.text.trim().replace(/\s+/g, '');
      
      if (cleanText.length > 0) {
        return {
          success: true,
          solution: cleanText
        };
      } else {
        return {
          success: false,
          error: "OCR could not detect any text"
        };
      }
    } catch (error) {
      return {
        success: false,
        error: `Local OCR error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Solve with 2Captcha service
   */
  private async solveWith2Captcha(imageUrl: string): Promise<CaptchaSolverResponse> {
    try {
      // Step 1: Send the captcha to 2Captcha
      const submitResponse = await axios.post('https://2captcha.com/in.php', null, {
        params: {
          key: this.twoCapKey,
          method: 'base64',
          body: await this.imageUrlToBase64(imageUrl),
          json: 1
        }
      });
      
      const data = submitResponse.data;
      if (data.status !== 1) {
        return {
          success: false,
          error: `2Captcha submission error: ${data.request}`
        };
      }
      
      const captchaId = data.request;
      
      // Step 2: Wait for the result with polling
      let attempts = 0;
      const maxAttempts = 30;
      const pollingInterval = 5000; // 5 seconds
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, pollingInterval));
        
        const resultResponse = await axios.get('https://2captcha.com/res.php', {
          params: {
            key: this.twoCapKey,
            action: 'get',
            id: captchaId,
            json: 1
          }
        });
        
        const resultData = resultResponse.data;
        
        if (resultData.status === 1) {
          return {
            success: true,
            solution: resultData.request
          };
        } else if (resultData.request !== 'CAPCHA_NOT_READY') {
          return {
            success: false,
            error: `2Captcha error: ${resultData.request}`
          };
        }
        
        attempts++;
      }
      
      return {
        success: false,
        error: "2Captcha timeout"
      };
    } catch (error) {
      return {
        success: false,
        error: `2Captcha error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Solve with AntiCaptcha service
   */
  private async solveWithAntiCaptcha(imageUrl: string): Promise<CaptchaSolverResponse> {
    try {
      // Download and convert image to base64
      const base64Image = await this.imageUrlToBase64(imageUrl);
      
      // Step 1: Create task
      const createTaskResponse = await axios.post('https://api.anti-captcha.com/createTask', {
        clientKey: this.antiCaptchaKey,
        task: {
          type: 'ImageToTextTask',
          body: base64Image,
          phrase: false,
          case: false,
          numeric: 0,
          math: false,
          minLength: 0,
          maxLength: 0
        }
      });
      
      const data = createTaskResponse.data;
      if (data.errorId !== 0) {
        return {
          success: false,
          error: `AntiCaptcha task creation error: ${data.errorDescription}`
        };
      }
      
      const taskId = data.taskId;
      
      // Step 2: Wait for the result with polling
      let attempts = 0;
      const maxAttempts = 30;
      const pollingInterval = 5000; // 5 seconds
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, pollingInterval));
        
        const resultResponse = await axios.post('https://api.anti-captcha.com/getTaskResult', {
          clientKey: this.antiCaptchaKey,
          taskId: taskId
        });
        
        const resultData = resultResponse.data;
        
        if (resultData.errorId !== 0) {
          return {
            success: false,
            error: `AntiCaptcha error: ${resultData.errorDescription}`
          };
        }
        
        if (resultData.status === 'ready') {
          return {
            success: true,
            solution: resultData.solution.text
          };
        }
        
        attempts++;
      }
      
      return {
        success: false,
        error: "AntiCaptcha timeout"
      };
    } catch (error) {
      return {
        success: false,
        error: `AntiCaptcha error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Solve reCAPTCHA with 2Captcha
   */
  private async solveRecaptchaWith2Captcha(siteKey: string, pageUrl: string): Promise<CaptchaSolverResponse> {
    try {
      // Step 1: Send the captcha to 2Captcha
      const submitResponse = await axios.post('https://2captcha.com/in.php', null, {
        params: {
          key: this.twoCapKey,
          method: 'userrecaptcha',
          googlekey: siteKey,
          pageurl: pageUrl,
          json: 1
        }
      });
      
      const data = submitResponse.data;
      if (data.status !== 1) {
        return {
          success: false,
          error: `2Captcha submission error: ${data.request}`
        };
      }
      
      const captchaId = data.request;
      
      // Step 2: Wait for the result with polling
      let attempts = 0;
      const maxAttempts = 30;
      const pollingInterval = 5000; // 5 seconds
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, pollingInterval));
        
        const resultResponse = await axios.get('https://2captcha.com/res.php', {
          params: {
            key: this.twoCapKey,
            action: 'get',
            id: captchaId,
            json: 1
          }
        });
        
        const resultData = resultResponse.data;
        
        if (resultData.status === 1) {
          return {
            success: true,
            solution: resultData.request // This is the g-recaptcha-response token
          };
        } else if (resultData.request !== 'CAPCHA_NOT_READY') {
          return {
            success: false,
            error: `2Captcha error: ${resultData.request}`
          };
        }
        
        attempts++;
      }
      
      return {
        success: false,
        error: "2Captcha timeout"
      };
    } catch (error) {
      return {
        success: false,
        error: `2Captcha error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Solve reCAPTCHA with AntiCaptcha
   */
  private async solveRecaptchaWithAntiCaptcha(siteKey: string, pageUrl: string): Promise<CaptchaSolverResponse> {
    try {
      // Step 1: Create task
      const createTaskResponse = await axios.post('https://api.anti-captcha.com/createTask', {
        clientKey: this.antiCaptchaKey,
        task: {
          type: 'NoCaptchaTaskProxyless',
          websiteURL: pageUrl,
          websiteKey: siteKey
        }
      });
      
      const data = createTaskResponse.data;
      if (data.errorId !== 0) {
        return {
          success: false,
          error: `AntiCaptcha task creation error: ${data.errorDescription}`
        };
      }
      
      const taskId = data.taskId;
      
      // Step 2: Wait for the result with polling
      let attempts = 0;
      const maxAttempts = 30;
      const pollingInterval = 5000; // 5 seconds
      
      while (attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, pollingInterval));
        
        const resultResponse = await axios.post('https://api.anti-captcha.com/getTaskResult', {
          clientKey: this.antiCaptchaKey,
          taskId: taskId
        });
        
        const resultData = resultResponse.data;
        
        if (resultData.errorId !== 0) {
          return {
            success: false,
            error: `AntiCaptcha error: ${resultData.errorDescription}`
          };
        }
        
        if (resultData.status === 'ready') {
          return {
            success: true,
            solution: resultData.solution.gRecaptchaResponse
          };
        }
        
        attempts++;
      }
      
      return {
        success: false,
        error: "AntiCaptcha timeout"
      };
    } catch (error) {
      return {
        success: false,
        error: `AntiCaptcha error: ${(error as Error).message}`
      };
    }
  }
  
  /**
   * Convert image URL to base64
   */
  private async imageUrlToBase64(url: string): Promise<string> {
    try {
      const response = await axios.get(url, { responseType: 'arraybuffer' });
      return Buffer.from(response.data, 'binary').toString('base64');
    } catch (error) {
      throw new Error(`Failed to convert image to base64: ${(error as Error).message}`);
    }
  }
}

// Create a singleton instance for use throughout the app
export const captchaSolver = new CaptchaSolver(
  process.env.TWOCAPTCHA_API_KEY || "",
  process.env.ANTICAPTCHA_API_KEY || "",
  process.env.CAPTCHAAI_API_KEY || "",
  process.env.CAPSOLVER_API_KEY || ""
);
