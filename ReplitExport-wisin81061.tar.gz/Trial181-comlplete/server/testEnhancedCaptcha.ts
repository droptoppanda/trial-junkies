import { captchaSolver } from './captchaSolver';

/**
 * Test the enhanced CAPTCHA solver functionality
 */
async function testEnhancedCaptcha() {
  console.log('Testing Enhanced CAPTCHA Solver...');
  
  // Mock image CAPTCHA URL for testing
  const mockImageUrl = 'https://example.com/captcha.png';
  
  // Test image CAPTCHA solving (should use mock)
  console.log('\n1. Testing image CAPTCHA solving:');
  const imageCaptchaResult = await captchaSolver.solveImageCaptcha(mockImageUrl);
  console.log('Image CAPTCHA Result:', imageCaptchaResult);
  
  // Mock reCAPTCHA site key and URL for testing
  const mockSiteKey = '6LceMH4UAAAAAOGjLxNcK03fQqGlfHoXVdcMZlcX';
  const mockPageUrl = 'https://example.com/login';
  
  // Test reCAPTCHA v2 solving (should use mock)
  console.log('\n2. Testing reCAPTCHA v2 solving:');
  const recaptchaResult = await captchaSolver.solveRecaptchaV2(mockSiteKey, mockPageUrl);
  console.log('reCAPTCHA Result:', recaptchaResult);
  
  console.log('\nAll tests completed.');
  
  // Report success if all tests passed
  if (imageCaptchaResult.success && recaptchaResult.success) {
    console.log('✅ All CAPTCHA tests passed successfully.');
    return true;
  } else {
    console.log('❌ Some CAPTCHA tests failed.');
    return false;
  }
}

// Run the tests if this file is executed directly
if (import.meta.url === import.meta.resolve('./testEnhancedCaptcha.ts')) {
  // Set environment variable to ensure mock is used for testing
  process.env.USE_MOCK_CAPTCHA = 'true';
  
  testEnhancedCaptcha()
    .then((success) => {
      process.exit(success ? 0 : 1);
    })
    .catch((error) => {
      console.error('Error during CAPTCHA tests:', error);
      process.exit(1);
    });
}

export { testEnhancedCaptcha };