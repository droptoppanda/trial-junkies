/**
 * Enhanced Solana Payment Routes
 * 
 * This file defines the API endpoints for Solana payment processing,
 * including payment requests, transaction verification, and extensive
 * diagnostic information.
 * 
 * Version: 2.0
 */

import { Router, Request, Response, Express } from 'express';
import solanaPaymentService from './solanaPaymentService';

const router = Router();

/**
 * Register Solana payment routes with the Express app
 * @param app Express application
 */
export function registerSolanaPaymentRoutes(app: Express) {
  app.use('/api/payments/solana', router);
  
  // Log that routes have been registered
  console.log('[Solana Payment Routes] Initialized');
}

/**
 * Common error handler for route exceptions
 * @param error The error that occurred
 * @param res Express response object
 * @param context Context message for logging
 */
function handleRouteError(error: unknown, res: Response, context: string): void {
  const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
  console.error(`[Solana Payment Routes] Error in ${context}:`, errorMessage);
  
  if (error instanceof Error && error.stack) {
    console.error('[Solana Payment Routes] Stack trace:', error.stack);
  }
  
  res.status(500).json({
    success: false,
    error: errorMessage,
    context
  });
}

/**
 * GET /api/payments/solana/info
 * 
 * Returns information about the Solana payment service,
 * including network details and if it's configured correctly.
 */
router.get('/info', (req: Request, res: Response) => {
  try {
    const networkInfo = solanaPaymentService.getNetworkInfo();
    const isConfigured = solanaPaymentService.isConfigured();
    
    res.json({
      success: true,
      network: networkInfo.name,
      endpoint: networkInfo.endpoint,
      mock_mode: networkInfo.mockMode,
      network_status: networkInfo.status,
      configured: isConfigured,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleRouteError(error, res, 'getting service info');
  }
});

/**
 * GET /api/payments/solana/config
 * 
 * Returns detailed configuration status with diagnostic information
 */
router.get('/config', (req: Request, res: Response) => {
  try {
    const configStatus = solanaPaymentService.getConfigStatus();
    
    // For security, if not in mock mode, only return limited information
    if (!configStatus.mockMode) {
      // Sanitize the response to remove sensitive info
      delete configStatus.receiverAddress;
    }
    
    res.json({
      success: true,
      ...configStatus,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleRouteError(error, res, 'getting configuration status');
  }
});

/**
 * GET /api/payments/solana/health
 * 
 * Returns comprehensive health check for the payment service
 */
router.get('/health', async (req: Request, res: Response) => {
  try {
    const healthInfo = await solanaPaymentService.checkHealth();
    res.json({
      success: true,
      ...healthInfo
    });
  } catch (error) {
    handleRouteError(error, res, 'checking service health');
  }
});

/**
 * GET /api/payments/solana/receiver
 * 
 * Returns information about the receiver wallet.
 */
router.get('/receiver', (req: Request, res: Response) => {
  try {
    const walletInfo = solanaPaymentService.getReceiverWallet();
    
    if (!walletInfo.isValid && !walletInfo.mockMode) {
      return res.status(500).json({
        success: false,
        error: 'Receiver wallet not properly configured',
        validation_errors: walletInfo.validationErrors
      });
    }
    
    // For security, don't return the full address in production
    // unless in mock mode or explicitly requested
    const showFullAddress = walletInfo.mockMode || req.query.showFull === 'true';
    
    res.json({
      success: true,
      receiver_wallet: showFullAddress ? walletInfo.address : walletInfo.maskedAddress,
      network: walletInfo.network,
      mock_mode: walletInfo.mockMode,
      is_valid: walletInfo.isValid
    });
  } catch (error) {
    handleRouteError(error, res, 'getting receiver wallet info');
  }
});

/**
 * POST /api/payments/solana/create
 * 
 * Creates a new payment request with enhanced metadata.
 * Requires amount in SOL and optional metadata.
 */
router.post('/create', (req: Request, res: Response) => {
  const { amount, metadata } = req.body;
  
  // Validate amount
  if (!amount || typeof amount !== 'number' || amount <= 0) {
    return res.status(400).json({
      success: false,
      error: 'Valid positive amount is required',
      context: 'payment_creation'
    });
  }
  
  try {
    // Check if service is configured
    if (!solanaPaymentService.isConfigured() && !solanaPaymentService.getConfigStatus().mockMode) {
      return res.status(503).json({
        success: false,
        error: 'Solana payment service is not properly configured',
        context: 'configuration_check'
      });
    }
    
    // Create the payment request
    const paymentRequest = solanaPaymentService.createPaymentRequest(amount, metadata || {});
    
    res.json({
      success: true,
      payment_id: paymentRequest.paymentId,
      amount: paymentRequest.amount,
      receiver_address: paymentRequest.receiverAddress,
      network: paymentRequest.network,
      mock_mode: paymentRequest.mockMode,
      instructions: paymentRequest.instructions,
      qr_code_data: paymentRequest.qrCodeData,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleRouteError(error, res, 'creating payment request');
  }
});

/**
 * POST /api/payments/solana/process
 * 
 * Enhanced payment processor endpoint.
 * In mock mode, immediately processes and verifies the transaction.
 * Adds detailed diagnostic information.
 */
router.post('/process', async (req: Request, res: Response) => {
  const { amount, senderPublicKey, reference, scenario = 'success' } = req.body;
  
  // Validate amount
  if (!amount || typeof amount !== 'number' || amount <= 0) {
    return res.status(400).json({
      success: false,
      error: 'Valid positive amount is required',
      context: 'payment_processing'
    });
  }
  
  try {
    // Create a payment request
    const paymentRequest = solanaPaymentService.createPaymentRequest(amount, { 
      senderPublicKey, 
      reference,
      processorScenario: scenario
    });
    
    // For mock mode, we simulate a transaction ID
    // Use different prefixes based on the requested scenario for testing
    let mockTransactionId: string;
    
    switch (scenario) {
      case 'pending':
        mockTransactionId = `mock_pending_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        break;
      case 'invalid':
        mockTransactionId = `mock_invalid_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        break;
      case 'error':
        mockTransactionId = `mock_error_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        break;
      case 'success':
      default:
        mockTransactionId = `mock_valid_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        break;
    }
    
    // Verify the transaction
    const verificationResult = await solanaPaymentService.verifyTransaction(
      mockTransactionId,
      amount,
      paymentRequest.paymentId
    );
    
    if (verificationResult.success && verificationResult.verified) {
      res.json({
        success: true,
        payment_id: paymentRequest.paymentId,
        transaction_id: verificationResult.transactionId,
        amount: verificationResult.amount,
        timestamp: verificationResult.timestamp,
        confirmations: verificationResult.signatureInfo?.confirmations,
        validations: verificationResult.validations,
        mock_mode: verificationResult.mockMode
      });
    } else {
      // Return 402 Payment Required for pending transactions
      if (scenario === 'pending') {
        res.status(402).json({
          success: false,
          payment_id: paymentRequest.paymentId,
          error: verificationResult.error || 'Transaction is pending confirmation',
          pending: true,
          transaction_id: mockTransactionId,
          validations: verificationResult.validations,
          mock_mode: true
        });
      } else {
        // Return 400 Bad Request for other verification failures
        res.status(400).json({
          success: false,
          payment_id: paymentRequest.paymentId,
          error: verificationResult.error || 'Transaction verification failed',
          transaction_id: mockTransactionId,
          validations: verificationResult.validations,
          mock_mode: true
        });
      }
    }
  } catch (error) {
    handleRouteError(error, res, 'processing payment');
  }
});

/**
 * POST /api/payments/solana/verify
 * 
 * Enhanced transaction verification endpoint.
 * Requires transactionId, amount, and optional paymentId.
 * Provides detailed validation information.
 */
router.post('/verify', async (req: Request, res: Response) => {
  const { transactionId, amount, paymentId } = req.body;
  
  // Validate transaction ID
  if (!transactionId || typeof transactionId !== 'string') {
    return res.status(400).json({
      success: false,
      error: 'Valid transaction ID is required',
      context: 'transaction_verification'
    });
  }
  
  // Validate amount
  if (!amount || typeof amount !== 'number' || amount <= 0) {
    return res.status(400).json({
      success: false,
      error: 'Valid positive amount is required',
      context: 'transaction_verification'
    });
  }
  
  try {
    const verificationResult = await solanaPaymentService.verifyTransaction(
      transactionId,
      amount,
      paymentId || null
    );
    
    if (verificationResult.success && verificationResult.verified) {
      res.json({
        success: true,
        verified: true,
        transaction_id: verificationResult.transactionId,
        amount: verificationResult.amount,
        timestamp: verificationResult.timestamp,
        mock_mode: verificationResult.mockMode,
        validations: verificationResult.validations,
        signature_info: verificationResult.signatureInfo
      });
    } else if (verificationResult.error && verificationResult.error.includes('pending')) {
      // Special case for pending transactions
      res.status(202).json({
        success: false,
        verified: false,
        pending: true,
        error: verificationResult.error,
        mock_mode: verificationResult.mockMode,
        validations: verificationResult.validations
      });
    } else {
      res.status(400).json({
        success: false,
        verified: false,
        error: verificationResult.error || 'Transaction verification failed',
        mock_mode: verificationResult.mockMode,
        validations: verificationResult.validations
      });
    }
  } catch (error) {
    handleRouteError(error, res, 'verifying transaction');
  }
});

/**
 * GET /api/payments/solana/status/:paymentId
 * 
 * Enhanced payment status endpoint with detailed information.
 */
router.get('/status/:paymentId', (req: Request, res: Response) => {
  const { paymentId } = req.params;
  
  if (!paymentId) {
    return res.status(400).json({
      success: false,
      error: 'Payment ID is required',
      context: 'payment_status'
    });
  }
  
  try {
    const paymentStatus = solanaPaymentService.getPaymentStatus(paymentId);
    
    if (paymentStatus.success) {
      res.json({
        ...paymentStatus,
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(404).json({
        ...paymentStatus,
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    handleRouteError(error, res, 'getting payment status');
  }
});

/**
 * GET /api/payments/solana/test-verification/:scenario
 * 
 * Test endpoint to simulate different verification scenarios.
 * For testing and development only.
 */
router.get('/test-verification/:scenario', async (req: Request, res: Response) => {
  const { scenario } = req.params;
  const mockAmount = 1.0; // Default test amount
  
  if (!solanaPaymentService.getConfigStatus().mockMode) {
    return res.status(403).json({
      success: false,
      error: 'Test endpoints are only available in mock mode',
      context: 'test_endpoint'
    });
  }
  
  try {
    // Create a test transaction ID based on the scenario
    let mockTransactionId: string;
    
    switch (scenario) {
      case 'pending':
        mockTransactionId = `mock_pending_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        break;
      case 'invalid':
        mockTransactionId = `mock_invalid_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        break;
      case 'error':
        mockTransactionId = `mock_error_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        break;
      case 'valid':
      case 'success':
      default:
        mockTransactionId = `mock_valid_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        break;
    }
    
    // Create a test payment
    const paymentRequest = solanaPaymentService.createPaymentRequest(mockAmount, { 
      testScenario: scenario
    });
    
    // Verify the test transaction
    const verificationResult = await solanaPaymentService.verifyTransaction(
      mockTransactionId,
      mockAmount,
      paymentRequest.paymentId
    );
    
    // Get the payment status
    const paymentStatus = solanaPaymentService.getPaymentStatus(paymentRequest.paymentId);
    
    res.json({
      success: true,
      test_scenario: scenario,
      payment_request: {
        payment_id: paymentRequest.paymentId,
        amount: paymentRequest.amount,
        mock_mode: paymentRequest.mockMode
      },
      verification_result: verificationResult,
      payment_status: paymentStatus,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleRouteError(error, res, 'testing verification scenario');
  }
});

/**
 * GET /api/payments/solana/network-check
 * 
 * Check the Solana network status
 */
router.get('/network-check', async (req: Request, res: Response) => {
  try {
    const isOnline = await solanaPaymentService.checkNetworkStatus();
    const networkInfo = solanaPaymentService.getNetworkInfo();
    
    res.json({
      success: true,
      online: isOnline,
      network: networkInfo.name,
      endpoint: networkInfo.endpoint,
      status: networkInfo.status,
      last_checked: networkInfo.lastChecked,
      mock_mode: networkInfo.mockMode,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    handleRouteError(error, res, 'checking network status');
  }
});

export default router;