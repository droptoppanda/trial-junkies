import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { registerCryptoPaymentRoutes } from "./cryptoPayment";
import { registerWebScraperRoutes } from "./webScraper";
import { registerSolanaPaymentRoutes } from "./solanaPaymentRoutes";
import { registerSetupRoutes } from "./setupRoutes";
import { serviceExamples, serviceCategories, getServicesByCategory, getPopularServices, searchServices } from "@shared/serviceExamples";
import { sendTrialNotification, sendEmailVerificationNotification, sendPhoneVerificationNotification, updateUserRole } from "./discordBot";
import { smsVerification } from "./smsVerification";
import { emailVerification } from "./emailVerification";
import { 
  insertUserSchema, 
  insertSubscriptionSchema, 
  insertAutomatedTrialSchema,
  insertVirtualIdentitySchema,
  insertVirtualCardSchema
} from "@shared/schema";
import { z } from "zod";
import express from "express";
import session from "express-session";
import MemoryStore from "memorystore";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";

export async function registerRoutes(app: Express): Promise<Server> {
  // Register crypto payment routes
  registerCryptoPaymentRoutes(app);
  // Register web scraper routes
  registerWebScraperRoutes(app);
  // Register Solana payment routes
  registerSolanaPaymentRoutes(app);
  // Register environment setup routes
  registerSetupRoutes(app);
  // Set up session middleware
  const MemoryStoreSession = MemoryStore(session);
  app.use(
    session({
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      secret: process.env.SESSION_SECRET || "trialjunkies-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
    })
  );

  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure passport local strategy
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Invalid username" });
        }
        if (user.password !== password) {
          // In production, use proper password hashing comparison
          return done(null, false, { message: "Invalid password" });
        }
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: "Unauthorized" });
  };

  const isAdmin = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated() && (req.user as any)?.is_admin) {
      return next();
    }
    res.status(403).json({ message: "Access denied" });
  };

  // Authentication routes
  app.post("/api/auth/login", (req, res, next) => {
    passport.authenticate("local", (err: Error | null, user: any, info: { message: string }) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info.message });
      }
      req.logIn(user, (err: Error | null) => {
        if (err) {
          return next(err);
        }
        return res.json({ user: { ...user, password: undefined } });
      });
    })(req, res, next);
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(validatedData);
      res.status(201).json({ user: { ...user, password: undefined } });
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/auth/logout", (req, res) => {
    req.logout(() => {
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/status", (req, res) => {
    if (req.isAuthenticated()) {
      const user = req.user as any;
      res.json({ authenticated: true, user: { ...user, password: undefined } });
    } else {
      res.json({ authenticated: false });
    }
  });

  // Wallet routes
  app.post("/api/wallet/link", isAuthenticated, async (req, res) => {
    try {
      const { wallet_address } = req.body;
      if (!wallet_address) {
        return res.status(400).json({ message: "Wallet address is required" });
      }
      
      const user = await storage.updateUser((req.user as any).id, { wallet_address });
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ user: { ...user, password: undefined } });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Discord routes
  app.post("/api/discord/link", isAuthenticated, async (req, res) => {
    try {
      const { discord_id, discord_username, discord_access_token, discord_refresh_token, discord_token_expiry } = req.body;
      
      if (!discord_id || !discord_username || !discord_access_token) {
        return res.status(400).json({ message: "Discord information is incomplete" });
      }
      
      const user = await storage.updateUser((req.user as any).id, { 
        discord_id, discord_username, discord_access_token, discord_refresh_token,
        discord_token_expiry: discord_token_expiry ? new Date(discord_token_expiry) : undefined
      });
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ user: { ...user, password: undefined } });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Subscription routes
  app.get("/api/subscriptions/tiers", (req, res) => {
    res.json({
      basic: {
        name: "Casual User",
        price: "0.1",
        features: [
          "Discord Basic Role",
          "5 Automated Trials per Month",
          "Basic Email Verification",
          "Community Support",
          "Single identity profile"
        ],
        notIncluded: [
          "Premium websites access",
          "Virtual card generation",
          "Custom identity profiles"
        ]
      },
      pro: {
        name: "Junkie Mode",
        price: "0.5",
        features: [
          "Discord Pro Role",
          "25 Automated Trials per Month",
          "Email & Phone Verification",
          "Priority Support",
          "Up to 5 Identity Profiles",
          "Basic Virtual Cards"
        ],
        notIncluded: [
          "Unlimited trials",
          "Advanced identity management"
        ],
        popular: true
      },
      enterprise: {
        name: "Overdose Plan",
        price: "2.0",
        features: [
          "Discord Enterprise Role",
          "Unlimited Automated Trials",
          "Advanced Verification Methods",
          "24/7 Dedicated Support",
          "Unlimited Identity Profiles",
          "Premium Virtual Cards",
          "Custom Website Targeting",
          "API Access"
        ],
        notIncluded: []
      }
    });
  });

  app.get("/api/subscriptions/user", isAuthenticated, async (req, res) => {
    try {
      const subscriptions = await storage.getSubscriptionsByUserId((req.user as any).id);
      res.json({ subscriptions });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/subscriptions/active", isAuthenticated, async (req, res) => {
    try {
      const subscription = await storage.getActiveSubscriptionByUserId((req.user as any).id);
      res.json({ subscription: subscription || null });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/subscriptions/subscribe", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertSubscriptionSchema.parse({
        ...req.body,
        user_id: (req.user as any).id,
      });
      
      // Deactivate any active subscriptions first
      const activeSubscription = await storage.getActiveSubscriptionByUserId(validatedData.user_id);
      if (activeSubscription) {
        await storage.deactivateSubscription(activeSubscription.id);
      }
      
      const subscription = await storage.createSubscription(validatedData);
      
      // Get user to check for Discord ID
      const user = await storage.getUser(validatedData.user_id);
      if (user && user.discord_id) {
        // Update Discord role based on subscription tier
        await updateUserRole(user.discord_id, subscription.tier);
      }
      
      res.status(201).json({ subscription });
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.post("/api/subscriptions/cancel", isAuthenticated, async (req, res) => {
    try {
      const activeSubscription = await storage.getActiveSubscriptionByUserId((req.user as any).id);
      if (!activeSubscription) {
        return res.status(404).json({ message: "No active subscription found" });
      }
      
      const updatedSubscription = await storage.deactivateSubscription(activeSubscription.id);
      res.json({ subscription: updatedSubscription });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin routes
  app.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Remove passwords from response
      const safeUsers = users.map(user => ({ ...user, password: undefined }));
      res.json({ users: safeUsers });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/subscriptions", isAdmin, async (req, res) => {
    try {
      const subscriptions = await storage.getAllSubscriptions();
      res.json({ subscriptions });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/admin/subscriptions/:userId", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const subscriptions = await storage.getSubscriptionsByUserId(userId);
      res.json({ subscriptions });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Automated Trial routes
  app.get("/api/trials", isAuthenticated, async (req, res) => {
    try {
      const trials = await storage.getAutomatedTrialsByUserId((req.user as any).id);
      res.json({ trials });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.get("/api/trials/:id", isAuthenticated, async (req, res) => {
    try {
      const trialId = parseInt(req.params.id);
      if (isNaN(trialId)) {
        return res.status(400).json({ message: "Invalid trial ID" });
      }
      
      const trial = await storage.getAutomatedTrial(trialId);
      if (!trial) {
        return res.status(404).json({ message: "Trial not found" });
      }
      
      // Only allow access to the user's own trials or admin users
      if (trial.user_id !== (req.user as any).id && !(req.user as any).is_admin) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json({ trial });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/trials/create", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      
      // Check if user has active subscription
      const activeSubscription = await storage.getActiveSubscriptionByUserId(userId);
      if (!activeSubscription) {
        return res.status(403).json({ message: "Active subscription required to create trials" });
      }
      
      // Validate trial data
      const validatedData = insertAutomatedTrialSchema.parse({
        ...req.body,
        user_id: userId,
        status: "queued" // Force initial status to be queued
      });
      
      const trial = await storage.createAutomatedTrial(validatedData);
      
      // Get user to check for Discord ID
      const user = await storage.getUser(userId);
      if (user && user.discord_id) {
        // Send Discord notification
        await sendTrialNotification(trial, userId, user.discord_id);
      } else {
        // Send notification without mentioning specific user
        await sendTrialNotification(trial, userId);
      }
      
      res.status(201).json({ trial });
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });
  
  app.patch("/api/trials/:id", isAuthenticated, async (req, res) => {
    try {
      const trialId = parseInt(req.params.id);
      if (isNaN(trialId)) {
        return res.status(400).json({ message: "Invalid trial ID" });
      }
      
      const trial = await storage.getAutomatedTrial(trialId);
      if (!trial) {
        return res.status(404).json({ message: "Trial not found" });
      }
      
      // Only allow updates to the user's own trials or admin users
      if (trial.user_id !== (req.user as any).id && !(req.user as any).is_admin) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updatedTrial = await storage.updateAutomatedTrial(trialId, req.body);
      res.json({ trial: updatedTrial });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Virtual Identity routes
  app.get("/api/identities", isAuthenticated, async (req, res) => {
    try {
      const identities = await storage.getVirtualIdentitiesByUserId((req.user as any).id);
      res.json({ identities });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.get("/api/identities/:id", isAuthenticated, async (req, res) => {
    try {
      const identityId = parseInt(req.params.id);
      if (isNaN(identityId)) {
        return res.status(400).json({ message: "Invalid identity ID" });
      }
      
      const identity = await storage.getVirtualIdentity(identityId);
      if (!identity) {
        return res.status(404).json({ message: "Identity not found" });
      }
      
      // Only allow access to the user's own identities or admin users
      if (identity.user_id !== (req.user as any).id && !(req.user as any).is_admin) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json({ identity });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/identities/create", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      
      // Check if user has active subscription
      const activeSubscription = await storage.getActiveSubscriptionByUserId(userId);
      if (!activeSubscription) {
        return res.status(403).json({ message: "Active subscription required to create virtual identities" });
      }
      
      // Get existing identities count to enforce limits based on subscription tier
      const existingIdentities = await storage.getVirtualIdentitiesByUserId(userId);
      
      // Apply subscription tier limits
      if (activeSubscription.tier === "basic" && existingIdentities.length >= 1) {
        return res.status(403).json({ message: "Basic subscription limited to 1 identity profile" });
      } else if (activeSubscription.tier === "pro" && existingIdentities.length >= 5) {
        return res.status(403).json({ message: "Pro subscription limited to 5 identity profiles" });
      }
      
      // Validate identity data
      const validatedData = insertVirtualIdentitySchema.parse({
        ...req.body,
        user_id: userId
      });
      
      const identity = await storage.createVirtualIdentity(validatedData);
      res.status(201).json({ identity });
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });
  
  app.patch("/api/identities/:id", isAuthenticated, async (req, res) => {
    try {
      const identityId = parseInt(req.params.id);
      if (isNaN(identityId)) {
        return res.status(400).json({ message: "Invalid identity ID" });
      }
      
      const identity = await storage.getVirtualIdentity(identityId);
      if (!identity) {
        return res.status(404).json({ message: "Identity not found" });
      }
      
      // Only allow updates to the user's own identities or admin users
      if (identity.user_id !== (req.user as any).id && !(req.user as any).is_admin) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updatedIdentity = await storage.updateVirtualIdentity(identityId, req.body);
      res.json({ identity: updatedIdentity });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Virtual Card routes
  app.get("/api/cards", isAuthenticated, async (req, res) => {
    try {
      const cards = await storage.getVirtualCardsByUserId((req.user as any).id);
      res.json({ cards });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.get("/api/cards/:id", isAuthenticated, async (req, res) => {
    try {
      const cardId = parseInt(req.params.id);
      if (isNaN(cardId)) {
        return res.status(400).json({ message: "Invalid card ID" });
      }
      
      const card = await storage.getVirtualCard(cardId);
      if (!card) {
        return res.status(404).json({ message: "Card not found" });
      }
      
      // Only allow access to the user's own cards or admin users
      if (card.user_id !== (req.user as any).id && !(req.user as any).is_admin) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      res.json({ card });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/cards/create", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      
      // Check if user has active subscription that allows virtual cards
      const activeSubscription = await storage.getActiveSubscriptionByUserId(userId);
      if (!activeSubscription) {
        return res.status(403).json({ message: "Active subscription required to create virtual cards" });
      }
      
      // Basic tier doesn't include virtual cards
      if (activeSubscription.tier === "basic") {
        return res.status(403).json({ message: "Your subscription tier does not include virtual cards" });
      }
      
      // Validate card data
      const validatedData = insertVirtualCardSchema.parse({
        ...req.body,
        user_id: userId
      });
      
      const card = await storage.createVirtualCard(validatedData);
      res.status(201).json({ card });
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });
  
  app.patch("/api/cards/:id", isAuthenticated, async (req, res) => {
    try {
      const cardId = parseInt(req.params.id);
      if (isNaN(cardId)) {
        return res.status(400).json({ message: "Invalid card ID" });
      }
      
      const card = await storage.getVirtualCard(cardId);
      if (!card) {
        return res.status(404).json({ message: "Card not found" });
      }
      
      // Only allow updates to the user's own cards or admin users
      if (card.user_id !== (req.user as any).id && !(req.user as any).is_admin) {
        return res.status(403).json({ message: "Access denied" });
      }
      
      const updatedCard = await storage.updateVirtualCard(cardId, req.body);
      res.json({ card: updatedCard });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Discord verification routes
  app.post("/api/discord/verify/email", isAuthenticated, async (req, res) => {
    try {
      const { email } = req.body;
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }
      
      // Get user to check for Discord ID
      const user = req.user as any;
      
      // Send Discord notification
      if (user.discord_id) {
        await sendEmailVerificationNotification(email, user.id, user.discord_id);
      } else {
        await sendEmailVerificationNotification(email, user.id);
      }
      
      res.json({ success: true, message: "Email verification notification sent" });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/discord/verify/phone", isAuthenticated, async (req, res) => {
    try {
      const { phone_number, service } = req.body;
      if (!phone_number) {
        return res.status(400).json({ message: "Phone number is required" });
      }
      
      // Get user to check for Discord ID
      const user = req.user as any;
      
      // Send Discord notification
      if (user.discord_id) {
        await sendPhoneVerificationNotification(phone_number, user.id, user.discord_id);
      } else {
        await sendPhoneVerificationNotification(phone_number, user.id);
      }
      
      // If a service is provided, use the SMS verification service
      if (service) {
        // Get a phone number for verification
        const smsResponse = await smsVerification.getPhoneNumber(service, "0");
        if (smsResponse.success && smsResponse.phoneNumber && smsResponse.verificationId) {
          // Store verification ID for later use
          // In a real scenario, you would associate this with the user's account
          res.json({ 
            success: true, 
            message: "Phone verification initiated", 
            phone_number: smsResponse.phoneNumber,
            verification_id: smsResponse.verificationId
          });
        } else {
          res.status(400).json({ 
            success: false, 
            message: `Failed to get phone number: ${smsResponse.error}` 
          });
        }
      } else {
        res.json({ success: true, message: "Phone verification notification sent" });
      }
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/discord/verify/phone/check", isAuthenticated, async (req, res) => {
    try {
      const { verification_id, service } = req.body;
      if (!verification_id || !service) {
        return res.status(400).json({ message: "Verification ID and service are required" });
      }
      
      // Get verification code
      const codeResponse = await smsVerification.getVerificationCode(verification_id, service);
      
      if (codeResponse.success && codeResponse.code) {
        res.json({ 
          success: true, 
          message: "Verification code retrieved", 
          code: codeResponse.code 
        });
      } else {
        res.status(400).json({ 
          success: false, 
          message: `Failed to get verification code: ${codeResponse.error}` 
        });
      }
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Email verification endpoints
  app.post("/api/email/verify", isAuthenticated, async (req, res) => {
    try {
      const { service } = req.body;
      
      // Get email address for verification
      const response = await emailVerification.getEmailAddress(service || "general");
      
      if (response.success && response.emailAddress && response.verificationId) {
        res.json({
          success: true,
          email: response.emailAddress,
          verification_id: response.verificationId,
          message: "Email address generated successfully"
        });
      } else {
        res.status(400).json({
          success: false,
          message: `Failed to get email address: ${response.error}`
        });
      }
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/email/verify/check", isAuthenticated, async (req, res) => {
    try {
      const { verification_id } = req.body;
      if (!verification_id) {
        return res.status(400).json({ message: "Verification ID is required" });
      }
      
      // Get verification code from email
      const codeResponse = await emailVerification.getVerificationCode(verification_id);
      
      if (codeResponse.success && codeResponse.code) {
        res.json({ 
          success: true, 
          message: "Verification code retrieved", 
          code: codeResponse.code 
        });
      } else {
        res.status(400).json({ 
          success: false, 
          message: `Failed to get verification code: ${codeResponse.error}` 
        });
      }
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Endpoint for trial signups with email verification
  app.post("/api/trial/signup", isAuthenticated, async (req, res) => {
    try {
      const { service, email_verification_required } = req.body;
      
      if (email_verification_required) {
        // Get email for verification
        const emailResponse = await emailVerification.getEmailAddress(service || "trial");
        
        if (!emailResponse.success) {
          return res.status(400).json({
            success: false,
            message: `Failed to get email address: ${emailResponse.error}`
          });
        }
        
        // Return email data for verification process
        res.json({
          success: true,
          email: emailResponse.emailAddress,
          verification_id: emailResponse.verificationId,
          message: "Use this email address for trial signup verification"
        });
      } else {
        // If email verification not required, just return success
        res.json({
          success: true,
          message: "Trial signup process initiated"
        });
      }
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // API Key management
  app.post("/api/user/generate-api-key", isAuthenticated, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      
      // Check if user has enterprise subscription for API access
      const activeSubscription = await storage.getActiveSubscriptionByUserId(userId);
      if (!activeSubscription || activeSubscription.tier !== "enterprise") {
        return res.status(403).json({ message: "Enterprise subscription required for API access" });
      }
      
      // Generate API key - in production, use a secure method
      const apiKey = `tj_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`;
      
      const user = await storage.updateUser(userId, { api_key: apiKey });
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ api_key: apiKey });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Admin routes for AI system
  app.get("/api/admin/trials", isAdmin, async (req, res) => {
    try {
      // This would typically be a more complex query with pagination in a real DB
      // For simplicity, we're just collecting all trials from all users
      const allTrials = [];
      const users = await storage.getAllUsers();
      
      for (const user of users) {
        const userTrials = await storage.getAutomatedTrialsByUserId(user.id);
        allTrials.push(...userTrials);
      }
      
      res.json({ trials: allTrials });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.get("/api/admin/identities", isAdmin, async (req, res) => {
    try {
      // Similar to trials, this would have pagination in production
      const allIdentities = [];
      const users = await storage.getAllUsers();
      
      for (const user of users) {
        const userIdentities = await storage.getVirtualIdentitiesByUserId(user.id);
        allIdentities.push(...userIdentities);
      }
      
      res.json({ identities: allIdentities });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.get("/api/admin/cards", isAdmin, async (req, res) => {
    try {
      const allCards = [];
      const users = await storage.getAllUsers();
      
      for (const user of users) {
        const userCards = await storage.getVirtualCardsByUserId(user.id);
        allCards.push(...userCards);
      }
      
      res.json({ cards: allCards });
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);

  // Enhanced SMS verification endpoints
  app.post("/api/sms/enhanced/getNumber", isAuthenticated, async (req, res) => {
    try {
      const { service, country } = req.body;
      if (!service) {
        return res.status(400).json({ message: "Service name is required" });
      }
      
      // Get phone number with provider info
      const response = await smsVerification.getPhoneNumberWithProvider(service, country || "0");
      
      if (response.success && response.phoneNumber && response.verificationId) {
        res.json({
          success: true,
          phone_number: response.phoneNumber,
          verification_id: response.verificationId,
          provider: response.provider,
          message: "Phone number obtained successfully using enhanced service"
        });
      } else {
        res.status(400).json({
          success: false,
          message: `Failed to get phone number: ${response.error}`
        });
      }
    } catch (err: any) {
      res.status(500).json({ 
        success: false,
        message: "Internal server error", 
        error: err.message
      });
    }
  });
  
  app.post("/api/sms/enhanced/getCode", isAuthenticated, async (req, res) => {
    try {
      const { verification_id, service } = req.body;
      if (!verification_id || !service) {
        return res.status(400).json({ message: "Verification ID and service are required" });
      }
      
      // Get verification code
      const response = await smsVerification.getVerificationCode(verification_id, service);
      
      if (response.success && response.code) {
        res.json({
          success: true,
          code: response.code,
          message: "Verification code retrieved successfully"
        });
      } else {
        res.status(400).json({
          success: false,
          message: `Failed to get verification code: ${response.error}`
        });
      }
    } catch (err: any) {
      res.status(500).json({ 
        success: false,
        message: "Internal server error", 
        error: err.message
      });
    }
  });
  
  // Test the available SMS verification providers
  app.get("/api/sms/providers/status", isAdmin, async (req, res) => {
    try {
      // We need to request API keys for SMS verification services
      if (!process.env.SMS_ACTIVATE_API_KEY && !process.env.SMSPVA_API_KEY && !process.env.FIVESIM_API_KEY) {
        return res.status(400).json({
          success: false,
          message: "No SMS verification API keys configured. Please add API keys for SMS-Activate, SMSPVA, or 5sim to use this feature."
        });
      }
      
      res.json({
        success: true,
        message: "SMS providers status",
        providers: {
          smsActivate: process.env.SMS_ACTIVATE_API_KEY ? "configured" : "not configured",
          smspva: process.env.SMSPVA_API_KEY ? "configured" : "not configured",
          fivesim: process.env.FIVESIM_API_KEY ? "configured" : "not configured",
        }
      });
    } catch (err: any) {
      res.status(500).json({ 
        success: false, 
        message: "Internal server error", 
        error: err.message
      });
    }
  });
  
  // Services examples endpoints
  app.get("/api/services", (_req, res) => {
    res.json({ services: serviceExamples });
  });

  app.get("/api/services/categories", (_req, res) => {
    res.json({ categories: serviceCategories });
  });

  app.get("/api/services/popular", (req, res) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
    res.json({ services: getPopularServices(limit) });
  });

  app.get("/api/services/category/:categoryId", (req, res) => {
    const categoryId = req.params.categoryId;
    res.json({ services: getServicesByCategory(categoryId) });
  });

  app.get("/api/services/search", (req, res) => {
    const query = req.query.q as string || '';
    res.json({ services: searchServices(query) });
  });
  
  return httpServer;
}
