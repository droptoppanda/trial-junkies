import { enhancedSmsVerification } from './services/smsVerificationService';

/**
 * Test the enhanced SMS verification service
 */
async function testEnhancedSmsVerification() {
  console.log('=============================================');
  console.log('Testing Enhanced SMS Verification Service');
  console.log('=============================================');
  
  try {
    // Check the environment for SMS API keys
    const smsActivateKey = process.env.SMS_ACTIVATE_API_KEY;
    const smspvaKey = process.env.SMSPVA_API_KEY;
    const fiveSimKey = process.env.FIVESIM_API_KEY;
    
    console.log('\nProvider Configuration:');
    console.log(`- SMS-Activate: ${smsActivateKey ? 'Configured ✓' : 'Not configured ✗'}`);
    console.log(`- SMSPVA: ${smspvaKey ? 'Configured ✓' : 'Not configured ✗'}`);
    console.log(`- 5sim: ${fiveSimKey ? 'Configured ✓' : 'Not configured ✗'}`);
    
    if (!smsActivateKey && !smspvaKey && !fiveSimKey) {
      console.log('\n⚠️ No SMS API keys configured!');
      console.log('To use real SMS providers, add one or more of the following environment variables:');
      console.log('- SMS_ACTIVATE_API_KEY');
      console.log('- SMSPVA_API_KEY');
      console.log('- FIVESIM_API_KEY');
      
      console.log('\nContinuing with the mock implementation...');
    }
    
    console.log('\nTest 1: Getting phone number for service "discord"');
    const phoneResult = await enhancedSmsVerification.getPhoneNumber('discord', '0');
    
    if (phoneResult.success) {
      console.log(`✓ Successfully got phone number: ${phoneResult.phoneNumber}`);
      console.log(`✓ Provider: ${phoneResult.provider || 'mock'}`);
      console.log(`✓ Verification ID: ${phoneResult.verificationId}`);
      
      console.log('\nTest 2: Getting verification code');
      const codeResult = await enhancedSmsVerification.getVerificationCode(
        phoneResult.verificationId || '',
        'discord',
        phoneResult.provider
      );
      
      if (codeResult.success) {
        console.log(`✓ Successfully got verification code: ${codeResult.code}`);
        console.log('\nAll tests passed successfully! ✓');
      } else {
        console.log(`✗ Failed to get verification code: ${codeResult.error}`);
      }
    } else {
      console.log(`✗ Failed to get phone number: ${phoneResult.error}`);
    }
  } catch (error) {
    console.error('Error during SMS verification test:', error);
  }
  
  console.log('\n=============================================');
}

export default testEnhancedSmsVerification;

// This is only for direct execution of this file
// Uncomment to enable running this file directly
// if (import.meta.url === import.meta.resolve('./testEnhancedSMS.ts')) {
//   testEnhancedSmsVerification().catch(console.error);
// }