
import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { storage } from "./storage";
import type { Express, Request, Response } from "express";
import { AutomatedTrial } from "@shared/schema";
import { smsVerification } from "./smsVerification";
import { captchaSolver } from "./captchaSolver";
import { proxyManager } from "./proxyManager";
import { disposableEmail } from "./disposableEmail";
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import fs from 'fs';

// Add stealth plugin to puppeteer for anti-detection
puppeteer.use(StealthPlugin());

// Ensure screenshots directory exists
if (!fs.existsSync('./screenshots')) {
  fs.mkdirSync('./screenshots', { recursive: true });
}

// Interface for scraper response
interface ScraperResponse {
  success: boolean;
  data?: any;
  credentials?: {
    username: string;
    password: string;
    email?: string;
    phone_number?: string;
  };
  error?: string;
  screenshot_path?: string;
}

/**
 * Automated web scraper and trial signup service
 * This service automates the process of creating trial accounts
 */
export const automateTrialSignup = async (
  trialData: AutomatedTrial
): Promise<ScraperResponse> => {
  let browser;
  let proxy = null;
  let emailAccount = null;
  
  try {
    console.log(`Starting automated trial for ${trialData.service_name}`);
    
    // Initialize proxy manager if not already initialized
    if (!proxyManager.getNextProxy()) {
      await proxyManager.initialize();
    }
    
    // Get a proxy for this session
    proxy = proxyManager.getNextProxy();
    
    // Create browser launch arguments
    const browserArgs = [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--disable-notifications',
      '--disable-extensions',
      '--mute-audio'
    ];
    
    // Add proxy if available
    if (proxy) {
      const proxyArgs = proxyManager.getPuppeteerProxyArgs(proxy);
      browserArgs.push(...proxyArgs);
    }
    
    // Create a unique session ID for this trial
    const sessionId = uuidv4();
    const userDataDir = path.join('./browser-sessions', sessionId);
    
    // Launch browser with stealth mode and additional protections
    browser = await puppeteer.launch({
      headless: false, // Set to false for better anti-detection
      args: browserArgs,
      ignoreHTTPSErrors: true,
      userDataDir // Use unique user data directory for each session
    });
    
    const page = await browser.newPage();
    
    // Set a more realistic viewport and user agent
    await page.setViewport({ 
      width: 1366, 
      height: 768, 
      deviceScaleFactor: 1,
      hasTouch: false,
      isLandscape: true,
      isMobile: false
    });
    
    // Randomize user agent slightly for better fingerprint protection
    const userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.71 Safari/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:96.0) Gecko/20100101 Firefox/96.0'
    ];
    const randomUserAgent = userAgents[Math.floor(Math.random() * userAgents.length)];
    await page.setUserAgent(randomUserAgent);
    
    // Set additional headers to appear more like a real browser
    await page.setExtraHTTPHeaders({
      'Accept-Language': 'en-US,en;q=0.9',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
      'Accept-Encoding': 'gzip, deflate, br',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1'
    });
    
    // Modify WebGL fingerprint
    await page.evaluateOnNewDocument(() => {
      // Override WebGL fingerprinting
      const getParameter = WebGLRenderingContext.prototype.getParameter;
      WebGLRenderingContext.prototype.getParameter = function(parameter) {
        // Randomize certain WebGL parameters
        if (parameter === 37445) {
          return 'Intel Inc.';
        }
        if (parameter === 37446) {
          return 'Intel(R) HD Graphics';
        }
        return getParameter.apply(this, arguments);
      };
      
      // Override navigator properties
      const navigatorProps = ['hardwareConcurrency', 'deviceMemory', 'platform', 'plugins', 'languages'];
      navigatorProps.forEach(prop => {
        if (Object.getOwnPropertyDescriptor(Navigator.prototype, prop)) {
          Object.defineProperty(Navigator.prototype, prop, {
            get: function() {
              if (prop === 'hardwareConcurrency') return 8;
              if (prop === 'deviceMemory') return 8;
              if (prop === 'platform') return 'Win32';
              if (prop === 'languages') return ['en-US', 'en'];
              // Default behavior for other properties
              return Object.getOwnPropertyDescriptor(Navigator.prototype, prop)?.get?.apply(this);
            }
          });
        }
      });
    });
    
    // Create email account for verification
    emailAccount = await disposableEmail.createAccount();
    console.log(`Created temporary email account: ${emailAccount.address}`);
    
    // Generate random credentials for the signup
    const credentials = generateRandomCredentials(trialData.service_name, emailAccount.address);
    
    // Initialize results object for accumulating data during the flow
    const flowResults = {
      phoneVerification: null as any,
      emailVerified: false,
      captchaSolved: false
    };
    
    // Navigate to the website with proper error handling and retry logic
    let navigationAttempts = 0;
    const maxNavigationAttempts = 3;
    
    while (navigationAttempts < maxNavigationAttempts) {
      try {
        await page.goto(trialData.website_url, { 
          waitUntil: 'networkidle2',
          timeout: 60000 
        });
        
        // Check if page loaded properly
        const title = await page.title();
        const url = page.url();
        
        // If we're blocked, banned, or got a captcha right away
        if (
          title.includes('Access Denied') || 
          title.includes('Robot') || 
          title.includes('Captcha') ||
          title.includes('Security Check') ||
          url.includes('captcha') ||
          url.includes('challenge')
        ) {
          console.log(`Detected blocking page: "${title}". Trying to solve or switch proxy...`);
          
          // Try to solve captcha if present
          const captchaSolved = await handleCaptcha(page);
          flowResults.captchaSolved = captchaSolved;
          
          if (!captchaSolved) {
            // Ban the proxy and try a new one
            if (proxy) {
              proxyManager.banProxy(proxy);
              proxy = proxyManager.getNextProxy();
              
              if (proxy) {
                // Restart browser with new proxy
                await browser.close();
                
                const newProxyArgs = proxyManager.getPuppeteerProxyArgs(proxy);
                browserArgs.splice(browserArgs.findIndex(arg => arg.startsWith('--proxy-server=')), 1, ...newProxyArgs);
                
                browser = await puppeteer.launch({
                  headless: false,
                  args: browserArgs,
                  ignoreHTTPSErrors: true,
                  userDataDir
                });
                
                page = await browser.newPage();
                await page.setViewport({ width: 1366, height: 768 });
                await page.setUserAgent(randomUserAgent);
                
                navigationAttempts++;
                continue;
              }
            }
          }
        }
        
        // If we reach here, navigation was successful
        break;
      } catch (error) {
        console.error(`Navigation attempt ${navigationAttempts + 1} failed:`, error);
        
        if (navigationAttempts >= maxNavigationAttempts - 1) {
          throw new Error(`Failed to navigate to website after ${maxNavigationAttempts} attempts`);
        }
        
        // Ban proxy and try a new one
        if (proxy) {
          proxyManager.banProxy(proxy);
          proxy = proxyManager.getNextProxy();
        }
        
        navigationAttempts++;
        await new Promise(resolve => setTimeout(resolve, 5000)); // Wait before retrying
      }
    }
    
    // Take screenshot of the initial page
    const initialScreenshotPath = `./screenshots/${credentials.username}-initial.png`;
    await page.screenshot({ path: initialScreenshotPath });
    
    // Execute service-specific signup logic
    const signupResult = await executeSignupWorkflow(
      page, 
      trialData.service_name, 
      credentials, 
      emailAccount,
      flowResults
    );
    
    if (!signupResult.success) {
      throw new Error(signupResult.error || 'Failed to complete signup process');
    }
    
    // Take final screenshot
    const finalScreenshotPath = `./screenshots/${credentials.username}-complete.png`;
    await page.screenshot({ path: finalScreenshotPath });
    
    // Check for verification email if needed
    if (!flowResults.emailVerified && emailAccount) {
      console.log("Waiting for verification email...");
      
      const verificationLink = await disposableEmail.waitForVerificationLink(
        trialData.service_name,
        180000 // 3 minutes timeout
      );
      
      if (verificationLink) {
        console.log(`Found verification link: ${verificationLink}`);
        
        // Open new page for verification
        const verifyPage = await browser.newPage();
        await verifyPage.goto(verificationLink, { waitUntil: 'networkidle2' });
        
        // Wait for verification to complete
        await verifyPage.waitForTimeout(5000);
        
        // Take screenshot of verification
        const verifyScreenshotPath = `./screenshots/${credentials.username}-verify.png`;
        await verifyPage.screenshot({ path: verifyScreenshotPath });
        
        flowResults.emailVerified = true;
      } else {
        console.log("No verification email received within timeout");
      }
    }
    
    // Update trial data with credentials and completion status
    await storage.updateAutomatedTrial(trialData.id, {
      status: "completed",
      completed_at: new Date(),
      credentials: {
        ...credentials,
        phone_number: flowResults.phoneVerification?.phoneNumber
      },
      result_message: `Successfully created trial account${flowResults.emailVerified ? ' and verified email' : ''}`,
      is_valid: true
    });
    
    // Update proxy stats if used
    if (proxy) {
      await proxyManager.updateProxyStats(proxy.id, true);
    }
    
    await browser.close();
    
    // Clean up browser session
    fs.rmSync(userDataDir, { recursive: true, force: true });
    
    return {
      success: true,
      credentials: {
        ...credentials,
        phone_number: flowResults.phoneVerification?.phoneNumber
      },
      data: signupResult.data,
      screenshot_path: finalScreenshotPath
    };
  } catch (error: any) {
    console.error(`Error in automated trial signup:`, error);
    
    // Take error screenshot if browser is open
    let errorScreenshotPath = '';
    if (browser) {
      try {
        const pages = await browser.pages();
        if (pages.length > 0) {
          errorScreenshotPath = `./screenshots/error-${Date.now()}.png`;
          await pages[0].screenshot({ path: errorScreenshotPath });
        }
      } catch (screenshotError) {
        console.error("Failed to take error screenshot:", screenshotError);
      }
    }
    
    // Update trial data with error information
    if (trialData.id) {
      await storage.updateAutomatedTrial(trialData.id, {
        status: "failed",
        completed_at: new Date(),
        result_message: error.message || "Failed to create trial account",
        screenshot_path: errorScreenshotPath || undefined
      });
    }
    
    // Update proxy stats if used
    if (proxy) {
      await proxyManager.updateProxyStats(proxy.id, false);
    }
    
    if (browser) {
      await browser.close();
    }
    
    return {
      success: false,
      error: error.message || "An unknown error occurred",
      screenshot_path: errorScreenshotPath
    };
  }
};

/**
 * Handle captcha if present on the page
 */
async function handleCaptcha(page: any): Promise<boolean> {
  try {
    // Check for reCAPTCHA v2
    const recaptchaFrame = await page.frames().find((frame: any) => 
      frame.url().includes('recaptcha/api2/anchor') || 
      frame.url().includes('recaptcha/api2/bframe')
    );
    
    if (recaptchaFrame) {
      console.log("Detected reCAPTCHA v2");
      
      // Extract site key
      const siteKey = await page.evaluate(() => {
        const recaptchaElements = Array.from(document.querySelectorAll('div.g-recaptcha, .grecaptcha-badge'));
        for (const el of recaptchaElements) {
          const siteKey = el.getAttribute('data-sitekey');
          if (siteKey) return siteKey;
        }
        return null;
      });
      
      if (!siteKey) {
        console.log("Could not find reCAPTCHA site key");
        return false;
      }
      
      // Solve the captcha
      const captchaResult = await captchaSolver.solveRecaptchaV2(
        siteKey,
        page.url()
      );
      
      if (captchaResult.success) {
        // Execute the reCAPTCHA callback function with our solution
        await page.evaluate((recaptchaResponse: string) => {
          // @ts-ignore
          window.grecaptcha.enterprise?.reset();
          // @ts-ignore
          window.___grecaptcha_cfg.clients[0].M.M.callback(recaptchaResponse);
        }, captchaResult.solution);
        
        // Wait for page to process the captcha
        await page.waitForTimeout(3000);
        return true;
      }
    }
    
    // Check for reCAPTCHA v3
    const hasRecaptchaV3 = await page.evaluate(() => {
      return !!window.grecaptcha?.enterprise || !!window.grecaptcha?.execute;
    });
    
    if (hasRecaptchaV3) {
      console.log("Detected reCAPTCHA v3");
      
      // Extract site key - harder for v3 as it's usually in page scripts
      const siteKey = await page.evaluate(() => {
        // Look in script tags
        const scripts = Array.from(document.getElementsByTagName('script'));
        for (const script of scripts) {
          const content = script.textContent || script.innerText;
          if (content.includes('recaptcha')) {
            const match = content.match(/['"]([0-9A-Za-z_-]{40})['"]/) || 
                         content.match(/sitekey=['"]([0-9A-Za-z_-]{40})['"]/);
            if (match) return match[1];
          }
        }
        return null;
      });
      
      if (siteKey) {
        const captchaResult = await captchaSolver.solveRecaptchaV3(
          siteKey,
          page.url()
        );
        
        if (captchaResult.success) {
          // For v3, we usually need to add the token to a form field
          await page.evaluate((token: string) => {
            // Look for hidden input field for g-recaptcha-response
            const tokenField = document.querySelector('input[name="g-recaptcha-response"]');
            if (tokenField) {
              // @ts-ignore
              tokenField.value = token;
            } else {
              // Create a hidden field if it doesn't exist
              const input = document.createElement('input');
              input.type = 'hidden';
              input.name = 'g-recaptcha-response';
              input.value = token;
              document.querySelector('form')?.appendChild(input);
            }
          }, captchaResult.solution);
          
          return true;
        }
      }
    }
    
    // Check for hCaptcha
    const hcaptchaFrame = await page.frames().find((frame: any) => 
      frame.url().includes('hcaptcha.com/captcha')
    );
    
    if (hcaptchaFrame) {
      console.log("Detected hCaptcha");
      
      const siteKey = await page.evaluate(() => {
        const hcaptchaElement = document.querySelector('[data-sitekey]');
        return hcaptchaElement ? hcaptchaElement.getAttribute('data-sitekey') : null;
      });
      
      if (siteKey) {
        const captchaResult = await captchaSolver.solveHCaptcha(
          siteKey,
          page.url()
        );
        
        if (captchaResult.success) {
          await page.evaluate((token: string) => {
            // @ts-ignore
            window.hcaptcha?.setResponse(token);
            
            // Also set the hidden field
            const tokenField = document.querySelector('textarea[name="h-captcha-response"]');
            if (tokenField) {
              // @ts-ignore
              tokenField.value = token;
            }
            
            // Trigger form submission
            document.querySelector('form')?.submit();
          }, captchaResult.solution);
          
          await page.waitForTimeout(3000);
          return true;
        }
      }
    }
    
    // Check for image-based text CAPTCHAs
    const captchaImages = await page.$$('img[src*="captcha"], img[alt*="captcha"], img[id*="captcha"]');
    if (captchaImages.length > 0) {
      console.log("Detected image-based CAPTCHA");
      
      // Get the image
      const captchaImage = captchaImages[0];
      const imageBase64 = await page.evaluate(async (img: any) => {
        // Create a canvas to draw the image
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        // Create a new image object
        const imgObj = new Image();
        imgObj.src = img.src;
        
        // Create a promise to wait for image to load
        return new Promise((resolve) => {
          imgObj.onload = () => {
            canvas.width = imgObj.width;
            canvas.height = imgObj.height;
            ctx?.drawImage(imgObj, 0, 0);
            resolve(canvas.toDataURL('image/png').split(',')[1]);
          };
        });
      }, captchaImage);
      
      if (imageBase64) {
        const captchaResult = await captchaSolver.solveImageCaptcha("", imageBase64);
        
        if (captchaResult.success) {
          // Find the input field for captcha
          const captchaInputs = await page.$$('input[name*="captcha"], input[id*="captcha"], input[placeholder*="captcha"]');
          if (captchaInputs.length > 0) {
            await captchaInputs[0].type(captchaResult.solution);
            
            // Find and click submit button
            const submitButtons = await page.$$('button[type="submit"], input[type="submit"], button:contains("Submit"), button:contains("Verify")');
            if (submitButtons.length > 0) {
              await submitButtons[0].click();
              await page.waitForTimeout(3000);
              return true;
            }
          }
        }
      }
    }
    
    return false;
  } catch (error) {
    console.error("Error handling CAPTCHA:", error);
    return false;
  }
}

/**
 * Execute service-specific signup workflow
 * This would be expanded with rules for different services
 */
async function executeSignupWorkflow(
  page: any, 
  serviceName: string, 
  credentials: any, 
  emailAccount: any,
  flowResults: any
): Promise<ScraperResponse> {
  try {
    // Normalize service name for standardized matching
    const service = serviceName.toLowerCase().trim();
    
    // Different workflows based on the target service
    if (service.includes('netflix')) {
      return await netflixSignupFlow(page, credentials, emailAccount, flowResults);
    } else if (service.includes('spotify')) {
      return await spotifySignupFlow(page, credentials, emailAccount, flowResults);
    } else if (service.includes('amazon') || service.includes('prime')) {
      return await amazonPrimeSignupFlow(page, credentials, emailAccount, flowResults);
    } else if (service.includes('disney')) {
      return await disneyPlusSignupFlow(page, credentials, emailAccount, flowResults);
    } else if (service.includes('hulu')) {
      return await huluSignupFlow(page, credentials, emailAccount, flowResults);
    } else {
      // Generic signup flow for unrecognized services
      return await genericSignupFlow(page, credentials, emailAccount, flowResults);
    }
  } catch (error: any) {
    console.error(`Error in signup workflow for ${serviceName}:`, error);
    return { 
      success: false, 
      error: `Failed to complete ${serviceName} signup: ${error.message}` 
    };
  }
}

/**
 * Generic signup flow for unknown services
 * Attempts to find common signup form elements
 */
async function genericSignupFlow(page: any, credentials: any): Promise<ScraperResponse> {
  try {
    // Look for common signup/register links
    const signupSelectors = [
      'a[href*="signup"]', 
      'a[href*="register"]', 
      'a[href*="trial"]',
      'button:contains("Sign up")', 
      'button:contains("Register")', 
      'button:contains("Try")'
    ];
    
    // Try to find and click on a signup link
    for (const selector of signupSelectors) {
      const found = await page.$(selector);
      if (found) {
        await found.click();
        await page.waitForNavigation({ waitUntil: 'networkidle2' });
        break;
      }
    }
    
    // Look for common form fields
    await page.waitForTimeout(2000); // Wait for form to be fully loaded
    
    // Try to fill email field
    const emailSelectors = ['input[type="email"]', 'input[name*="email"]', 'input[id*="email"]'];
    for (const selector of emailSelectors) {
      const emailField = await page.$(selector);
      if (emailField) {
        await emailField.type(credentials.email);
        break;
      }
    }
    
    // Try to fill username field if present
    const usernameSelectors = [
      'input[name*="username"]', 
      'input[id*="username"]', 
      'input[name*="user"]', 
      'input[id*="user"]'
    ];
    for (const selector of usernameSelectors) {
      const usernameField = await page.$(selector);
      if (usernameField) {
        await usernameField.type(credentials.username);
        break;
      }
    }
    
    // Try to fill password fields
    const passwordSelectors = [
      'input[type="password"]', 
      'input[name*="password"]', 
      'input[id*="password"]', 
      'input[name*="pass"]', 
      'input[id*="pass"]'
    ];
    
    let pwFields = 0;
    for (const selector of passwordSelectors) {
      const passwordFields = await page.$$(selector);
      for (const field of passwordFields) {
        await field.type(credentials.password);
        pwFields++;
      }
      if (pwFields > 0) break;
    }
    
    // Try to click submit button
    const submitSelectors = [
      'button[type="submit"]', 
      'input[type="submit"]', 
      'button:contains("Sign up")', 
      'button:contains("Register")', 
      'button:contains("Continue")', 
      'button:contains("Next")'
    ];
    
    for (const selector of submitSelectors) {
      const submitButton = await page.$(selector);
      if (submitButton) {
        await submitButton.click();
        await page.waitForNavigation({ waitUntil: 'networkidle2' }).catch(() => {});
        break;
      }
    }
    
    await page.waitForTimeout(5000); // Wait for redirect/confirmation
    
    // Take screenshot for verification
    await page.screenshot({ path: `./screenshots/${credentials.username}-signup.png` });
    
    return { 
      success: true,
      data: { 
        url: page.url(),
        title: await page.title()
      }
    };
  } catch (error: any) {
    console.error("Error in generic signup flow:", error);
    return { 
      success: false, 
      error: `Generic signup failed: ${error.message}` 
    };
  }
}

/**
 * Netflix-specific signup flow
 */
async function netflixSignupFlow(page: any, credentials: any): Promise<ScraperResponse> {
  try {
    // Look for email input on first page
    await page.waitForSelector('input[name="email"]', { timeout: 10000 });
    await page.type('input[name="email"]', credentials.email);
    
    // Click the get started or continue button
    await page.click('button.nf-btn-primary');
    await page.waitForNavigation({ waitUntil: 'networkidle2' });
    
    // Fill password on next page
    await page.waitForSelector('input[name="password"]', { timeout: 10000 });
    await page.type('input[name="password"]', credentials.password);
    
    // Continue to next step
    await page.click('button.nf-btn-primary');
    await page.waitForNavigation({ waitUntil: 'networkidle2' });
    
    // Select a plan (typically choosing the basic plan)
    const planSelectors = await page.$$('button.nf-btn-primary');
    if (planSelectors.length > 0) {
      await planSelectors[0].click();
      await page.waitForNavigation({ waitUntil: 'networkidle2' });
    }
    
    // Take screenshot for verification
    await page.screenshot({ path: `./screenshots/netflix-${credentials.username}.png` });
    
    return { 
      success: true,
      data: { 
        url: page.url(),
        title: await page.title()
      }
    };
  } catch (error: any) {
    console.error("Error in Netflix signup flow:", error);
    return { 
      success: false, 
      error: `Netflix signup failed: ${error.message}` 
    };
  }
}

/**
 * Spotify-specific signup flow
 */
async function spotifySignupFlow(page: any, credentials: any): Promise<ScraperResponse> {
  // Implementation specific to Spotify
  return { success: false, error: "Spotify workflow not yet implemented" };
}

/**
 * Amazon Prime-specific signup flow
 */
async function amazonPrimeSignupFlow(page: any, credentials: any): Promise<ScraperResponse> {
  // Implementation specific to Amazon Prime
  return { success: false, error: "Amazon Prime workflow not yet implemented" };
}

/**
 * Disney Plus-specific signup flow
 */
async function disneyPlusSignupFlow(page: any, credentials: any): Promise<ScraperResponse> {
  // Implementation specific to Disney+
  return { success: false, error: "Disney+ workflow not yet implemented" };
}

/**
 * Hulu-specific signup flow
 */
async function huluSignupFlow(page: any, credentials: any): Promise<ScraperResponse> {
  // Implementation specific to Hulu
  return { success: false, error: "Hulu workflow not yet implemented" };
}

/**
 * Generate random credentials for trial signup
 */
function generateRandomCredentials(serviceName: string) {
  const randomString = Math.random().toString(36).substring(2, 10);
  const domains = ["tempmail.io", "burnerbox.app", "disposable.cc", "throwmail.org"];
  const domain = domains[Math.floor(Math.random() * domains.length)];
  
  return {
    username: `user_${randomString}`,
    password: `Pass${randomString}${Math.floor(Math.random() * 1000)}!`,
    email: `${randomString}@${domain}`
  };
}

/**
 * Register web scraper routes
 */
export function registerWebScraperRoutes(app: Express) {
  // Start new automated trial
  app.post("/api/trials/start/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ 
          success: false, 
          error: "Authentication required" 
        });
      }
      
      const trialId = parseInt(req.params.id);
      if (isNaN(trialId)) {
        return res.status(400).json({ 
          success: false, 
          error: "Invalid trial ID" 
        });
      }
      
      // Get trial data
      const trial = await storage.getAutomatedTrial(trialId);
      if (!trial) {
        return res.status(404).json({ 
          success: false, 
          error: "Trial not found" 
        });
      }
      
      // Only allow the user who created the trial or admins to start it
      if (trial.user_id !== (req.user as any).id && !(req.user as any).is_admin) {
        return res.status(403).json({ 
          success: false, 
          error: "Access denied" 
        });
      }
      
      // Check if the trial is already started or completed
      if (trial.status !== "queued") {
        return res.status(400).json({ 
          success: false, 
          error: `Trial is already ${trial.status}` 
        });
      }
      
      // Check user's subscription limits
      const subscription = await storage.getActiveSubscriptionByUserId((req.user as any).id);
      if (!subscription) {
        return res.status(403).json({ 
          success: false, 
          error: "Active subscription required" 
        });
      }
      
      // Enforce trial limits based on subscription tier
      const monthStart = new Date();
      monthStart.setDate(1);
      monthStart.setHours(0, 0, 0, 0);
      
      const trials = await storage.getAutomatedTrialsByUserId((req.user as any).id);
      const monthlyTrials = trials.filter(t => 
        new Date(t.created_at) >= monthStart && 
        (t.status === "completed" || t.status === "in_progress")
      );
      
      if (subscription.tier === "basic" && monthlyTrials.length >= 5) {
        return res.status(403).json({ 
          success: false, 
          error: "Basic subscription limited to 5 automated trials per month" 
        });
      } else if (subscription.tier === "pro" && monthlyTrials.length >= 25) {
        return res.status(403).json({ 
          success: false, 
          error: "Pro subscription limited to 25 automated trials per month" 
        });
      }
      
      // Update trial status to in_progress
      await storage.updateAutomatedTrial(trialId, {
        status: "in_progress"
      });
      
      // Start the automation process in the background
      automateTrialSignup(trial).catch(error => {
        console.error(`Background task error for trial ${trialId}:`, error);
      });
      
      res.json({ 
        success: true, 
        message: "Trial automation started" 
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        error: error.message || "Internal server error" 
      });
    }
  });
  
  // Get automated trial results
  app.get("/api/trials/results/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ 
          success: false, 
          error: "Authentication required" 
        });
      }
      
      const trialId = parseInt(req.params.id);
      if (isNaN(trialId)) {
        return res.status(400).json({ 
          success: false, 
          error: "Invalid trial ID" 
        });
      }
      
      // Get trial data
      const trial = await storage.getAutomatedTrial(trialId);
      if (!trial) {
        return res.status(404).json({ 
          success: false, 
          error: "Trial not found" 
        });
      }
      
      // Only allow the user who created the trial or admins to view results
      if (trial.user_id !== (req.user as any).id && !(req.user as any).is_admin) {
        return res.status(403).json({ 
          success: false, 
          error: "Access denied" 
        });
      }
      
      res.json({ 
        success: true, 
        trial 
      });
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        error: error.message || "Internal server error" 
      });
    }
  });
  
  // Bulk trial execution API (enterprise tier only)
  app.post("/api/trials/bulk-start", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ 
          success: false, 
          error: "Authentication required" 
        });
      }
      
      // Check if user has enterprise subscription
      const subscription = await storage.getActiveSubscriptionByUserId((req.user as any).id);
      if (!subscription || subscription.tier !== "enterprise") {
        return res.status(403).json({ 
          success: false, 
          error: "Enterprise subscription required for bulk trial execution" 
        });
      }
      
      const { trialIds } = req.body;
      
      if (!Array.isArray(trialIds) || trialIds.length === 0) {
        return res.status(400).json({ 
          success: false, 
          error: "No trial IDs provided" 
        });
      }
      
      const results = {
        success: true,
        started: 0,
        failed: 0,
        errors: [] as string[]
      };
      
      // Process each trial
      for (const id of trialIds) {
        const trialId = parseInt(id);
        if (isNaN(trialId)) {
          results.failed++;
          results.errors.push(`Invalid trial ID: ${id}`);
          continue;
        }
        
        try {
          // Get trial data
          const trial = await storage.getAutomatedTrial(trialId);
          if (!trial) {
            results.failed++;
            results.errors.push(`Trial not found: ${trialId}`);
            continue;
          }
          
          // Verify ownership
          if (trial.user_id !== (req.user as any).id) {
            results.failed++;
            results.errors.push(`Access denied for trial: ${trialId}`);
            continue;
          }
          
          // Check status
          if (trial.status !== "queued") {
            results.failed++;
            results.errors.push(`Trial ${trialId} is already ${trial.status}`);
            continue;
          }
          
          // Update status and start automation
          await storage.updateAutomatedTrial(trialId, {
            status: "in_progress"
          });
          
          // Start in background
          automateTrialSignup(trial).catch(error => {
            console.error(`Background task error for trial ${trialId}:`, error);
          });
          
          results.started++;
        } catch (error: any) {
          results.failed++;
          results.errors.push(`Error processing trial ${trialId}: ${error.message}`);
        }
      }
      
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        error: error.message || "Internal server error" 
      });
    }
  });
}
