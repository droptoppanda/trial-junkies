import fs from 'fs';
import path from 'path';
import { setupEnvironmentSchema } from '@shared/schema';
import { execSync } from 'child_process';
import { storage } from './storage';

type EnvironmentSetup = typeof setupEnvironmentSchema._type;

/**
 * SetupService
 * 
 * Handles environment configuration management:
 * - Saves configurations to database and .env file
 * - Retrieves current configuration from environment and database
 * - Tests environment configuration
 */
class SetupService {
  private envPath: string;
  
  constructor() {
    // Path to .env file (at the root of the project)
    this.envPath = path.resolve(process.cwd(), '.env');
  }
  
  /**
   * Get current environment configuration
   * Merges values from .env file and database
   */
  async getConfiguration(): Promise<EnvironmentSetup> {
    try {
      // Load environment variables from .env file
      this.loadEnvFile();
      
      // Try to get saved configuration from database
      const dbConfig = await storage.getEnvironmentConfig();
      
      // Default configuration
      const defaultConfig: EnvironmentSetup = {
        solana_receiver_public_key: process.env.SOLANA_RECEIVER_PUBLIC_KEY || '',
        mock_solana_verification: process.env.MOCK_SOLANA_VERIFICATION === 'true',
        enable_sms_verification: process.env.ENABLE_SMS_VERIFICATION === 'true',
        sms_provider: process.env.SMS_PROVIDER || '',
        sms_api_key: process.env.SMS_API_KEY || '',
        sms_sender_id: process.env.SMS_SENDER_ID || '',
        enable_email_verification: process.env.ENABLE_EMAIL_VERIFICATION === 'true',
        email_provider: process.env.EMAIL_PROVIDER || '',
        email_api_key: process.env.EMAIL_API_KEY || '',
        email_sender: process.env.EMAIL_SENDER || '',
        enable_proxy: process.env.ENABLE_PROXY === 'true',
        proxy_provider: process.env.PROXY_PROVIDER || '',
        proxy_api_key: process.env.PROXY_API_KEY || '',
        proxy_country: process.env.PROXY_COUNTRY || '',
        database_type: process.env.DATABASE_TYPE || 'postgres',
        database_url: process.env.DATABASE_URL || '',
        enable_web_scraping: process.env.ENABLE_WEB_SCRAPING !== 'false',
        enable_captcha_solver: process.env.ENABLE_CAPTCHA_SOLVER === 'true',
        enable_discord_integration: process.env.ENABLE_DISCORD_INTEGRATION === 'true',
        development_mode: process.env.DEVELOPMENT_MODE !== 'false',
      };
      
      // Merge with database configuration (if exists)
      if (dbConfig) {
        return { ...defaultConfig, ...dbConfig };
      }
      
      return defaultConfig;
    } catch (error) {
      console.error('Error reading configuration:', error);
      throw new Error('Failed to retrieve environment configuration');
    }
  }
  
  /**
   * Save environment configuration
   * @param config Configuration data to save
   */
  async saveConfiguration(config: EnvironmentSetup): Promise<void> {
    try {
      // Update database config
      await storage.saveEnvironmentConfig(config);
      
      // Update .env file
      await this.updateEnvFile(config);
      
      console.log('Configuration saved successfully');
    } catch (error) {
      console.error('Error saving configuration:', error);
      throw new Error('Failed to save environment configuration');
    }
  }
  
  /**
   * Test environment configuration
   * @param config Configuration to test
   */
  async testConfiguration(config: EnvironmentSetup): Promise<{
    success: boolean;
    message: string;
    details?: Record<string, boolean>;
  }> {
    const testResults: Record<string, boolean> = {};
    
    // Test Solana configuration
    if (config.solana_receiver_public_key) {
      testResults.solana = this.isValidSolanaPublicKey(config.solana_receiver_public_key);
    } else {
      testResults.solana = false;
    }
    
    // Test SMS verification configuration
    testResults.sms = !config.enable_sms_verification || 
      (!!config.sms_provider && !!config.sms_api_key);
    
    // Test Email verification configuration
    testResults.email = !config.enable_email_verification || 
      (!!config.email_provider && !!config.email_api_key);
    
    // Test Proxy configuration
    testResults.proxy = !config.enable_proxy || 
      (!!config.proxy_provider && !!config.proxy_api_key);
    
    // Test Database configuration
    testResults.database = !!config.database_url;
    
    // Overall success
    const success = Object.values(testResults).every(Boolean);
    
    return {
      success,
      message: success 
        ? 'Configuration tests passed successfully' 
        : 'Some configuration tests failed. Please check the details.',
      details: testResults
    };
  }
  
  /**
   * Update the .env file with new configuration
   * @param config Configuration data
   */
  private async updateEnvFile(config: EnvironmentSetup): Promise<void> {
    try {
      // Read existing .env file or create empty string if it doesn't exist
      let envContent = '';
      try {
        envContent = fs.existsSync(this.envPath) 
          ? fs.readFileSync(this.envPath, 'utf8')
          : '';
      } catch (error) {
        console.log('Creating new .env file');
      }
      
      // Create map of environment variables
      const envMap = new Map<string, string>();
      
      // Parse existing variables
      envContent.split('\n').forEach(line => {
        const match = line.match(/^([^=]+)=(.*)$/);
        if (match) {
          const [, key, value] = match;
          envMap.set(key.trim(), value.trim());
        }
      });
      
      // Update with new values
      envMap.set('SOLANA_RECEIVER_PUBLIC_KEY', config.solana_receiver_public_key);
      envMap.set('MOCK_SOLANA_VERIFICATION', config.mock_solana_verification.toString());
      
      envMap.set('ENABLE_SMS_VERIFICATION', config.enable_sms_verification.toString());
      if (config.enable_sms_verification) {
        envMap.set('SMS_PROVIDER', config.sms_provider || '');
        envMap.set('SMS_API_KEY', config.sms_api_key || '');
        envMap.set('SMS_SENDER_ID', config.sms_sender_id || '');
      }
      
      envMap.set('ENABLE_EMAIL_VERIFICATION', config.enable_email_verification.toString());
      if (config.enable_email_verification) {
        envMap.set('EMAIL_PROVIDER', config.email_provider || '');
        envMap.set('EMAIL_API_KEY', config.email_api_key || '');
        envMap.set('EMAIL_SENDER', config.email_sender || '');
      }
      
      envMap.set('ENABLE_PROXY', config.enable_proxy.toString());
      if (config.enable_proxy) {
        envMap.set('PROXY_PROVIDER', config.proxy_provider || '');
        envMap.set('PROXY_API_KEY', config.proxy_api_key || '');
        envMap.set('PROXY_COUNTRY', config.proxy_country || '');
      }
      
      envMap.set('DATABASE_TYPE', config.database_type || 'postgres');
      // Don't overwrite DATABASE_URL as it's provided by Replit
      
      envMap.set('ENABLE_WEB_SCRAPING', config.enable_web_scraping.toString());
      envMap.set('ENABLE_CAPTCHA_SOLVER', config.enable_captcha_solver.toString());
      envMap.set('ENABLE_DISCORD_INTEGRATION', config.enable_discord_integration.toString());
      envMap.set('DEVELOPMENT_MODE', config.development_mode.toString());
      
      // Convert map back to .env format
      const newEnvContent = Array.from(envMap.entries())
        .map(([key, value]) => `${key}=${value}`)
        .join('\n');
      
      // Write .env file
      fs.writeFileSync(this.envPath, newEnvContent);
      
      console.log('.env file updated successfully');
    } catch (error) {
      console.error('Error updating .env file:', error);
      throw new Error('Failed to update .env file');
    }
  }
  
  /**
   * Load environment variables from .env file
   */
  private loadEnvFile(): void {
    try {
      if (fs.existsSync(this.envPath)) {
        const envContent = fs.readFileSync(this.envPath, 'utf8');
        
        // Parse variables and set them in process.env
        envContent.split('\n').forEach(line => {
          const match = line.match(/^([^=]+)=(.*)$/);
          if (match) {
            const [, key, value] = match;
            process.env[key.trim()] = value.trim();
          }
        });
      }
    } catch (error) {
      console.error('Error loading .env file:', error);
    }
  }

  /**
   * Validate Solana public key format
   * @param publicKey Solana public key to validate
   */
  private isValidSolanaPublicKey(publicKey: string): boolean {
    // Basic validation: Solana public keys are base58-encoded and 32-44 characters long
    const solanaKeyRegex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
    return solanaKeyRegex.test(publicKey);
  }
}

export const setupService = new SetupService();