
import axios from "axios";
import { Proxy } from "@shared/schema";
import { storage } from "./storage";

/**
 * Proxy Manager Service
 * Handles proxy rotation, validation, and management
 */
export class ProxyManager {
  private proxyList: Proxy[] = [];
  private bannedProxies: Set<string> = new Set();
  private currentIndex: number = 0;
  
  /**
   * Initialize the proxy manager with available proxies
   */
  public async initialize(): Promise<void> {
    try {
      // Load proxies from storage
      this.proxyList = await storage.getAllProxies();
      
      if (this.proxyList.length === 0) {
        // If no proxies in storage, try to fetch some free ones as a fallback
        await this.fetchFreeProxies();
      }
      
      console.log(`Proxy manager initialized with ${this.proxyList.length} proxies`);
    } catch (error) {
      console.error("Failed to initialize proxy manager:", error);
    }
  }
  
  /**
   * Get the next available proxy
   */
  public getNextProxy(): Proxy | null {
    if (this.proxyList.length === 0) {
      return null;
    }
    
    // Try up to all proxies in the list
    for (let i = 0; i < this.proxyList.length; i++) {
      this.currentIndex = (this.currentIndex + 1) % this.proxyList.length;
      const proxy = this.proxyList[this.currentIndex];
      
      // Skip banned proxies
      if (this.bannedProxies.has(this.getProxyKey(proxy))) {
        continue;
      }
      
      return proxy;
    }
    
    return null; // All proxies are banned
  }
  
  /**
   * Mark a proxy as banned/invalid
   */
  public banProxy(proxy: Proxy): void {
    const proxyKey = this.getProxyKey(proxy);
    this.bannedProxies.add(proxyKey);
    console.log(`Banned proxy: ${proxyKey}`);
  }
  
  /**
   * Reset banned proxies
   */
  public resetBannedProxies(): void {
    this.bannedProxies.clear();
    console.log("Reset banned proxies list");
  }
  
  /**
   * Add a new proxy to the pool
   */
  public async addProxy(proxy: Proxy): Promise<void> {
    // Check if proxy already exists
    const proxyKey = this.getProxyKey(proxy);
    const exists = this.proxyList.some(p => this.getProxyKey(p) === proxyKey);
    
    if (!exists) {
      // Validate proxy before adding
      if (await this.validateProxy(proxy)) {
        // Add to storage
        const savedProxy = await storage.createProxy(proxy);
        
        // Add to in-memory list
        this.proxyList.push(savedProxy);
        console.log(`Added new proxy: ${proxyKey}`);
      } else {
        console.log(`Rejected invalid proxy: ${proxyKey}`);
      }
    }
  }
  
  /**
   * Remove a proxy from the pool
   */
  public async removeProxy(proxyId: number): Promise<void> {
    // Remove from storage
    await storage.deleteProxy(proxyId);
    
    // Remove from in-memory list
    this.proxyList = this.proxyList.filter(p => p.id !== proxyId);
    console.log(`Removed proxy with ID: ${proxyId}`);
  }
  
  /**
   * Validate a proxy by testing its connectivity
   */
  public async validateProxy(proxy: Proxy): Promise<boolean> {
    try {
      const proxyConfig = {
        host: proxy.host,
        port: proxy.port,
        auth: proxy.username && proxy.password ? {
          username: proxy.username,
          password: proxy.password
        } : undefined
      };
      
      const proxyUrl = `${proxy.protocol || 'http'}://${proxy.host}:${proxy.port}`;
      
      // Try to connect to an external API using the proxy
      const response = await axios.get('https://api.ipify.org?format=json', {
        proxy: proxyConfig,
        timeout: 10000 // 10 second timeout
      });
      
      return response.status === 200;
    } catch (error) {
      console.error(`Proxy validation failed for ${proxy.host}:${proxy.port}:`, error);
      return false;
    }
  }
  
  /**
   * Get a unique key for a proxy
   */
  private getProxyKey(proxy: Proxy): string {
    return `${proxy.protocol || 'http'}://${proxy.host}:${proxy.port}`;
  }
  
  /**
   * Fetch free proxies from public APIs
   */
  private async fetchFreeProxies(): Promise<void> {
    try {
      // Try to fetch proxies from ProxyScrape
      const response = await axios.get('https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all&simplified=true');
      
      if (response.status === 200 && response.data) {
        const proxyList = response.data.split('\n').filter(Boolean);
        
        for (const proxyString of proxyList) {
          const [host, port] = proxyString.split(':');
          
          if (host && port) {
            const proxy: Proxy = {
              id: 0, // Will be set by storage
              host,
              port: parseInt(port, 10),
              protocol: 'http',
              country: 'unknown',
              is_residential: false,
              last_used: new Date(),
              success_count: 0,
              fail_count: 0,
              created_at: new Date()
            };
            
            // Validate before adding
            if (await this.validateProxy(proxy)) {
              const savedProxy = await storage.createProxy(proxy);
              this.proxyList.push(savedProxy);
            }
            
            // Limit to 20 valid proxies to avoid overloading the system
            if (this.proxyList.length >= 20) {
              break;
            }
          }
        }
      }
    } catch (error) {
      console.error("Failed to fetch free proxies:", error);
    }
  }
  
  /**
   * Convert a proxy to a URL string
   */
  public getProxyUrl(proxy: Proxy): string {
    if (proxy.username && proxy.password) {
      return `${proxy.protocol || 'http'}://${proxy.username}:${proxy.password}@${proxy.host}:${proxy.port}`;
    }
    return `${proxy.protocol || 'http'}://${proxy.host}:${proxy.port}`;
  }
  
  /**
   * Get puppeteer proxy args
   */
  public getPuppeteerProxyArgs(proxy: Proxy): string[] {
    if (!proxy) return [];
    
    const proxyUrl = this.getProxyUrl(proxy);
    return [`--proxy-server=${proxyUrl}`];
  }
  
  /**
   * Update proxy performance stats
   */
  public async updateProxyStats(proxyId: number, success: boolean): Promise<void> {
    const proxy = this.proxyList.find(p => p.id === proxyId);
    
    if (proxy) {
      if (success) {
        proxy.success_count++;
      } else {
        proxy.fail_count++;
      }
      
      proxy.last_used = new Date();
      
      // Update in storage
      await storage.updateProxy(proxyId, {
        success_count: proxy.success_count,
        fail_count: proxy.fail_count,
        last_used: proxy.last_used
      });
    }
  }
}

// Singleton instance for use throughout the app
export const proxyManager = new ProxyManager();
