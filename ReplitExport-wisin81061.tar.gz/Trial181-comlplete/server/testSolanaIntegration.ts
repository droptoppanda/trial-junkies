/**
 * Test file for Solana payment integration
 * 
 * This file tests the Solana payment service and API routes
 */

import solanaPaymentService from './solanaPaymentService';

/**
 * Test Solana payment service configuration
 */
async function testSolanaConfig() {
  console.log('Testing Solana Payment Service Configuration...');
  
  // Test network info
  const networkInfo = solanaPaymentService.getNetworkInfo();
  console.log('Network info:', networkInfo);
  
  // Test configuration status
  const isConfigured = solanaPaymentService.isConfigured();
  console.log('Is configured:', isConfigured);
  
  // Test receiver wallet
  const receiverWallet = solanaPaymentService.getReceiverWallet();
  console.log('Receiver wallet info:', {
    address: receiverWallet.address ? 
      `${receiverWallet.address.substring(0, 4)}...${receiverWallet.address.slice(-4)}` : 
      'Not configured',
    network: receiverWallet.network,
    isValid: receiverWallet.isValid
  });
  
  return isConfigured;
}

/**
 * Test payment request creation
 */
async function testPaymentCreation() {
  console.log('\nTesting Payment Request Creation...');
  
  const amount = 0.5; // SOL
  const metadata = {
    productName: 'Premium Subscription',
    customerId: 'user_123',
    orderId: 'order_' + Date.now()
  };
  
  const paymentRequest = solanaPaymentService.createPaymentRequest(amount, metadata);
  console.log('Payment request created:', {
    paymentId: paymentRequest.paymentId,
    amount: paymentRequest.amount,
    receiverAddress: paymentRequest.receiverAddress ? 
      `${paymentRequest.receiverAddress.substring(0, 4)}...${paymentRequest.receiverAddress.slice(-4)}` : 
      'Not configured',
    mockMode: paymentRequest.mockMode
  });
  
  return paymentRequest;
}

/**
 * Test transaction verification
 */
async function testTransactionVerification(paymentRequest: any) {
  console.log('\nTesting Transaction Verification...');
  
  // Generate a mock transaction ID for testing
  const mockValidTxId = `mock_valid_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
  const mockInvalidTxId = `mock_invalid_${Date.now()}`;
  
  // Test valid transaction
  console.log('Testing valid transaction verification...');
  const validResult = await solanaPaymentService.verifyTransaction(
    mockValidTxId,
    paymentRequest.amount,
    paymentRequest.paymentId
  );
  console.log('Valid transaction result:', validResult);
  
  // Test invalid transaction
  console.log('\nTesting invalid transaction verification...');
  const invalidResult = await solanaPaymentService.verifyTransaction(
    mockInvalidTxId,
    paymentRequest.amount,
    paymentRequest.paymentId
  );
  console.log('Invalid transaction result:', invalidResult);
  
  return validResult.success;
}

/**
 * Test payment status
 */
async function testPaymentStatus(paymentId: string) {
  console.log('\nTesting Payment Status...');
  
  const paymentStatus = solanaPaymentService.getPaymentStatus(paymentId);
  console.log('Payment status:', paymentStatus);
  
  return paymentStatus.success;
}

/**
 * Run all Solana integration tests
 */
export async function testSolanaIntegration() {
  console.log('===== SOLANA PAYMENT INTEGRATION TESTS =====\n');
  
  try {
    // Test configuration
    const configResult = await testSolanaConfig();
    if (!configResult) {
      console.warn('⚠️ Configuration test failed. Some tests may not work correctly.');
    } else {
      console.log('✅ Configuration test passed');
    }
    
    // Test payment creation
    const paymentRequest = await testPaymentCreation();
    console.log('✅ Payment creation test passed');
    
    // Test transaction verification
    const verificationResult = await testTransactionVerification(paymentRequest);
    if (verificationResult) {
      console.log('✅ Transaction verification test passed');
    } else {
      console.warn('⚠️ Transaction verification test failed');
    }
    
    // Test payment status
    const statusResult = await testPaymentStatus(paymentRequest.paymentId);
    if (statusResult) {
      console.log('✅ Payment status test passed');
    } else {
      console.warn('⚠️ Payment status test failed');
    }
    
    console.log('\n===== SOLANA PAYMENT INTEGRATION TESTS COMPLETE =====');
    return true;
  } catch (error) {
    console.error('Error running Solana integration tests:', error);
    return false;
  }
}

// Run tests if directly executed
if (require.main === module) {
  testSolanaIntegration()
    .then(success => {
      console.log(`\nTests ${success ? 'completed successfully' : 'failed'}`);
    })
    .catch(err => {
      console.error('Unhandled error in tests:', err);
      process.exit(1);
    });
}