import express, { Request, Response } from "express";
import { storage } from "./storage";
import { setupService } from "./setupService";
import { setupEnvironmentSchema } from "@shared/schema";
import { z } from "zod";

const router = express.Router();

/**
 * Register setup routes with the Express app
 * @param app Express application
 */
export function registerSetupRoutes(app: any) {
  app.use("/api/setup", router);
}

type EnvironmentSetup = typeof setupEnvironmentSchema._type;

/**
 * GET /api/setup
 * 
 * Get current environment configuration
 */
router.get('/', async (req: Request, res: Response) => {
  try {
    const config = await setupService.getConfiguration();
    res.json({ config });
  } catch (error) {
    console.error('Error retrieving configuration:', error);
    res.status(500).json({ message: 'Failed to retrieve configuration' });
  }
});

/**
 * POST /api/setup
 * 
 * Save environment configuration
 */
router.post('/', async (req: Request, res: Response) => {
  try {
    const configData = setupEnvironmentSchema.parse(req.body);
    await setupService.saveConfiguration(configData);
    res.json({ message: 'Configuration saved successfully' });
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ message: 'Invalid configuration data', errors: error.errors });
    } else {
      console.error('Error saving configuration:', error);
      res.status(500).json({ message: 'Failed to save configuration' });
    }
  }
});

/**
 * POST /api/setup/test
 * 
 * Test environment configuration
 */
router.post('/test', async (req: Request, res: Response) => {
  try {
    const configData = setupEnvironmentSchema.parse(req.body);
    const testResults = await setupService.testConfiguration(configData);
    res.json(testResults);
  } catch (error) {
    if (error instanceof z.ZodError) {
      res.status(400).json({ 
        success: false, 
        message: 'Invalid configuration data', 
        errors: error.errors 
      });
    } else {
      console.error('Error testing configuration:', error);
      res.status(500).json({ 
        success: false, 
        message: 'Failed to test configuration'
      });
    }
  }
});

export default router;