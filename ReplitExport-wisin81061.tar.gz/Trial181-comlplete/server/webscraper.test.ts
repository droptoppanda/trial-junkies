
import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { Browser, Page } from 'puppeteer';
import fs from 'fs';
import path from 'path';
import { cloudLlmApi } from './apiPlaceholders';

// Add stealth plugin to puppeteer
puppeteer.use(StealthPlugin());

/**
 * WebScraper Test Module
 * Tests the web scraper functionality with various service websites
 */

interface ServiceDefinition {
  name: string;
  url: string;
  loginSelector?: string;
  signupSelector?: string;
  freeTrialSelector?: string;
}

// Service definitions for popular streaming/trial services
const SERVICES: { [key: string]: ServiceDefinition } = {
  hulu: {
    name: 'Hulu',
    url: 'https://www.hulu.com',
    signupSelector: 'a[data-automationid="navigation-item-signup"]',
    freeTrialSelector: 'div[data-automationid="plan-card-0"]'
  },
  netflix: {
    name: 'Netflix',
    url: 'https://www.netflix.com',
    signupSelector: 'a.authLinks.redButton'
  },
  spotify: {
    name: 'Spotify',
    url: 'https://www.spotify.com',
    freeTrialSelector: 'a[data-ga-action="free"]'
  },
  youtube: {
    name: 'YouTube Premium',
    url: 'https://www.youtube.com/premium',
    freeTrialSelector: 'a[data-is-premium="true"]'
  },
  disney: {
    name: 'Disney+',
    url: 'https://www.disneyplus.com',
    signupSelector: 'a[data-testid="header-sign-up-link"]'
  }
};

/**
 * Test interface for trial data
 */
interface TrialTest {
  id: number;
  service_name: string;
  website_url: string;
  user_id: number;
  status: string;
  created_at: Date;
  updated_at: Date;
}

/**
 * Automate a trial signup process
 * This is a mock/test implementation with safety measures to prevent actual signups
 */
export async function automateTrialSignup(trial: TrialTest): Promise<{ 
  success: boolean; 
  data?: any;
  error?: string;
}> {
  let browser: Browser | null = null;
  let page: Page | null = null;

  try {
    console.log(`Starting trial automation for ${trial.service_name}`);

    // Check if service is supported
    const service = SERVICES[trial.service_name.toLowerCase()];
    if (!service) {
      return {
        success: false,
        error: `Service '${trial.service_name}' not supported`
      };
    }

    // Create screenshots directory if it doesn't exist
    console.log('Creating screenshots directory');
    try {
      if (!fs.existsSync('./screenshots')) {
        fs.mkdirSync('./screenshots', { recursive: true });
      }
    } catch (error) {
      console.log('Screenshots directory already exists or could not be created');
    }

    // Launch browser with stealth mode
    browser = await puppeteer.launch({
      headless: "new", // Use new headless mode
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-web-security',
        '--disable-features=IsolateOrigins,site-per-process'
      ]
    });

    // Create a new page
    page = await browser.newPage();

    // Set viewport
    await page.setViewport({ width: 1280, height: 800 });

    // Set user agent to appear as a normal browser
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36');

    // Navigate to service website
    console.log(`Navigating to ${service.url}`);
    await page.goto(service.url, { waitUntil: 'networkidle2', timeout: 60000 });

    // Take screenshot for debugging
    const timestamp = Date.now();
    await page.screenshot({ path: `./screenshots/${trial.service_name}_${timestamp}_landing.png` });

    console.log(`Successfully loaded ${service.url}`);

    // This is just a test implementation that doesn't actually sign up
    // In a real implementation, you would:
    // 1. Find and click the sign-up button
    // 2. Fill out the registration form with generated data
    // 3. Handle CAPTCHA if needed
    // 4. Process payment information
    // 5. Complete the signup process

    // For testing, we're just checking if we can identify the signup elements
    let signupElementFound = false;

    if (service.signupSelector) {
      const signupElement = await page.$(service.signupSelector);
      if (signupElement) {
        console.log(`Found signup element on ${service.name}`);
        signupElementFound = true;

        // Take screenshot with signup element highlighted
        await page.evaluate((selector) => {
          const element = document.querySelector(selector);
          if (element) {
            element.setAttribute('style', 'border: 3px solid red; background-color: rgba(255, 0, 0, 0.2) !important');
          }
        }, service.signupSelector);

        await page.screenshot({ path: `./screenshots/${trial.service_name}_${timestamp}_signup.png` });
      }
    }

    if (service.freeTrialSelector) {
      const trialElement = await page.$(service.freeTrialSelector);
      if (trialElement) {
        console.log(`Found free trial element on ${service.name}`);
        signupElementFound = true;

        // Take screenshot with free trial element highlighted
        await page.evaluate((selector) => {
          const element = document.querySelector(selector);
          if (element) {
            element.setAttribute('style', 'border: 3px solid green; background-color: rgba(0, 255, 0, 0.2) !important');
          }
        }, service.freeTrialSelector);

        await page.screenshot({ path: `./screenshots/${trial.service_name}_${timestamp}_trial.png` });
      }
    }

    // Check for cookies popup and accept if found
    const cookieSelectors = [
      'button[id*="accept"]', 
      'button[id*="cookie"]',
      'button[class*="cookie"]',
      'button[id*="consent"]',
      'button[class*="consent"]',
      'button[id*="agree"]',
      'button[class*="agree"]'
    ];

    for (const selector of cookieSelectors) {
      try {
        const cookieButtons = await page.$$(selector);
        for (const button of cookieButtons) {
          const buttonText = await page.evaluate(el => el.textContent, button);
          if (buttonText && /accept|agree|consent|continue|got it/i.test(buttonText)) {
            console.log(`Found and clicking cookie consent button: ${buttonText}`);
            await button.click();
            await page.waitForTimeout(1000);
            break;
          }
        }
      } catch (e) {
        // Ignore errors, just trying various selectors
      }
    }

    // Save page title and URL for reporting
    const pageTitle = await page.title();
    const currentUrl = page.url();

    // Close browser
    if (browser) {
      await browser.close();
      browser = null;
    }

    // Use cloud LLM API to analyze the content
    try {
      const llmResult = await cloudLlmApi.generateText(
        `Analyze this URL: ${currentUrl} with title: ${pageTitle}. Is it likely to offer free trials?`
      );
      console.log(`LLM Analysis: ${llmResult.text}`);
    } catch (error) {
      console.log('LLM analysis failed, continuing without it');
    }

    return {
      success: true,
      data: {
        service: service.name,
        url: currentUrl,
        title: pageTitle,
        signupElementFound,
        timestamp: new Date().toISOString()
      }
    };
  } catch (error: any) {
    console.error(`Error in trial automation:`, error);

    // Take error screenshot if page is available
    if (page) {
      const errorTimestamp = Date.now();
      try {
        await page.screenshot({ path: `./screenshots/${trial.service_name}_${errorTimestamp}_error.png` });
      } catch (e) {
        console.error('Failed to take error screenshot:', e);
      }
    }

    return {
      success: false,
      error: error.message || 'Unknown error occurred'
    };
  } finally {
    // Make sure browser is closed
    if (browser) {
      await browser.close();
    }
  }
}

/**
 * Test the web scraper for a specific service
 */
export async function testWebScraper(serviceName: string = 'hulu') {
  console.log('\n=== Running Web Scraper Tests ===');

  try {
    // Ensure screenshots directory exists
    try {
      const fs = await import('fs');
      if (!fs.existsSync('./screenshots')) {
        console.log('Creating screenshots directory');
        fs.mkdirSync('./screenshots', { recursive: true });
      }
    } catch (error) {
      console.log('Error with screenshots directory:', error);
    }

    // Normalize service name to lowercase
    serviceName = serviceName.toLowerCase();

    // Check if service is supported
    if (!SERVICES[serviceName]) {
      console.error(`Service '${serviceName}' not supported`);
      console.log('Supported services:', Object.keys(SERVICES).join(', '));
      return false;
    }

    const service = SERVICES[serviceName];
    console.log(`Testing web scraper on: ${service.name} (${service.url})`);

    // Create a test trial object
    const testTrial: TrialTest = {
      id: 9999, // Test ID
      service_name: serviceName,
      website_url: service.url,
      user_id: 1, // Test user ID
      status: "queued",
      created_at: new Date(),
      updated_at: new Date()
    };

    // Run the scraper with a timeout to just test connectivity and initial page load
    // This prevents actual signup
    const result = await Promise.race([
      automateTrialSignup(testTrial),
      new Promise<any>(resolve => setTimeout(() => resolve({ 
        success: true, 
        data: { message: 'Test stopped after initial navigation (timeout)' }
      }), 30000)) // 30 second timeout
    ]);

    console.log(`Web Scraper Test Result: ${result.success ? 'Success ✓' : 'Failed ✗'}`);

    if (result.success) {
      console.log('Successfully connected to the target website');
      if (result.data) {
        console.log('Test data:', JSON.stringify(result.data, null, 2));
      }
    } else {
      console.error('Failed to connect to the target website:', result.error);
    }

    console.log('\n=== Web Scraper Tests Completed ===');
    return result.success;
  } catch (error: any) {
    console.error('Error in web scraper test:', error);
    console.log('Web Scraper Test: Failed ✗');
    return false;
  }
}

/**
 * Test all supported services
 */
export async function testAllServices() {
  console.log('\n=== Testing All Supported Services ===');
  const results: { [key: string]: boolean } = {};

  for (const serviceName of Object.keys(SERVICES)) {
    console.log(`\nTesting ${SERVICES[serviceName].name}...`);
    results[serviceName] = await testWebScraper(serviceName);
  }

  console.log('\n=== Service Test Results Summary ===');
  let allPassed = true;

  for (const [service, passed] of Object.entries(results)) {
    console.log(`${SERVICES[service].name}: ${passed ? 'Passed ✓' : 'Failed ✗'}`);
    if (!passed) allPassed = false;
  }

  return allPassed;
}

// Allow running this test directly
if (import.meta.url.endsWith(process.argv[1])) {
  // Check if a specific service was requested
  const requestedService = process.argv[2];

  if (requestedService && requestedService !== 'all') {
    testWebScraper(requestedService)
      .then(success => {
        if (!success) {
          process.exit(1);
        }
      })
      .catch(err => {
        console.error('Web scraper test runner error:', err);
        process.exit(1);
      });
  } else if (requestedService === 'all') {
    testAllServices()
      .then(success => {
        if (!success) {
          process.exit(1);
        }
      })
      .catch(err => {
        console.error('Web scraper test runner error:', err);
        process.exit(1);
      });
  } else {
    // Default to Hulu
    testWebScraper()
      .then(success => {
        if (!success) {
          process.exit(1);
        }
      })
      .catch(err => {
        console.error('Web scraper test runner error:', err);
        process.exit(1);
      });
  }
}
