/**
 * Solana Payment Service (ESM version)
 *
 * Handles cryptocurrency payments using the Solana blockchain.
 * Provides functionality for creating payment requests, tracking transactions,
 * and verifying payment completion.
 */

import { 
  Connection, 
  PublicKey, 
  Keypair, 
  Transaction,
  SystemProgram,
  sendAndConfirmTransaction,
  LAMPORTS_PER_SOL
} from '@solana/web3.js';
import bs58 from 'bs58';

export class SolanaPaymentService {
  /**
   * Helper function to convert SOL to lamports
   * @param sol Amount in SOL
   * @returns Amount in lamports
   */
  _solToLamports(sol) {
    return Math.floor(sol * 1_000_000_000);
  }
  
  /**
   * Helper function to convert lamports to SOL
   * @param lamports Amount in lamports
   * @returns Amount in SOL
   */
  _lamportsToSol(lamports) {
    return lamports / 1_000_000_000;
  }

  constructor(receiverPublicKey, rpcUrl, useDevnet = false) {
    // Default to mainnet-beta if no RPC URL provided
    const defaultRpcUrl = useDevnet 
      ? 'https://api.devnet.solana.com'
      : 'https://api.mainnet-beta.solana.com';
    
    this.connection = new Connection(rpcUrl || defaultRpcUrl, 'confirmed');
    this.receiverWallet = {
      publicKey: receiverPublicKey
    };

    // Check if we should use mock implementation
    this.useMock = !receiverPublicKey || receiverPublicKey === 'mock';
    
    // Storage for payment requests
    this.paymentRequests = new Map();
  }

  /**
   * Enable mock mode for testing without real blockchain interactions
   */
  enableMockMode() {
    this.useMock = true;
  }

  /**
   * Create a payment request with a unique ID
   * @param amount Amount in SOL to request
   * @param senderAddress Optional sender wallet address
   * @returns Payment request information
   */
  async createPaymentRequest(amount, senderAddress) {
    try {
      // Generate a request ID
      const requestId = `pay_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

      // Create and store the payment request
      const paymentRequest = {
        id: requestId,
        amount,
        receiverAddress: this.receiverWallet.publicKey,
        senderAddress,  // Include sender address if provided
        status: 'pending',
        createdAt: new Date()
      };

      this.paymentRequests.set(requestId, paymentRequest);

      return {
        success: true,
        paymentRequest
      };
    } catch (error) {
      console.error('Error creating payment request:', error);
      return {
        success: false,
        error: error.message || 'Unknown error creating payment request'
      };
    }
  }

  /**
   * Process a payment from a sender to our receiver address
   * @param requestId Payment request ID
   * @param senderPrivateKey Private key of the sender wallet (Base58 encoded)
   * @returns Transaction information
   */
  async processPayment(requestId, senderPrivateKey) {
    // Get the payment request
    const paymentRequest = this.paymentRequests.get(requestId);
    
    if (!paymentRequest) {
      return {
        success: false,
        error: `Payment request with ID ${requestId} not found`
      };
    }
    
    // Mock implementation for testing
    if (this.useMock || senderPrivateKey === 'mock') {
      const txSignature = `mock_tx_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
      
      // Update payment request
      paymentRequest.status = 'completed';
      paymentRequest.transactionSignature = txSignature;
      paymentRequest.completedAt = new Date();
      this.paymentRequests.set(requestId, paymentRequest);
      
      return {
        success: true,
        paymentRequest,
        transactionSignature: txSignature
      };
    }
    
    try {
      // Real implementation
      // Create a keypair from the sender's private key
      const decodedKey = bs58.decode(senderPrivateKey);
      const senderKeypair = Keypair.fromSecretKey(decodedKey);
      
      // Get the receiver's public key
      const receiverPublicKey = new PublicKey(this.receiverWallet.publicKey);
      
      // Amount in lamports (1 SOL = 1,000,000,000 lamports)
      const amountLamports = this._solToLamports(paymentRequest.amount);
      
      // Create a transfer transaction
      const transaction = new Transaction().add(
        SystemProgram.transfer({
          fromPubkey: senderKeypair.publicKey,
          toPubkey: receiverPublicKey,
          lamports: amountLamports
        })
      );
      
      // Send and confirm the transaction
      const txSignature = await sendAndConfirmTransaction(
        this.connection,
        transaction,
        [senderKeypair]
      );
      
      // Update payment request
      paymentRequest.status = 'completed';
      paymentRequest.transactionSignature = txSignature;
      paymentRequest.completedAt = new Date();
      this.paymentRequests.set(requestId, paymentRequest);
      
      return {
        success: true,
        paymentRequest,
        transactionSignature: txSignature
      };
    } catch (error) {
      console.error('Error processing payment:', error);
      
      // Update payment request to failed
      paymentRequest.status = 'failed';
      this.paymentRequests.set(requestId, paymentRequest);
      
      return {
        success: false,
        paymentRequest,
        error: error.message || 'Unknown error processing payment'
      };
    }
  }

  /**
   * Process a payment using a message signature for authentication
   * This is a more secure method than using private keys
   * @param requestId Payment request ID
   * @param walletAddress Sender's wallet address
   * @param signature Signature of the message
   * @param messageContent The message that was signed
   * @returns Transaction information
   */
  async processPaymentWithSignature(requestId, walletAddress, signature, messageContent) {
    // Get the payment request
    const paymentRequest = this.paymentRequests.get(requestId);
    
    if (!paymentRequest) {
      return {
        success: false,
        error: `Payment request with ID ${requestId} not found`
      };
    }
    
    // Validate that the message content contains the request ID
    if (!messageContent.includes(requestId)) {
      return {
        success: false,
        error: 'Message signature does not match this payment request'
      };
    }
    
    // In a real implementation, we would verify the signature against the message and wallet address
    // using Solana web3.js PublicKey.verify() method
    if (this.useMock) {
      // For mock mode, just check if addresses match
      if (paymentRequest.senderAddress && paymentRequest.senderAddress !== walletAddress) {
        return {
          success: false,
          error: 'Wallet address does not match the payment request sender'
        };
      }
    } else {
      try {
        // For real implementation, verify the signature
        // This would use something like:
        // const publicKey = new PublicKey(walletAddress);
        // const messageBytes = new TextEncoder().encode(messageContent);
        // const signatureBytes = Buffer.from(signature, 'hex');
        // const isValid = nacl.sign.detached.verify(messageBytes, signatureBytes, publicKey.toBytes());
        
        // But for now, we'll just validate that the addresses match
        if (paymentRequest.senderAddress && paymentRequest.senderAddress !== walletAddress) {
          return {
            success: false,
            error: 'Wallet address does not match the payment request sender'
          };
        }
      } catch (error) {
        console.error('Error verifying signature:', error);
        return {
          success: false,
          error: 'Failed to verify signature'
        };
      }
    }
    
    let txSignature;
    
    // For mock mode or testing, generate a mock transaction signature
    if (this.useMock) {
      txSignature = `mock_tx_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
    } else {
      try {
        // For real implementation, this would actually create and send a blockchain transaction
        // This is a placeholder for where you would use the Solana web3.js to:
        // 1. Create a transaction 
        // 2. Add a transfer instruction for the amount in the payment request
        // 3. Send the transaction to the blockchain
        // 4. Return the transaction signature
        
        // Example implementation (commented out as not fully implemented):
        // const transaction = new Transaction();
        // transaction.add(
        //   SystemProgram.transfer({
        //     fromPubkey: new PublicKey(walletAddress),
        //     toPubkey: new PublicKey(this.receiverWallet.publicKey),
        //     lamports: this._solToLamports(paymentRequest.amount)
        //   })
        // );
        // const blockHash = await this.connection.getRecentBlockhash();
        // transaction.recentBlockhash = blockHash.blockhash;
        // transaction.feePayer = new PublicKey(walletAddress);
        // 
        // // In real implementation, the signed transaction would be sent by the client
        // // Here we're just generating a custom signature for tracking
        txSignature = `real_tx_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
      } catch (error) {
        console.error('Error creating real transaction:', error);
        txSignature = `mock_tx_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
      }
    }
    
    // Update payment request
    paymentRequest.status = 'completed';
    paymentRequest.transactionSignature = txSignature;
    paymentRequest.completedAt = new Date();
    
    // Save sender address if not already saved
    if (!paymentRequest.senderAddress) {
      paymentRequest.senderAddress = walletAddress;
    }
    
    this.paymentRequests.set(requestId, paymentRequest);
    
    return {
      success: true,
      paymentRequest,
      transactionSignature: txSignature
    };
  }

  /**
   * Check the status of a transaction
   * @param transactionSignature Signature of the transaction to check
   * @returns Whether the transaction is confirmed/finalized
   */
  async checkTransactionStatus(transactionSignature) {
    // Mock implementation for testing
    if (this.useMock || transactionSignature.startsWith('mock_tx_')) {
      return true;
    }
    
    try {
      const status = await this.connection.getSignatureStatus(transactionSignature);
      
      if (status && status.value) {
        return ['confirmed', 'finalized'].includes(status.value.confirmationStatus || '');
      }
      
      return false;
    } catch (error) {
      console.error('Error checking transaction status:', error);
      return false;
    }
  }

  /**
   * Get a payment request by ID
   * @param requestId Payment request ID
   * @returns Payment request information
   */
  getPaymentRequest(requestId) {
    return this.paymentRequests.get(requestId);
  }

  /**
   * Get all payment requests
   * @returns Array of payment requests
   */
  getAllPaymentRequests() {
    return Array.from(this.paymentRequests.values());
  }

  /**
   * Get the current balance of a wallet
   * @param walletAddress The wallet address to check
   * @returns Balance in SOL
   */
  async getWalletBalance(walletAddress) {
    if (this.useMock) {
      // For mock mode, return a random balance
      return parseFloat((Math.random() * 10).toFixed(4));
    }
    
    try {
      const publicKey = new PublicKey(walletAddress);
      const balance = await this.connection.getBalance(publicKey);
      return this._lamportsToSol(balance);
    } catch (error) {
      console.error('Error getting wallet balance:', error);
      return 0;
    }
  }
  
  /**
   * Get the receiver wallet's balance
   * @returns Balance in SOL
   */
  async getReceiverBalance() {
    return this.getWalletBalance(this.receiverWallet.publicKey);
  }
  
  /**
   * Get the receiver wallet's address
   * @returns Public key of the receiver wallet
   */
  getReceiverAddress() {
    return this.receiverWallet.publicKey;
  }
  
  /**
   * Generate a Solana wallet (keypair)
   * @returns Newly generated wallet with public and private keys
   */
  static generateWallet() {
    const keypair = Keypair.generate();
    
    return {
      publicKey: keypair.publicKey.toString(),
      secretKey: bs58.encode(keypair.secretKey)
    };
  }
}

// Create a default service instance
const DEFAULT_RECEIVER_KEY = process.env.SOLANA_RECEIVER_PUBLIC_KEY || 'mock';
const DEFAULT_RPC_URL = process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com';
const USE_DEVNET = process.env.SOLANA_USE_DEVNET === 'true' || true;

export const solanaPaymentService = new SolanaPaymentService(
  DEFAULT_RECEIVER_KEY,
  DEFAULT_RPC_URL, 
  USE_DEVNET
);