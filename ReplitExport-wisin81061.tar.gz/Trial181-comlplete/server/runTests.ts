/**
 * Test Runner
 * 
 * This script runs our test files
 */
import { exec } from 'child_process';

// Set environment variables for testing
process.env.MOCK_SOLANA_VERIFICATION = 'true';

// List of test files to run
const testFiles = [
  './test-full-service-integration.js'
];

async function runTests() {
  console.log("Running tests...");
  
  for (const testFile of testFiles) {
    console.log(`\n=== Running ${testFile} ===\n`);
    
    try {
      // Use exec to run the test file
      await new Promise<void>((resolve, reject) => {
        const childProcess = exec(`node ${testFile}`, { env: process.env });
        
        childProcess.stdout?.pipe(process.stdout);
        childProcess.stderr?.pipe(process.stderr);
        
        childProcess.on('exit', (code) => {
          if (code === 0) {
            resolve();
          } else {
            reject(new Error(`Test ${testFile} failed with exit code ${code}`));
          }
        });
      });
      
      console.log(`\n✅ ${testFile} passed`);
    } catch (error) {
      console.error(`\n❌ ${testFile} failed:`, error);
      process.exit(1);
    }
  }
  
  console.log("\n🎉 All tests completed successfully!");
}

runTests()
  .catch(error => {
    console.error("Test runner failed:", error);
    process.exit(1);
  });