import { testDiscordBot } from './tests';
import { testWebScraper } from './webscraper.test';
import { cloudLlm } from './cloudLlmService';
import { testSolanaIntegration } from './testSolanaIntegration';

/**
 * Run all automated tests
 */
export async function runAllTests(): Promise<boolean> {
  console.log('=== Starting Automated Tests ===\n');

  let testsPassed = true;

  // Start with Discord bot tests
  testsPassed = await testDiscordBot() && testsPassed;

  // Test web scraper (only in development)
  if (process.env.NODE_ENV === 'development') {
    try {
      const webScraperResult = await testWebScraper('hulu');
      testsPassed = webScraperResult && testsPassed;
    } catch (error) {
      console.error('Web scraper test error:', error);
      testsPassed = false;
    }

    // Test cloud LLM service
    try {
      const llmResult = await cloudLlm.testService();
      testsPassed = llmResult && testsPassed;
    } catch (error) {
      console.error('Cloud LLM test error:', error);
      testsPassed = false;
    }
    
    // Test Solana payment integration
    try {
      console.log('\nRunning Solana payment integration tests...');
      const solanaResult = await testSolanaIntegration();
      testsPassed = solanaResult && testsPassed;
    } catch (error) {
      console.error('Solana integration test error:', error);
      testsPassed = false;
    }
  }

  console.log('\n=== All Tests Completed' + (testsPassed ? ' Successfully ✓' : ' with Errors ✗') + ' ===');
  return testsPassed;
}

// ESM compatible check for direct execution
// Using import.meta.url instead of require.main === module
const isMainModule = import.meta.url.endsWith(process.argv[1]);

if (isMainModule) {
  runAllTests()
    .then(success => {
      if (!success) {
        process.exit(1);
      }
    })
    .catch(err => {
      console.error('Test runner error:', err);
      process.exit(1);
    });
}