
import axios from "axios";
import { randomBytes } from "crypto";

// Interface for email account
export interface EmailAccount {
  address: string;
  password: string;
  token?: string;
}

// Interface for email message
export interface EmailMessage {
  id: string;
  from: string;
  to: string;
  subject: string;
  text?: string;
  html?: string;
  date: Date;
}

/**
 * Disposable Email Service
 * Creates and manages temporary email accounts using the Mail.tm API
 */
export class DisposableEmailService {
  private apiBaseUrl: string = "https://api.mail.tm";
  private currentAccount: EmailAccount | null = null;
  private domains: string[] = [];
  
  constructor() {
    this.fetchAvailableDomains().catch(error => {
      console.error("Failed to fetch mail.tm domains:", error);
      // Fallback domains if API call fails
      this.domains = ["mail.tm", "inbox.tm", "tmpbox.net"];
    });
  }
  
  /**
   * Fetch available domains from Mail.tm
   */
  private async fetchAvailableDomains(): Promise<void> {
    try {
      const response = await axios.get(`${this.apiBaseUrl}/domains`);
      if (response.data && Array.isArray(response.data)) {
        this.domains = response.data.map((domain: any) => domain.domain);
      }
    } catch (error) {
      console.error("Error fetching domains:", error);
      throw error;
    }
  }
  
  /**
   * Create a new disposable email account
   */
  public async createAccount(): Promise<EmailAccount> {
    try {
      // Ensure we have domains available
      if (this.domains.length === 0) {
        await this.fetchAvailableDomains();
      }
      
      // Generate random username and password
      const username = randomBytes(8).toString("hex");
      const password = randomBytes(12).toString("hex");
      const domain = this.domains[Math.floor(Math.random() * this.domains.length)];
      const address = `${username}@${domain}`;
      
      // Create account on Mail.tm
      const response = await axios.post(`${this.apiBaseUrl}/accounts`, {
        address,
        password
      });
      
      // Get authentication token
      const authResponse = await axios.post(`${this.apiBaseUrl}/token`, {
        address,
        password
      });
      
      const account: EmailAccount = {
        address,
        password,
        token: authResponse.data.token
      };
      
      this.currentAccount = account;
      return account;
    } catch (error: any) {
      console.error("Error creating email account:", error.response?.data || error.message);
      throw error;
    }
  }
  
  /**
   * Get current account or create a new one
   */
  public async getOrCreateAccount(): Promise<EmailAccount> {
    if (this.currentAccount) {
      return this.currentAccount;
    }
    
    return await this.createAccount();
  }
  
  /**
   * Get all messages for the current account
   */
  public async getMessages(): Promise<EmailMessage[]> {
    try {
      if (!this.currentAccount?.token) {
        throw new Error("No active email account");
      }
      
      const response = await axios.get(`${this.apiBaseUrl}/messages`, {
        headers: {
          Authorization: `Bearer ${this.currentAccount.token}`
        }
      });
      
      if (!response.data || !Array.isArray(response.data)) {
        return [];
      }
      
      return response.data.map((msg: any) => ({
        id: msg.id,
        from: msg.from.address,
        to: msg.to[0].address,
        subject: msg.subject,
        text: msg.text,
        html: msg.html,
        date: new Date(msg.createdAt)
      }));
    } catch (error) {
      console.error("Error getting messages:", error);
      throw error;
    }
  }
  
  /**
   * Get message details by ID
   */
  public async getMessage(messageId: string): Promise<EmailMessage> {
    try {
      if (!this.currentAccount?.token) {
        throw new Error("No active email account");
      }
      
      const response = await axios.get(`${this.apiBaseUrl}/messages/${messageId}`, {
        headers: {
          Authorization: `Bearer ${this.currentAccount.token}`
        }
      });
      
      const msg = response.data;
      return {
        id: msg.id,
        from: msg.from.address,
        to: msg.to[0].address,
        subject: msg.subject,
        text: msg.text,
        html: msg.html,
        date: new Date(msg.createdAt)
      };
    } catch (error) {
      console.error("Error getting message:", error);
      throw error;
    }
  }
  
  /**
   * Wait for new message matching a subject or sender filter
   * @param filter Function to determine if a message matches the criteria
   * @param timeoutMs Maximum time to wait in milliseconds
   * @param pollIntervalMs Time between checks in milliseconds
   */
  public async waitForMessage(
    filter: (message: EmailMessage) => boolean,
    timeoutMs: number = 120000,
    pollIntervalMs: number = 5000
  ): Promise<EmailMessage | null> {
    const startTime = Date.now();
    
    while (Date.now() - startTime < timeoutMs) {
      // Get all messages
      const messages = await this.getMessages();
      
      // Find the first message that matches the filter
      const matchedMessage = messages.find(filter);
      
      if (matchedMessage) {
        // Get full message details
        return await this.getMessage(matchedMessage.id);
      }
      
      // Wait before polling again
      await new Promise(resolve => setTimeout(resolve, pollIntervalMs));
    }
    
    return null; // Timeout exceeded
  }
  
  /**
   * Wait for verification email and extract verification link
   * @param serviceName Name of the service to expect email from (e.g., "Netflix", "Spotify")
   * @param timeoutMs Maximum time to wait in milliseconds
   */
  public async waitForVerificationLink(
    serviceName: string,
    timeoutMs: number = 120000
  ): Promise<string | null> {
    try {
      // Create email filter based on common email verification patterns
      const verificationFilter = (message: EmailMessage) => {
        const serviceNameLower = serviceName.toLowerCase();
        const fromLower = message.from.toLowerCase();
        const subjectLower = message.subject.toLowerCase();
        
        // Check if from address contains service name
        const fromMatch = fromLower.includes(serviceNameLower);
        
        // Check if subject contains common verification terms
        const subjectMatch = 
          subjectLower.includes("verify") ||
          subjectLower.includes("confirm") ||
          subjectLower.includes("activation") ||
          subjectLower.includes("welcome") ||
          subjectLower.includes("validate") ||
          subjectLower.includes("email") ||
          subjectLower.includes("account") ||
          subjectLower.includes(serviceNameLower);
        
        return fromMatch || subjectMatch;
      };
      
      // Wait for matching message
      const message = await this.waitForMessage(verificationFilter, timeoutMs);
      
      if (!message) {
        return null;
      }
      
      // Extract verification link from email content
      let content = message.html || message.text || "";
      
      // Simple link extraction regex
      const urlRegex = /(https?:\/\/[^\s"<>]+)/g;
      const urls = content.match(urlRegex) || [];
      
      // Find the most likely verification link
      for (const url of urls) {
        if (
          url.includes("verify") ||
          url.includes("confirm") ||
          url.includes("activate") ||
          url.includes("validation") ||
          url.includes("email") ||
          url.includes("account") ||
          url.includes("welcome") ||
          url.includes("register") ||
          url.includes("sign-up") ||
          url.includes("signup")
        ) {
          return url;
        }
      }
      
      // If no specific verification link found, return the first link
      return urls.length > 0 ? urls[0] : null;
    } catch (error) {
      console.error("Error waiting for verification link:", error);
      return null;
    }
  }
  
  /**
   * Delete the current account
   */
  public async deleteAccount(): Promise<boolean> {
    try {
      if (!this.currentAccount?.token) {
        return false;
      }
      
      await axios.delete(`${this.apiBaseUrl}/accounts`, {
        headers: {
          Authorization: `Bearer ${this.currentAccount.token}`
        }
      });
      
      this.currentAccount = null;
      return true;
    } catch (error) {
      console.error("Error deleting account:", error);
      return false;
    }
  }
}

// Singleton instance for use throughout the app
export const disposableEmail = new DisposableEmailService();
