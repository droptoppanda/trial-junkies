/**
 * Test script for Solana payment service
 * 
 * This script tests the basic functionality of the Solana payment service
 * including wallet address validation and mock transaction verification.
 */

import solanaPaymentService from './solanaPaymentService.js';

// Force mock verification mode for testing
process.env.MOCK_SOLANA_VERIFICATION = 'true';
console.log("Setting mock verification mode:", process.env.MOCK_SOLANA_VERIFICATION);

/**
 * Test Solana payment service functionality
 */
async function testSolanaPaymentService() {
  console.log('======= Testing Solana Payment Service =======');
  
  // 1. Test network info
  console.log('\n--- Testing network info ---');
  const networkInfo = solanaPaymentService.getNetworkInfo();
  console.log('Network:', networkInfo.network);
  console.log('Endpoint:', networkInfo.endpoint);
  console.log('Receiver configured:', networkInfo.receiverConfigured);
  console.log('Receiver address:', networkInfo.receiverAddress);
  
  // 2. Test configuration status
  console.log('\n--- Testing configuration status ---');
  const isConfigured = solanaPaymentService.isConfigured();
  console.log('Service configured:', isConfigured);
  
  if (!isConfigured) {
    console.error('ERROR: Solana payment service is not configured');
    console.error('Set SOLANA_RECEIVER_PUBLIC_KEY environment variable to a valid Solana address');
    console.error('Skipping transaction verification tests');
    return;
  }

  // 3. Test address validation
  console.log('\n--- Testing address validation ---');
  const validAddresses = [
    networkInfo.receiverAddress,
    '7UX2i7SucgLMQcfZ75s3VXmZZY4YRUyJN9X1RgfMoDUi',
    '5T6pGJ6fU8Vw9DmP9fFf2DWKaMqhPMoqvQoKvxvW6DP4'
  ];
  
  const invalidAddresses = [
    'not-an-address',
    '123456',
    'ABCDEF',
    'ETH-address-0x1234567890123456789012345678901234567890',
    null,
    undefined,
    ''
  ];
  
  for (const address of validAddresses) {
    const isValid = solanaPaymentService.isValidPublicKeyFormat(address);
    console.log(`Address ${address} is ${isValid ? 'valid' : 'invalid'}`);
  }
  
  for (const address of invalidAddresses) {
    const isValid = solanaPaymentService.isValidPublicKeyFormat(address);
    console.log(`Address ${address} is ${isValid ? 'valid' : 'invalid'}`);
  }
  
  // 4. Test create payment request
  console.log('\n--- Testing payment request creation ---');
  const paymentAmount = 1.5;
  const paymentMetadata = {
    subscriptionTier: 'basic',
    userId: '12345',
    description: 'Basic Trial Junkies subscription'
  };
  
  try {
    const paymentRequest = solanaPaymentService.createPaymentRequest(
      paymentAmount,
      paymentMetadata
    );
    console.log('Payment request created successfully:');
    console.log(JSON.stringify(paymentRequest, null, 2));
  } catch (error) {
    console.error('Error creating payment request:', error.message);
  }
  
  // 5. Test mock transaction verification
  console.log('\n--- Testing mock transaction verification ---');
  // Valid mock transaction format: mock_[random chars]
  const validMockTx = 'mock_validtransaction12345';
  const invalidMockTx = 'invalid_transaction';
  
  try {
    const validResult = await solanaPaymentService.verifyTransaction(
      validMockTx,
      paymentAmount
    );
    console.log('Valid mock transaction verification result:');
    console.log(JSON.stringify(validResult, null, 2));
    
    const invalidResult = await solanaPaymentService.verifyTransaction(
      invalidMockTx,
      paymentAmount
    );
    console.log('Invalid mock transaction verification result:');
    console.log(JSON.stringify(invalidResult, null, 2));
  } catch (error) {
    console.error('Error during transaction verification:', error.message);
  }
  
  console.log('\n======= Solana Payment Service Test Complete =======');
}

// Run the tests
testSolanaPaymentService()
  .then(() => {
    console.log('Tests completed.');
  })
  .catch(error => {
    console.error('Test failed with error:', error);
  });