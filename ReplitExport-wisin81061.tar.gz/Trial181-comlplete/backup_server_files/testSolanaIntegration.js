/**
 * Test script for Solana payment functionality
 * 
 * This script tests our Solana payment system by:
 * 1. Creating a payment request
 * 2. Generating a test wallet
 * 3. Checking receiver wallet balance
 * 4. Processing a payment using message signature
 * 5. Verifying the payment status
 * 
 * Run with: node server/testSolanaIntegration.js
 */

const { solanaPaymentService, SolanaPaymentService } = require('./solanaPaymentService');

async function testSolanaIntegration() {
  console.log('=== Starting Solana Integration Test ===');
  
  // Enable mock mode for testing
  solanaPaymentService.enableMockMode();
  
  // Step 1: Check if our receiver wallet is correctly configured
  console.log('\n1. Checking receiver wallet...');
  const receiverAddress = solanaPaymentService.getReceiverAddress();
  console.log(`Receiver address: ${receiverAddress}`);
  
  if (receiverAddress === 'mock') {
    console.log('Using mock mode, SOLANA_RECEIVER_PUBLIC_KEY is not set.');
  } else {
    console.log('Using real receiver address from environment variable.');
  }
  
  // Step 2: Get receiver wallet balance
  console.log('\n2. Checking receiver wallet balance...');
  try {
    const receiverBalance = await solanaPaymentService.getReceiverBalance();
    console.log(`Receiver balance: ${receiverBalance} SOL`);
  } catch (error) {
    console.error('Error getting receiver balance:', error);
  }
  
  // Step 3: Create a payment request
  console.log('\n3. Creating payment request...');
  const amount = 1.5; // 1.5 SOL
  try {
    const createResponse = await solanaPaymentService.createPaymentRequest(amount);
    
    if (!createResponse.success) {
      console.error('Failed to create payment request:', createResponse.error);
      return;
    }
    
    console.log('Payment request created successfully:');
    console.log(`- ID: ${createResponse.paymentRequest?.id}`);
    console.log(`- Amount: ${createResponse.paymentRequest?.amount} SOL`);
    console.log(`- Receiver: ${createResponse.paymentRequest?.receiverAddress}`);
    
    // Step 4: Generate test wallet
    console.log('\n4. Generating test wallet...');
    const testWallet = SolanaPaymentService.generateWallet();
    console.log('Test wallet generated:');
    console.log(`- Public Key: ${testWallet.publicKey}`);
    console.log(`- Secret Key: ${testWallet.secretKey?.substring(0, 5)}...`);
    
    // Step 5: Process payment with message signature
    console.log('\n5. Processing payment with message signature...');
    const paymentRequestId = createResponse.paymentRequest?.id;
    if (!paymentRequestId) {
      console.error('No payment request ID available');
      return;
    }
    
    const messageToSign = `Payment authorization for ${amount} SOL. Request ID: ${paymentRequestId}`;
    const mockSignature = 'mock_signature_' + Date.now();
    
    try {
      const processResponse = await solanaPaymentService.processPaymentWithSignature(
        paymentRequestId,
        testWallet.publicKey,
        mockSignature,
        messageToSign
      );
      
      if (!processResponse.success) {
        console.error('Failed to process payment:', processResponse.error);
        return;
      }
      
      console.log('Payment processed successfully:');
      console.log(`- Transaction signature: ${processResponse.transactionSignature}`);
      console.log(`- Status: ${processResponse.paymentRequest?.status}`);
      
      // Step 6: Verify payment status
      console.log('\n6. Verifying payment status...');
      const txSignature = processResponse.transactionSignature;
      if (!txSignature) {
        console.error('No transaction signature available');
        return;
      }
      
      const isConfirmed = await solanaPaymentService.checkTransactionStatus(txSignature);
      console.log(`Transaction status: ${isConfirmed ? 'Confirmed' : 'Pending'}`);
      
      // Step 7: Get all payment requests
      console.log('\n7. Getting all payment requests...');
      const allPayments = solanaPaymentService.getAllPaymentRequests();
      console.log(`Found ${allPayments.length} payment requests.`);
      
      console.log('\n=== Solana Integration Test Completed Successfully ===');
    } catch (error) {
      console.error('Error during payment processing:', error);
    }
  } catch (error) {
    console.error('Error during payment request creation:', error);
  }
}

// Run the tests
testSolanaIntegration().catch(error => {
  console.error('Error running Solana integration test:', error);
});