/**
 * Test script for SMS verification service
 * 
 * This script tests the basic functionality of the SMS verification service
 * including provider registration, phone number requests, and code verification.
 */

import smsVerificationService from './smsVerificationService.js';

/**
 * Utility function to wait for a specified time
 * @param {number} ms - Milliseconds to wait
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Test SMS verification service functionality
 */
async function testSmsVerificationService() {
  console.log('======= Testing SMS Verification Service =======');
  
  // 1. Check available providers
  console.log('\n--- Testing provider registration ---');
  const providers = smsVerificationService.getProviders();
  console.log('Available providers:', providers);
  
  if (!providers.length) {
    console.error('ERROR: No SMS providers available');
    return;
  }
  
  // 2. Request a phone number
  console.log('\n--- Testing phone number request ---');
  const services = ['netflix', 'spotify', 'amazon', 'discord', 'facebook'];
  const randomService = services[Math.floor(Math.random() * services.length)];
  
  try {
    const phoneRequest = await smsVerificationService.requestPhoneNumber(randomService, 'US');
    console.log('Phone request result:', phoneRequest);
    
    if (!phoneRequest.success) {
      console.error('ERROR: Failed to request phone number');
      return;
    }
    
    const { verificationId, phoneNumber } = phoneRequest;
    console.log(`Successfully requested phone number: ${phoneNumber}`);
    console.log(`Verification ID: ${verificationId}`);
    
    // 3. Wait for SMS code
    console.log('\n--- Waiting for SMS code ---');
    console.log('Checking for SMS code (this may take a few seconds)...');
    
    // Wait up to 3 seconds for the code to arrive
    for (let i = 0; i < 3; i++) {
      await sleep(1000);
      
      try {
        const codeResult = await smsVerificationService.getVerificationCode(verificationId);
        
        if (codeResult.success && codeResult.hasCode) {
          console.log(`Received SMS code: ${codeResult.code}`);
          
          // 4. Verify the code
          console.log('\n--- Testing code verification ---');
          const verificationResult = smsVerificationService.verifyCode(verificationId, codeResult.code);
          console.log('Verification result:', verificationResult);
          
          // Test with invalid code
          const invalidCode = '000000';
          const invalidVerificationResult = smsVerificationService.verifyCode(verificationId, invalidCode);
          console.log('Invalid code verification result:', invalidVerificationResult);
          
          break;
        } else {
          process.stdout.write('.');
        }
      } catch (error) {
        console.error('Error checking for code:', error.message);
      }
    }
    
    // 5. Test cancellation
    console.log('\n--- Testing verification cancellation ---');
    const cancellationResult = await smsVerificationService.cancelVerification(verificationId);
    console.log('Cancellation result:', cancellationResult);
    
  } catch (error) {
    console.error('Error testing SMS verification:', error);
  }
  
  console.log('\n======= SMS Verification Service Test Complete =======');
}

// Run the tests
testSmsVerificationService()
  .then(() => {
    console.log('Tests completed.');
  })
  .catch(error => {
    console.error('Test failed with error:', error);
  });