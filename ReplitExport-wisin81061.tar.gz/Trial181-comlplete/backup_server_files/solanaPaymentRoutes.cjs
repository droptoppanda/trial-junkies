/**
 * Solana Payment Routes
 * 
 * This file defines the Express routes for Solana payment functionality
 */

const solanaPaymentService = require('./solanaPaymentService.cjs');

/**
 * Register Solana payment routes
 * @param {Express} app - Express app
 */
function registerSolanaRoutes(app) {
  // Get payment status
  app.get('/api/payment/:paymentId', async (req, res) => {
    const { paymentId } = req.params;
    
    if (!paymentId) {
      return res.status(400).json({
        success: false,
        error: 'Payment ID is required'
      });
    }
    
    const paymentStatus = solanaPaymentService.getPaymentStatus(paymentId);
    res.json(paymentStatus);
  });
  
  // Create payment request
  app.post('/api/payment/create', (req, res) => {
    const { amount, metadata } = req.body;
    
    if (!amount || isNaN(parseFloat(amount))) {
      return res.status(400).json({
        success: false,
        error: 'Valid amount is required'
      });
    }
    
    const parsedAmount = parseFloat(amount);
    const paymentRequest = solanaPaymentService.createPaymentRequest(parsedAmount, metadata || {});
    
    res.json({
      success: true,
      ...paymentRequest
    });
  });
  
  // Verify transaction
  app.post('/api/payment/verify', async (req, res) => {
    const { transactionId, amount, paymentId } = req.body;
    
    if (!transactionId) {
      return res.status(400).json({
        success: false,
        error: 'Transaction ID is required'
      });
    }
    
    if (!amount || isNaN(parseFloat(amount))) {
      return res.status(400).json({
        success: false,
        error: 'Valid amount is required'
      });
    }
    
    try {
      const parsedAmount = parseFloat(amount);
      const verificationResult = await solanaPaymentService.verifyTransaction(
        transactionId,
        parsedAmount,
        paymentId
      );
      
      res.json(verificationResult);
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Verification failed: ' + error.message
      });
    }
  });
  
  // Get network info
  app.get('/api/payment/network', (req, res) => {
    const networkInfo = solanaPaymentService.getNetworkInfo();
    
    res.json({
      success: true,
      ...networkInfo
    });
  });
}

// Export using CommonJS
module.exports = { registerSolanaRoutes };