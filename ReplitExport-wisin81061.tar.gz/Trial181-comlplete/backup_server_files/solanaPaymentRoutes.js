// server/solanaPaymentRoutes.js
import express from 'express';
import { solanaPaymentService } from './solanaPaymentService.js';

/**
 * Register Solana payment API routes
 * @param {express.Application} app - Express application
 */
export function registerSolanaRoutes(app) {
  if (!app || typeof app.use !== 'function') {
    throw new Error('Valid Express app instance is required');
  }

  // Get payment configuration
  app.get('/api/payment/config', (req, res) => {
    try {
      res.json({
        success: true,
        network: process.env.SOLANA_NETWORK || 'devnet',
        mockMode: process.env.MOCK_SOLANA_VERIFICATION === 'true',
        receiverAddress: solanaPaymentService.receiverPublicKey
      });
    } catch (error) {
      console.error('Failed to get payment config:', error);
      res.status(500).json({ success: false, error: 'Failed to get payment configuration' });
    }
  });

  // Get payment instructions
  app.get('/api/payment/instructions', (req, res) => {
    try {
      const amount = parseFloat(req.query.amount || '0.01');
      if (isNaN(amount) || amount <= 0) {
        return res.status(400).json({
          success: false,
          error: 'Invalid amount specified'
        });
      }
      
      const instructions = solanaPaymentService.getPaymentInstructions(amount);
      res.json({
        success: true,
        ...instructions
      });
    } catch (error) {
      console.error('Failed to get payment instructions:', error);
      res.status(500).json({ success: false, error: 'Failed to generate payment instructions' });
    }
  });

  // Process payment
  app.post('/api/payment/process', express.json(), async (req, res) => {
    try {
      const { amount } = req.body;
      
      if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
        return res.status(400).json({
          success: false,
          error: 'Valid amount is required'
        });
      }
      
      const paymentResult = await solanaPaymentService.processPayment(parseFloat(amount));
      res.json(paymentResult);
    } catch (error) {
      console.error('Payment processing failed:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Payment processing failed'
      });
    }
  });

  // Verify transaction
  app.get('/api/payment/verify/:transactionId', async (req, res) => {
    try {
      const { transactionId } = req.params;
      
      if (!transactionId) {
        return res.status(400).json({
          success: false,
          error: 'Transaction ID is required'
        });
      }
      
      const verificationResult = await solanaPaymentService.verifyTransaction(transactionId);
      res.json(verificationResult);
    } catch (error) {
      console.error('Transaction verification failed:', error);
      res.status(500).json({
        success: false,
        error: error.message || 'Transaction verification failed'
      });
    }
  });

  // Health check for payment service
  app.get('/api/payment/health', (req, res) => {
    res.json({
      success: true,
      service: 'Solana Payment Service',
      status: 'operational',
      mockMode: process.env.MOCK_SOLANA_VERIFICATION === 'true',
      network: process.env.SOLANA_NETWORK || 'devnet',
      timestamp: new Date().toISOString()
    });
  });

  console.log('[Server] Solana payment routes registered');
}

export default registerSolanaRoutes;