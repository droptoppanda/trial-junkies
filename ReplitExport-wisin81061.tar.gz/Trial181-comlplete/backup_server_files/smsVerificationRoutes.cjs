/**
 * SMS Verification Routes
 * 
 * This file defines the Express routes for SMS verification functionality
 */

const smsVerificationService = require('./smsVerificationService.cjs');

/**
 * Register SMS verification routes
 * @param {Express} app - Express app
 */
function registerSmsRoutes(app) {
  // Request a phone number
  app.post('/api/sms/request', async (req, res) => {
    const { service, country, providers } = req.body;
    
    if (!service) {
      return res.status(400).json({
        success: false,
        error: 'Service name is required'
      });
    }
    
    try {
      const result = await smsVerificationService.requestPhoneNumber(
        service,
        country || 'US',
        providers || []
      );
      
      res.json(result);
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to request phone number: ' + error.message
      });
    }
  });
  
  // Get verification code
  app.get('/api/sms/code/:verificationId', async (req, res) => {
    const { verificationId } = req.params;
    const timeout = req.query.timeout ? parseInt(req.query.timeout) : 120;
    
    if (!verificationId) {
      return res.status(400).json({
        success: false,
        error: 'Verification ID is required'
      });
    }
    
    try {
      const result = await smsVerificationService.getVerificationCode(verificationId, timeout);
      res.json(result);
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to get verification code: ' + error.message
      });
    }
  });
  
  // Verify a code
  app.post('/api/sms/verify', (req, res) => {
    const { verificationId, code } = req.body;
    
    if (!verificationId || !code) {
      return res.status(400).json({
        success: false,
        error: 'Verification ID and code are required'
      });
    }
    
    const result = smsVerificationService.verifyCode(verificationId, code);
    res.json(result);
  });
  
  // Cancel a verification
  app.delete('/api/sms/cancel/:verificationId', async (req, res) => {
    const { verificationId } = req.params;
    
    if (!verificationId) {
      return res.status(400).json({
        success: false,
        error: 'Verification ID is required'
      });
    }
    
    try {
      const result = await smsVerificationService.cancelVerification(verificationId);
      res.json(result);
    } catch (error) {
      res.status(500).json({
        success: false,
        error: 'Failed to cancel verification: ' + error.message
      });
    }
  });
  
  // Get available providers
  app.get('/api/sms/providers', (req, res) => {
    const providers = smsVerificationService.getProviders();
    
    res.json({
      success: true,
      providers
    });
  });
}

// Export using CommonJS
module.exports = { registerSmsRoutes };