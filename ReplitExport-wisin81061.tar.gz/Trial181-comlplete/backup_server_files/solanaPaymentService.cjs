/**
 * Solana Payment Service
 * 
 * This service handles Solana blockchain payments, including:
 * - Creating payment requests
 * - Verifying transactions
 * - Managing wallet addresses
 * - Supporting mock mode for testing
 */

// Check if we're in mock mode for testing
const MOCK_MODE = process.env.MOCK_SOLANA_VERIFICATION === 'true';
const SOLANA_RECEIVER_KEY = process.env.SOLANA_RECEIVER_PUBLIC_KEY || '';

/**
 * Solana Payment Service class
 * Provides an interface for handling Solana payments
 */
class SolanaPaymentService {
  constructor() {
    this.receiverAddress = SOLANA_RECEIVER_KEY;
    this.network = 'devnet'; // Default to devnet for safety
    this.transactions = new Map(); // Store transaction data
    this.mockMode = MOCK_MODE;
    
    // Initialize and validate configuration
    this._initialize();
  }
  
  /**
   * Initialize the service and validate configuration
   * @private
   */
  _initialize() {
    // Log configuration
    console.log(`Solana Payment Service initialized.`);
    console.log(`Network: ${this.network}`);
    console.log(`Mock mode: ${this.mockMode ? 'Enabled' : 'Disabled'}`);
    
    if (this.isConfigured()) {
      console.log(`Receiver address: ${this._maskAddress(this.receiverAddress)}`);
    } else {
      console.warn('WARNING: Receiver address not configured. Payment processing will not work.');
    }
  }
  
  /**
   * Get network endpoint based on selected network
   * @returns {string} Network endpoint info
   */
  getNetworkInfo() {
    const endpoints = {
      mainnet: 'https://api.mainnet-beta.solana.com',
      devnet: 'https://api.devnet.solana.com',
      testnet: 'https://api.testnet.solana.com',
    };
    
    return {
      name: this.network,
      endpoint: endpoints[this.network] || endpoints.devnet,
      mockMode: this.mockMode
    };
  }
  
  /**
   * Check if the service is properly configured
   * @returns {boolean} Configuration status
   */
  isConfigured() {
    // If in mock mode, we don't need a real receiver address
    if (this.mockMode) {
      return true;
    }
    
    return this._validateSolanaAddress(this.receiverAddress);
  }
  
  /**
   * Create a payment request
   * @param {number} amount - Amount in SOL
   * @param {Object} metadata - Payment metadata
   * @returns {Object} Payment request info
   */
  createPaymentRequest(amount, metadata = {}) {
    // Generate a unique payment ID
    const paymentId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    
    // Store the payment request
    this.transactions.set(paymentId, {
      paymentId,
      amount,
      receiverAddress: this.receiverAddress,
      status: 'pending',
      createdAt: Date.now(),
      metadata,
      network: this.network,
      mockMode: this.mockMode
    });
    
    return {
      paymentId,
      amount,
      receiverAddress: this.receiverAddress,
      network: this.network,
      mockMode: this.mockMode,
      instructions: [
        `Send ${amount} SOL to ${this.receiverAddress}`,
        'Include the payment ID in the transaction memo',
        'Submit the transaction ID for verification'
      ]
    };
  }
  
  /**
   * Verify a transaction
   * @param {string} transactionId - Solana transaction ID
   * @param {number} expectedAmount - Expected amount in SOL
   * @param {string} paymentId - Optional payment ID to verify
   * @returns {Promise<Object>} Verification result
   */
  async verifyTransaction(transactionId, expectedAmount, paymentId = null) {
    // In mock mode, we simulate verification
    if (this.mockMode) {
      return this._mockVerifyTransaction(transactionId, expectedAmount, paymentId);
    }
    
    // Real verification would happen here using Solana web3.js
    // This would include:
    // 1. Fetching the transaction from the blockchain
    // 2. Validating the receiver address
    // 3. Confirming the amount
    // 4. Checking the transaction status
    
    // For now, return an error since we're not implementing real verification
    return {
      success: false,
      error: 'Real transaction verification not implemented. Use mock mode for testing.'
    };
  }
  
  /**
   * Mock transaction verification for testing
   * @param {string} transactionId - Mock transaction ID
   * @param {number} expectedAmount - Expected amount in SOL
   * @param {string} paymentId - Optional payment ID to verify
   * @returns {Promise<Object>} Mock verification result
   * @private
   */
  async _mockVerifyTransaction(transactionId, expectedAmount, paymentId = null) {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Check if the transaction ID looks valid
    if (!transactionId || typeof transactionId !== 'string' || transactionId.length < 10) {
      return {
        success: false,
        error: 'Invalid transaction ID format'
      };
    }
    
    // For mock verification, we'll accept transaction IDs that start with "mock_valid"
    const isValid = transactionId.startsWith('mock_valid');
    
    // If we have a payment ID, update its status
    if (paymentId && this.transactions.has(paymentId)) {
      const payment = this.transactions.get(paymentId);
      payment.transactionId = transactionId;
      payment.verifiedAt = Date.now();
      payment.status = isValid ? 'confirmed' : 'failed';
      this.transactions.set(paymentId, payment);
    }
    
    if (isValid) {
      return {
        success: true,
        verified: true,
        amount: expectedAmount,
        receiverAddress: this.receiverAddress,
        transactionId,
        timestamp: new Date().toISOString(),
        mockMode: true
      };
    } else {
      return {
        success: false,
        verified: false,
        error: 'Transaction verification failed',
        mockMode: true
      };
    }
  }
  
  /**
   * Get payment status
   * @param {string} paymentId - Payment ID to check
   * @returns {Object} Payment status
   */
  getPaymentStatus(paymentId) {
    if (!this.transactions.has(paymentId)) {
      return {
        success: false,
        error: 'Payment not found'
      };
    }
    
    const payment = this.transactions.get(paymentId);
    
    return {
      success: true,
      paymentId,
      status: payment.status,
      amount: payment.amount,
      createdAt: new Date(payment.createdAt).toISOString(),
      verifiedAt: payment.verifiedAt ? new Date(payment.verifiedAt).toISOString() : null,
      transactionId: payment.transactionId || null
    };
  }
  
  /**
   * Validate a Solana address format
   * @param {string} address - Address to validate
   * @returns {boolean} Is valid
   * @private
   */
  _validateSolanaAddress(address) {
    if (!address || typeof address !== 'string') {
      return false;
    }
    
    // Basic format check: 32-44 characters, alphanumeric
    // Real validation would use PublicKey from @solana/web3.js
    return /^[a-zA-Z0-9]{32,44}$/.test(address);
  }
  
  /**
   * Mask an address for display (privacy)
   * @param {string} address - Address to mask
   * @returns {string} Masked address
   * @private
   */
  _maskAddress(address) {
    if (!address || typeof address !== 'string') {
      return '';
    }
    
    if (address.length <= 8) {
      return address;
    }
    
    return `${address.substring(0, 4)}...${address.substring(address.length - 4)}`;
  }
}

// Create a singleton instance
const solanaPaymentService = new SolanaPaymentService();

// Export using CommonJS
module.exports = solanaPaymentService;