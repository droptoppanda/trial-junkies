/**
 * SMS Verification Service
 * 
 * This service provides SMS verification functionality with multi-provider support and
 * automatic fallback mechanisms for optimal success rates.
 */

/**
 * SMS Provider interface
 * All SMS providers should implement these methods
 */
class SmsProvider {
  constructor(apiKey, options = {}) {
    this.apiKey = apiKey;
    this.options = options;
  }

  /**
   * Request a phone number for verification
   * @param {string} service - Service to verify for (e.g., "netflix", "spotify")
   * @param {string} country - Country code (e.g., "US", "UK")
   * @returns {Promise<Object>} - Phone number information
   */
  async requestPhoneNumber(service, country) {
    throw new Error('Not implemented');
  }

  /**
   * Get the SMS code sent to a phone number
   * @param {string} id - ID returned from requestPhoneNumber
   * @param {number} timeout - Timeout in seconds
   * @returns {Promise<Object>} - SMS information with code
   */
  async getSmsCode(id, timeout = 120) {
    throw new Error('Not implemented');
  }

  /**
   * Cancel a phone number request
   * @param {string} id - ID to cancel
   * @returns {Promise<boolean>} - Success status
   */
  async cancelRequest(id) {
    throw new Error('Not implemented');
  }

  /**
   * Check if the provider is available and working
   * @returns {Promise<boolean>} - Available status
   */
  async checkAvailability() {
    throw new Error('Not implemented');
  }
}

/**
 * Mock SMS Provider for testing
 * Simulates SMS verification without real API calls
 */
class MockSmsProvider extends SmsProvider {
  constructor(options = {}) {
    super('mock_key', options);
    this.phoneRequests = new Map();
    this.mockDelay = options.mockDelay || 500; // Default 500ms mock delay
  }

  async requestPhoneNumber(service, country = 'US') {
    const id = `mock_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    const phoneNumber = this._generatePhoneNumber(country);
    
    this.phoneRequests.set(id, {
      id,
      phoneNumber,
      service,
      country,
      status: 'pending',
      requestTime: Date.now(),
      // In mock mode, prepare a code immediately but don't "send" it yet
      code: this._generateVerificationCode(),
      codeTime: null,
    });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, this.mockDelay));
    
    return {
      success: true,
      id,
      phoneNumber,
      provider: 'mock'
    };
  }

  async getSmsCode(id, timeout = 120) {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, this.mockDelay));
    
    if (!this.phoneRequests.has(id)) {
      return {
        success: false,
        error: 'Invalid ID'
      };
    }
    
    const request = this.phoneRequests.get(id);
    
    // If the code hasn't been "sent" yet, send it now
    if (!request.codeTime) {
      request.codeTime = Date.now();
      this.phoneRequests.set(id, request);
    }
    
    return {
      success: true,
      code: request.code,
      phoneNumber: request.phoneNumber,
      receivedAt: new Date(request.codeTime).toISOString()
    };
  }

  async cancelRequest(id) {
    if (!this.phoneRequests.has(id)) {
      return {
        success: false,
        error: 'Invalid ID'
      };
    }
    
    this.phoneRequests.delete(id);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, this.mockDelay));
    
    return {
      success: true
    };
  }

  async checkAvailability() {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, this.mockDelay));
    return true;
  }
  
  _generatePhoneNumber(country) {
    // Generate a realistic looking phone number based on country
    switch (country.toUpperCase()) {
      case 'US':
        return '+1' + Math.floor(200000000 + Math.random() * 799999999);
      case 'UK':
        return '+44' + Math.floor(7000000000 + Math.random() * 2999999999);
      default:
        return '+1' + Math.floor(200000000 + Math.random() * 799999999);
    }
  }
  
  _generateVerificationCode() {
    // Generate a 6-digit verification code
    return Math.floor(100000 + Math.random() * 899999).toString();
  }
}

/**
 * SMS Verification service with multi-provider support
 */
class SmsVerificationService {
  constructor() {
    this.providers = new Map();
    this.verifications = new Map();
    
    // Register mock provider by default
    this.registerProvider('mock', new MockSmsProvider({
      mockDelay: 300 // Faster response for testing
    }));
  }
  
  /**
   * Register an SMS provider
   * @param {string} name - Provider name
   * @param {SmsProvider} provider - Provider instance
   */
  registerProvider(name, provider) {
    this.providers.set(name, provider);
  }
  
  /**
   * Initialize the service with API keys
   * @param {Object} apiKeys - Map of provider names to API keys
   */
  initialize(apiKeys = {}) {
    // Implementation would configure real providers with API keys
    console.log('Initializing SMS Verification Service with providers:', Object.keys(apiKeys));
    return true;
  }
  
  /**
   * Get available providers
   * @returns {Array<string>} - List of provider names
   */
  getProviders() {
    return Array.from(this.providers.keys());
  }
  
  /**
   * Request a phone number for verification with automatic provider selection
   * @param {string} service - Service to verify for (e.g., "netflix", "spotify") 
   * @param {string} country - Country code (e.g., "US", "UK")
   * @param {Array<string>} preferredProviders - Ordered list of preferred providers
   * @returns {Promise<Object>} - Phone number information
   */
  async requestPhoneNumber(service, country = 'US', preferredProviders = []) {
    let providers = preferredProviders.length > 0 
      ? preferredProviders.filter(p => this.providers.has(p))
      : Array.from(this.providers.keys());
    
    // If no specified providers are available, use all providers
    if (providers.length === 0) {
      providers = Array.from(this.providers.keys());
    }
    
    // Try each provider in order until success
    let lastError = null;
    for (const providerName of providers) {
      try {
        const provider = this.providers.get(providerName);
        const result = await provider.requestPhoneNumber(service, country);
        
        // Generate a unique verification ID
        const verificationId = `v_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
        
        // Store verification details
        this.verifications.set(verificationId, {
          id: result.id,
          verificationId,
          phoneNumber: result.phoneNumber,
          provider: providerName,
          service,
          country,
          requestTime: Date.now(),
          status: 'pending',
          code: null,
          verified: false
        });
        
        return {
          success: true,
          verificationId,
          phoneNumber: result.phoneNumber,
          provider: providerName
        };
      } catch (error) {
        console.error(`Provider ${providerName} failed:`, error);
        lastError = error;
        // Continue to next provider
      }
    }
    
    return {
      success: false,
      error: `All providers failed. Last error: ${lastError?.message || 'Unknown error'}`
    };
  }
  
  /**
   * Get verification code for a phone number
   * @param {string} verificationId - Verification ID from requestPhoneNumber
   * @param {number} timeout - Timeout in seconds
   * @returns {Promise<Object>} - Verification code information
   */
  async getVerificationCode(verificationId, timeout = 120) {
    if (!this.verifications.has(verificationId)) {
      return {
        success: false,
        error: 'Invalid verification ID'
      };
    }
    
    const verification = this.verifications.get(verificationId);
    const provider = this.providers.get(verification.provider);
    
    if (!provider) {
      return {
        success: false,
        error: 'Provider not available'
      };
    }
    
    try {
      const result = await provider.getSmsCode(verification.id, timeout);
      
      if (result.success && result.code) {
        // Update verification with code
        verification.code = result.code;
        verification.codeTime = Date.now();
        verification.status = 'received';
        this.verifications.set(verificationId, verification);
        
        return {
          success: true,
          code: result.code,
          receivedAt: result.receivedAt || new Date().toISOString()
        };
      } else {
        return {
          success: false,
          error: result.error || 'Code not received yet'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * Cancel a verification request
   * @param {string} verificationId - Verification ID to cancel
   * @returns {Promise<Object>} - Cancellation result
   */
  async cancelVerification(verificationId) {
    if (!this.verifications.has(verificationId)) {
      return {
        success: false,
        error: 'Invalid verification ID'
      };
    }
    
    const verification = this.verifications.get(verificationId);
    const provider = this.providers.get(verification.provider);
    
    if (!provider) {
      return {
        success: false,
        error: 'Provider not available'
      };
    }
    
    try {
      const result = await provider.cancelRequest(verification.id);
      
      if (result.success) {
        // Remove verification
        this.verifications.delete(verificationId);
        
        return {
          success: true
        };
      } else {
        return {
          success: false,
          error: result.error || 'Failed to cancel'
        };
      }
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  /**
   * Verify a code against a stored verification
   * @param {string} verificationId - Verification ID
   * @param {string} code - Code to verify
   * @returns {Object} - Verification result
   */
  verifyCode(verificationId, code) {
    if (!this.verifications.has(verificationId)) {
      return {
        success: false,
        error: 'Invalid verification ID'
      };
    }
    
    const verification = this.verifications.get(verificationId);
    
    // Check if we have a code to verify against
    if (!verification.code) {
      return {
        success: false,
        error: 'No code received yet'
      };
    }
    
    // Verify the code
    if (verification.code === code) {
      verification.verified = true;
      verification.status = 'verified';
      verification.verifiedAt = Date.now();
      this.verifications.set(verificationId, verification);
      
      return {
        success: true,
        verified: true,
        phoneNumber: verification.phoneNumber,
        service: verification.service
      };
    } else {
      return {
        success: false,
        error: 'Invalid code',
        verified: false
      };
    }
  }
}

// Create a singleton instance
const smsVerificationService = new SmsVerificationService();

// Export using CommonJS
module.exports = smsVerificationService;