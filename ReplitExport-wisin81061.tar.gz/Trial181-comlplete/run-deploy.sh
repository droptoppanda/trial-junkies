#!/bin/bash

# Deployment script for Solana Payment Server
echo "Starting Solana Payment System deployment..."

# Set environment variables if not already set
export PORT=${PORT:-3000}
export NODE_ENV=${NODE_ENV:-production}
export SOLANA_MOCK_MODE=${SOLANA_MOCK_MODE:-true}
export SOLANA_NETWORK=${SOLANA_NETWORK:-devnet}

# Print configuration
echo "Configuration:"
echo "- PORT: $PORT"
echo "- NODE_ENV: $NODE_ENV"
echo "- SOLANA_MOCK_MODE: $SOLANA_MOCK_MODE"
echo "- SOLANA_NETWORK: $SOLANA_NETWORK"

# Load .env file if it exists
if [ -f .env ]; then
  echo "Loading environment from .env file"
  set -o allexport
  source .env
  set +o allexport
fi

# Start the server
echo "Starting the server..."
node server-express.js