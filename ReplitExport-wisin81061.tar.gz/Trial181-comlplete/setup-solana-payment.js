/**
 * Setup Script for Solana Payment System
 * 
 * This script helps set up the Solana payment system by:
 * 1. Checking for required environment variables
 * 2. Creating or updating the .env file if needed
 * 3. Verifying all required files are present
 * 4. Printing setup instructions
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get the directory name of the current module (equivalent to __dirname in CommonJS)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('=== Solana Payment System Setup ===');

// Check if required files exist
const requiredFiles = [
  'ultra-minimal-server.js',
  'ultra-minimal-test.js',
  'run-minimal-solana-esm.js',
  'run-server-esm.js',
  'run-tests-esm.js',
  '.replit.solana-esm.workflow',
  '.replit.solana-server-esm.workflow',
  '.replit.solana-tests-esm.workflow'
];

const missingFiles = [];
for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(__dirname, file))) {
    missingFiles.push(file);
  }
}

if (missingFiles.length > 0) {
  console.error(`Error: The following required files are missing: ${missingFiles.join(', ')}`);
  process.exit(1);
}

console.log('✅ All required files are present');

// Check for .env file
let envFileContents = '';
const defaultEnvSettings = {
  SOLANA_RECEIVER_PUBLIC_KEY: 'DUMMY_SOLANA_ADDRESS_FOR_TESTING_PURPOSES_ONLY',
  SOLANA_NETWORK: 'devnet',
  SOLANA_MOCK_MODE: 'true',
  PORT: '3000',
  MOCK_SOLANA_VERIFICATION: 'true'
};

try {
  envFileContents = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
  console.log('✅ Found existing .env file');
} catch (error) {
  console.log('⚠️ No .env file found, creating default .env file');
  
  envFileContents = Object.entries(defaultEnvSettings)
    .map(([key, value]) => `${key}=${value}`)
    .join('\n');
  
  // Add comments
  envFileContents = '# Solana Payment Configuration\n' + 
    envFileContents.slice(0, envFileContents.indexOf('PORT')) + 
    '\n# Server Configuration\n' + 
    envFileContents.slice(envFileContents.indexOf('PORT'), envFileContents.indexOf('MOCK_SOLANA_VERIFICATION')) +
    '\n# Mock Mode Overrides\n' + 
    envFileContents.slice(envFileContents.indexOf('MOCK_SOLANA_VERIFICATION'));
  
  fs.writeFileSync(path.join(__dirname, '.env'), envFileContents);
  console.log('✅ Created default .env file');
}

// Parse existing .env file to check for missing variables
const envVars = {};
envFileContents.split('\n').forEach(line => {
  if (line.trim() && !line.startsWith('#')) {
    const [key, value] = line.split('=');
    if (key && value) {
      envVars[key.trim()] = value.trim();
    }
  }
});

// Check for missing environment variables
const missingEnvVars = [];
for (const [key, value] of Object.entries(defaultEnvSettings)) {
  if (!envVars[key]) {
    missingEnvVars.push(key);
    envVars[key] = value;
  }
}

// Update .env file if missing variables were found
if (missingEnvVars.length > 0) {
  console.log(`⚠️ Missing environment variables: ${missingEnvVars.join(', ')}`);
  
  // Preserve comments and format of existing file
  const envLines = envFileContents.split('\n');
  for (const key of missingEnvVars) {
    envLines.push(`${key}=${envVars[key]}`);
  }
  
  fs.writeFileSync(path.join(__dirname, '.env'), envLines.join('\n'));
  console.log('✅ Updated .env file with missing variables');
}

console.log('\n=== Setup Complete ===');
console.log('\nTo run the Solana payment system, use one of the following commands:');
console.log('');
console.log('1. Run both server and tests:');
console.log('   node run-minimal-solana-esm.js');
console.log('');
console.log('2. Run only the server:');
console.log('   node run-server-esm.js');
console.log('');
console.log('3. Run tests against a running server:');
console.log('   node run-tests-esm.js');
console.log('');
console.log('For more information, please refer to SOLANA_PAYMENT_README.md');

// Check for Solana receiver key
if (envVars.SOLANA_RECEIVER_PUBLIC_KEY === 'DUMMY_SOLANA_ADDRESS_FOR_TESTING_PURPOSES_ONLY') {
  console.log('\n⚠️ WARNING: You are using a dummy Solana receiver address.');
  console.log('To accept real payments, update SOLANA_RECEIVER_PUBLIC_KEY in the .env file.');
}

// Check for mock mode
if (envVars.SOLANA_MOCK_MODE === 'true') {
  console.log('\n⚠️ WARNING: Mock mode is enabled. No real Solana transactions will be processed.');
  console.log('To process real transactions, set SOLANA_MOCK_MODE=false in the .env file.');
}