/**
 * Test Runner Script
 * 
 * This script runs the test suite for the application
 */

const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

// Set environment variables for testing
process.env.NODE_ENV = 'test';
process.env.MOCK_SOLANA_VERIFICATION = 'true';
process.env.SOLANA_MOCK_MODE = 'true';
process.env.SOLANA_NETWORK = 'devnet';

// If no receiver key is set, use a test key
if (!process.env.SOLANA_RECEIVER_PUBLIC_KEY) {
  process.env.SOLANA_RECEIVER_PUBLIC_KEY = 'Ey9MqEpP5QzBjStfNV1Z2Jj7WEnzQ5j8t2Wtg8fgGcHa';
  console.log('Using test receiver key for Solana tests.');
}

// Ensure test scripts are executable
try {
  console.log('Setting up test scripts...');
  execSync('chmod +x tests/*.sh');
  execSync('chmod +x test-scripts/*.sh');
  console.log('✅ Test scripts are now executable');
} catch (error) {
  console.error('❌ Failed to make test scripts executable:', error.message);
}

// Run the tests
try {
  console.log('\nRunning test suite...');
  console.log('-'.repeat(50));
  execSync('cd tests && bash run-tests.sh', { stdio: 'inherit' });
} catch (error) {
  console.error('\n❌ Test suite failed:', error.message);
  process.exit(1);
}

console.log('\n✅ All tests completed successfully!');
process.exit(0);