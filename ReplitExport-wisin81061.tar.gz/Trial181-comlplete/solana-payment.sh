#!/bin/bash

# Solana Payment System Launcher Script
# This script provides an easy way to set up and run the Solana payment system

NODEJS_PATH="/nix/store/0akvkk9k1a7z5vjp34yz6dr91j776jhv-nodejs-20.11.1/bin/node"

# Check if Node.js is available
if [ ! -f "$NODEJS_PATH" ]; then
  echo "Error: Node.js not found at $NODEJS_PATH"
  echo "Please update the NODEJS_PATH variable in this script"
  exit 1
fi

# Display menu
show_menu() {
  clear
  echo "===== Solana Payment System ====="
  echo "1. Run Setup"
  echo "2. Run Server and Tests"
  echo "3. Run Server Only"
  echo "4. Run Tests Only"
  echo "5. View README"
  echo "6. Edit .env File"
  echo "7. Exit"
  echo "=================================="
  echo -n "Please enter your choice [1-7]: "
}

# Run setup
run_setup() {
  echo "Running setup..."
  $NODEJS_PATH setup-solana-payment.js
  echo ""
  read -p "Press Enter to continue..."
}

# Run server and tests
run_server_and_tests() {
  echo "Running server and tests..."
  $NODEJS_PATH run-minimal-solana-esm.js
  echo ""
  read -p "Press Enter to continue..."
}

# Run server only
run_server_only() {
  echo "Running server only..."
  echo "Press Ctrl+C to stop the server"
  $NODEJS_PATH run-server-esm.js
  echo ""
  read -p "Press Enter to continue..."
}

# Run tests only
run_tests_only() {
  echo "Running tests only..."
  echo "Make sure the server is running in another terminal"
  $NODEJS_PATH run-tests-esm.js
  echo ""
  read -p "Press Enter to continue..."
}

# View README
view_readme() {
  clear
  if [ -f "SOLANA_PAYMENT_README.md" ]; then
    cat SOLANA_PAYMENT_README.md
  else
    echo "README file not found"
  fi
  echo ""
  read -p "Press Enter to continue..."
}

# Edit .env file
edit_env_file() {
  if [ -f ".env" ]; then
    echo "Editing .env file..."
    if [ -n "$EDITOR" ]; then
      $EDITOR .env
    elif command -v nano >/dev/null 2>&1; then
      nano .env
    elif command -v vim >/dev/null 2>&1; then
      vim .env
    else
      echo "No editor found. Please edit the .env file manually."
    fi
  else
    echo ".env file not found"
  fi
  echo ""
  read -p "Press Enter to continue..."
}

# Main loop
while true; do
  show_menu
  read choice
  
  case $choice in
    1) run_setup ;;
    2) run_server_and_tests ;;
    3) run_server_only ;;
    4) run_tests_only ;;
    5) view_readme ;;
    6) edit_env_file ;;
    7) echo "Exiting..."; exit 0 ;;
    *) echo "Invalid option. Please try again."; read -p "Press Enter to continue..." ;;
  esac
done