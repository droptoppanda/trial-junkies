import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Environment config table
export const environmentConfig = pgTable("environment_config", {
  id: serial("id").primaryKey(),
  solana_receiver_public_key: text("solana_receiver_public_key").notNull(),
  mock_solana_verification: boolean("mock_solana_verification").default(false),
  enable_sms_verification: boolean("enable_sms_verification").default(false),
  sms_provider: text("sms_provider"),
  sms_api_key: text("sms_api_key"),
  sms_sender_id: text("sms_sender_id"),
  enable_email_verification: boolean("enable_email_verification").default(false),
  email_provider: text("email_provider"),
  email_api_key: text("email_api_key"),
  email_sender: text("email_sender"),
  enable_proxy: boolean("enable_proxy").default(false),
  proxy_provider: text("proxy_provider"),
  proxy_api_key: text("proxy_api_key"),
  proxy_country: text("proxy_country"),
  database_type: text("database_type").default("postgres"),
  database_url: text("database_url"),
  enable_web_scraping: boolean("enable_web_scraping").default(true),
  enable_captcha_solver: boolean("enable_captcha_solver").default(false),
  enable_discord_integration: boolean("enable_discord_integration").default(false),
  development_mode: boolean("development_mode").default(true),
  last_updated: timestamp("last_updated").defaultNow(),
});

// Environment setup schema for the setup wizard
export const setupEnvironmentSchema = z.object({
  // Solana configuration
  solana_receiver_public_key: z.string().min(1, "Receiver wallet address is required"),
  mock_solana_verification: z.boolean().default(false),
  
  // SMS Verification
  enable_sms_verification: z.boolean().default(false),
  sms_provider: z.string().optional(),
  sms_api_key: z.string().optional(),
  sms_sender_id: z.string().optional(),
  
  // Email Verification
  enable_email_verification: z.boolean().default(false),
  email_provider: z.string().optional(),
  email_api_key: z.string().optional(),
  email_sender: z.string().optional(),
  
  // Proxy Configuration
  enable_proxy: z.boolean().default(false),
  proxy_provider: z.string().optional(),
  proxy_api_key: z.string().optional(),
  proxy_country: z.string().optional(),
  
  // Database Configuration
  database_type: z.string().default("postgres"),
  database_url: z.string().optional(),
  
  // Feature Flags
  enable_web_scraping: z.boolean().default(true),
  enable_captcha_solver: z.boolean().default(false),
  enable_discord_integration: z.boolean().default(false),
  development_mode: z.boolean().default(true),
});

export const insertEnvironmentConfigSchema = createInsertSchema(environmentConfig);
export type InsertEnvironmentConfig = z.infer<typeof insertEnvironmentConfigSchema>;
export type EnvironmentConfig = typeof environmentConfig.$inferSelect;

// Legacy environment setup configuration
export const environmentSetupSchema = z.object({
  solana: z.object({
    receiver_public_key: z.string().min(32).max(44),
    mock_verification: z.boolean().default(true),
    network: z.enum(["mainnet-beta", "testnet", "devnet"]).default("devnet")
  }),
  sms_verification: z.object({
    api_key: z.string().min(1).optional(),
    mock_verification: z.boolean().default(true),
    provider: z.enum(["twilio", "vonage", "mock"]).default("mock")
  }),
  email_verification: z.object({
    api_key: z.string().min(1).optional(),
    mock_verification: z.boolean().default(true),
    provider: z.enum(["sendgrid", "mailchimp", "mock"]).default("mock")
  }),
  proxy_configuration: z.object({
    enabled: z.boolean().default(false),
    provider: z.enum(["brightdata", "oxylabs", "smartproxy", "mock"]).default("mock"),
    api_key: z.string().min(1).optional()
  }),
  database: z.object({
    use_memory_storage: z.boolean().default(true)
  }),
  features: z.object({
    solana_payments: z.boolean().default(true),
    sms_verification: z.boolean().default(true),
    virtual_cards: z.boolean().default(true),
    discord_integration: z.boolean().default(false)
  })
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  wallet_address: text("wallet_address"),
  discord_id: text("discord_id"),
  discord_username: text("discord_username"),
  discord_access_token: text("discord_access_token"),
  discord_refresh_token: text("discord_refresh_token"),
  discord_token_expiry: timestamp("discord_token_expiry"),
  is_admin: boolean("is_admin").default(false),
  api_key: text("api_key"), // For API access to automated services
  credits_remaining: integer("credits_remaining"), // Track usage credits
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  tier: text("tier").notNull(), // "basic", "pro", "enterprise"
  price: text("price").notNull(), // Amount in SOL
  start_date: timestamp("start_date").notNull(),
  end_date: timestamp("end_date").notNull(),
  active: boolean("active").default(true),
  transaction_signature: text("transaction_signature"),
  discord_role_id: text("discord_role_id"),
});

// AI agent system tables
export const automatedTrials = pgTable("automated_trials", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  service_name: text("service_name").notNull(),
  status: text("status").notNull(), // "queued", "in_progress", "completed", "failed"
  created_at: timestamp("created_at").notNull().defaultNow(),
  completed_at: timestamp("completed_at"),
  credentials: jsonb("credentials"), // Store generated credentials (username, password, etc.)
  website_url: text("website_url").notNull(),
  result_message: text("result_message"),
  is_valid: boolean("is_valid").default(false),
  discord_message_id: text("discord_message_id"), // Store Discord message ID for updates
});

export const virtualIdentities = pgTable("virtual_identities", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  email: text("email").notNull(),
  username: text("username").notNull(),
  password: text("password").notNull(),
  first_name: text("first_name"),
  last_name: text("last_name"),
  birth_date: text("birth_date"),
  created_at: timestamp("created_at").notNull().defaultNow(),
  is_active: boolean("is_active").default(true),
  virtual_card_id: integer("virtual_card_id").references(() => virtualCards.id),
  metadata: jsonb("metadata"), // Store additional identity information
});

export const virtualCards = pgTable("virtual_cards", {
  id: serial("id").primaryKey(),
  user_id: integer("user_id").notNull().references(() => users.id),
  card_number: text("card_number").notNull(),
  expiry_date: text("expiry_date").notNull(),
  cvv: text("cvv").notNull(),
  cardholder_name: text("cardholder_name").notNull(),
  created_at: timestamp("created_at").notNull().defaultNow(),
  is_active: boolean("is_active").default(true),
  balance: text("balance").default("0"),
  provider: text("provider"), // Card provider information
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  wallet_address: true,
  discord_id: true,
  discord_username: true,
  discord_access_token: true,
  discord_refresh_token: true,
  discord_token_expiry: true,
  is_admin: true,
  api_key: true,
  credits_remaining: true,
}).partial({
  wallet_address: true,
  discord_id: true,
  discord_username: true,
  discord_access_token: true,
  discord_refresh_token: true,
  discord_token_expiry: true,
  is_admin: true,
  api_key: true,
  credits_remaining: true,
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).pick({
  user_id: true,
  tier: true,
  price: true,
  start_date: true,
  end_date: true,
  active: true,
  transaction_signature: true,
  discord_role_id: true,
}).partial({
  transaction_signature: true,
  discord_role_id: true,
});

// AI agent system insert schemas
export const insertAutomatedTrialSchema = createInsertSchema(automatedTrials).pick({
  user_id: true,
  service_name: true,
  status: true,
  created_at: true,
  completed_at: true,
  credentials: true,
  website_url: true,
  result_message: true,
  is_valid: true,
  discord_message_id: true,
}).partial({
  completed_at: true,
  credentials: true,
  result_message: true,
  is_valid: true,
  discord_message_id: true,
});

export const insertVirtualIdentitySchema = createInsertSchema(virtualIdentities).pick({
  user_id: true,
  email: true,
  username: true,
  password: true,
  first_name: true,
  last_name: true,
  birth_date: true,
  created_at: true,
  is_active: true,
  virtual_card_id: true,
  metadata: true,
}).partial({
  first_name: true,
  last_name: true,
  birth_date: true,
  virtual_card_id: true,
  metadata: true,
});

export const insertVirtualCardSchema = createInsertSchema(virtualCards).pick({
  user_id: true,
  card_number: true,
  expiry_date: true,
  cvv: true,
  cardholder_name: true,
  created_at: true,
  is_active: true,
  balance: true,
  provider: true,
}).partial({
  created_at: true,
  balance: true,
  provider: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;

export type InsertAutomatedTrial = z.infer<typeof insertAutomatedTrialSchema>;
export type AutomatedTrial = typeof automatedTrials.$inferSelect;

export type InsertVirtualIdentity = z.infer<typeof insertVirtualIdentitySchema>;
export type VirtualIdentity = typeof virtualIdentities.$inferSelect;

export type InsertVirtualCard = z.infer<typeof insertVirtualCardSchema>;
export type VirtualCard = typeof virtualCards.$inferSelect;

// Define subscription tiers
export const subscriptionTiers = {
  basic: {
    name: "Casual User",
    price: "0.1",
    features: [
      "Discord Basic Role",
      "5 Automated Trials per Month",
      "Basic Email Verification",
      "Community Support",
      "Single identity profile"
    ],
    notIncluded: [
      "Premium websites access",
      "Virtual card generation",
      "Custom identity profiles"
    ]
  },
  pro: {
    name: "Junkie Mode",
    price: "0.5",
    features: [
      "Discord Pro Role",
      "25 Automated Trials per Month",
      "Email & Phone Verification",
      "Priority Support",
      "Up to 5 Identity Profiles",
      "Basic Virtual Cards"
    ],
    notIncluded: [
      "Unlimited trials",
      "Advanced identity management"
    ],
    popular: true
  },
  enterprise: {
    name: "Overdose Plan",
    price: "2.0",
    features: [
      "Discord Enterprise Role",
      "Unlimited Automated Trials",
      "Advanced Verification Methods",
      "24/7 Dedicated Support",
      "Unlimited Identity Profiles",
      "Premium Virtual Cards",
      "Custom Website Targeting",
      "API Access"
    ],
    notIncluded: []
  }
};
