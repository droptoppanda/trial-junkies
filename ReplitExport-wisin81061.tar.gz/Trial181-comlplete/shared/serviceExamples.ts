/**
 * Service Examples for Trial Junkies
 * 
 * This file contains examples of services that users can automate trials for.
 * Each service includes details about trial limitations and verification requirements.
 */

export interface ServiceExample {
  id: string;
  name: string;
  logo: string;
  category: 'streaming' | 'productivity' | 'design' | 'gaming' | 'music' | 'cloud' | 'software' | 'education' | 'finance' | 'security';
  trialLength: string;
  paymentRequired: boolean;
  cardRequired: boolean;
  phoneVerification: boolean;
  emailVerification: boolean;
  captchaPresent: boolean;
  ipRestrictions: boolean;
  cookieTracking: boolean;
  difficulty: 'easy' | 'medium' | 'hard';
  popularity: number; // 1-10 rating of popularity
  notes: string;
}

export const serviceExamples: ServiceExample[] = [
  {
    id: 'netflix',
    name: 'Netflix',
    logo: 'netflix.svg',
    category: 'streaming',
    trialLength: '30 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: true,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 10,
    notes: 'Requires new email, payment method, and IP rotation for multiple trials.'
  },
  {
    id: 'spotify',
    name: 'Spotify Premium',
    logo: 'spotify.svg',
    category: 'music',
    trialLength: '30 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 9,
    notes: 'Requires new email and payment method for each trial.'
  },
  {
    id: 'youtube_premium',
    name: 'YouTube Premium',
    logo: 'youtube.svg',
    category: 'streaming',
    trialLength: '1 month',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 8,
    notes: 'Requires new Google account and payment method for each trial.'
  },
  {
    id: 'adobe_cc',
    name: 'Adobe Creative Cloud',
    logo: 'adobe.svg',
    category: 'design',
    trialLength: '7 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 7,
    notes: 'Requires payment method but easy to cancel before charges. New email needed.'
  },
  {
    id: 'hbo_max',
    name: 'HBO Max',
    logo: 'hbomax.svg',
    category: 'streaming',
    trialLength: '7 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: true,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 7,
    notes: 'Checks IP location. Requires new email and payment method.'
  },
  {
    id: 'disney_plus',
    name: 'Disney+',
    logo: 'disneyplus.svg',
    category: 'streaming',
    trialLength: '7 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: true,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 8,
    notes: 'May require different IP for each trial.'
  },
  {
    id: 'hulu',
    name: 'Hulu',
    logo: 'hulu.svg',
    category: 'streaming',
    trialLength: '30 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: true,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 7,
    notes: 'US only. Requires new email and payment method.'
  },
  {
    id: 'amazon_prime',
    name: 'Amazon Prime',
    logo: 'amazon.svg',
    category: 'streaming',
    trialLength: '30 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'hard',
    popularity: 9,
    notes: 'Difficult to automate - may require separate Amazon accounts.'
  },
  {
    id: 'notion',
    name: 'Notion Team',
    logo: 'notion.svg',
    category: 'productivity',
    trialLength: '14 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: false,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'easy',
    popularity: 6,
    notes: 'Easy to set up with new email.'
  },
  {
    id: 'mailchimp',
    name: 'Mailchimp',
    logo: 'mailchimp.svg',
    category: 'productivity',
    trialLength: '30 days',
    paymentRequired: false,
    cardRequired: false,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'easy',
    popularity: 5,
    notes: 'No payment required for trial, just email verification.'
  },
  {
    id: 'canva_pro',
    name: 'Canva Pro',
    logo: 'canva.svg',
    category: 'design',
    trialLength: '30 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'easy',
    popularity: 8,
    notes: 'Simple verification process, requires credit card.'
  },
  {
    id: 'grammarly',
    name: 'Grammarly Premium',
    logo: 'grammarly.svg',
    category: 'productivity',
    trialLength: '7 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'easy',
    popularity: 7,
    notes: 'Requires new email and payment method for each trial.'
  },
  {
    id: 'aws',
    name: 'AWS Free Tier',
    logo: 'aws.svg',
    category: 'cloud',
    trialLength: '12 months',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: true,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'hard',
    popularity: 6,
    notes: 'Requires phone verification and payment method. High fraud detection.'
  },
  {
    id: 'azure',
    name: 'Microsoft Azure',
    logo: 'azure.svg',
    category: 'cloud',
    trialLength: '12 months',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: true,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'hard',
    popularity: 5,
    notes: 'Requires Microsoft account, phone verification, and payment method.'
  },
  {
    id: 'chatgpt',
    name: 'ChatGPT Plus',
    logo: 'chatgpt.svg',
    category: 'productivity',
    trialLength: 'No free trial',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 10,
    notes: 'No standard trial but occasional promotions. Strong account verification.'
  },
  {
    id: 'discord_nitro',
    name: 'Discord Nitro',
    logo: 'discord.svg',
    category: 'gaming',
    trialLength: '7 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: true,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: true,
    cookieTracking: true,
    difficulty: 'hard',
    popularity: 9,
    notes: 'Requires phone verification for new accounts. Strong fraud detection.'
  },
  {
    id: 'shopify',
    name: 'Shopify',
    logo: 'shopify.svg',
    category: 'finance',
    trialLength: '14 days',
    paymentRequired: false,
    cardRequired: false,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'easy',
    popularity: 7,
    notes: 'No payment required for trial, just email verification.'
  },
  {
    id: 'nordvpn',
    name: 'NordVPN',
    logo: 'nordvpn.svg',
    category: 'security',
    trialLength: '30 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 8,
    notes: 'Money-back guarantee rather than free trial. Requires payment upfront.'
  },
  {
    id: 'expressvpn',
    name: 'ExpressVPN',
    logo: 'expressvpn.svg',
    category: 'security',
    trialLength: '30 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'medium',
    popularity: 7,
    notes: 'Money-back guarantee rather than free trial. Requires payment upfront.'
  },
  {
    id: 'coursera',
    name: 'Coursera Plus',
    logo: 'coursera.svg',
    category: 'education',
    trialLength: '14 days',
    paymentRequired: true,
    cardRequired: true,
    phoneVerification: false,
    emailVerification: true,
    captchaPresent: true,
    ipRestrictions: false,
    cookieTracking: true,
    difficulty: 'easy',
    popularity: 6,
    notes: 'Simple verification process with new email and payment method.'
  }
];

/**
 * Service Categories
 * Used for filtering services by category
 */
export const serviceCategories = [
  { id: 'streaming', name: 'Streaming Services' },
  { id: 'productivity', name: 'Productivity Tools' },
  { id: 'design', name: 'Design & Creative' },
  { id: 'gaming', name: 'Gaming Services' },
  { id: 'music', name: 'Music Services' },
  { id: 'cloud', name: 'Cloud Computing' },
  { id: 'software', name: 'Software' },
  { id: 'education', name: 'Education' },
  { id: 'finance', name: 'Finance & Business' },
  { id: 'security', name: 'Security & VPN' }
];

/**
 * Get services by category
 * @param category Category ID
 * @returns Array of services in the specified category
 */
export function getServicesByCategory(category: string): ServiceExample[] {
  return serviceExamples.filter(service => service.category === category);
}

/**
 * Get most popular services
 * @param limit Maximum number of services to return
 * @returns Array of most popular services
 */
export function getPopularServices(limit = 5): ServiceExample[] {
  return [...serviceExamples]
    .sort((a, b) => b.popularity - a.popularity)
    .slice(0, limit);
}

/**
 * Search services by name or category
 * @param query Search query
 * @returns Array of services matching the search query
 */
export function searchServices(query: string): ServiceExample[] {
  const lowerQuery = query.toLowerCase();
  return serviceExamples.filter(
    service => 
      service.name.toLowerCase().includes(lowerQuery) || 
      service.category.toLowerCase().includes(lowerQuery)
  );
}