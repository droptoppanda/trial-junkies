// Setup Database Schema Script
// This script checks the database connection and creates necessary tables
// based on our schema definition

import { drizzle } from 'drizzle-orm/postgres-js';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import postgres from 'postgres';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Get database URL from environment variables
const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  console.error('DATABASE_URL environment variable is not set!');
  process.exit(1);
}

console.log('Connecting to database...');

// Create the database connection
const sql = postgres(databaseUrl, { max: 1 });
const db = drizzle(sql);

console.log('Database connection established.');
console.log('Setting up database schema...');

// We'll use the `drizzle-orm/postgres-js/migrator` for simple setup
// In a production environment, you might want to use a more robust migration tool
async function setupDatabase() {
  try {
    // Check if the connection works by running a simple query
    const result = await sql`SELECT NOW()`;
    console.log('Database connection test successful:', result[0].now);
    
    // Note: In a real application, you would likely use migrations
    // For this example, we'll just log information
    console.log('Database is configured and ready to use!');
    console.log('To run migrations or schema changes, use:');
    console.log('npm run db:push');
    
    // Clean up
    await sql.end();
    console.log('Database connection closed.');
  } catch (error) {
    console.error('Error setting up database:', error);
    process.exit(1);
  }
}

// Run the setup
setupDatabase();