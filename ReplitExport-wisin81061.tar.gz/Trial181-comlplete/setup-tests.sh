#!/bin/bash

# Setup Test Environment
#
# This script makes all test scripts executable and sets up the test environment

echo "Setting up test environment..."

# Make all test scripts executable
echo "Making test scripts executable..."
chmod +x tests/*.sh
chmod +x test-scripts/*.sh

echo "Test environment setup complete!"
echo ""
echo "Available test commands:"
echo "  bash tests/run-tests.sh                 - Run all tests"
echo "  bash tests/api-test.sh                  - Test API endpoints"
echo "  bash tests/trial-creation-test.sh       - Test trial creation flow"
echo "  bash tests/sms-verification-test.sh     - Test SMS verification"
echo "  bash tests/captcha-test.sh              - Test captcha solver"
echo "  bash tests/database-test.sh             - Test database operations"
echo "  npx tsx test-scripts/run-solana-tests.ts - Run Solana tests"
echo ""
echo "Or use the Run Tests workflow to run all tests at once."