import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Catch the SolanaWalletAdapterProvider polyfill warnings
const originalConsoleWarn = console.warn;
console.warn = function(...args) {
  if (args.length > 0 && 
      typeof args[0] === 'string' && 
      args[0].includes('Unexpected implementation of')) {
    return;
  }
  originalConsoleWarn.apply(console, args);
};

createRoot(document.getElementById("root")!).render(<App />);
