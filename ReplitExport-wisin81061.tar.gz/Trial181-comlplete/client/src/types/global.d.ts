declare module 'lucide-react';
declare module 'date-fns';
declare module 'framer-motion';