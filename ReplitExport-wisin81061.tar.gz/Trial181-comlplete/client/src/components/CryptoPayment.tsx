import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, CheckCircle2, CopyIcon, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import axios from 'axios';
import { WalletConnectionModal } from './WalletConnectionModal';

interface CryptoPaymentProps {
  amount: number;
  onSuccess: (transactionId: string) => void;
  onCancel: () => void;
}

export function CryptoPayment({ amount, onSuccess, onCancel }: CryptoPaymentProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('solana');
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  
  // Payment state
  const [paymentInfo, setPaymentInfo] = useState<{
    receiverPublicKey: string;
    network: string;
    mockMode: boolean;
  } | null>(null);
  
  const [transactionState, setTransactionState] = useState<{
    status: 'idle' | 'processing' | 'success' | 'error';
    signature?: string;
    error?: string;
  }>({
    status: 'idle'
  });
  
  // Private key for testing (This should never be stored in the frontend in a real application)
  const [privateKey, setPrivateKey] = useState('');
  
  // Load payment info on component mount
  useEffect(() => {
    const fetchPaymentInfo = async () => {
      try {
        const response = await axios.get('/api/payments/solana/receiver');
        if (response.data.success) {
          setPaymentInfo({
            receiverPublicKey: response.data.receiver_wallet,
            network: response.data.network,
            mockMode: process.env.NODE_ENV !== 'production'
          });
        }
      } catch (error) {
        console.error('Error loading payment info:', error);
        toast({
          title: 'Error',
          description: 'Failed to load payment information. Please try again.',
          variant: 'destructive'
        });
      }
    };
    
    fetchPaymentInfo();
  }, [toast]);
  
  // Function to create a new test wallet (for demo purposes only)
  const generateTestWallet = async () => {
    try {
      // For demo purposes, let's generate a dummy private key
      // In a real app, this would be done securely by the server
      const dummyPrivateKey = Array(64).fill(0).map(() => 
        Math.floor(Math.random() * 16).toString(16)).join('');
      
      setPrivateKey(dummyPrivateKey);
      toast({
        title: 'Test Wallet Generated',
        description: 'A dummy wallet has been created for demo purposes.',
        variant: 'default'
      });
    } catch (error) {
      console.error('Error generating test wallet:', error);
      toast({
        title: 'Error',
        description: 'Failed to generate test wallet.',
        variant: 'destructive'
      });
    }
  };
  
  // Function to process the payment
  const processPayment = async () => {
    setTransactionState({ status: 'processing' });
    
    try {
      const response = await axios.post('/api/payments/solana/process', {
        senderPublicKey: "test-public-key", // In a real app, this would be derived from the privateKey
        amount,
        reference: `Payment for subscription - ${new Date().toISOString()}`
      });
      
      if (response.data.success) {
        setTransactionState({
          status: 'success',
          signature: response.data.transactionId
        });
        
        // Wait for 2 seconds before calling onSuccess to show the success state
        setTimeout(() => {
          onSuccess(response.data.transactionId);
        }, 2000);
      } else {
        setTransactionState({
          status: 'error',
          error: response.data.error
        });
      }
    } catch (error: any) {
      console.error('Error processing payment:', error);
      setTransactionState({
        status: 'error',
        error: error.response?.data?.error || error.message || 'Unknown error'
      });
    }
  };
  
  // Function to handle wallet connection
  const handleWalletConnection = (connectedWallet: { publicKey: string, privateKey: string }) => {
    setPrivateKey(connectedWallet.privateKey);
    setIsWalletModalOpen(false);
    toast({
      title: 'Wallet Connected',
      description: `Connected to wallet ${connectedWallet.publicKey.substring(0, 8)}...`,
      variant: 'default'
    });
  };
  
  // Function to copy receiver address to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied!',
      description: 'Address copied to clipboard',
      variant: 'default'
    });
  };
  
  return (
    <div className="w-full max-w-md mx-auto">
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Payment Details</CardTitle>
          <CardDescription>
            Complete your payment using cryptocurrency.
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue="solana" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-1">
              <TabsTrigger value="solana">Solana (SOL)</TabsTrigger>
            </TabsList>
            
            <TabsContent value="solana" className="space-y-4 mt-4">
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Amount</Label>
                    <div className="font-bold text-xl">{amount} SOL</div>
                  </div>
                  
                  <div>
                    <Label>Network</Label>
                    <div>{paymentInfo?.network || 'Loading...'}</div>
                  </div>
                </div>
                
                {paymentInfo?.mockMode && (
                  <Alert className="mt-4 bg-yellow-50 border-yellow-200">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <AlertTitle className="text-yellow-800">Test Mode</AlertTitle>
                    <AlertDescription className="text-yellow-700">
                      This is running in test mode. No real transactions will be made.
                    </AlertDescription>
                  </Alert>
                )}
                
                <div className="mt-4">
                  <Label htmlFor="receiver-address">Receiver Wallet Address</Label>
                  <div className="flex items-center mt-1">
                    <Input 
                      id="receiver-address"
                      value={paymentInfo?.receiverPublicKey || 'Loading...'}
                      readOnly
                      className="flex-1"
                    />
                    <button
                      onClick={() => paymentInfo?.receiverPublicKey && copyToClipboard(paymentInfo.receiverPublicKey)}
                      className="ml-2 inline-flex items-center justify-center whitespace-nowrap rounded-md border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 w-10"
                    >
                      <CopyIcon className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                
                {paymentInfo?.mockMode && (
                  <>
                    <div className="mt-4">
                      <Label htmlFor="private-key">Private Key (for testing only)</Label>
                      <div className="flex items-center mt-1">
                        <Input
                          id="private-key"
                          value={privateKey}
                          onChange={(e) => setPrivateKey(e.target.value)}
                          placeholder="Enter wallet private key for testing"
                          className="flex-1"
                        />
                        <button
                          onClick={generateTestWallet}
                          className="ml-2 inline-flex items-center justify-center whitespace-nowrap rounded-md border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 w-10"
                          title="Generate Test Wallet"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        In a real application, you would connect your wallet instead.
                      </p>
                    </div>
                  </>
                )}
                
                {transactionState.status === 'success' && (
                  <Alert className="mt-4">
                    <CheckCircle2 className="h-4 w-4" />
                    <AlertTitle>Payment Successful</AlertTitle>
                    <AlertDescription>
                      Your payment has been processed successfully.
                      <div className="text-xs mt-2">
                        Transaction ID: {transactionState.signature}
                      </div>
                    </AlertDescription>
                  </Alert>
                )}
                
                {transactionState.status === 'error' && (
                  <Alert variant="destructive" className="mt-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Payment Failed</AlertTitle>
                    <AlertDescription>
                      {transactionState.error || 'An error occurred during payment processing.'}
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        
        <CardFooter className="flex justify-between">
          <button 
            className="inline-flex items-center justify-center whitespace-nowrap rounded-md border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2 text-sm font-medium disabled:opacity-50" 
            onClick={onCancel} 
            disabled={transactionState.status === 'processing'}
          >
            Cancel
          </button>
          
          {!paymentInfo?.mockMode ? (
            <button 
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 text-sm font-medium disabled:opacity-50"
              onClick={() => setIsWalletModalOpen(true)} 
              disabled={transactionState.status === 'processing'}
            >
              Connect Wallet
            </button>
          ) : (
            <button 
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 text-sm font-medium disabled:opacity-50"
              onClick={processPayment} 
              disabled={transactionState.status === 'processing' || !privateKey}
            >
              {transactionState.status === 'processing' ? 'Processing...' : 'Pay Now'}
            </button>
          )}
        </CardFooter>
      </Card>
      
      <WalletConnectionModal 
        isOpen={isWalletModalOpen} 
        onClose={() => setIsWalletModalOpen(false)}
        onConnect={handleWalletConnection}
      />
    </div>
  );
}