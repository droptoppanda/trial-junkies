import { Button } from "@/components/ui/button";
import { useScrollTo } from "@/lib/useScrollTo";
import { motion } from "framer-motion";

export function CTASection() {
  const { scrollToNext } = useScrollTo();

  const statsData = [
    { value: "100+", label: "Active Projects" },
    { value: "10k+", label: "Discord Members" },
    { value: "$2M+", label: "SOL Processed" },
    { value: "99.9%", label: "Uptime" }
  ];

  return (
    <section id="cta" className="relative min-h-screen flex items-center bg-cta">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div 
          className="max-w-4xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6">Ready to transform your <span className="text-[#14F195]">subscription experience?</span></h2>
          <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">Join the future of Web3 subscription management with seamless Solana payments and Discord integration.</p>
          
          <motion.div 
            className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Button className="bg-[#14F195] hover:bg-[#14F195]/90 text-black py-3 px-8 rounded-md flex items-center glow-on-hover h-auto font-bold" size="lg">
              <svg 
                className="mr-2 h-5 w-5" 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              Get Started Now
            </Button>
            <Button variant="outline" className="bg-transparent hover:bg-white/5 text-white border border-white/20 py-3 px-8 rounded-md flex items-center h-auto font-medium" size="lg">
              <svg 
                className="mr-2 h-5 w-5" 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="3" y1="9" x2="21" y2="9"></line>
                <line x1="9" y1="21" x2="9" y2="9"></line>
              </svg>
              Request Demo
            </Button>
          </motion.div>
          
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl mx-auto"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {statsData.map((stat, index) => (
              <motion.div 
                key={index} 
                className="text-center"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.1 * index }}
              >
                <div className="text-3xl font-bold text-[#14F195] mb-1">{stat.value}</div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
      
      <div className="section-divider animate-bounce">
        <button 
          onClick={() => scrollToNext("cta")}
          aria-label="Scroll to footer section"
          className="focus:outline-none"
        >
          <svg 
            className="w-6 h-6 text-[#14F195]/80 hover:text-[#14F195] transition-colors" 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <polyline points="19 12 12 19 5 12"></polyline>
          </svg>
        </button>
      </div>
    </section>
  );
}

export default CTASection;
