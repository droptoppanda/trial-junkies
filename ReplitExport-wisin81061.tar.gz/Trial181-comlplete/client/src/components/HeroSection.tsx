import { Button } from "@/components/ui/button";
import { useScrollTo } from "@/lib/useScrollTo";
import { motion, useAnimationControls, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

export function HeroSection() {
  const { scrollToNext } = useScrollTo();
  const [typedText, setTypedText] = useState("");
  const [showCursor, setShowCursor] = useState(true);
  const [textComplete, setTextComplete] = useState(false);
  const [hoveredButton, setHoveredButton] = useState<string | null>(null);
  const controls = useAnimationControls();
  const headingControls = useAnimationControls();
  const cardControls = useAnimationControls();

  const fullText = "Save serious cash by generating unlimited trials. Why pay full price when you can hack the system?";
  
  // Typing animation effect
  useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      if (index < fullText.length) {
        setTypedText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(interval);
        setTextComplete(true);
      }
    }, 30); // Speed of typing

    return () => clearInterval(interval);
  }, []);
  
  // Cursor blinking effect
  useEffect(() => {
    const cursorInterval = setInterval(() => {
      setShowCursor(prev => !prev);
    }, 530);
    
    return () => clearInterval(cursorInterval);
  }, []);
  
  // Trigger animations when text is complete
  useEffect(() => {
    if (textComplete) {
      controls.start({
        opacity: 1,
        y: 0,
        transition: { duration: 0.5, staggerChildren: 0.1, delayChildren: 0.2 }
      });
      
      headingControls.start({
        scale: [1, 1.03, 1],
        transition: { 
          duration: 1.2, 
          times: [0, 0.5, 1],
          repeat: Infinity,
          repeatType: "reverse" 
        }
      });
    }
  }, [textComplete, controls, headingControls]);

  const bounceAnimation = {
    scale: [1, 1.05, 1],
    transition: { duration: 0.5 }
  };

  return (
    <section 
      id="hero" 
      className="relative flex items-center justify-center min-h-screen bg-hero"
    >
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          className="absolute -top-20 -left-20 w-72 h-72 bg-[#14F195]/10 rounded-full blur-3xl"
          animate={{
            x: [0, 20, 0],
            y: [0, 15, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
        <motion.div 
          className="absolute top-1/3 right-1/4 w-52 h-52 bg-purple-500/10 rounded-full blur-3xl"
          animate={{
            x: [0, -30, 0],
            y: [0, 20, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
        <motion.div 
          className="absolute bottom-1/4 right-1/5 w-60 h-60 bg-blue-500/10 rounded-full blur-3xl"
          animate={{
            x: [0, 25, 0],
            y: [0, -15, 0],
            scale: [1, 1.15, 1],
          }}
          transition={{
            duration: 9,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-16 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between">
          <motion.div 
            className="w-full lg:w-1/2 mb-12 lg:mb-0"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <motion.h1 
              className="text-4xl sm:text-5xl md:text-6xl font-bold leading-tight mb-6 responsive-text-lg"
              animate={headingControls}
            >
              <motion.span 
                className="text-[#14F195] inline-block"
                whileHover={{ 
                  scale: 1.05,
                  textShadow: "0 0 8px rgb(20, 241, 149, 0.8)",
                  transition: { duration: 0.2 } 
                }}
              >
                Trial
              </motion.span>{" "}
              <motion.span
                className="inline-block"
                whileHover={{ 
                  scale: 1.05,
                  transition: { duration: 0.2 } 
                }}
              >
                Junkies
              </motion.span>{" "}
              <br />
              <motion.span
                className="inline-block"
                initial={{ opacity: 0 }}
                animate={{ 
                  opacity: 1,
                  transition: { delay: 0.5, duration: 0.5 }
                }}
                whileHover={{ 
                  scale: 1.05,
                  color: "#14F195",
                  transition: { duration: 0.2 } 
                }}
              >
                Unleashed
              </motion.span>
            </motion.h1>
            
            <div className="text-xl text-gray-300 mb-8 max-w-lg responsive-text-md min-h-[72px]">
              {typedText}
              <span className={`${showCursor ? 'opacity-100' : 'opacity-0'} transition-opacity ml-1 inline-block w-[2px] h-[1.2em] bg-[#14F195] align-text-top`}></span>
              {textComplete && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="mt-2 text-[#14F195]"
                >
                  Unleash the power of Solana and Discord authentication.
                </motion.p>
              )}
            </div>
            
            <motion.div 
              className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4"
              initial={{ opacity: 0, y: 10 }}
              animate={controls}
            >
              <motion.div
                whileHover={bounceAnimation}
                whileTap={{ scale: 0.95 }}
                onHoverStart={() => setHoveredButton("getStarted")}
                onHoverEnd={() => setHoveredButton(null)}
              >
                <Button 
                  className="bg-[#14F195] hover:bg-[#14F195]/90 text-black font-medium py-3 px-8 rounded-md flex items-center justify-center glow-on-hover h-auto relative overflow-hidden group"
                  size="lg"
                  onClick={() => scrollToNext("hero")}
                >
                  <motion.span 
                    className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity"
                    animate={hoveredButton === "getStarted" ? {
                      scale: [1, 1.5],
                      opacity: [0.1, 0],
                      borderRadius: ["20%", "50%"]
                    } : {}}
                    transition={{
                      duration: 0.5,
                      ease: "easeOut"
                    }}
                  />
                  <svg 
                    className="mr-2 h-5 w-5" 
                    xmlns="http://www.w3.org/2000/svg" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  >
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                  </svg>
                  Get Started
                </Button>
              </motion.div>
              
              <motion.div
                whileHover={bounceAnimation}
                whileTap={{ scale: 0.95 }}
                onHoverStart={() => setHoveredButton("learnMore")}
                onHoverEnd={() => setHoveredButton(null)}
              >
                <Button 
                  variant="outline" 
                  className="bg-transparent hover:bg-white/5 text-white border border-[#14F195]/30 py-3 px-8 rounded-md flex items-center justify-center h-auto relative overflow-hidden group"
                  size="lg"
                >
                  <motion.span 
                    className="absolute inset-0 bg-[#14F195] opacity-0 group-hover:opacity-5 transition-opacity"
                    animate={hoveredButton === "learnMore" ? {
                      scale: [1, 1.5],
                      opacity: [0.05, 0],
                      borderRadius: ["20%", "50%"]
                    } : {}}
                    transition={{
                      duration: 0.5,
                      ease: "easeOut"
                    }}
                  />
                  <svg 
                    className="mr-2 h-5 w-5" 
                    xmlns="http://www.w3.org/2000/svg" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  >
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="16" x2="12" y2="12"></line>
                    <line x1="12" y1="8" x2="12.01" y2="8"></line>
                  </svg>
                  Learn More
                </Button>
              </motion.div>
            </motion.div>
            
            <motion.div 
              className="mt-12 flex items-center space-x-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7, duration: 0.5 }}
            >
              <motion.div 
                className="flex items-center"
                whileHover={{ scale: 1.05 }}
              >
                <motion.svg 
                  className="h-6 w-6 mr-2 text-[#14F195]" 
                  viewBox="0 0 24 24" 
                  fill="currentColor"
                  xmlns="http://www.w3.org/2000/svg"
                  animate={{
                    rotate: [0, 5, 0, -5, 0],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    repeatType: "loop",
                    ease: "easeInOut",
                    times: [0, 0.2, 0.5, 0.8, 1]
                  }}
                >
                  <path d="M19.54 0c1.356 0 2.46 1.104 2.46 2.472v21.528l-2.58-2.28-1.452-1.344-1.536-1.428.636 2.22h-13.608c-1.356 0-2.46-1.104-2.46-2.472v-16.224c0-1.368 1.104-2.472 2.46-2.472h16.08zm-4.632 15.672c2.652-.084 3.672-1.824 3.672-1.824 0-3.864-1.728-6.996-1.728-6.996-1.728-1.296-3.372-1.26-3.372-1.26l-.168.192c2.04.624 2.988 1.524 2.988 1.524-1.248-.684-2.472-1.02-3.612-1.152-.864-.096-1.692-.072-2.424.024l-.204.024c-.42.036-1.44.192-2.724.756-.444.204-.708.348-.708.348s.996-.948 3.156-1.572l-.12-.144s-1.644-.036-3.372 1.26c0 0-1.728 3.132-1.728 6.996 0 0 1.008 1.74 3.66 1.824 0 0 .444-.54.804-.996-1.524-.456-2.1-1.416-2.1-1.416l.336.204.048.036.047.027.014.006.047.027c.3.168.6.3.876.408.492.192 1.08.384 1.764.516.9.168 1.956.228 3.108.012.564-.096 1.14-.264 1.74-.516.42-.156.888-.384 1.38-.708 0 0-.6.984-2.172 1.428.36.456.792.972.792.972zm-5.58-5.604c-.684 0-1.224.6-1.224 1.332 0 .732.552 1.332 1.224 1.332.684 0 1.224-.6 1.224-1.332.012-.732-.54-1.332-1.224-1.332zm4.38 0c-.684 0-1.224.6-1.224 1.332 0 .732.552 1.332 1.224 1.332.684 0 1.224-.6 1.224-1.332 0-.732-.54-1.332-1.224-1.332z" />
                </motion.svg>
                <motion.span 
                  className="text-sm text-gray-300"
                  whileHover={{ color: "#14F195" }}
                >
                  Discord Integration
                </motion.span>
              </motion.div>
            </motion.div>
          </motion.div>
          
          <motion.div 
            className="w-full lg:w-1/2 relative"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
          >
            <motion.div 
              className="relative z-10 p-6 rounded-xl card-gradient shadow-xl max-w-md mx-auto"
              animate={{ y: [0, -10, 0] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              whileHover={{
                boxShadow: "0 0 25px rgba(20, 241, 149, 0.3)",
                scale: 1.02,
                transition: { duration: 0.2 }
              }}
            >
              <motion.div 
                className="absolute -top-3 -right-3 bg-[#14F195] text-black text-xs font-bold px-3 py-1 rounded-full z-20"
                whileHover={{ scale: 1.1 }}
                animate={{
                  boxShadow: ["0 0 0px rgba(20, 241, 149, 0)", "0 0 10px rgba(20, 241, 149, 0.7)", "0 0 0px rgba(20, 241, 149, 0)"],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "loop"
                }}
              >
                NEW
              </motion.div>
              
              <div className="mb-6">
                <motion.h3 
                  className="text-xl font-semibold mb-2"
                  animate={{
                    color: ["rgb(255, 255, 255)", "rgb(20, 241, 149)", "rgb(255, 255, 255)"],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    repeatType: "reverse"
                  }}
                >
                  Save Big. Hack Smart.
                </motion.h3>
                <motion.p 
                  className="text-gray-400 text-sm"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                >
                  Get unlimited trials and stop paying for expensive subscriptions. Connect now.
                </motion.p>
              </div>
              
              <div className="space-y-4">
                <motion.div
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                >
                  <Button className="w-full bg-[#14F195] hover:bg-[#14F195]/90 text-black font-medium py-3 rounded-md flex items-center justify-center h-auto relative overflow-hidden group">
                    <motion.span 
                      className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10"
                      animate={{
                        scale: [1, 1.5],
                        opacity: [0, 0.1, 0],
                        borderRadius: ["20%", "50%"]
                      }}
                      transition={{
                        duration: 1,
                        repeat: Infinity,
                        repeatType: "loop"
                      }}
                    />
                    Connect Wallet
                  </Button>
                </motion.div>
                
                <motion.div
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                >
                  <Button variant="outline" className="w-full bg-[#0A1014]/50 hover:bg-[#0A1014]/80 text-white py-3 rounded-md flex items-center justify-center border border-[#14F195]/20 h-auto group">
                    <motion.svg 
                      className="mr-2 h-5 w-5 text-[#14F195] group-hover:text-[#14F195]" 
                      xmlns="http://www.w3.org/2000/svg" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                      animate={{ rotate: [0, 5, 0, -5, 0] }}
                      transition={{
                        duration: 1,
                        repeat: Infinity,
                        repeatType: "loop",
                        ease: "easeInOut",
                        times: [0, 0.2, 0.5, 0.8, 1],
                        repeatDelay: 1
                      }}
                    >
                      <path d="M18 7v4c0 1.1-.9 2-2 2H4a2 2 0 01-2-2V7c0-1.1.9-2 2-2h12c1.1 0 2 .9 2 2z" />
                      <path d="M16 21h2c1.1 0 2-.9 2-2v-5h-4v7z" />
                      <path d="M10 21v-7H6v7" />
                    </motion.svg>
                    Connect with WalletConnect
                  </Button>
                </motion.div>
              </div>
              
              <motion.div 
                className="mt-6 pt-6 border-t border-[#14F195]/20"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.3 }}
              >
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm text-gray-400">Save Up To</span>
                  <motion.span 
                    className="text-xs text-[#14F195] font-bold"
                    animate={{
                      scale: [1, 1.1, 1],
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      repeatType: "reverse"
                    }}
                  >
                    $1000+/Year
                  </motion.span>
                </div>
                
                <div className="flex items-center justify-between">
                  <AnimatePresence>
                    {['discord', 'solana', 'user', 'settings'].map((icon, index) => (
                      <motion.div
                        key={icon}
                        whileHover={{ scale: 1.2, y: -5 }}
                        whileTap={{ scale: 0.9 }}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.6 + (index * 0.1), duration: 0.3 }}
                      >
                        <Button variant="ghost" size="icon" className="bg-[#0A1014]/50 text-gray-300 hover:text-[#14F195] p-2 rounded-md transition-colors">
                          {icon === 'discord' && (
                            <svg 
                              className="h-5 w-5" 
                              viewBox="0 0 24 24" 
                              fill="currentColor"
                              xmlns="http://www.w3.org/2000/svg"
                            >
                              <path d="M19.54 0c1.356 0 2.46 1.104 2.46 2.472v21.528l-2.58-2.28-1.452-1.344-1.536-1.428.636 2.22h-13.608c-1.356 0-2.46-1.104-2.46-2.472v-16.224c0-1.368 1.104-2.472 2.46-2.472h16.08zm-4.632 15.672c2.652-.084 3.672-1.824 3.672-1.824 0-3.864-1.728-6.996-1.728-6.996-1.728-1.296-3.372-1.26-3.372-1.26l-.168.192c2.04.624 2.988 1.524 2.988 1.524-1.248-.684-2.472-1.02-3.612-1.152-.864-.096-1.692-.072-2.424.024l-.204.024c-.42.036-1.44.192-2.724.756-.444.204-.708.348-.708.348s.996-.948 3.156-1.572l-.12-.144s-1.644-.036-3.372 1.26c0 0-1.728 3.132-1.728 6.996 0 0 1.008 1.74 3.66 1.824 0 0 .444-.54.804-.996-1.524-.456-2.1-1.416-2.1-1.416l.336.204.048.036.047.027.014.006.047.027c.3.168.6.3.876.408.492.192 1.08.384 1.764.516.9.168 1.956.228 3.108.012.564-.096 1.14-.264 1.74-.516.42-.156.888-.384 1.38-.708 0 0-.6.984-2.172 1.428.36.456.792.972.792.972zm-5.58-5.604c-.684 0-1.224.6-1.224 1.332 0 .732.552 1.332 1.224 1.332.684 0 1.224-.6 1.224-1.332.012-.732-.54-1.332-1.224-1.332zm4.38 0c-.684 0-1.224.6-1.224 1.332 0 .732.552 1.332 1.224 1.332.684 0 1.224-.6 1.224-1.332 0-.732-.54-1.332-1.224-1.332z" />
                            </svg>
                          )}
                          {icon === 'solana' && (
                            <svg 
                              className="h-5 w-5" 
                              xmlns="http://www.w3.org/2000/svg" 
                              viewBox="0 0 24 24" 
                              fill="none" 
                              stroke="currentColor" 
                              strokeWidth="2" 
                              strokeLinecap="round" 
                              strokeLinejoin="round"
                            >
                              <circle cx="12" cy="12" r="10"></circle>
                              <circle cx="12" cy="12" r="4"></circle>
                              <line x1="4.93" y1="4.93" x2="9.17" y2="9.17"></line>
                              <line x1="14.83" y1="14.83" x2="19.07" y2="19.07"></line>
                              <line x1="14.83" y1="9.17" x2="19.07" y2="4.93"></line>
                              <line x1="14.83" y1="9.17" x2="18.36" y2="5.64"></line>
                              <line x1="4.93" y1="19.07" x2="9.17" y2="14.83"></line>
                            </svg>
                          )}
                          {icon === 'user' && (
                            <svg 
                              className="h-5 w-5" 
                              xmlns="http://www.w3.org/2000/svg" 
                              viewBox="0 0 24 24" 
                              fill="none" 
                              stroke="currentColor" 
                              strokeWidth="2" 
                              strokeLinecap="round" 
                              strokeLinejoin="round"
                            >
                              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                              <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                          )}
                          {icon === 'settings' && (
                            <svg 
                              className="h-5 w-5" 
                              xmlns="http://www.w3.org/2000/svg" 
                              viewBox="0 0 24 24" 
                              fill="none" 
                              stroke="currentColor" 
                              strokeWidth="2" 
                              strokeLinecap="round" 
                              strokeLinejoin="round"
                            >
                              <circle cx="12" cy="12" r="3"></circle>
                              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                            </svg>
                          )}
                        </Button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </motion.div>
            </motion.div>
            
            <motion.div 
              className="absolute -bottom-10 -left-10 w-40 h-40 bg-[#14F195]/10 rounded-full blur-3xl"
              animate={{
                scale: [1, 1.2, 1],
                opacity: [0.5, 0.8, 0.5],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                repeatType: "reverse"
              }}
            />
            <motion.div 
              className="absolute top-10 right-0 w-20 h-20 bg-[#14F195]/10 rounded-full blur-2xl"
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.5, 0.7, 0.5],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                repeatType: "reverse",
                delay: 0.5
              }}
            />
          </motion.div>
        </div>
      </div>
      
      <motion.div 
        className="section-divider"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.5 }}
      >
        <motion.button 
          onClick={() => scrollToNext("hero")}
          aria-label="Scroll to features section"
          className="focus:outline-none group"
          whileHover={{ scale: 1.2, y: 5 }}
          whileTap={{ scale: 0.9 }}
          animate={{
            y: [0, 5, 0],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            repeatType: "reverse"
          }}
        >
          <svg 
            className="w-8 h-8 text-[#14F195]/80 hover:text-[#14F195] transition-colors" 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <polyline points="19 12 12 19 5 12"></polyline>
          </svg>
        </motion.button>
      </motion.div>
    </section>
  );
}

export default HeroSection;
