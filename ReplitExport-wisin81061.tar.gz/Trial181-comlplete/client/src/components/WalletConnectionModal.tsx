import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { AlertCircle, Wallet } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface WalletConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnect: (wallet: { publicKey: string; privateKey: string }) => void;
}

export function WalletConnectionModal({ isOpen, onClose, onConnect }: WalletConnectionModalProps) {
  const { toast } = useToast();
  const [step, setStep] = useState<'select' | 'connect'>('select');
  const [walletType, setWalletType] = useState<'phantom' | 'solflare' | 'manual' | null>(null);
  const [privateKey, setPrivateKey] = useState('');
  const [publicKey, setPublicKey] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Reset state when modal opens
  useEffect(() => {
    if (isOpen) {
      setStep('select');
      setWalletType(null);
      setPrivateKey('');
      setPublicKey('');
      setError(null);
    }
  }, [isOpen]);

  // Function to check for Solana wallet extensions
  const checkWalletExtension = (type: 'phantom' | 'solflare') => {
    const windowObj = window as any;
    if (type === 'phantom') {
      return windowObj.phantom?.solana;
    } else if (type === 'solflare') {
      return windowObj.solflare;
    }
    return null;
  };

  // Function to handle wallet selection
  const handleSelectWallet = (type: 'phantom' | 'solflare' | 'manual') => {
    setWalletType(type);
    
    if (type === 'manual') {
      setStep('connect');
      return;
    }
    
    const walletExtension = checkWalletExtension(type);
    if (!walletExtension) {
      setError(`${type === 'phantom' ? 'Phantom' : 'Solflare'} wallet extension not detected. Please install it or use manual connection.`);
      return;
    }
    
    // For demonstration purposes, we're not actually connecting to the wallet extension
    // In a real application, you would use the wallet adapter to connect
    toast({
      title: 'Wallet Connection',
      description: `In a real application, this would connect to your ${type === 'phantom' ? 'Phantom' : 'Solflare'} wallet.`,
      variant: 'default'
    });
    
    // Instead, we'll move to manual connection for the demo
    setStep('connect');
  };

  // Function to handle manual connection
  const handleManualConnect = () => {
    setLoading(true);
    setError(null);
    
    // Validate inputs
    if (!privateKey.trim()) {
      setError('Private key is required');
      setLoading(false);
      return;
    }
    
    if (!publicKey.trim() && walletType === 'manual') {
      setError('Public key is required for manual connection');
      setLoading(false);
      return;
    }
    
    // Simulating connection delay
    setTimeout(() => {
      setLoading(false);
      
      // For demo purposes, we're accepting any input
      // In a real app, you would validate the private key format and derive the public key
      onConnect({
        publicKey: publicKey || 'derived-public-key-would-go-here',
        privateKey
      });
    }, 1000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Connect Your Wallet</DialogTitle>
          <DialogDescription>
            Connect your Solana wallet to make a payment.
          </DialogDescription>
        </DialogHeader>

        {step === 'select' && (
          <div className="grid gap-4 py-4">
            <Button 
              onClick={() => handleSelectWallet('phantom')}
              className="flex items-center justify-between"
              variant="outline"
            >
              <span>Connect with Phantom</span>
              <Wallet className="h-5 w-5" />
            </Button>
            
            <Button 
              onClick={() => handleSelectWallet('solflare')}
              className="flex items-center justify-between"
              variant="outline"
            >
              <span>Connect with Solflare</span>
              <Wallet className="h-5 w-5" />
            </Button>
            
            <Button 
              onClick={() => handleSelectWallet('manual')}
              className="flex items-center justify-between"
              variant="outline"
            >
              <span>Manual Connection</span>
              <Wallet className="h-5 w-5" />
            </Button>
            
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </div>
        )}

        {step === 'connect' && (
          <div className="grid gap-4 py-4">
            {walletType === 'manual' && (
              <div className="grid gap-2">
                <Label htmlFor="public-key">Public Key</Label>
                <Input
                  id="public-key"
                  placeholder="Enter your wallet public key"
                  value={publicKey}
                  onChange={(e) => setPublicKey(e.target.value)}
                />
              </div>
            )}
            
            <div className="grid gap-2">
              <Label htmlFor="private-key">Private Key</Label>
              <Input
                id="private-key"
                type="password"
                placeholder="Enter your wallet private key"
                value={privateKey}
                onChange={(e) => setPrivateKey(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Note: In production, you should never share your private key. This is only for demonstration purposes.
              </p>
            </div>
            
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </div>
        )}

        <DialogFooter>
          {step === 'select' ? (
            <Button variant="outline" onClick={onClose}>Cancel</Button>
          ) : (
            <>
              <Button variant="outline" onClick={() => setStep('select')} disabled={loading}>
                Back
              </Button>
              <Button onClick={handleManualConnect} disabled={loading}>
                {loading ? 'Connecting...' : 'Connect'}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}