import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useWallet, shortenAddress } from "@/lib/wallet";
import WalletConnectionModal from "./WalletConnectionModal";
import { useScrollTo } from "@/lib/useScrollTo";
import { MoonIcon, MenuIcon, XIcon, LogOut } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";

export function NavBar() {
  const [isOpen, setIsOpen] = useState(false);
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [location] = useLocation();
  const { scrollTo } = useScrollTo();
  const { connected, publicKey, disconnect, checkForWallet } = useWallet();

  const isHomePage = location === "/";

  // Check wallet connection status on component mount
  useEffect(() => {
    const verifyWalletConnection = async () => {
      try {
        await checkForWallet();
      } catch (error) {
        console.error("Error verifying wallet connection:", error);
      }
    };
    
    verifyWalletConnection();
  }, [checkForWallet]);

  // Close mobile menu when changing location
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const handleConnect = () => {
    if (connected) return;
    setShowWalletModal(true);
  };
  
  const handleDisconnect = async () => {
    await disconnect();
    toast({
      title: "Wallet disconnected",
      description: "Your wallet has been disconnected successfully.",
    });
  };

  const handleScroll = (sectionId: string) => {
    scrollTo(sectionId);
    setIsOpen(false);
  };

  return (
    <>
      <nav className="fixed top-0 w-full z-50 bg-[#0A1014]/90 backdrop-blur-md border-b border-[#14F195]/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link href="/" className="text-2xl font-bold text-white flex items-center group">
                <motion.span 
                  className="text-[#14F195] mr-1 relative"
                  whileHover={{ 
                    scale: 1.05,
                    textShadow: "0 0 8px rgba(20, 241, 149, 0.8)",
                  }}
                >
                  Trial
                  <motion.span 
                    className="absolute -bottom-1 left-0 h-[2px] bg-[#14F195] w-0 group-hover:w-full"
                    initial={{ width: 0 }}
                    animate={{ width: "100%" }}
                    transition={{ duration: 0.3, delay: 0.2 }}
                  />
                </motion.span>
                <motion.span
                  whileHover={{ scale: 1.05 }}
                >
                  Junkies
                </motion.span>
              </Link>
            </div>
            
            {isHomePage && (
              <div className="hidden md:flex items-center space-x-8">
                <motion.button 
                  onClick={() => handleScroll("hero")} 
                  className="text-gray-300 hover:text-white transition-colors relative group"
                  whileHover={{ y: -2 }}
                  whileTap={{ y: 0 }}
                >
                  Home
                  <motion.span 
                    className="absolute -bottom-1 left-0 h-[2px] bg-[#14F195] w-0 group-hover:w-full"
                    initial={{ width: 0 }}
                    whileHover={{ width: "100%" }}
                    transition={{ duration: 0.2 }}
                  />
                </motion.button>
                <motion.button 
                  onClick={() => handleScroll("features")} 
                  className="text-gray-300 hover:text-white transition-colors relative group"
                  whileHover={{ y: -2 }}
                  whileTap={{ y: 0 }}
                >
                  Features
                  <motion.span 
                    className="absolute -bottom-1 left-0 h-[2px] bg-[#14F195] w-0 group-hover:w-full"
                    initial={{ width: 0 }}
                    whileHover={{ width: "100%" }}
                    transition={{ duration: 0.2 }}
                  />
                </motion.button>
                <motion.button 
                  onClick={() => handleScroll("pricing")} 
                  className="text-gray-300 hover:text-white transition-colors relative group"
                  whileHover={{ y: -2 }}
                  whileTap={{ y: 0 }}
                >
                  Pricing
                  <motion.span 
                    className="absolute -bottom-1 left-0 h-[2px] bg-[#14F195] w-0 group-hover:w-full"
                    initial={{ width: 0 }}
                    whileHover={{ width: "100%" }}
                    transition={{ duration: 0.2 }}
                  />
                </motion.button>
                <motion.button 
                  onClick={() => handleScroll("faq")} 
                  className="text-gray-300 hover:text-white transition-colors relative group"
                  whileHover={{ y: -2 }}
                  whileTap={{ y: 0 }}
                >
                  FAQ
                  <motion.span 
                    className="absolute -bottom-1 left-0 h-[2px] bg-[#14F195] w-0 group-hover:w-full"
                    initial={{ width: 0 }}
                    whileHover={{ width: "100%" }}
                    transition={{ duration: 0.2 }}
                  />
                </motion.button>
              </div>
            )}
            
            <div className="flex items-center space-x-4">
              <Link href="/docs" className="text-gray-300 hover:text-white transition-colors hidden md:block">
                Documentation
              </Link>
              <Link href="/setup" className="text-gray-300 hover:text-white transition-colors hidden md:block">
                Setup
              </Link>
              <button className="p-1 rounded-full text-gray-300 hover:text-white transition-colors" aria-label="Toggle dark mode">
                <MoonIcon className="h-5 w-5" />
              </button>
              
              {!connected ? (
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Button 
                    onClick={handleConnect} 
                    className="bg-[#14F195] hover:bg-[#14F195]/90 text-black font-semibold flex items-center relative overflow-hidden group"
                  >
                    <span className="relative z-10">Connect Wallet</span>
                    <motion.div 
                      className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20"
                      initial={{ x: "-100%" }}
                      whileHover={{ x: "100%" }}
                      transition={{ duration: 0.5 }}
                    />
                  </Button>
                </motion.div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Button variant="outline" className="border-white/20 text-white">
                    {publicKey ? shortenAddress(publicKey) : ''}
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={handleDisconnect}
                    className="text-gray-400 hover:text-white hover:bg-red-500/10"
                    title="Disconnect wallet"
                  >
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </div>
            
            <div className="md:hidden flex items-center">
              <button 
                onClick={() => setIsOpen(!isOpen)} 
                className="text-gray-300 hover:text-white transition-colors"
              >
                {isOpen ? (
                  <XIcon className="h-6 w-6" />
                ) : (
                  <MenuIcon className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        <div className={`${isOpen ? 'block' : 'hidden'} bg-[#0F1A20] border-b border-[#14F195]/10 md:hidden`}>
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {isHomePage ? (
              <>
                <button 
                  onClick={() => handleScroll("hero")} 
                  className="block px-3 py-2 text-base font-medium text-white hover:bg-[#192830] rounded-md w-full text-left transition-colors"
                >
                  Home
                </button>
                <button 
                  onClick={() => handleScroll("features")} 
                  className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-[#192830] hover:text-white rounded-md w-full text-left transition-colors"
                >
                  Features
                </button>
                <button 
                  onClick={() => handleScroll("pricing")} 
                  className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-[#192830] hover:text-white rounded-md w-full text-left transition-colors"
                >
                  Pricing
                </button>
                <button 
                  onClick={() => handleScroll("faq")} 
                  className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-[#192830] hover:text-white rounded-md w-full text-left transition-colors"
                >
                  FAQ
                </button>
                {!connected ? (
                  <motion.div
                    whileTap={{ scale: 0.95 }}
                    className="mt-2"
                  >
                    <Button 
                      onClick={handleConnect} 
                      className="bg-[#14F195] hover:bg-[#14F195]/90 text-black font-semibold flex items-center w-full justify-center relative overflow-hidden group"
                    >
                      <span className="relative z-10">Connect Wallet</span>
                      <motion.div 
                        className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20"
                        initial={{ x: "-100%" }}
                        whileHover={{ x: "100%" }}
                        transition={{ duration: 0.5 }}
                      />
                    </Button>
                  </motion.div>
                ) : (
                  <div className="mt-2 flex flex-col space-y-2">
                    <div className="px-3 py-2 bg-[#192830] rounded-md flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-300">
                        {publicKey ? shortenAddress(publicKey) : ''}
                      </span>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={handleDisconnect}
                        className="text-gray-400 hover:text-white"
                      >
                        <LogOut className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <>
                <Link href="/" className="block px-3 py-2 text-base font-medium text-white hover:bg-[#192830] rounded-md transition-colors">
                  Home
                </Link>
                {connected && (
                  <Link href="/dashboard" className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-[#192830] hover:text-white rounded-md transition-colors">
                    Dashboard
                  </Link>
                )}
                <Link href="/docs" className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-[#192830] hover:text-white rounded-md transition-colors">
                  Documentation
                </Link>
                <Link href="/setup" className="block px-3 py-2 text-base font-medium text-gray-300 hover:bg-[#192830] hover:text-white rounded-md transition-colors">
                  Setup
                </Link>
                {!connected ? (
                  <motion.div
                    whileTap={{ scale: 0.95 }}
                    className="mt-2 mx-3"
                  >
                    <Button 
                      onClick={handleConnect} 
                      className="bg-[#14F195] hover:bg-[#14F195]/90 text-black font-semibold flex items-center w-full justify-center relative overflow-hidden group"
                    >
                      <span className="relative z-10">Connect Wallet</span>
                      <motion.div 
                        className="absolute inset-0 bg-white opacity-0 group-hover:opacity-20"
                        initial={{ x: "-100%" }}
                        whileHover={{ x: "100%" }}
                        transition={{ duration: 0.5 }}
                      />
                    </Button>
                  </motion.div>
                ) : (
                  <div className="mt-2 mx-3 flex flex-col space-y-2">
                    <div className="py-2 bg-[#192830] rounded-md flex justify-between items-center px-3">
                      <span className="text-sm font-medium text-gray-300">
                        {publicKey ? shortenAddress(publicKey) : ''}
                      </span>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        onClick={handleDisconnect}
                        className="text-gray-400 hover:text-white"
                      >
                        <LogOut className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </nav>

      <WalletConnectionModal
        isOpen={showWalletModal}
        onClose={() => setShowWalletModal(false)}
      />
    </>
  );
}

export default NavBar;
