import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { z } from 'zod';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Loader2, Check, AlertCircle } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';

// Define the setup schema using zod
const setupSchema = z.object({
  // Solana configuration
  solana_receiver_public_key: z.string().min(1, "Receiver wallet address is required"),
  mock_solana_verification: z.boolean().default(false),
  
  // SMS Verification
  enable_sms_verification: z.boolean().default(false),
  sms_provider: z.string().optional(),
  sms_api_key: z.string().optional(),
  sms_sender_id: z.string().optional(),
  
  // Email Verification
  enable_email_verification: z.boolean().default(false),
  email_provider: z.string().optional(),
  email_api_key: z.string().optional(),
  email_sender: z.string().optional(),
  
  // Proxy Configuration
  enable_proxy: z.boolean().default(false),
  proxy_provider: z.string().optional(),
  proxy_api_key: z.string().optional(),
  proxy_country: z.string().optional(),
  
  // Database Configuration
  database_type: z.string().default("postgres"),
  database_url: z.string().optional(),
  
  // Feature Flags
  enable_web_scraping: z.boolean().default(true),
  enable_captcha_solver: z.boolean().default(false),
  enable_discord_integration: z.boolean().default(false),
  development_mode: z.boolean().default(true),
});

type SetupFormValues = z.infer<typeof setupSchema>;

const SetupWizard: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [currentTab, setCurrentTab] = useState('solana');
  const [testResults, setTestResults] = useState<any>(null);
  const [setupComplete, setSetupComplete] = useState(false);
  
  // Initialize the form with default values
  const form = useForm<SetupFormValues>({
    resolver: zodResolver(setupSchema),
    defaultValues: {
      solana_receiver_public_key: '',
      mock_solana_verification: true,
      enable_sms_verification: false,
      sms_provider: '',
      sms_api_key: '',
      sms_sender_id: '',
      enable_email_verification: false,
      email_provider: '',
      email_api_key: '',
      email_sender: '',
      enable_proxy: false,
      proxy_provider: '',
      proxy_api_key: '',
      proxy_country: '',
      database_type: 'postgres',
      database_url: '',
      enable_web_scraping: true,
      enable_captcha_solver: false,
      enable_discord_integration: false,
      development_mode: true,
    }
  });
  
  // Load current configuration on component mount
  useEffect(() => {
    const fetchConfig = async () => {
      try {
        const response = await fetch('/api/setup');
        const data = await response.json();
        if (data.config) {
          form.reset(data.config);
        }
      } catch (error) {
        console.error('Error loading configuration:', error);
        toast({
          title: 'Failed to load configuration',
          description: 'Could not retrieve the current setup. You may need to configure it manually.',
          variant: 'destructive',
        });
      }
    };
    
    fetchConfig();
  }, [form]);
  
  // Handle form submission
  const onSubmit = async (values: SetupFormValues) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/setup', {
        method: 'POST',
        body: JSON.stringify(values),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      if (response.ok) {
        toast({
          title: 'Setup completed successfully',
          description: 'Your environment has been configured.',
          variant: 'default',
        });
        setSetupComplete(true);
      } else {
        const errorData = await response.json();
        toast({
          title: 'Setup failed',
          description: errorData.message || 'Something went wrong during setup.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error saving configuration:', error);
      toast({
        title: 'Setup failed',
        description: 'An unexpected error occurred while saving the configuration.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Function to test the current configuration
  const testConfiguration = async () => {
    setIsLoading(true);
    setTestResults(null);
    
    try {
      const currentValues = form.getValues();
      const response = await fetch('/api/setup/test', {
        method: 'POST',
        body: JSON.stringify(currentValues),
        headers: {
          'Content-Type': 'application/json',
        },
      });
      
      const results = await response.json();
      setTestResults(results);
      
      if (results.success) {
        toast({
          title: 'Test successful',
          description: 'Your configuration has been tested successfully.',
          variant: 'default',
        });
      } else {
        toast({
          title: 'Test failed',
          description: results.message || 'Some tests failed. Please check the results.',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error testing configuration:', error);
      toast({
        title: 'Test failed',
        description: 'An unexpected error occurred while testing the configuration.',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Function to handle tab changes
  const handleTabChange = (value: string) => {
    setCurrentTab(value);
  };
  
  // Function to determine if we should continue to the next tab
  const goToNextTab = () => {
    const tabs = ['solana', 'verification', 'proxy', 'database', 'features', 'review'];
    const currentIndex = tabs.indexOf(currentTab);
    if (currentIndex < tabs.length - 1) {
      setCurrentTab(tabs[currentIndex + 1]);
    }
  };
  
  // Function to go back to the previous tab
  const goToPreviousTab = () => {
    const tabs = ['solana', 'verification', 'proxy', 'database', 'features', 'review'];
    const currentIndex = tabs.indexOf(currentTab);
    if (currentIndex > 0) {
      setCurrentTab(tabs[currentIndex - 1]);
    }
  };
  
  // Render the form
  return (
    <div className="max-w-4xl mx-auto mt-8">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <Tabs value={currentTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="grid grid-cols-6 mb-8">
              <TabsTrigger value="solana">Solana</TabsTrigger>
              <TabsTrigger value="verification">Verification</TabsTrigger>
              <TabsTrigger value="proxy">Proxy</TabsTrigger>
              <TabsTrigger value="database">Database</TabsTrigger>
              <TabsTrigger value="features">Features</TabsTrigger>
              <TabsTrigger value="review">Review</TabsTrigger>
            </TabsList>
            
            {/* Solana Configuration */}
            <TabsContent value="solana">
              <Card>
                <CardHeader>
                  <CardTitle>Solana Payment Configuration</CardTitle>
                  <CardDescription>Configure your Solana wallet settings for payments</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="solana_receiver_public_key"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Solana Receiver Public Key</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your Solana wallet public key" {...field} />
                        </FormControl>
                        <FormDescription>
                          This is the wallet address that will receive payments from users.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="mock_solana_verification"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            Use Mock Solana Verification
                          </FormLabel>
                          <FormDescription>
                            Enable this in development mode to simulate Solana payments without actual blockchain transactions.
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div></div>
                  <Button type="button" onClick={goToNextTab}>
                    Next
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Verification Services */}
            <TabsContent value="verification">
              <Card>
                <CardHeader>
                  <CardTitle>Verification Services</CardTitle>
                  <CardDescription>Configure SMS and Email verification services</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">SMS Verification</h3>
                    <FormField
                      control={form.control}
                      name="enable_sms_verification"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              Enable SMS Verification
                            </FormLabel>
                            <FormDescription>
                              Verify users via SMS messages.
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    {form.watch('enable_sms_verification') && (
                      <>
                        <FormField
                          control={form.control}
                          name="sms_provider"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>SMS Provider</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. Twilio, Vonage" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="sms_api_key"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>SMS API Key</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your SMS provider API key" type="password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="sms_sender_id"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>SMS Sender ID</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your SMS sender ID or phone number" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </>
                    )}
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Email Verification</h3>
                    <FormField
                      control={form.control}
                      name="enable_email_verification"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              Enable Email Verification
                            </FormLabel>
                            <FormDescription>
                              Verify users via email messages.
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    {form.watch('enable_email_verification') && (
                      <>
                        <FormField
                          control={form.control}
                          name="email_provider"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Provider</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g. SendGrid, Mailgun" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email_api_key"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email API Key</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your email provider API key" type="password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="email_sender"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email Sender</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your email sender address" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button type="button" variant="outline" onClick={goToPreviousTab}>
                    Previous
                  </Button>
                  <Button type="button" onClick={goToNextTab}>
                    Next
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Proxy Configuration */}
            <TabsContent value="proxy">
              <Card>
                <CardHeader>
                  <CardTitle>Proxy Configuration</CardTitle>
                  <CardDescription>Configure proxy settings for web scraping and API requests</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="enable_proxy"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Enable Proxy
                          </FormLabel>
                          <FormDescription>
                            Use proxies for web requests to avoid rate limiting and IP blocking.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  {form.watch('enable_proxy') && (
                    <>
                      <FormField
                        control={form.control}
                        name="proxy_provider"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Proxy Provider</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. BrightData, Oxylabs, SmartProxy" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="proxy_api_key"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Proxy API Key</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your proxy provider API key" type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="proxy_country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Proxy Country</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. US, UK, CA" {...field} />
                            </FormControl>
                            <FormDescription>
                              Preferred country for proxy IP addresses (if applicable).
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button type="button" variant="outline" onClick={goToPreviousTab}>
                    Previous
                  </Button>
                  <Button type="button" onClick={goToNextTab}>
                    Next
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Database Configuration */}
            <TabsContent value="database">
              <Card>
                <CardHeader>
                  <CardTitle>Database Configuration</CardTitle>
                  <CardDescription>Configure your database connection</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="database_type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Database Type</FormLabel>
                        <FormControl>
                          <Input placeholder="Database type" {...field} />
                        </FormControl>
                        <FormDescription>
                          Currently only PostgreSQL is supported.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="database_url"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Database URL</FormLabel>
                        <FormControl>
                          <Input placeholder="postgresql://username:password@hostname:port/database" {...field} />
                        </FormControl>
                        <FormDescription>
                          Your database connection string. This is already configured on Replit.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button type="button" variant="outline" onClick={goToPreviousTab}>
                    Previous
                  </Button>
                  <Button type="button" onClick={goToNextTab}>
                    Next
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Feature Flags */}
            <TabsContent value="features">
              <Card>
                <CardHeader>
                  <CardTitle>Feature Flags</CardTitle>
                  <CardDescription>Enable or disable various features</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <FormField
                    control={form.control}
                    name="enable_web_scraping"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Enable Web Scraping
                          </FormLabel>
                          <FormDescription>
                            Use web scraping to automate trial creation on service websites.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="enable_captcha_solver"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Enable CAPTCHA Solver
                          </FormLabel>
                          <FormDescription>
                            Use automated CAPTCHA solving for web automation.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="enable_discord_integration"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Enable Discord Integration
                          </FormLabel>
                          <FormDescription>
                            Send notifications to Discord when trials are created or completed.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="development_mode"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Development Mode
                          </FormLabel>
                          <FormDescription>
                            Run in development mode with additional logging and mock services.
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button type="button" variant="outline" onClick={goToPreviousTab}>
                    Previous
                  </Button>
                  <Button type="button" onClick={goToNextTab}>
                    Next
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
            
            {/* Review & Submit */}
            <TabsContent value="review">
              <Card>
                <CardHeader>
                  <CardTitle>Review & Submit</CardTitle>
                  <CardDescription>Review your configuration before saving</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Configuration Summary</h3>
                    
                    <div className="rounded-md bg-muted p-4">
                      <h4 className="font-medium mb-2">Solana Configuration</h4>
                      <p><strong>Receiver Public Key:</strong> {form.watch('solana_receiver_public_key') || 'Not set'}</p>
                      <p><strong>Mock Verification:</strong> {form.watch('mock_solana_verification') ? 'Enabled' : 'Disabled'}</p>
                    </div>
                    
                    <div className="rounded-md bg-muted p-4">
                      <h4 className="font-medium mb-2">Verification Services</h4>
                      <p><strong>SMS Verification:</strong> {form.watch('enable_sms_verification') ? 'Enabled' : 'Disabled'}</p>
                      {form.watch('enable_sms_verification') && (
                        <>
                          <p><strong>SMS Provider:</strong> {form.watch('sms_provider') || 'Not set'}</p>
                          <p><strong>SMS API Key:</strong> {form.watch('sms_api_key') ? '••••••••' : 'Not set'}</p>
                        </>
                      )}
                      <p><strong>Email Verification:</strong> {form.watch('enable_email_verification') ? 'Enabled' : 'Disabled'}</p>
                      {form.watch('enable_email_verification') && (
                        <>
                          <p><strong>Email Provider:</strong> {form.watch('email_provider') || 'Not set'}</p>
                          <p><strong>Email API Key:</strong> {form.watch('email_api_key') ? '••••••••' : 'Not set'}</p>
                        </>
                      )}
                    </div>
                    
                    <div className="rounded-md bg-muted p-4">
                      <h4 className="font-medium mb-2">Proxy Configuration</h4>
                      <p><strong>Proxy:</strong> {form.watch('enable_proxy') ? 'Enabled' : 'Disabled'}</p>
                      {form.watch('enable_proxy') && (
                        <>
                          <p><strong>Provider:</strong> {form.watch('proxy_provider') || 'Not set'}</p>
                          <p><strong>API Key:</strong> {form.watch('proxy_api_key') ? '••••••••' : 'Not set'}</p>
                          <p><strong>Country:</strong> {form.watch('proxy_country') || 'Not set'}</p>
                        </>
                      )}
                    </div>
                    
                    <div className="rounded-md bg-muted p-4">
                      <h4 className="font-medium mb-2">Database Configuration</h4>
                      <p><strong>Type:</strong> {form.watch('database_type') || 'Not set'}</p>
                      <p><strong>URL:</strong> {form.watch('database_url') ? '••••••••' : 'Not set'}</p>
                    </div>
                    
                    <div className="rounded-md bg-muted p-4">
                      <h4 className="font-medium mb-2">Feature Flags</h4>
                      <p><strong>Web Scraping:</strong> {form.watch('enable_web_scraping') ? 'Enabled' : 'Disabled'}</p>
                      <p><strong>CAPTCHA Solver:</strong> {form.watch('enable_captcha_solver') ? 'Enabled' : 'Disabled'}</p>
                      <p><strong>Discord Integration:</strong> {form.watch('enable_discord_integration') ? 'Enabled' : 'Disabled'}</p>
                      <p><strong>Development Mode:</strong> {form.watch('development_mode') ? 'Enabled' : 'Disabled'}</p>
                    </div>
                  </div>
                  
                  {testResults && (
                    <div className={`rounded-md ${testResults.success ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20'} p-4 mt-6`}>
                      <div className="flex">
                        <div className="flex-shrink-0">
                          {testResults.success ? (
                            <Check className="h-5 w-5 text-green-400" />
                          ) : (
                            <AlertCircle className="h-5 w-5 text-red-400" />
                          )}
                        </div>
                        <div className="ml-3">
                          <h3 className={`text-sm font-medium ${testResults.success ? 'text-green-800 dark:text-green-200' : 'text-red-800 dark:text-red-200'}`}>
                            {testResults.success ? 'Configuration test passed!' : 'Configuration test failed'}
                          </h3>
                          <div className={`mt-2 text-sm ${testResults.success ? 'text-green-700 dark:text-green-300' : 'text-red-700 dark:text-red-300'}`}>
                            <p>{testResults.message}</p>
                            {testResults.details && (
                              <ul className="list-disc pl-5 mt-1 space-y-1">
                                {Object.entries(testResults.details).map(([key, value]) => (
                                  <li key={key}>
                                    {key}: {value ? '✓' : '✗'}
                                  </li>
                                ))}
                              </ul>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex space-x-2">
                    <Button type="button" variant="outline" onClick={goToPreviousTab}>
                      Previous
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={testConfiguration}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Testing...
                        </>
                      ) : 'Test Configuration'}
                    </Button>
                  </div>
                  <Button 
                    type="submit" 
                    disabled={isLoading || setupComplete}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : setupComplete ? (
                      <>
                        <Check className="mr-2 h-4 w-4" />
                        Setup Complete
                      </>
                    ) : 'Save Configuration'}
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </form>
      </Form>
    </div>
  );
};

export default SetupWizard;