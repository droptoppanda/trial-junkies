
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Loader2, Play, Check, AlertCircle } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Badge } from './ui/badge';
import { ToggleGroup, ToggleGroupItem } from './ui/toggle-group';

interface TrialFormData {
  service_name: string;
  website_url: string;
}

interface Trial {
  id: number;
  service_name: string;
  website_url: string;
  status: string;
  created_at: string;
  completed_at?: string;
  credentials?: any;
  result_message?: string;
  is_valid: boolean;
}

const popularServices = [
  { name: "Netflix", url: "https://www.netflix.com" },
  { name: "Amazon Prime", url: "https://www.amazon.com/Prime-Video" },
  { name: "Disney+", url: "https://www.disneyplus.com" },
  { name: "Spotify", url: "https://www.spotify.com" },
  { name: "Hulu", url: "https://www.hulu.com" },
  { name: "HBO Max", url: "https://www.hbomax.com" },
  { name: "YouTube Premium", url: "https://www.youtube.com/premium" }
];

export default function TrialAutomation() {
  const [trials, setTrials] = useState<Trial[]>([]);
  const [formData, setFormData] = useState<TrialFormData>({
    service_name: '',
    website_url: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>('all');
  const [selectedService, setSelectedService] = useState<string | null>(null);

  useEffect(() => {
    fetchTrials();
  }, []);

  const fetchTrials = async () => {
    try {
      const response = await fetch('/api/trials', {
        credentials: 'include'
      });
      const data = await response.json();
      
      if (response.ok) {
        setTrials(data.trials);
      } else {
        setError(data.message || 'Failed to fetch trials');
      }
    } catch (err) {
      setError('Error connecting to server');
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleServiceSelect = (service: string) => {
    const selectedService = popularServices.find(s => s.name === service);
    if (selectedService) {
      setFormData({
        service_name: selectedService.name,
        website_url: selectedService.url
      });
      setSelectedService(service);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSuccess(null);
    
    try {
      const response = await fetch('/api/trials/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(formData)
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setSuccess('Trial created successfully');
        setFormData({
          service_name: '',
          website_url: ''
        });
        setSelectedService(null);
        fetchTrials();
      } else {
        setError(data.message || 'Failed to create trial');
      }
    } catch (err) {
      setError('Error connecting to server');
    } finally {
      setIsLoading(false);
    }
  };

  const startTrial = async (trialId: number) => {
    try {
      setIsLoading(true);
      
      const response = await fetch(`/api/trials/start/${trialId}`, {
        method: 'POST',
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setSuccess('Trial started successfully');
        fetchTrials();
      } else {
        setError(data.error || 'Failed to start trial');
      }
    } catch (err) {
      setError('Error connecting to server');
    } finally {
      setIsLoading(false);
    }
  };

  const filteredTrials = trials.filter(trial => {
    if (activeTab === 'all') return true;
    if (activeTab === 'queued') return trial.status === 'queued';
    if (activeTab === 'active') return trial.status === 'in_progress';
    if (activeTab === 'completed') return trial.status === 'completed';
    if (activeTab === 'failed') return trial.status === 'failed';
    return true;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'queued':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Queued</Badge>;
      case 'in_progress':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">In Progress</Badge>;
      case 'completed':
        return <Badge variant="outline" className="bg-green-100 text-green-800">Completed</Badge>;
      case 'failed':
        return <Badge variant="outline" className="bg-red-100 text-red-800">Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="container mx-auto p-4 space-y-8">
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Create Automated Trial</CardTitle>
          <CardDescription>Let our AI create a trial account for you</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <div className="p-4 mb-4 bg-red-100 text-red-800 rounded-md flex items-center space-x-2">
              <AlertCircle className="h-5 w-5" />
              <span>{error}</span>
            </div>
          )}
          
          {success && (
            <div className="p-4 mb-4 bg-green-100 text-green-800 rounded-md flex items-center space-x-2">
              <Check className="h-5 w-5" />
              <span>{success}</span>
            </div>
          )}
          
          <div className="mb-6">
            <h3 className="font-medium mb-2">Popular Services</h3>
            <div className="flex flex-wrap gap-2">
              {popularServices.map(service => (
                <Button
                  key={service.name}
                  variant={selectedService === service.name ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleServiceSelect(service.name)}
                >
                  {service.name}
                </Button>
              ))}
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="service_name">Service Name</Label>
              <Input
                id="service_name"
                name="service_name"
                value={formData.service_name}
                onChange={handleInputChange}
                placeholder="e.g., Netflix, Spotify, etc."
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="website_url">Website URL</Label>
              <Input
                id="website_url"
                name="website_url"
                value={formData.website_url}
                onChange={handleInputChange}
                placeholder="https://www.example.com"
                required
              />
            </div>
            
            <Button type="submit" disabled={isLoading} className="w-full">
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                'Create Trial'
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Your Automated Trials</CardTitle>
          <CardDescription>Manage your trial accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <ToggleGroup type="single" value={activeTab} onValueChange={(value) => setActiveTab(value || 'all')}>
              <ToggleGroupItem value="all">All</ToggleGroupItem>
              <ToggleGroupItem value="queued">Queued</ToggleGroupItem>
              <ToggleGroupItem value="active">Active</ToggleGroupItem>
              <ToggleGroupItem value="completed">Completed</ToggleGroupItem>
              <ToggleGroupItem value="failed">Failed</ToggleGroupItem>
            </ToggleGroup>
          </div>
          
          {filteredTrials.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Service</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTrials.map(trial => (
                  <TableRow key={trial.id}>
                    <TableCell className="font-medium">{trial.service_name}</TableCell>
                    <TableCell>{getStatusBadge(trial.status)}</TableCell>
                    <TableCell>{new Date(trial.created_at).toLocaleDateString()}</TableCell>
                    <TableCell>
                      {trial.status === 'queued' && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => startTrial(trial.id)}
                          disabled={isLoading}
                        >
                          <Play className="h-4 w-4 mr-1" />
                          Start
                        </Button>
                      )}
                      
                      {trial.status === 'completed' && trial.credentials && (
                        <div className="text-xs">
                          <p><strong>Username:</strong> {trial.credentials.username}</p>
                          <p><strong>Password:</strong> {trial.credentials.password}</p>
                          {trial.credentials.email && (
                            <p><strong>Email:</strong> {trial.credentials.email}</p>
                          )}
                        </div>
                      )}
                      
                      {trial.status === 'failed' && trial.result_message && (
                        <div className="text-xs text-red-600">
                          {trial.result_message}
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center p-8 text-gray-500">
              No trials found. Create one to get started.
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
