import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Search, CheckCircle2, XCircle } from "lucide-react";
import { format } from "date-fns";

export default function UsersTable() {
  const [search, setSearch] = useState("");
  
  // Fetch users from the backend
  const { data, isLoading } = useQuery({
    queryKey: ['/api/admin/users'],
  });
  
  const filteredUsers = data?.users?.filter((user: any) => 
    user.username.toLowerCase().includes(search.toLowerCase()) ||
    (user.discord_username && user.discord_username.toLowerCase().includes(search.toLowerCase())) ||
    (user.wallet_address && user.wallet_address.toLowerCase().includes(search.toLowerCase()))
  ) || [];
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-[#8A2BE2]" />
      </div>
    );
  }
  
  return (
    <Card className="bg-[#1E1E1E] border-white/10">
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
          <div>
            <CardTitle>Users</CardTitle>
            <CardDescription>Manage user accounts and information</CardDescription>
          </div>
          
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search users..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-[#2D2D2D] border-white/10 w-full md:w-64"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border border-white/10 overflow-hidden">
          <Table>
            <TableHeader className="bg-[#2D2D2D]">
              <TableRow>
                <TableHead className="text-white">Username</TableHead>
                <TableHead className="text-white">Wallet</TableHead>
                <TableHead className="text-white">Discord</TableHead>
                <TableHead className="text-white">Admin</TableHead>
                <TableHead className="text-white">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-6 text-gray-400">
                    No users found
                  </TableCell>
                </TableRow>
              ) : (
                filteredUsers.map((user: any) => (
                  <TableRow key={user.id} className="border-white/5">
                    <TableCell className="font-medium">{user.username}</TableCell>
                    <TableCell>
                      {user.wallet_address ? (
                        <div className="flex items-center">
                          <CheckCircle2 className="h-4 w-4 text-[#14F195] mr-1" />
                          <span className="text-sm">{user.wallet_address.slice(0, 6)}...{user.wallet_address.slice(-4)}</span>
                        </div>
                      ) : (
                        <div className="flex items-center">
                          <XCircle className="h-4 w-4 text-gray-500 mr-1" />
                          <span className="text-sm text-gray-500">Not linked</span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      {user.discord_id ? (
                        <div className="flex items-center">
                          <CheckCircle2 className="h-4 w-4 text-[#14F195] mr-1" />
                          <span className="text-sm">{user.discord_username}</span>
                        </div>
                      ) : (
                        <div className="flex items-center">
                          <XCircle className="h-4 w-4 text-gray-500 mr-1" />
                          <span className="text-sm text-gray-500">Not linked</span>
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      {user.is_admin ? (
                        <Badge className="bg-[#8A2BE2] hover:bg-[#8A2BE2]/90">Admin</Badge>
                      ) : (
                        <Badge variant="outline" className="border-white/20 text-gray-400">User</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm" className="h-8 border-white/20">
                          View
                        </Button>
                        <Button variant="outline" size="sm" className="h-8 border-white/20 hover:bg-red-900/20 hover:text-red-400 hover:border-red-900/50">
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
