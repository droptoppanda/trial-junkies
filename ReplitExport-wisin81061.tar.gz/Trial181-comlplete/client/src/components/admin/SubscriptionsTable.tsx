import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Search, ArrowUpDown } from "lucide-react";
import { format } from "date-fns";

export default function SubscriptionsTable() {
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState<string>("start_date");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  
  // Fetch subscriptions from the backend
  const { data, isLoading } = useQuery({
    queryKey: ['/api/admin/subscriptions'],
  });
  
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };
  
  // Apply sorting and filtering
  const sortedAndFilteredSubscriptions = data?.subscriptions
    ? [...data.subscriptions]
        .filter((sub: any) => 
          sub.tier.toLowerCase().includes(search.toLowerCase()) || 
          String(sub.user_id).includes(search)
        )
        .sort((a: any, b: any) => {
          if (sortField === "start_date" || sortField === "end_date") {
            return sortDirection === "asc"
              ? new Date(a[sortField]).getTime() - new Date(b[sortField]).getTime()
              : new Date(b[sortField]).getTime() - new Date(a[sortField]).getTime();
          }
          
          if (sortField === "price") {
            return sortDirection === "asc"
              ? parseFloat(a.price) - parseFloat(b.price)
              : parseFloat(b.price) - parseFloat(a.price);
          }
          
          return sortDirection === "asc"
            ? String(a[sortField]).localeCompare(String(b[sortField]))
            : String(b[sortField]).localeCompare(String(a[sortField]));
        })
    : [];
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-[#8A2BE2]" />
      </div>
    );
  }
  
  return (
    <Card className="bg-[#1E1E1E] border-white/10">
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
          <div>
            <CardTitle>Subscriptions</CardTitle>
            <CardDescription>Manage user subscriptions and payment records</CardDescription>
          </div>
          
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search subscriptions..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-[#2D2D2D] border-white/10 w-full md:w-64"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border border-white/10 overflow-hidden">
          <Table>
            <TableHeader className="bg-[#2D2D2D]">
              <TableRow>
                <TableHead 
                  className="text-white cursor-pointer" 
                  onClick={() => handleSort("user_id")}
                >
                  <div className="flex items-center">
                    User ID
                    {sortField === "user_id" && (
                      <ArrowUpDown className={`ml-2 h-4 w-4 ${sortDirection === "asc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead 
                  className="text-white cursor-pointer" 
                  onClick={() => handleSort("tier")}
                >
                  <div className="flex items-center">
                    Plan
                    {sortField === "tier" && (
                      <ArrowUpDown className={`ml-2 h-4 w-4 ${sortDirection === "asc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead 
                  className="text-white cursor-pointer" 
                  onClick={() => handleSort("price")}
                >
                  <div className="flex items-center">
                    Price
                    {sortField === "price" && (
                      <ArrowUpDown className={`ml-2 h-4 w-4 ${sortDirection === "asc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead 
                  className="text-white cursor-pointer" 
                  onClick={() => handleSort("start_date")}
                >
                  <div className="flex items-center">
                    Start Date
                    {sortField === "start_date" && (
                      <ArrowUpDown className={`ml-2 h-4 w-4 ${sortDirection === "asc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead 
                  className="text-white cursor-pointer" 
                  onClick={() => handleSort("end_date")}
                >
                  <div className="flex items-center">
                    End Date
                    {sortField === "end_date" && (
                      <ArrowUpDown className={`ml-2 h-4 w-4 ${sortDirection === "asc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead 
                  className="text-white cursor-pointer" 
                  onClick={() => handleSort("active")}
                >
                  <div className="flex items-center">
                    Status
                    {sortField === "active" && (
                      <ArrowUpDown className={`ml-2 h-4 w-4 ${sortDirection === "asc" ? "rotate-180" : ""}`} />
                    )}
                  </div>
                </TableHead>
                <TableHead className="text-white">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedAndFilteredSubscriptions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-6 text-gray-400">
                    No subscriptions found
                  </TableCell>
                </TableRow>
              ) : (
                sortedAndFilteredSubscriptions.map((subscription: any) => (
                  <TableRow key={subscription.id} className="border-white/5">
                    <TableCell>{subscription.user_id}</TableCell>
                    <TableCell className="font-medium capitalize">{subscription.tier}</TableCell>
                    <TableCell>{subscription.price} SOL</TableCell>
                    <TableCell>{format(new Date(subscription.start_date), "MMM d, yyyy")}</TableCell>
                    <TableCell>{format(new Date(subscription.end_date), "MMM d, yyyy")}</TableCell>
                    <TableCell>
                      {subscription.active ? (
                        <Badge className="bg-[#14F195]/20 text-[#14F195] hover:bg-[#14F195]/30 border-none">
                          Active
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="border-red-400/30 text-red-400">
                          Inactive
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm" className="h-8 border-white/20">
                          View
                        </Button>
                        {subscription.active && (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="h-8 border-white/20 hover:bg-red-900/20 hover:text-red-400 hover:border-red-900/50"
                          >
                            Cancel
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
