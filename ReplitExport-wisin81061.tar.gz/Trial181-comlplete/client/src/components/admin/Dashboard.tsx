import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Users, CreditCard, Activity, TrendingUp, TrendingDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from "recharts";

export default function AdminDashboard() {
  // Fetch users from backend
  const { data: usersData, isLoading: isLoadingUsers } = useQuery({
    queryKey: ['/api/admin/users'],
  });
  
  // Fetch subscriptions from backend
  const { data: subscriptionsData, isLoading: isLoadingSubscriptions } = useQuery({
    queryKey: ['/api/admin/subscriptions'],
  });
  
  // Calculate statistics
  const calculateStats = () => {
    const users = usersData?.users || [];
    const subscriptions = subscriptionsData?.subscriptions || [];
    
    // Total users
    const totalUsers = users.length;
    
    // Users with wallets connected
    const usersWithWallets = users.filter((user: any) => user.wallet_address).length;
    
    // Users with Discord connected
    const usersWithDiscord = users.filter((user: any) => user.discord_id).length;
    
    // Total active subscriptions
    const activeSubscriptions = subscriptions.filter((sub: any) => sub.active).length;
    
    // Total revenue (from active subscriptions)
    const totalRevenue = subscriptions
      .filter((sub: any) => sub.active)
      .reduce((sum: number, sub: any) => sum + parseFloat(sub.price), 0);
    
    // Subscription distribution by tier
    const subscriptionsByTier = {
      basic: subscriptions.filter((sub: any) => sub.tier === "basic").length,
      pro: subscriptions.filter((sub: any) => sub.tier === "pro").length,
      enterprise: subscriptions.filter((sub: any) => sub.tier === "enterprise").length,
    };
    
    return {
      totalUsers,
      usersWithWallets,
      usersWithDiscord,
      activeSubscriptions,
      totalRevenue,
      subscriptionsByTier,
    };
  };
  
  const stats = calculateStats();
  
  // Chart data
  const subscriptionPieData = [
    { name: "Basic", value: stats.subscriptionsByTier.basic, fill: "#1A1A1A" },
    { name: "Pro", value: stats.subscriptionsByTier.pro, fill: "#8A2BE2" },
    { name: "Enterprise", value: stats.subscriptionsByTier.enterprise, fill: "#14F195" },
  ];
  
  const COLORS = ["#1A1A1A", "#8A2BE2", "#14F195"];
  
  // Revenue trend data (mock - would come from backend in real app)
  const revenueData = [
    { name: "Jan", revenue: 1.2 },
    { name: "Feb", revenue: 2.3 },
    { name: "Mar", revenue: 3.1 },
    { name: "Apr", revenue: 2.5 },
    { name: "May", revenue: 3.8 },
    { name: "Jun", revenue: 5.2 },
    { name: "Jul", revenue: 4.9 },
  ];
  
  const isLoading = isLoadingUsers || isLoadingSubscriptions;
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-[#8A2BE2]" />
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Users Card */}
        <Card className="bg-[#1E1E1E] border-white/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{stats.totalUsers}</div>
              <div className="p-2 bg-[#8A2BE2]/20 rounded-full">
                <Users className="h-5 w-5 text-[#8A2BE2]" />
              </div>
            </div>
            <div className="mt-2 flex items-center">
              <Badge className="bg-[#14F195]/10 text-[#14F195] flex items-center">
                <TrendingUp className="h-3.5 w-3.5 mr-1" />
                12%
              </Badge>
              <span className="ml-2 text-xs text-gray-400">vs. last month</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Active Subscriptions Card */}
        <Card className="bg-[#1E1E1E] border-white/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Active Subscriptions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{stats.activeSubscriptions}</div>
              <div className="p-2 bg-[#8A2BE2]/20 rounded-full">
                <CreditCard className="h-5 w-5 text-[#8A2BE2]" />
              </div>
            </div>
            <div className="mt-2 flex items-center">
              <Badge className="bg-[#14F195]/10 text-[#14F195] flex items-center">
                <TrendingUp className="h-3.5 w-3.5 mr-1" />
                8%
              </Badge>
              <span className="ml-2 text-xs text-gray-400">vs. last month</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Monthly Revenue Card */}
        <Card className="bg-[#1E1E1E] border-white/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Monthly Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{stats.totalRevenue.toFixed(2)} SOL</div>
              <div className="p-2 bg-[#8A2BE2]/20 rounded-full">
                <Activity className="h-5 w-5 text-[#8A2BE2]" />
              </div>
            </div>
            <div className="mt-2 flex items-center">
              <Badge className="bg-[#14F195]/10 text-[#14F195] flex items-center">
                <TrendingUp className="h-3.5 w-3.5 mr-1" />
                24%
              </Badge>
              <span className="ml-2 text-xs text-gray-400">vs. last month</span>
            </div>
          </CardContent>
        </Card>
        
        {/* Wallet Connections Card */}
        <Card className="bg-[#1E1E1E] border-white/10">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-400">Wallet Connections</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-2xl font-bold">{Math.round((stats.usersWithWallets / stats.totalUsers) * 100)}%</div>
              <div className="p-2 bg-[#8A2BE2]/20 rounded-full">
                <svg 
                  className="h-5 w-5 text-[#8A2BE2]" 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M18 7v4c0 1.1-.9 2-2 2H4a2 2 0 01-2-2V7c0-1.1.9-2 2-2h12c1.1 0 2 .9 2 2z" />
                  <path d="M16 21h2c1.1 0 2-.9 2-2v-5h-4v7z" />
                  <path d="M10 21v-7H6v7" />
                </svg>
              </div>
            </div>
            <div className="mt-2 flex items-center">
              <span className="text-xs text-gray-400">{stats.usersWithWallets} of {stats.totalUsers} users</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Trend Chart */}
        <Card className="bg-[#1E1E1E] border-white/10 lg:col-span-2">
          <CardHeader>
            <CardTitle>Revenue Trend</CardTitle>
            <CardDescription>Monthly revenue in SOL</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={revenueData}
                  margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8A2BE2" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#8A2BE2" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="name" 
                    stroke="#666" 
                    tick={{ fill: '#999' }}
                  />
                  <YAxis 
                    stroke="#666" 
                    tick={{ fill: '#999' }}
                    tickFormatter={(value) => `${value} SOL`}
                  />
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#2D2D2D', 
                      border: '1px solid #444',
                      borderRadius: '6px',
                      color: 'white'
                    }}
                    formatter={(value) => [`${value} SOL`, "Revenue"]}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#8A2BE2" 
                    fillOpacity={1} 
                    fill="url(#colorRevenue)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        {/* Subscription Distribution Chart */}
        <Card className="bg-[#1E1E1E] border-white/10">
          <CardHeader>
            <CardTitle>Subscription Tiers</CardTitle>
            <CardDescription>Distribution of active subscriptions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={subscriptionPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {subscriptionPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend 
                    verticalAlign="bottom" 
                    height={36} 
                    formatter={(value, entry, index) => (
                      <span style={{ color: '#999' }}>{value}</span>
                    )}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#2D2D2D', 
                      border: '1px solid #444',
                      borderRadius: '6px',
                      color: 'white'
                    }}
                    formatter={(value) => [`${value} subscriptions`, ""]}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
