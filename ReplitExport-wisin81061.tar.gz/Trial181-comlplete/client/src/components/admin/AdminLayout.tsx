import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  LayoutDashboard, 
  Users, 
  CreditCard, 
  Settings, 
  LogOut, 
  Menu, 
  X,
  Home
} from "lucide-react";

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const handleLogout = async () => {
    try {
      await apiRequest("GET", "/api/auth/logout", null);
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Logout failed",
        description: "There was an error logging out. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const navigation = [
    { name: "Dashboard", icon: LayoutDashboard, href: "#dashboard" },
    { name: "Users", icon: Users, href: "#users" },
    { name: "Subscriptions", icon: CreditCard, href: "#subscriptions" },
    { name: "Settings", icon: Settings, href: "#settings" },
  ];
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  return (
    <div className="min-h-screen bg-[#121212] text-white">
      {/* Mobile header */}
      <div className="lg:hidden fixed top-0 left-0 w-full bg-[#1E1E1E] z-40 border-b border-white/10">
        <div className="flex items-center justify-between px-4 h-16">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleMenu}
              className="mr-2"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
            <span className="text-xl font-bold">Admin Panel</span>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setLocation("/")}
          >
            <Home className="h-5 w-5" />
          </Button>
        </div>
      </div>
      
      {/* Mobile sidebar */}
      <div className={`lg:hidden fixed inset-0 bg-black/50 z-30 ${isMenuOpen ? 'block' : 'hidden'}`} onClick={toggleMenu}>
        <div 
          className={`fixed top-16 left-0 h-full w-64 bg-[#1E1E1E] transform ${isMenuOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-200 ease-in-out`}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex flex-col h-full">
            <div className="flex-1 py-6 px-4 space-y-1">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="flex items-center px-3 py-2 rounded-md text-gray-300 hover:bg-[#2D2D2D] hover:text-white"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  {item.name}
                </a>
              ))}
            </div>
            
            <div className="p-4 border-t border-white/10">
              <Button 
                variant="outline" 
                onClick={handleLogout}
                className="w-full border-white/20 text-white"
              >
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      {/* Desktop layout */}
      <div className="lg:flex">
        {/* Sidebar */}
        <aside className="hidden lg:block w-64 fixed h-screen bg-[#1E1E1E] border-r border-white/10">
          <div className="flex flex-col h-full">
            <div className="flex items-center h-16 px-6 border-b border-white/10">
              <span className="text-xl font-bold">Admin Panel</span>
            </div>
            
            <div className="flex-1 py-6 px-4 space-y-1">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="flex items-center px-3 py-2 rounded-md text-gray-300 hover:bg-[#2D2D2D] hover:text-white"
                >
                  <item.icon className="mr-3 h-5 w-5" />
                  {item.name}
                </a>
              ))}
            </div>
            
            <div className="p-4 space-y-4 border-t border-white/10">
              <Button 
                variant="outline" 
                onClick={() => setLocation("/")}
                className="w-full border-white/20 text-white"
              >
                <Home className="mr-2 h-4 w-4" />
                Go to Site
              </Button>
              
              <Button 
                variant="outline" 
                onClick={handleLogout}
                className="w-full border-white/20 text-white hover:bg-red-900/20 hover:text-red-400 hover:border-red-900/50"
              >
                <LogOut className="mr-2 h-4 w-4" />
                Logout
              </Button>
            </div>
          </div>
        </aside>
        
        {/* Main content */}
        <main className="lg:ml-64 w-full py-6 px-4 sm:px-6 lg:px-8 pt-20 lg:pt-6">
          {children}
        </main>
      </div>
    </div>
  );
}
