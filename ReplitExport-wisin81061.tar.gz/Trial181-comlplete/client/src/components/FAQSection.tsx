import { useState } from "react";
import { useScrollTo } from "@/lib/useScrollTo";
import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export function FAQSection() {
  const { scrollToNext } = useScrollTo();

  // FAQ data
  const faqs = [
    {
      question: "How does the wallet connection work?",
      answer: "Our platform integrates with Phantom Wallet using their official SDK. When you click \"Connect Wallet,\" a popup will appear asking for connection approval. Once connected, you'll be able to make payments and manage your subscription directly through your Solana wallet."
    },
    {
      question: "How does Discord role integration work?",
      answer: "After subscribing, you'll need to link your Discord account through our OAuth integration. Once linked, our system automatically assigns the appropriate role based on your subscription tier. Roles are updated in real-time as subscriptions change or renew."
    },
    {
      question: "Can I upgrade or downgrade my subscription?",
      answer: "Yes, you can change your subscription tier at any time. When upgrading, you'll be charged the prorated difference for the remainder of your billing cycle. When downgrading, your new rate will take effect at the next billing cycle. Your Discord roles will update automatically with your subscription changes."
    },
    {
      question: "What happens if my payment fails?",
      answer: "If a payment fails, you'll receive a notification and have a 3-day grace period to update your payment method. During this time, your access and Discord roles remain unchanged. If payment isn't completed within the grace period, your subscription will be paused and roles removed until payment is processed."
    },
    {
      question: "Is my data secure?",
      answer: "Yes, we prioritize security across our platform. We never store your private keys or sensitive wallet information. All transactions are processed directly through wallet-approved prompts, and our Discord integration only requests the minimum permissions needed for role management."
    }
  ];

  return (
    <section id="faq" className="relative min-h-screen flex items-center bg-[#121212]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Frequently Asked <span className="text-[#14F195]">Questions</span></h2>
          <p className="text-gray-400 max-w-2xl mx-auto">Find answers to common questions about our platform, subscriptions, and integrations.</p>
        </motion.div>
        
        <motion.div 
          className="max-w-3xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`faq-${index}`}
                className="border border-white/10 rounded-lg overflow-hidden bg-[#1E1E1E]"
              >
                <AccordionTrigger className="px-4 py-4 hover:bg-[#2D2D2D] transition-colors font-medium text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="px-4 py-4 bg-[#2D2D2D] border-t border-white/10 text-gray-400">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
        
        <motion.div 
          className="mt-12 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <p className="text-gray-400">Still have questions?</p>
          <a href="#contact" className="inline-flex items-center text-[#14F195] hover:text-[#14F195]/80 transition-colors mt-2">
            <span className="mr-2">Contact our support team</span>
            <svg 
              className="w-4 h-4" 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <line x1="5" y1="12" x2="19" y2="12"></line>
              <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
          </a>
        </motion.div>
      </div>
      
      <div className="section-divider animate-bounce">
        <button 
          onClick={() => scrollToNext("faq")}
          aria-label="Scroll to CTA section"
          className="focus:outline-none"
        >
          <svg 
            className="w-6 h-6 text-[#14F195]/80 hover:text-[#14F195] transition-colors" 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <polyline points="19 12 12 19 5 12"></polyline>
          </svg>
        </button>
      </div>
    </section>
  );
}

export default FAQSection;
