import { Button } from "@/components/ui/button";
import { useScrollTo } from "@/lib/useScrollTo";
import { motion } from "framer-motion";
import { subscriptionTiers } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Check, X } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useWallet } from "@/lib/wallet";
import { toast } from "@/hooks/use-toast";

// Define the SubscriptionTier type based on the schema
type SubscriptionTier = {
  name: string;
  price: string;
  features: string[];
  notIncluded: string[];
  popular?: boolean;
};

// Define the SubscriptionTiers type
type SubscriptionTiers = {
  basic: SubscriptionTier;
  pro: SubscriptionTier;
  enterprise: SubscriptionTier;
  [key: string]: SubscriptionTier;
};

export function PricingSection() {
  const { scrollToNext } = useScrollTo();
  const [, setLocation] = useLocation();
  const { connected } = useWallet();
  
  // Fetch subscription tiers from the backend
  const { data: tiers } = useQuery<SubscriptionTiers>({
    queryKey: ['/api/subscriptions/tiers'],
    staleTime: Infinity, // This data doesn't change frequently
  });

  // Use fetched data if available, otherwise fall back to imported data
  const pricingData: SubscriptionTiers = tiers || subscriptionTiers;
  
  const handleSubscribe = (tier: string) => {
    // Redirect to the payment page
    setLocation(`/payment/${tier}`);
    
    toast({
      title: "Redirecting to payment",
      description: `You're being redirected to complete your ${tier} plan subscription.`,
    });
  };

  return (
    <section id="pricing" className="relative min-h-screen flex items-center bg-[#121212]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Subscription <span className="text-[#14F195]">Plans</span></h2>
          <p className="text-gray-400 max-w-2xl mx-auto">Choose the perfect plan for your needs with flexible options and Discord role integration.</p>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {/* Basic Plan */}
          <div className="subscription-card bg-[#1E1E1E] rounded-xl overflow-hidden transition-all duration-300 hover:translate-y-[-5px]">
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{pricingData.basic.name}</h3>
              <div className="flex items-end mb-4">
                <span className="text-3xl font-bold">{pricingData.basic.price}</span>
                <span className="ml-1 text-sm text-gray-400">SOL/month</span>
              </div>
              <p className="text-gray-400 text-sm mb-6">Perfect for individuals getting started</p>
              
              <ul className="space-y-3 mb-6">
                {pricingData.basic.features.map((feature: string, index: number) => (
                  <li key={index} className="flex items-start">
                    <Check className="text-[#14F195] mt-1 mr-2 h-4 w-4" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
                {pricingData.basic.notIncluded.map((feature: string, index: number) => (
                  <li key={index} className="flex items-start text-gray-500">
                    <X className="mt-1 mr-2 h-4 w-4" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button 
                onClick={() => handleSubscribe("basic")} 
                className="w-full bg-[#2D2D2D] hover:bg-[#14F195]/90 text-white py-2 rounded-md h-auto"
              >
                Subscribe Now
              </Button>
            </div>
          </div>
          
          {/* Pro Plan */}
          <div className="subscription-card premium-card bg-[#1E1E1E] rounded-xl overflow-hidden transition-all duration-300 hover:translate-y-[-5px] transform scale-105 shadow-lg relative z-10">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#14F195] to-[#0f9e63]"></div>
            <div className="absolute top-0 right-0 bg-[#14F195] text-black text-xs font-bold px-3 py-1 rounded-bl-lg">
              POPULAR
            </div>
            
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{pricingData.pro.name}</h3>
              <div className="flex items-end mb-4">
                <span className="text-3xl font-bold">{pricingData.pro.price}</span>
                <span className="ml-1 text-sm text-gray-400">SOL/month</span>
              </div>
              <p className="text-gray-400 text-sm mb-6">Best value for most users</p>
              
              <ul className="space-y-3 mb-6">
                {pricingData.pro.features.map((feature: string, index: number) => (
                  <li key={index} className="flex items-start">
                    <Check className="text-[#14F195] mt-1 mr-2 h-4 w-4" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
                {pricingData.pro.notIncluded.map((feature: string, index: number) => (
                  <li key={index} className="flex items-start text-gray-500">
                    <X className="mt-1 mr-2 h-4 w-4" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button 
                onClick={() => handleSubscribe("pro")} 
                className="w-full bg-[#14F195] hover:bg-[#14F195]/90 text-black font-medium py-2 rounded-md glow-on-hover h-auto"
              >
                Subscribe Now
              </Button>
            </div>
          </div>
          
          {/* Enterprise Plan */}
          <div className="subscription-card bg-[#1E1E1E] rounded-xl overflow-hidden transition-all duration-300 hover:translate-y-[-5px]">
            <div className="p-6">
              <h3 className="text-xl font-semibold mb-2">{pricingData.enterprise.name}</h3>
              <div className="flex items-end mb-4">
                <span className="text-3xl font-bold">{pricingData.enterprise.price}</span>
                <span className="ml-1 text-sm text-gray-400">SOL/month</span>
              </div>
              <p className="text-gray-400 text-sm mb-6">Complete solution for businesses</p>
              
              <ul className="space-y-3 mb-6">
                {pricingData.enterprise.features.map((feature: string, index: number) => (
                  <li key={index} className="flex items-start">
                    <Check className="text-[#14F195] mt-1 mr-2 h-4 w-4" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Button 
                onClick={() => handleSubscribe("enterprise")} 
                className="w-full bg-[#2D2D2D] hover:bg-[#14F195]/90 text-white py-2 rounded-md h-auto"
              >
                Subscribe Now
              </Button>
            </div>
          </div>
        </motion.div>
        <motion.div 
          className="mt-16 max-w-3xl mx-auto bg-[#1E1E1E] rounded-xl p-6 card-gradient"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div>
              <h3 className="text-xl font-semibold mb-2">Need a custom plan?</h3>
              <p className="text-gray-400 mb-4 md:mb-0">Contact us to create a tailored solution for your specific requirements.</p>
            </div>
            <Button variant="outline" className="bg-transparent hover:bg-white/5 text-white border border-white/20 py-2 px-6 rounded-md h-auto">
              Contact Sales
            </Button>
          </div>
        </motion.div>
      </div>
      
      <div className="section-divider animate-bounce">
        <button 
          onClick={() => scrollToNext("pricing")}
          aria-label="Scroll to FAQ section"
          className="focus:outline-none"
        >
          <svg 
            className="w-6 h-6 text-[#14F195]/80 hover:text-[#14F195] transition-colors" 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <polyline points="19 12 12 19 5 12"></polyline>
          </svg>
        </button>
      </div>
    </section>
  );
}

export default PricingSection;
