
import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { apiRequest } from "@/lib/queryClient";

interface DiscordVerificationProps {
  isConnected: boolean;
  discordUsername: string | null;
}

export default function DiscordVerification({ isConnected, discordUsername }: DiscordVerificationProps) {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [service, setService] = useState("spotify");
  const [loading, setLoading] = useState(false);
  const [verificationId, setVerificationId] = useState<string | null>(null);
  const [verificationCode, setVerificationCode] = useState<string | null>(null);

  const handleEmailVerification = async () => {
    if (!email) {
      toast({
        title: "Email required",
        description: "Please enter an email address.",
        variant: "destructive",
      });
      return;
    }

    try {
      setLoading(true);

      const response = await apiRequest("POST", "/api/discord/verify/email", {
        email,
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Verification initiated",
          description: "Check Discord for verification instructions.",
        });
      } else {
        toast({
          title: "Verification failed",
          description: data.message || "An error occurred during verification.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Verification failed",
        description: "An error occurred during verification.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneVerification = async () => {
    if (!phoneNumber) {
      toast({
        title: "Phone number required",
        description: "Please enter a phone number.",
        variant: "destructive",
      });
      return;
    }

    try {
      setLoading(true);

      const response = await apiRequest("POST", "/api/discord/verify/phone", {
        phone_number: phoneNumber,
        service,
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Verification initiated",
          description: "Check Discord for verification instructions.",
        });

        if (data.verification_id) {
          setVerificationId(data.verification_id);
          // After a short delay, check for the verification code
          setTimeout(checkVerificationCode, 10000, data.verification_id);
        }
      } else {
        toast({
          title: "Verification failed",
          description: data.message || "An error occurred during verification.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Verification failed",
        description: "An error occurred during verification.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const checkVerificationCode = async (verId: string) => {
    try {
      const response = await apiRequest("POST", "/api/discord/verify/phone/check", {
        verification_id: verId,
        service,
      });

      const data = await response.json();

      if (data.success && data.code) {
        setVerificationCode(data.code);
        toast({
          title: "Verification code",
          description: `Your verification code is: ${data.code}`,
        });
      } else {
        // Try again after a short delay
        setTimeout(checkVerificationCode, 5000, verId);
      }
    } catch (error) {
      console.error("Error checking verification code:", error);
    }
  };

  if (!isConnected) {
    return (
      <Card className="bg-[#1E1E1E] border-white/10">
        <CardHeader>
          <CardTitle>Discord Verification</CardTitle>
          <CardDescription>
            Connect your Discord account first to use verification features
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="bg-[#1E1E1E] border-white/10">
      <CardHeader>
        <CardTitle>Discord Verification</CardTitle>
        <CardDescription>
          Verify your identity through Discord
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="email">
          <TabsList className="bg-black/50 mb-4">
            <TabsTrigger value="email">Email</TabsTrigger>
            <TabsTrigger value="phone">Phone</TabsTrigger>
          </TabsList>
          
          <TabsContent value="email">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-black/30 border-white/10"
                />
              </div>
              
              <Button 
                onClick={handleEmailVerification} 
                disabled={loading}
                className="w-full"
              >
                {loading ? "Verifying..." : "Verify Email"}
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="phone">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  placeholder="Enter your phone number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="bg-black/30 border-white/10"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="service">Service</Label>
                <select
                  id="service"
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  className="w-full bg-black/30 border border-white/10 rounded-md p-2"
                >
                  <option value="spotify">Spotify</option>
                  <option value="netflix">Netflix</option>
                  <option value="google">Google</option>
                  <option value="facebook">Facebook</option>
                  <option value="twitter">Twitter</option>
                  <option value="amazon">Amazon</option>
                </select>
              </div>
              
              <Button 
                onClick={handlePhoneVerification} 
                disabled={loading}
                className="w-full"
              >
                {loading ? "Verifying..." : "Verify Phone"}
              </Button>
              
              {verificationCode && (
                <div className="mt-4 p-3 bg-[#14F195]/10 border border-[#14F195]/30 rounded-md">
                  <p className="font-medium">Verification Code:</p>
                  <p className="text-xl font-bold">{verificationCode}</p>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="border-t border-white/10 pt-4">
        <p className="text-xs text-white/60">
          Connected as: <span className="font-medium text-white">{discordUsername}</span>
        </p>
      </CardFooter>
    </Card>
  );
}
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { Input } from "../ui/input";
import { Button } from "../ui/button";
import { Label } from "../ui/label";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import axios from 'axios';

export function DiscordVerification() {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [emailStatus, setEmailStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [phoneStatus, setPhoneStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [emailMessage, setEmailMessage] = useState('');
  const [phoneMessage, setPhoneMessage] = useState('');

  const handleEmailVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      setEmailMessage('Please enter an email address');
      setEmailStatus('error');
      return;
    }
    
    try {
      setEmailStatus('loading');
      setEmailMessage('');
      
      const response = await axios.post('/api/discord/verify/email', { email });
      
      if (response.data.success) {
        setEmailStatus('success');
        setEmailMessage('Verification sent! Check your Discord for updates.');
      } else {
        setEmailStatus('error');
        setEmailMessage(response.data.message || 'Failed to send verification');
      }
    } catch (error: any) {
      setEmailStatus('error');
      setEmailMessage(error.response?.data?.message || 'An error occurred');
    }
  };

  const handlePhoneVerification = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!phone) {
      setPhoneMessage('Please enter a phone number');
      setPhoneStatus('error');
      return;
    }
    
    try {
      setPhoneStatus('loading');
      setPhoneMessage('');
      
      const response = await axios.post('/api/discord/verify/phone', { phone_number: phone });
      
      if (response.data.success) {
        setPhoneStatus('success');
        setPhoneMessage('Verification sent! Check your Discord for updates.');
      } else {
        setPhoneStatus('error');
        setPhoneMessage(response.data.message || 'Failed to send verification');
      }
    } catch (error: any) {
      setPhoneStatus('error');
      setPhoneMessage(error.response?.data?.message || 'An error occurred');
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Email Verification</CardTitle>
          <CardDescription>
            Verify your email through our Discord bot
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleEmailVerification} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            
            {emailMessage && (
              <div className={`text-sm ${emailStatus === 'error' ? 'text-red-500' : 'text-green-500'}`}>
                {emailMessage}
              </div>
            )}
            
            <Button type="submit" disabled={emailStatus === 'loading'} className="w-full">
              {emailStatus === 'loading' ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying...
                </>
              ) : emailStatus === 'success' ? (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Verification Sent
                </>
              ) : (
                'Verify Email'
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Phone Verification</CardTitle>
          <CardDescription>
            Verify your phone number through our Discord bot
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handlePhoneVerification} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+1234567890"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            
            {phoneMessage && (
              <div className={`text-sm ${phoneStatus === 'error' ? 'text-red-500' : 'text-green-500'}`}>
                {phoneMessage}
              </div>
            )}
            
            <Button type="submit" disabled={phoneStatus === 'loading'} className="w-full">
              {phoneStatus === 'loading' ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Verifying...
                </>
              ) : phoneStatus === 'success' ? (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Verification Sent
                </>
              ) : (
                'Verify Phone'
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
