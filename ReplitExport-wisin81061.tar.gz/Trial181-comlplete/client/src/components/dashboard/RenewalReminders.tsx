import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Calendar, ArrowRight } from "lucide-react";
import { format, differenceInDays } from 'date-fns';
import { motion } from "framer-motion";

interface RenewalRemindersProps {
  subscriptionData?: {
    subscription?: {
      tier: string;
      price: string;
      start_date: string;
      end_date: string;
      active: boolean;
    };
  };
  trialsData?: {
    trials?: Array<{
      id: number;
      service_name: string;
      created_at: string;
      trial_duration_days: number;
      status: string;
    }>;
  };
}

export default function RenewalReminders({ subscriptionData, trialsData }: RenewalRemindersProps) {
  const [upcomingRenewals, setUpcomingRenewals] = useState<Array<{
    id: string;
    name: string;
    type: 'subscription' | 'trial';
    date: Date;
    daysRemaining: number;
    status: string;
  }>>([]);

  useEffect(() => {
    const reminders = [];
    const now = new Date();

    // Add subscription renewal if available
    if (subscriptionData?.subscription) {
      const endDate = new Date(subscriptionData.subscription.end_date);
      const daysToRenewal = differenceInDays(endDate, now);
      
      if (daysToRenewal >= 0 && daysToRenewal <= 14) {
        reminders.push({
          id: `subscription-${subscriptionData.subscription.tier}`,
          name: `${subscriptionData.subscription.tier.charAt(0).toUpperCase() + subscriptionData.subscription.tier.slice(1)} Plan`,
          type: 'subscription' as const,
          date: endDate,
          daysRemaining: daysToRenewal,
          status: subscriptionData.subscription.active ? 'active' : 'inactive'
        });
      }
    }

    // Add trial expirations
    if (trialsData?.trials) {
      trialsData.trials.forEach(trial => {
        if (trial.status === 'completed' || trial.status === 'in_progress') {
          const createdDate = new Date(trial.created_at);
          const expirationDate = new Date(createdDate);
          expirationDate.setDate(createdDate.getDate() + trial.trial_duration_days);
          
          const daysToExpiration = differenceInDays(expirationDate, now);
          
          if (daysToExpiration >= 0 && daysToExpiration <= 14) {
            reminders.push({
              id: `trial-${trial.id}`,
              name: trial.service_name,
              type: 'trial' as const,
              date: expirationDate,
              daysRemaining: daysToExpiration,
              status: trial.status
            });
          }
        }
      });
    }

    // Sort by date (closest first)
    reminders.sort((a, b) => a.daysRemaining - b.daysRemaining);
    
    setUpcomingRenewals(reminders);
  }, [subscriptionData, trialsData]);

  if (upcomingRenewals.length === 0) {
    return null;
  }

  return (
    <Card className="bg-[#1E1E1E] border-white/10">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center">
            <Bell className="h-5 w-5 mr-2 text-[#14F195]" /> 
            Upcoming Renewals & Expirations
          </CardTitle>
          <CardDescription>
            Stay informed about your subscription and trial renewal dates
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {upcomingRenewals.map((renewal) => (
          <motion.div 
            key={renewal.id}
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className={`p-3 rounded-md flex justify-between items-center ${
              renewal.daysRemaining <= 3 
                ? "bg-red-950/20 border border-red-500/20" 
                : renewal.daysRemaining <= 7
                  ? "bg-amber-950/20 border border-amber-500/20"
                  : "bg-[#2D2D2D]"
            }`}
          >
            <div className="flex items-center">
              <div className={`p-2 rounded-full mr-3 ${
                renewal.type === 'subscription' 
                  ? "bg-[#14F195]/10" 
                  : "bg-[#8A2BE2]/10"
              }`}>
                <Calendar className={`h-4 w-4 ${
                  renewal.type === 'subscription' 
                    ? "text-[#14F195]" 
                    : "text-[#8A2BE2]"
                }`} />
              </div>
              <div>
                <div className="flex items-center">
                  <p className="font-medium">{renewal.name}</p>
                  <Badge 
                    variant="outline" 
                    className={`ml-2 text-xs ${
                      renewal.type === 'subscription' 
                        ? "bg-[#14F195]/10 text-[#14F195] border-[#14F195]/30" 
                        : "bg-[#8A2BE2]/10 text-[#8A2BE2] border-[#8A2BE2]/30"
                    }`}
                  >
                    {renewal.type === 'subscription' ? 'Subscription' : 'Trial'}
                  </Badge>
                </div>
                <p className="text-xs text-gray-400">
                  {renewal.type === 'subscription' 
                    ? 'Renews' 
                    : 'Expires'} on {format(renewal.date, "MMM d, yyyy")}
                </p>
              </div>
            </div>
            <div className="flex flex-col items-end">
              <Badge 
                variant="outline" 
                className={
                  renewal.daysRemaining <= 3
                    ? "bg-red-500/10 text-red-500 border-red-500/30"
                    : renewal.daysRemaining <= 7
                      ? "bg-amber-500/10 text-amber-500 border-amber-500/30"
                      : "bg-blue-500/10 text-blue-500 border-blue-500/30"
                }
              >
                {renewal.daysRemaining === 0 
                  ? "Today" 
                  : renewal.daysRemaining === 1 
                    ? "Tomorrow" 
                    : `${renewal.daysRemaining} days`}
              </Badge>
              <p className="text-xs text-gray-400 mt-1">
                {renewal.type === 'subscription' 
                  ? 'Auto-renewal ' 
                  : 'Auto-cancellation '} 
                {renewal.daysRemaining === 0 
                  ? "today" 
                  : `in ${renewal.daysRemaining} days`}
              </p>
            </div>
          </motion.div>
        ))}
      </CardContent>
      <CardFooter className="border-t border-white/10 pt-4">
        <Button 
          variant="link" 
          className="ml-auto text-[#14F195] hover:text-[#14F195]/80 p-0 flex items-center"
        >
          Manage all renewals <ArrowRight className="ml-1 h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}