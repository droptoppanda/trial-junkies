import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface VirtualIdentity {
  id: number;
  user_id: number;
  profile_name: string;
  first_name: string;
  last_name: string;
  email: string;
  phone_number?: string;
  date_of_birth?: string;
  address?: string;
  city?: string;
  state?: string;
  zip_code?: string;
  country?: string;
  created_at: string;
  updated_at?: string;
}

export default function IdentityProfiles() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreating, setIsCreating] = useState(false);
  const [selectedIdentity, setSelectedIdentity] = useState<VirtualIdentity | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    profile_name: "",
    first_name: "",
    last_name: "",
    email: "",
    phone_number: "",
    date_of_birth: "",
    address: "",
    city: "",
    state: "",
    zip_code: "",
    country: "",
  });

  // Fetch user's identities
  const { data: identitiesData, isLoading, error } = useQuery({
    queryKey: ["/api/identities"],
  });

  // Create new identity mutation
  const createMutation = useMutation({
    mutationFn: (identity: typeof formData) => {
      return apiRequest("POST", "/api/identities/create", identity);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/identities"] });
      setIsCreating(false);
      resetForm();
      toast({
        title: "Identity Created",
        description: "Your virtual identity profile has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error Creating Identity",
        description: error.message || "Failed to create identity profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update identity mutation
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<typeof formData> }) => {
      return apiRequest("PATCH", `/api/identities/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/identities"] });
      setIsEditing(false);
      setSelectedIdentity(null);
      resetForm();
      toast({
        title: "Identity Updated",
        description: "Your virtual identity profile has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error Updating Identity",
        description: error.message || "Failed to update identity profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditing && selectedIdentity) {
      updateMutation.mutate({ id: selectedIdentity.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const editIdentity = (identity: VirtualIdentity) => {
    setSelectedIdentity(identity);
    setFormData({
      profile_name: identity.profile_name || "",
      first_name: identity.first_name || "",
      last_name: identity.last_name || "",
      email: identity.email || "",
      phone_number: identity.phone_number || "",
      date_of_birth: identity.date_of_birth || "",
      address: identity.address || "",
      city: identity.city || "",
      state: identity.state || "",
      zip_code: identity.zip_code || "",
      country: identity.country || "",
    });
    setIsEditing(true);
    setIsCreating(true);
  };

  const resetForm = () => {
    setFormData({
      profile_name: "",
      first_name: "",
      last_name: "",
      email: "",
      phone_number: "",
      date_of_birth: "",
      address: "",
      city: "",
      state: "",
      zip_code: "",
      country: "",
    });
  };

  const cancelEditing = () => {
    setIsCreating(false);
    setIsEditing(false);
    setSelectedIdentity(null);
    resetForm();
  };

  if (isLoading) {
    return (
      <div className="w-full py-6">
        <div className="flex justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full py-6 text-center">
        <p className="text-red-500">Failed to load identity profiles. Please try again.</p>
      </div>
    );
  }

  const identities = identitiesData?.identities || [];

  return (
    <div className="w-full space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Virtual Identity Profiles</h2>
        {!isCreating && (
          <button
            onClick={() => setIsCreating(true)}
            className="px-4 py-2 bg-primary text-black rounded-md hover:opacity-90 transition-opacity"
          >
            Create New Identity
          </button>
        )}
      </div>

      {isCreating && (
        <div className="p-4 bg-secondary rounded-lg">
          <h3 className="text-lg font-medium mb-4">
            {isEditing ? "Edit Identity Profile" : "Create New Identity Profile"}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Profile Name</label>
                <input
                  type="text"
                  name="profile_name"
                  placeholder="e.g., Work Profile, Gaming Profile"
                  value={formData.profile_name}
                  onChange={handleInputChange}
                  required
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Email</label>
                <input
                  type="email"
                  name="email"
                  placeholder="Email address"
                  value={formData.email}
                  onChange={handleInputChange}
                  required
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">First Name</label>
                <input
                  type="text"
                  name="first_name"
                  placeholder="First name"
                  value={formData.first_name}
                  onChange={handleInputChange}
                  required
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Last Name</label>
                <input
                  type="text"
                  name="last_name"
                  placeholder="Last name"
                  value={formData.last_name}
                  onChange={handleInputChange}
                  required
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Phone Number (Optional)</label>
                <input
                  type="tel"
                  name="phone_number"
                  placeholder="Phone number"
                  value={formData.phone_number}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Date of Birth (Optional)</label>
                <input
                  type="date"
                  name="date_of_birth"
                  value={formData.date_of_birth}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-1">Address (Optional)</label>
                <input
                  type="text"
                  name="address"
                  placeholder="Street address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">City (Optional)</label>
                <input
                  type="text"
                  name="city"
                  placeholder="City"
                  value={formData.city}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">State/Province (Optional)</label>
                <input
                  type="text"
                  name="state"
                  placeholder="State/Province"
                  value={formData.state}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">ZIP/Postal Code (Optional)</label>
                <input
                  type="text"
                  name="zip_code"
                  placeholder="ZIP/Postal code"
                  value={formData.zip_code}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Country (Optional)</label>
                <input
                  type="text"
                  name="country"
                  placeholder="Country"
                  value={formData.country}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
            </div>
            
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={cancelEditing}
                className="px-4 py-2 border border-gray-600 text-white rounded-md hover:bg-gray-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-primary text-black rounded-md hover:opacity-90 transition-opacity"
                disabled={createMutation.isPending || updateMutation.isPending}
              >
                {(createMutation.isPending || updateMutation.isPending) ? (
                  <span className="flex items-center">
                    <span className="animate-spin mr-2 h-4 w-4 border-2 border-black border-t-transparent rounded-full"></span>
                    {isEditing ? "Updating..." : "Creating..."}
                  </span>
                ) : (
                  isEditing ? "Update Identity" : "Create Identity"
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {identities.length === 0 ? (
        <div className="text-center py-8 bg-secondary rounded-lg">
          <p className="text-gray-400">You don't have any virtual identity profiles yet.</p>
          <p className="mt-2">Create your first profile to use with automated trials!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {identities.map((identity: VirtualIdentity) => (
            <div key={identity.id} className="p-4 bg-secondary rounded-lg hover:bg-gray-800 transition-colors">
              <div className="flex justify-between">
                <h3 className="text-lg font-medium">{identity.profile_name}</h3>
                <button
                  onClick={() => editIdentity(identity)}
                  className="text-primary hover:underline"
                >
                  Edit
                </button>
              </div>
              <div className="mt-2 space-y-1 text-sm">
                <p><span className="text-gray-400">Name:</span> {identity.first_name} {identity.last_name}</p>
                <p><span className="text-gray-400">Email:</span> {identity.email}</p>
                {identity.phone_number && (
                  <p><span className="text-gray-400">Phone:</span> {identity.phone_number}</p>
                )}
                {identity.address && (
                  <p className="text-gray-400">
                    Address: {[
                      identity.address,
                      identity.city,
                      identity.state,
                      identity.zip_code,
                      identity.country
                    ].filter(Boolean).join(", ")}
                  </p>
                )}
                <p className="text-xs text-gray-500 mt-2">
                  Created on {new Date(identity.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}