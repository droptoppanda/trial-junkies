import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface ApiKeyManagerProps {
  subscription?: {
    tier: string;
    active: boolean;
  };
}

export default function ApiKeyManager({ subscription }: ApiKeyManagerProps) {
  const { toast } = useToast();
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [isRevealed, setIsRevealed] = useState(false);

  // Generate API key mutation
  const generateKeyMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", "/api/user/generate-api-key", {});
    },
    onSuccess: (data) => {
      setApiKey(data.api_key);
      setIsRevealed(true);
      toast({
        title: "API Key Generated",
        description: "Your API key has been generated successfully. Keep it secure!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error Generating API Key",
        description: error.message || "Failed to generate API key. Please try again.",
        variant: "destructive",
      });
    },
  });

  const isEnterprise = subscription?.tier === "enterprise" && subscription?.active;

  const handleGenerateKey = () => {
    generateKeyMutation.mutate();
  };

  const handleCopyKey = () => {
    if (apiKey) {
      navigator.clipboard.writeText(apiKey)
        .then(() => {
          toast({
            title: "Copied to Clipboard",
            description: "API key copied to clipboard.",
          });
        })
        .catch(() => {
          toast({
            title: "Copy Failed",
            description: "Failed to copy API key. Please try again.",
            variant: "destructive",
          });
        });
    }
  };

  return (
    <div className="w-full p-4 bg-secondary rounded-lg space-y-4">
      <h3 className="text-lg font-bold">API Access</h3>
      
      {!isEnterprise ? (
        <div className="py-6 text-center">
          <p className="text-gray-400 mb-2">API access is only available for Enterprise tier subscribers.</p>
          <p>Upgrade to the Overdose Plan to access our API.</p>
        </div>
      ) : (
        <>
          <p className="text-sm text-gray-400">
            Your Enterprise subscription includes API access. Use this key to authenticate your API requests.
          </p>
          
          {apiKey ? (
            <div className="space-y-3">
              <div className="flex items-center">
                <input
                  type={isRevealed ? "text" : "password"}
                  value={apiKey}
                  readOnly
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary font-mono text-sm"
                />
                <button
                  onClick={() => setIsRevealed(!isRevealed)}
                  className="ml-2 px-3 py-2 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors"
                >
                  {isRevealed ? "Hide" : "Show"}
                </button>
                <button
                  onClick={handleCopyKey}
                  className="ml-2 px-3 py-2 bg-gray-800 rounded-md hover:bg-gray-700 transition-colors"
                >
                  Copy
                </button>
              </div>
              <div className="text-xs text-yellow-500">
                <p>⚠️ Store this API key securely. For security reasons, we cannot display it again later.</p>
              </div>
              <button
                onClick={handleGenerateKey}
                className="px-4 py-2 bg-gray-800 border border-gray-700 text-white rounded-md hover:bg-gray-700 transition-colors text-sm"
                disabled={generateKeyMutation.isPending}
              >
                {generateKeyMutation.isPending ? "Generating..." : "Generate New Key (Invalidates Old Key)"}
              </button>
            </div>
          ) : (
            <button
              onClick={handleGenerateKey}
              className="w-full px-4 py-2 bg-primary text-black rounded-md hover:opacity-90 transition-opacity"
              disabled={generateKeyMutation.isPending}
            >
              {generateKeyMutation.isPending ? (
                <span className="flex items-center justify-center">
                  <span className="animate-spin mr-2 h-4 w-4 border-2 border-black border-t-transparent rounded-full"></span>
                  Generating API Key...
                </span>
              ) : (
                "Generate API Key"
              )}
            </button>
          )}
          
          <div className="mt-4 text-sm">
            <h4 className="font-medium">API Documentation Quick Reference:</h4>
            <div className="mt-2 p-3 bg-black rounded-md font-mono text-xs">
              <p className="mb-1 text-gray-400">// Example API request</p>
              <p>
                <span className="text-blue-400">fetch</span>
                (<span className="text-green-400">'https://api.trialjunkies.com/v1/trials'</span>, {"{"}
              </p>
              <p className="ml-4">
                <span className="text-purple-400">method</span>: <span className="text-green-400">'GET'</span>,
              </p>
              <p className="ml-4">
                <span className="text-purple-400">headers</span>: {"{"}
              </p>
              <p className="ml-8">
                <span className="text-green-400">'Authorization'</span>: <span className="text-green-400">'Bearer YOUR_API_KEY'</span>
              </p>
              <p className="ml-4">{"}"}</p>
              <p>{"}"});</p>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-2">
            For full API documentation, please visit our developers portal.
          </p>
        </>
      )}
    </div>
  );
}