import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface VirtualCard {
  id: number;
  user_id: number;
  card_name: string;
  card_number: string;
  expiration_date: string;
  cvv: string;
  cardholder_name: string;
  billing_address?: string;
  billing_city?: string;
  billing_state?: string;
  billing_zip?: string;
  billing_country?: string;
  card_type: "visa" | "mastercard" | "amex" | "discover";
  status: "active" | "inactive" | "expired";
  created_at: string;
  updated_at?: string;
}

export default function VirtualCards() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreating, setIsCreating] = useState(false);
  const [formData, setFormData] = useState({
    card_name: "",
    cardholder_name: "",
    card_type: "visa",
    billing_address: "",
    billing_city: "",
    billing_state: "",
    billing_zip: "",
    billing_country: ""
  });

  // Fetch user's virtual cards
  const { data: cardsData, isLoading, error } = useQuery({
    queryKey: ["/api/cards"],
  });

  // Create new virtual card mutation
  const createMutation = useMutation({
    mutationFn: (cardData: typeof formData) => {
      return apiRequest("POST", "/api/cards/create", cardData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cards"] });
      setIsCreating(false);
      resetForm();
      toast({
        title: "Virtual Card Created",
        description: "Your virtual card has been created successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error Creating Card",
        description: error.message || "Failed to create virtual card. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(formData);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const resetForm = () => {
    setFormData({
      card_name: "",
      cardholder_name: "",
      card_type: "visa",
      billing_address: "",
      billing_city: "",
      billing_state: "",
      billing_zip: "",
      billing_country: ""
    });
  };

  const getCardTypeIcon = (type: VirtualCard["card_type"]) => {
    switch (type) {
      case "visa":
        return "💳 Visa";
      case "mastercard":
        return "💳 Mastercard";
      case "amex":
        return "💳 Amex";
      case "discover":
        return "💳 Discover";
      default:
        return "💳";
    }
  };

  const getStatusBadge = (status: VirtualCard["status"]) => {
    switch (status) {
      case "active":
        return <span className="px-2 py-1 bg-green-500 text-white text-xs rounded-full">Active</span>;
      case "inactive":
        return <span className="px-2 py-1 bg-yellow-500 text-white text-xs rounded-full">Inactive</span>;
      case "expired":
        return <span className="px-2 py-1 bg-red-500 text-white text-xs rounded-full">Expired</span>;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="w-full py-6">
        <div className="flex justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full py-6 text-center">
        <p className="text-red-500">Failed to load virtual cards. Please try again.</p>
      </div>
    );
  }

  const cards = cardsData?.cards || [];

  return (
    <div className="w-full space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Virtual Cards</h2>
        {!isCreating && (
          <button
            onClick={() => setIsCreating(true)}
            className="px-4 py-2 bg-primary text-black rounded-md hover:opacity-90 transition-opacity"
          >
            Create New Card
          </button>
        )}
      </div>

      {isCreating && (
        <div className="p-4 bg-secondary rounded-lg">
          <h3 className="text-lg font-medium mb-4">Create New Virtual Card</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Card Name</label>
                <input
                  type="text"
                  name="card_name"
                  placeholder="e.g., Shopping Card, Subscription Card"
                  value={formData.card_name}
                  onChange={handleInputChange}
                  required
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Cardholder Name</label>
                <input
                  type="text"
                  name="cardholder_name"
                  placeholder="Name on card"
                  value={formData.cardholder_name}
                  onChange={handleInputChange}
                  required
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Card Type</label>
                <select
                  name="card_type"
                  value={formData.card_type}
                  onChange={handleInputChange}
                  required
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                >
                  <option value="visa">Visa</option>
                  <option value="mastercard">Mastercard</option>
                  <option value="amex">American Express</option>
                  <option value="discover">Discover</option>
                </select>
              </div>
            </div>
            
            <h4 className="text-md font-medium mt-4 mb-2">Billing Address</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Address</label>
                <input
                  type="text"
                  name="billing_address"
                  placeholder="Street address"
                  value={formData.billing_address}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">City</label>
                <input
                  type="text"
                  name="billing_city"
                  placeholder="City"
                  value={formData.billing_city}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">State/Province</label>
                <input
                  type="text"
                  name="billing_state"
                  placeholder="State/Province"
                  value={formData.billing_state}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">ZIP/Postal Code</label>
                <input
                  type="text"
                  name="billing_zip"
                  placeholder="ZIP/Postal code"
                  value={formData.billing_zip}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Country</label>
                <input
                  type="text"
                  name="billing_country"
                  placeholder="Country"
                  value={formData.billing_country}
                  onChange={handleInputChange}
                  className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
                />
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-4">
              <button
                type="button"
                onClick={() => {
                  setIsCreating(false);
                  resetForm();
                }}
                className="px-4 py-2 border border-gray-600 text-white rounded-md hover:bg-gray-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-primary text-black rounded-md hover:opacity-90 transition-opacity"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? (
                  <span className="flex items-center">
                    <span className="animate-spin mr-2 h-4 w-4 border-2 border-black border-t-transparent rounded-full"></span>
                    Creating...
                  </span>
                ) : (
                  "Create Card"
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {cards.length === 0 ? (
        <div className="text-center py-8 bg-secondary rounded-lg">
          <p className="text-gray-400">You don't have any virtual cards yet.</p>
          <p className="mt-2">Create your first virtual card to use with automated trials!</p>
          <p className="mt-4 text-sm text-gray-400">Note: Virtual cards require Pro or Enterprise subscription.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {cards.map((card: VirtualCard) => (
            <div key={card.id} className="p-4 bg-secondary rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-medium">{card.card_name}</h3>
                {getStatusBadge(card.status)}
              </div>
              <div className="p-4 bg-black rounded-md border border-gray-700 mb-3">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-primary font-bold">{getCardTypeIcon(card.card_type)}</span>
                  <span className="text-xs text-gray-400">Expires: {card.expiration_date}</span>
                </div>
                <div className="text-lg font-mono tracking-widest mb-2">
                  {card.card_number.replace(/\d{4}(?=.)/g, "$& ")}
                </div>
                <div className="text-sm text-gray-400">{card.cardholder_name}</div>
              </div>
              <div className="text-xs text-gray-500">
                <p>Created on {new Date(card.created_at).toLocaleDateString()}</p>
                {card.billing_address && (
                  <p className="mt-1">
                    Billing: {[
                      card.billing_address,
                      card.billing_city,
                      card.billing_state,
                      card.billing_zip,
                      card.billing_country
                    ].filter(Boolean).join(", ")}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}