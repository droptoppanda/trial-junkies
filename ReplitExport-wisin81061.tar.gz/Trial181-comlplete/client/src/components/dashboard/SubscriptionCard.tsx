import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/lib/wallet";
import { Check, X, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { subscriptionTiers } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

export default function SubscriptionCard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { connected, publicKey } = useWallet();
  const [selectedTier, setSelectedTier] = useState<string | null>(null);
  
  // Get subscription tiers from the backend
  const { data: tiers, isLoading: isLoadingTiers } = useQuery({
    queryKey: ['/api/subscriptions/tiers'],
    staleTime: Infinity, // This data doesn't change frequently
  });
  
  // Get user's active subscription
  const { data: subscriptionData, isLoading: isLoadingSubscription } = useQuery({
    queryKey: ['/api/subscriptions/active'],
  });
  
  // Subscribe mutation
  const { mutate: subscribe, isPending } = useMutation({
    mutationFn: async (tier: string) => {
      // Create a subscription start and end date (30 days from now)
      const startDate = new Date();
      const endDate = new Date();
      endDate.setDate(endDate.getDate() + 30);
      
      // Get price from the tier
      const price = (tiers || subscriptionTiers)[tier].price;
      
      const response = await apiRequest("POST", "/api/subscriptions/subscribe", {
        tier,
        price,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        active: true,
        transaction_signature: `mock_sig_${Date.now()}`, // In a real app, this would come from a blockchain transaction
      });
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/subscriptions/active'] });
      toast({
        title: "Subscription successful",
        description: `You are now subscribed to the ${selectedTier} plan.`,
      });
    },
    onError: (error) => {
      toast({
        title: "Subscription failed",
        description: error instanceof Error ? error.message : "An error occurred during subscription.",
        variant: "destructive",
      });
    },
  });
  
  // Cancel subscription mutation
  const { mutate: cancelSubscription, isPending: isCanceling } = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/subscriptions/cancel", {});
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/subscriptions/active'] });
      toast({
        title: "Subscription canceled",
        description: "Your subscription has been canceled successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Cancellation failed",
        description: error instanceof Error ? error.message : "An error occurred while canceling your subscription.",
        variant: "destructive",
      });
    },
  });
  
  const handleSubscribe = async (tier: string) => {
    if (!connected) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your Phantom wallet to subscribe.",
        variant: "destructive",
      });
      return;
    }
    
    setSelectedTier(tier);
    subscribe(tier);
  };
  
  const handleCancel = () => {
    cancelSubscription();
  };
  
  // Use fetched data if available, otherwise fall back to imported data
  const pricingData = tiers || subscriptionTiers;
  
  const isLoading = isLoadingTiers || isLoadingSubscription;
  const activeSubscription = subscriptionData?.subscription;
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-[#8A2BE2]" />
      </div>
    );
  }
  
  return (
    <div className="space-y-8">
      {activeSubscription && (
        <Card className="bg-[#1E1E1E] border-white/10">
          <CardHeader>
            <CardTitle>Current Subscription</CardTitle>
            <CardDescription>Your active subscription details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-400">Plan</p>
                <p className="text-lg font-medium capitalize">{activeSubscription.tier}</p>
              </div>
              <Badge variant="outline" className="bg-[#14F195]/10 text-[#14F195] border-[#14F195]/20">
                Active
              </Badge>
            </div>
            
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-400">Price</p>
                <p className="text-lg font-medium">{activeSubscription.price} SOL/month</p>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-400">Start Date</p>
                <p className="text-lg font-medium">
                  {new Date(activeSubscription.start_date).toLocaleDateString()}
                </p>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-400">Next Renewal</p>
                <p className="text-lg font-medium">
                  {new Date(activeSubscription.end_date).toLocaleDateString()}
                </p>
              </div>
            </div>
          </CardContent>
          <CardFooter className="border-t border-white/10 pt-4 flex justify-between">
            <p className="text-sm text-gray-400">
              Your subscription will automatically renew on {new Date(activeSubscription.end_date).toLocaleDateString()}
            </p>
            <Button 
              variant="destructive" 
              size="sm"
              onClick={handleCancel}
              disabled={isCanceling}
            >
              {isCanceling && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Cancel
            </Button>
          </CardFooter>
        </Card>
      )}
      
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold mb-2">
          {activeSubscription ? "Change Subscription Plan" : "Choose a Subscription Plan"}
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Select the plan that best suits your needs
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Basic Plan */}
        <motion.div 
          className="subscription-card bg-[#1E1E1E] rounded-xl overflow-hidden transition-all duration-300 hover:translate-y-[-5px]"
          whileHover={{ y: -5 }}
        >
          <div className="p-6">
            <h3 className="text-xl font-semibold mb-2">{pricingData.basic.name}</h3>
            <div className="flex items-end mb-4">
              <span className="text-3xl font-bold">{pricingData.basic.price}</span>
              <span className="ml-1 text-sm text-gray-400">SOL/month</span>
            </div>
            <p className="text-gray-400 text-sm mb-6">Perfect for individuals getting started</p>
            
            <ul className="space-y-3 mb-6">
              {pricingData.basic.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="text-[#14F195] mt-1 mr-2 h-4 w-4" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
              {pricingData.basic.notIncluded.map((feature, index) => (
                <li key={index} className="flex items-start text-gray-500">
                  <X className="mt-1 mr-2 h-4 w-4" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
            </ul>
            
            <Button 
              onClick={() => handleSubscribe("basic")}
              disabled={isPending && selectedTier === "basic"}
              className={`w-full ${activeSubscription?.tier === "basic" 
                ? "bg-[#14F195] hover:bg-[#14F195]/90" 
                : "bg-[#2D2D2D] hover:bg-[#8A2BE2]/90"} text-white py-2 rounded-md h-auto`}
            >
              {isPending && selectedTier === "basic" ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              {activeSubscription?.tier === "basic" 
                ? "Current Plan" 
                : activeSubscription ? "Switch Plan" : "Subscribe Now"}
            </Button>
          </div>
        </motion.div>
        
        {/* Pro Plan */}
        <motion.div 
          className="subscription-card premium-card bg-[#1E1E1E] rounded-xl overflow-hidden transition-all duration-300 hover:translate-y-[-5px] transform scale-105 shadow-lg relative z-10"
          whileHover={{ y: -5 }}
        >
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-[#8A2BE2] to-[#14F195]"></div>
          <div className="absolute top-0 right-0 bg-[#8A2BE2] text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
            POPULAR
          </div>
          
          <div className="p-6">
            <h3 className="text-xl font-semibold mb-2">{pricingData.pro.name}</h3>
            <div className="flex items-end mb-4">
              <span className="text-3xl font-bold">{pricingData.pro.price}</span>
              <span className="ml-1 text-sm text-gray-400">SOL/month</span>
            </div>
            <p className="text-gray-400 text-sm mb-6">Best value for most users</p>
            
            <ul className="space-y-3 mb-6">
              {pricingData.pro.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="text-[#14F195] mt-1 mr-2 h-4 w-4" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
              {pricingData.pro.notIncluded.map((feature, index) => (
                <li key={index} className="flex items-start text-gray-500">
                  <X className="mt-1 mr-2 h-4 w-4" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
            </ul>
            
            <Button 
              onClick={() => handleSubscribe("pro")}
              disabled={isPending && selectedTier === "pro"}
              className={`w-full ${activeSubscription?.tier === "pro" 
                ? "bg-[#14F195] hover:bg-[#14F195]/90" 
                : "bg-[#8A2BE2] hover:bg-[#8A2BE2]/90"} text-white py-2 rounded-md h-auto ${
                activeSubscription?.tier !== "pro" ? "glow-on-hover" : ""
              }`}
            >
              {isPending && selectedTier === "pro" ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              {activeSubscription?.tier === "pro" 
                ? "Current Plan" 
                : activeSubscription ? "Switch Plan" : "Subscribe Now"}
            </Button>
          </div>
        </motion.div>
        
        {/* Enterprise Plan */}
        <motion.div 
          className="subscription-card bg-[#1E1E1E] rounded-xl overflow-hidden transition-all duration-300 hover:translate-y-[-5px]"
          whileHover={{ y: -5 }}
        >
          <div className="p-6">
            <h3 className="text-xl font-semibold mb-2">{pricingData.enterprise.name}</h3>
            <div className="flex items-end mb-4">
              <span className="text-3xl font-bold">{pricingData.enterprise.price}</span>
              <span className="ml-1 text-sm text-gray-400">SOL/month</span>
            </div>
            <p className="text-gray-400 text-sm mb-6">Complete solution for businesses</p>
            
            <ul className="space-y-3 mb-6">
              {pricingData.enterprise.features.map((feature, index) => (
                <li key={index} className="flex items-start">
                  <Check className="text-[#14F195] mt-1 mr-2 h-4 w-4" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
            </ul>
            
            <Button 
              onClick={() => handleSubscribe("enterprise")}
              disabled={isPending && selectedTier === "enterprise"}
              className={`w-full ${activeSubscription?.tier === "enterprise" 
                ? "bg-[#14F195] hover:bg-[#14F195]/90" 
                : "bg-[#2D2D2D] hover:bg-[#8A2BE2]/90"} text-white py-2 rounded-md h-auto`}
            >
              {isPending && selectedTier === "enterprise" ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              {activeSubscription?.tier === "enterprise" 
                ? "Current Plan" 
                : activeSubscription ? "Switch Plan" : "Subscribe Now"}
            </Button>
          </div>
        </motion.div>
      </div>
      
      <div className="mt-8 max-w-3xl mx-auto bg-[#1E1E1E] rounded-xl p-6 card-gradient">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div>
            <h3 className="text-xl font-semibold mb-2">Need a custom plan?</h3>
            <p className="text-gray-400 mb-4 md:mb-0">Contact us to create a tailored solution for your specific requirements.</p>
          </div>
          <Button variant="outline" className="bg-transparent hover:bg-white/5 text-white border border-white/20 py-2 px-6 rounded-md h-auto">
            Contact Sales
          </Button>
        </div>
      </div>
    </div>
  );
}
