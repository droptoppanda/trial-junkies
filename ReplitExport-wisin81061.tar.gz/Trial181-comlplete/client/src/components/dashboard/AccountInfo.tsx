import { useState } from "react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { useWallet } from "@/lib/wallet";

interface User {
  id: number;
  username: string;
  wallet_address?: string;
  is_admin?: boolean;
}

interface AccountInfoProps {
  user: User;
}

export default function AccountInfo({ user }: AccountInfoProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { connected, publicKey } = useWallet();
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  
  // Link wallet mutation
  const { mutate: linkWallet, isPending: isLinking } = useMutation({
    mutationFn: async (walletAddress: string) => {
      const response = await apiRequest("POST", "/api/wallet/link", {
        wallet_address: walletAddress,
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/status'] });
      toast({
        title: "Wallet linked",
        description: "Your wallet has been successfully linked to your account.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to link wallet",
        description: error instanceof Error ? error.message : "An error occurred while linking your wallet.",
        variant: "destructive",
      });
    },
  });
  
  // Password change mutation (mock - in a real app, implement proper password changing)
  const { mutate: changePassword, isPending: isChangingPassword } = useMutation({
    mutationFn: async (passwordData: { newPassword: string }) => {
      // This is a mock - would need a proper API endpoint
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Password updated",
        description: "Your password has been updated successfully.",
      });
      setNewPassword("");
      setConfirmPassword("");
    },
    onError: (error) => {
      toast({
        title: "Password update failed",
        description: error instanceof Error ? error.message : "An error occurred while updating your password.",
        variant: "destructive",
      });
    },
  });
  
  const handleLinkWallet = () => {
    if (!connected || !publicKey) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your Phantom wallet first.",
        variant: "destructive",
      });
      return;
    }
    
    linkWallet(publicKey);
  };
  
  const handlePasswordChange = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newPassword.length < 6) {
      toast({
        title: "Password too short",
        description: "Password must be at least 6 characters long.",
        variant: "destructive",
      });
      return;
    }
    
    if (newPassword !== confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match.",
        variant: "destructive",
      });
      return;
    }
    
    changePassword({ newPassword });
  };
  
  return (
    <div className="space-y-6">
      <Card className="bg-[#1E1E1E] border-white/10">
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
          <CardDescription>View and update your account details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="username">Username</Label>
            <Input 
              id="username" 
              value={user.username}
              disabled
              className="bg-[#2D2D2D] border-white/10 mt-1"
            />
            <p className="text-xs text-gray-400 mt-1">Username cannot be changed</p>
          </div>
          
          <div>
            <Label htmlFor="wallet">Wallet Address</Label>
            <div className="flex items-center mt-1">
              <Input 
                id="wallet" 
                value={user.wallet_address || "Not linked"}
                disabled
                className="bg-[#2D2D2D] border-white/10"
              />
              {!user.wallet_address && connected && publicKey && (
                <Button 
                  onClick={handleLinkWallet}
                  disabled={isLinking}
                  className="ml-2 bg-[#8A2BE2] hover:bg-[#8A2BE2]/90"
                >
                  {isLinking ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : null}
                  Link
                </Button>
              )}
            </div>
            {!connected && !user.wallet_address && (
              <p className="text-xs text-amber-400 mt-1">Connect your wallet first to link it to your account</p>
            )}
          </div>
          
          {user.is_admin && (
            <div className="bg-[#8A2BE2]/10 border border-[#8A2BE2]/20 rounded-md p-3 mt-4">
              <p className="text-sm flex items-center">
                <svg 
                  className="mr-2 h-4 w-4 text-[#8A2BE2]" 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                  <circle cx="9" cy="7" r="4"></circle>
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                  <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
                Administrator Account
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card className="bg-[#1E1E1E] border-white/10">
        <CardHeader>
          <CardTitle>Change Password</CardTitle>
          <CardDescription>Update your account password</CardDescription>
        </CardHeader>
        <form onSubmit={handlePasswordChange}>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="new-password">New Password</Label>
              <Input 
                id="new-password" 
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="bg-[#2D2D2D] border-white/10 mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="confirm-password">Confirm Password</Label>
              <Input 
                id="confirm-password" 
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="bg-[#2D2D2D] border-white/10 mt-1"
              />
            </div>
          </CardContent>
          <CardFooter className="border-t border-white/10 pt-4">
            <Button 
              type="submit"
              disabled={isChangingPassword || !newPassword || !confirmPassword}
              className="bg-[#8A2BE2] hover:bg-[#8A2BE2]/90"
            >
              {isChangingPassword ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : null}
              Update Password
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}
