import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";
import { format } from "date-fns";

interface TransactionHistoryProps {
  limit?: number;
}

interface Transaction {
  id: number;
  date: string;
  amount: string;
  type: "payment" | "refund";
  status: "successful" | "pending" | "failed";
  description: string;
}

export default function TransactionHistory({ limit }: TransactionHistoryProps) {
  // This would typically fetch from /api/transactions or similar
  // For now, we'll use mock data that matches what would be stored in the database
  const { data, isLoading } = useQuery({
    queryKey: ['/api/subscriptions/user'],
    select: (data) => {
      if (!data || !data.subscriptions) return [];
      
      // Convert subscriptions to transactions
      const transactions: Transaction[] = data.subscriptions.map((sub: any) => ({
        id: sub.id,
        date: sub.start_date,
        amount: sub.price,
        type: "payment",
        status: sub.active ? "successful" : "failed",
        description: `Subscription: ${sub.tier} plan`
      }));
      
      // Sort by date descending
      transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      // Limit if specified
      return limit ? transactions.slice(0, limit) : transactions;
    }
  });
  
  if (isLoading) {
    return (
      <div className="flex justify-center py-6">
        <Loader2 className="h-6 w-6 animate-spin text-[#8A2BE2]" />
      </div>
    );
  }
  
  if (!data || data.length === 0) {
    return (
      <div className="text-center py-6 text-gray-400">
        <p>No transaction history found</p>
      </div>
    );
  }
  
  const getStatusColor = (status: string) => {
    switch (status) {
      case "successful":
        return "bg-[#14F195]/10 text-[#14F195] border-[#14F195]/30";
      case "pending":
        return "bg-amber-500/10 text-amber-500 border-amber-500/30";
      case "failed":
        return "bg-red-500/10 text-red-500 border-red-500/30";
      default:
        return "bg-gray-500/10 text-gray-500 border-gray-500/30";
    }
  };
  
  return (
    <div className="space-y-4">
      {data.map((transaction: Transaction) => (
        <Card key={transaction.id} className="bg-[#2D2D2D] border-white/5">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row justify-between">
              <div>
                <p className="font-medium">{transaction.description}</p>
                <p className="text-sm text-gray-400">
                  {format(new Date(transaction.date), "MMM d, yyyy")}
                </p>
              </div>
              <div className="flex flex-col sm:items-end mt-2 sm:mt-0">
                <p className={`font-medium ${transaction.type === "refund" ? "text-red-400" : "text-white"}`}>
                  {transaction.type === "refund" ? "-" : ""}{transaction.amount} SOL
                </p>
                <Badge variant="outline" className={`mt-1 ${getStatusColor(transaction.status)}`}>
                  {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
