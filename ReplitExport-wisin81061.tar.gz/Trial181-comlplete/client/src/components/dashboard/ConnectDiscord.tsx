import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useDiscord } from "@/lib/discord";
import { Loader2 } from "lucide-react";

interface ConnectDiscordProps {
  isConnected: boolean;
  username: string | null;
  onConnect: () => void;
}

export default function ConnectDiscord({ isConnected, username, onConnect }: ConnectDiscordProps) {
  const { toast } = useToast();
  const { loading, disconnect } = useDiscord();
  
  const handleDisconnect = async () => {
    try {
      await disconnect();
      toast({
        title: "Discord disconnected",
        description: "Your Discord account has been unlinked from your account.",
      });
    } catch (error) {
      toast({
        title: "Failed to disconnect",
        description: "There was an error disconnecting your Discord account. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <Card className="bg-[#1E1E1E] border-white/10 h-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <img 
            src="https://assets-global.website-files.com/6257adef93867e50d84d30e2/636e0a6cc3c481a15a141738_icon_clyde_white_RGB.png" 
            alt="Discord" 
            className="h-5 w-6 mr-3"
          />
          Discord Integration
        </CardTitle>
        <CardDescription>Link your Discord account to unlock social features</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {isConnected ? (
          <div className="bg-[#14F195]/10 border border-[#14F195]/30 rounded-md p-4">
            <div className="flex items-center space-x-2 mb-2">
              <svg 
                className="h-5 w-5 text-[#14F195]" 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
              <span className="font-medium">Connected</span>
            </div>
            <p className="text-sm text-gray-300">
              Logged in as <span className="font-medium text-white">{username}</span>
            </p>
          </div>
        ) : (
          <div className="bg-[#2D2D2D] rounded-md p-4">
            <p className="text-sm text-gray-300 mb-4">
              Connect your Discord account to automatically receive role assignments based on your subscription tier.
            </p>
            <div className="space-y-4">
              <div className="flex items-center">
                <svg 
                  className="h-5 w-5 text-[#14F195] mr-2" 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <polyline points="9 11 12 14 22 4"></polyline>
                  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                </svg>
                <span className="text-sm">Automatic role assignment</span>
              </div>
              <div className="flex items-center">
                <svg 
                  className="h-5 w-5 text-[#14F195] mr-2" 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <polyline points="9 11 12 14 22 4"></polyline>
                  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                </svg>
                <span className="text-sm">Access to subscriber-only channels</span>
              </div>
              <div className="flex items-center">
                <svg 
                  className="h-5 w-5 text-[#14F195] mr-2" 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <polyline points="9 11 12 14 22 4"></polyline>
                  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"></path>
                </svg>
                <span className="text-sm">Community integration</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-white/10 pt-4">
        {isConnected ? (
          <Button 
            variant="outline" 
            onClick={handleDisconnect}
            disabled={loading}
            className="border-white/20 text-white hover:bg-red-900/20 hover:text-red-400 hover:border-red-900/50"
          >
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Disconnect Discord
          </Button>
        ) : (
          <Button 
            onClick={onConnect}
            disabled={loading}
            className="bg-[#5865F2] hover:bg-[#5865F2]/90 text-white w-full"
          >
            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            <svg 
              className="mr-2 h-5 w-5" 
              viewBox="0 0 24 24" 
              fill="currentColor"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M19.54 0c1.356 0 2.46 1.104 2.46 2.472v21.528l-2.58-2.28-1.452-1.344-1.536-1.428.636 2.22h-13.608c-1.356 0-2.46-1.104-2.46-2.472v-16.224c0-1.368 1.104-2.472 2.46-2.472h16.08zm-4.632 15.672c2.652-.084 3.672-1.824 3.672-1.824 0-3.864-1.728-6.996-1.728-6.996-1.728-1.296-3.372-1.26-3.372-1.26l-.168.192c2.04.624 2.988 1.524 2.988 1.524-1.248-.684-2.472-1.02-3.612-1.152-.864-.096-1.692-.072-2.424.024l-.204.024c-.42.036-1.44.192-2.724.756-.444.204-.708.348-.708.348s.996-.948 3.156-1.572l-.12-.144s-1.644-.036-3.372 1.26c0 0-1.728 3.132-1.728 6.996 0 0 1.008 1.74 3.66 1.824 0 0 .444-.54.804-.996-1.524-.456-2.1-1.416-2.1-1.416l.336.204.048.036.047.027.014.006.047.027c.3.168.6.3.876.408.492.192 1.08.384 1.764.516.9.168 1.956.228 3.108.012.564-.096 1.14-.264 1.74-.516.42-.156.888-.384 1.38-.708 0 0-.6.984-2.172 1.428.36.456.792.972.792.972zm-5.58-5.604c-.684 0-1.224.6-1.224 1.332 0 .732.552 1.332 1.224 1.332.684 0 1.224-.6 1.224-1.332.012-.732-.54-1.332-1.224-1.332zm4.38 0c-.684 0-1.224.6-1.224 1.332 0 .732.552 1.332 1.224 1.332.684 0 1.224-.6 1.224-1.332 0-.732-.54-1.332-1.224-1.332z" />
            </svg>
            Connect Discord
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
