import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface Trial {
  id: number;
  user_id: number;
  target_website: string;
  service_name: string;
  status: "queued" | "in_progress" | "completed" | "failed";
  trial_duration_days: number;
  created_at: string;
  updated_at?: string;
  completed_at?: string;
  details?: string;
  credentials?: {
    username?: string;
    email?: string;
    password?: string;
  };
  notes?: string;
}

export default function TrialsManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCreating, setIsCreating] = useState(false);
  const [newTrial, setNewTrial] = useState({
    target_website: "",
    service_name: "",
    trial_duration_days: 7,
    notes: ""
  });

  // Fetch user's trials
  const { data: trialsData, isLoading, error } = useQuery({
    queryKey: ["/api/trials"],
    refetchInterval: 30000, // Refresh every 30 seconds to get status updates
  });

  // Create new trial mutation
  const createMutation = useMutation({
    mutationFn: (trialData: typeof newTrial) => {
      return apiRequest("POST", "/api/trials/create", trialData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trials"] });
      setIsCreating(false);
      setNewTrial({
        target_website: "",
        service_name: "",
        trial_duration_days: 7,
        notes: ""
      });
      toast({
        title: "Trial Created",
        description: "Your automated trial has been queued for processing.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error Creating Trial",
        description: error.message || "Failed to create trial. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(newTrial);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewTrial((prev) => ({
      ...prev,
      [name]: name === "trial_duration_days" ? parseInt(value) : value,
    }));
  };

  // Status badge colors
  const getStatusColor = (status: Trial["status"]) => {
    switch (status) {
      case "queued":
        return "bg-yellow-500 text-white";
      case "in_progress":
        return "bg-blue-500 text-white";
      case "completed":
        return "bg-green-500 text-white";
      case "failed":
        return "bg-red-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  if (isLoading) {
    return (
      <div className="w-full py-6">
        <div className="flex justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full py-6 text-center">
        <p className="text-red-500">Failed to load trials. Please try again.</p>
      </div>
    );
  }

  const trials = trialsData?.trials || [];

  return (
    <div className="w-full space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Your Automated Trials</h2>
        <button
          onClick={() => setIsCreating(!isCreating)}
          className="px-4 py-2 bg-primary text-black rounded-md hover:opacity-90 transition-opacity"
        >
          {isCreating ? "Cancel" : "Create New Trial"}
        </button>
      </div>

      {isCreating && (
        <div className="p-4 bg-secondary rounded-lg">
          <h3 className="text-lg font-medium mb-4">Create New Automated Trial</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Service Name</label>
              <input
                type="text"
                name="service_name"
                placeholder="e.g., Netflix, Spotify, HBO Max"
                value={newTrial.service_name}
                onChange={handleInputChange}
                required
                className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Website URL</label>
              <input
                type="url"
                name="target_website"
                placeholder="https://website.com"
                value={newTrial.target_website}
                onChange={handleInputChange}
                required
                className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Trial Duration (Days)</label>
              <select
                name="trial_duration_days"
                value={newTrial.trial_duration_days}
                onChange={handleInputChange}
                className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary"
              >
                <option value={3}>3 days</option>
                <option value={7}>7 days</option>
                <option value={14}>14 days</option>
                <option value={30}>30 days</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1">Notes (Optional)</label>
              <textarea
                name="notes"
                placeholder="Any specific requirements or details?"
                value={newTrial.notes}
                onChange={handleInputChange}
                rows={3}
                className="w-full p-2 border border-gray-700 rounded-md bg-black focus:ring-1 focus:ring-primary resize-none"
              />
            </div>
            
            <div className="flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 bg-primary text-black rounded-md hover:opacity-90 transition-opacity"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? (
                  <span className="flex items-center">
                    <span className="animate-spin mr-2 h-4 w-4 border-2 border-black border-t-transparent rounded-full"></span>
                    Creating...
                  </span>
                ) : (
                  "Create Trial"
                )}
              </button>
            </div>
          </form>
        </div>
      )}

      {trials.length === 0 ? (
        <div className="text-center py-8 bg-secondary rounded-lg">
          <p className="text-gray-400">You don't have any automated trials yet.</p>
          <p className="mt-2">Create your first trial to get started!</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full table-auto">
            <thead className="bg-secondary text-left">
              <tr>
                <th className="px-4 py-3 rounded-tl-lg">Service</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Created</th>
                <th className="px-4 py-3 rounded-tr-lg">Credentials</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {trials.map((trial: Trial) => (
                <tr key={trial.id} className="hover:bg-secondary/50 transition-colors">
                  <td className="px-4 py-3">
                    <div>
                      <p className="font-medium">{trial.service_name}</p>
                      <p className="text-sm text-gray-400">{trial.target_website}</p>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-block px-2 py-1 text-xs rounded-full ${getStatusColor(
                        trial.status
                      )}`}
                    >
                      {trial.status.replace("_", " ")}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-400">
                    {new Date(trial.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3">
                    {trial.status === "completed" && trial.credentials ? (
                      <div className="text-sm">
                        <p><span className="text-gray-400">Email:</span> {trial.credentials.email || "N/A"}</p>
                        <p><span className="text-gray-400">Password:</span> {trial.credentials.password || "N/A"}</p>
                      </div>
                    ) : (
                      <p className="text-sm text-gray-400">Not available yet</p>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}