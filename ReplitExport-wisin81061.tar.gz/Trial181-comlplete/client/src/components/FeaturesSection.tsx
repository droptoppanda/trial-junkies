import { useScrollTo } from "@/lib/useScrollTo";
import { motion } from "framer-motion";
import { Wallet, Repeat, LayoutDashboard, Smartphone, ShieldCheck } from "lucide-react";

// Custom Discord icon component
const DiscordIcon = () => (
  <svg 
    width="24" 
    height="24" 
    viewBox="0 0 24 24" 
    fill="none" 
    xmlns="http://www.w3.org/2000/svg"
    stroke="currentColor"
  >
    <path d="M19.27 5.33C17.94 4.71 16.5 4.26 15 4C14.89 4.19 14.76 4.45 14.67 4.64C13.05 4.41 11.43 4.41 9.83 4.64C9.74 4.45 9.61 4.19 9.5 4C7.99 4.26 6.55 4.71 5.22 5.33C2.36 9.55 1.63 13.66 2 17.69C3.77 19.04 5.5 19.85 7.21 20.37C7.58 19.87 7.91 19.33 8.18 18.77C7.45 18.49 6.76 18.14 6.11 17.72C6.23 17.63 6.34 17.53 6.45 17.43C9.67 18.89 13.22 18.89 16.4 17.43C16.51 17.53 16.62 17.63 16.74 17.72C16.08 18.14 15.39 18.49 14.66 18.77C14.93 19.33 15.25 19.87 15.63 20.37C17.34 19.85 19.07 19.04 20.84 17.69C21.27 13.06 20.1 9 19.27 5.33ZM8.56 15.13C7.5 15.13 6.65 14.17 6.65 13C6.65 11.83 7.5 10.87 8.56 10.87C9.63 10.87 10.49 11.82 10.48 13C10.47 14.17 9.62 15.13 8.56 15.13ZM15.44 15.13C14.38 15.13 13.53 14.17 13.53 13C13.53 11.83 14.38 10.87 15.44 10.87C16.51 10.87 17.37 11.82 17.36 13C17.35 14.17 16.5 15.13 15.44 15.13Z" 
      fill="currentColor"
    />
  </svg>
);

export function FeaturesSection() {
  const { scrollToNext } = useScrollTo();

  const features = [
    {
      Icon: Wallet,
      title: "Phantom Wallet Integration",
      description: "Seamlessly connect with Phantom Wallet for secure Solana transactions and payments."
    },
    {
      Icon: DiscordIcon,
      title: "Discord Authentication",
      description: "Use Discord OAuth for easy user authentication and automatic role management."
    },
    {
      Icon: Repeat,
      title: "Subscription Management",
      description: "Manage multiple subscription tiers with automated payments and role assignments."
    },
    {
      Icon: LayoutDashboard,
      title: "Admin Dashboard",
      description: "Comprehensive admin panel to manage users, subscriptions, and payment history."
    },
    {
      Icon: Smartphone,
      title: "Responsive Design",
      description: "Optimized experience across all devices with fast loading and smooth animations."
    },
    {
      Icon: ShieldCheck,
      title: "Secure Transactions",
      description: "End-to-end encryption and secure wallet connections for safe payment processing."
    }
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 40, scale: 0.9 },
    show: { 
      opacity: 1, 
      y: 0, 
      scale: 1, 
      transition: { 
        type: "spring", 
        stiffness: 100, 
        damping: 10, 
        duration: 0.7 
      } 
    }
  };

  return (
    <section id="features" className="relative min-h-screen flex items-center bg-[#121212]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">Powerful <span className="text-[#14F195]">Features</span></h2>
          <p className="text-gray-400 max-w-2xl mx-auto">Integrate Solana payments, Discord authentication and subscription management in one seamless platform.</p>
        </motion.div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          transition={{ staggerChildren: 0.15 }}
        >
          {features.map((feature, index) => (
            <motion.div 
              key={index} 
              className="p-6 rounded-xl card-gradient hover:translate-y-[-8px] hover:shadow-lg hover:shadow-[#14F195]/20 transition-all duration-300"
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.98 }}
              variants={item}
            >
              <div className="w-12 h-12 bg-[#14F195]/20 rounded-lg flex items-center justify-center mb-4">
                <feature.Icon className="w-6 h-6 text-[#14F195]" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </motion.div>
          ))}
        </motion.div>
        
        <motion.div 
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <a href="#demo" className="inline-flex items-center text-[#14F195] hover:text-[#14F195]/80 transition-colors">
            <span className="mr-2">See how it works</span>
            <svg 
              className="w-4 h-4" 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <line x1="5" y1="12" x2="19" y2="12"></line>
              <polyline points="12 5 19 12 12 19"></polyline>
            </svg>
          </a>
        </motion.div>
      </div>
      
      <div className="section-divider animate-bounce">
        <button 
          onClick={() => scrollToNext("features")}
          aria-label="Scroll to pricing section"
          className="focus:outline-none"
        >
          <svg 
            className="w-6 h-6 text-[#14F195]/80 hover:text-[#14F195] transition-colors" 
            xmlns="http://www.w3.org/2000/svg" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
          >
            <line x1="12" y1="5" x2="12" y2="19"></line>
            <polyline points="19 12 12 19 5 12"></polyline>
          </svg>
        </button>
      </div>
    </section>
  );
}

export default FeaturesSection;
