import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function Documentation() {
  return (
    <div className="min-h-screen bg-[#121212] text-white">
      <NavBar />
      
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 pt-32 pb-24">
        <div className="max-w-5xl mx-auto">
          <h1 className="text-4xl font-bold mb-6">Documentation</h1>
          <p className="text-xl text-gray-400 mb-12">
            Learn how to use the Trial Junkies platform to automate your free trials
          </p>
          
          <Tabs defaultValue="overview" className="space-y-8">
            <TabsList className="bg-[#1E1E1E] border border-white/10 flex flex-wrap justify-start">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="agents">AI Agents</TabsTrigger>
              <TabsTrigger value="identity">Virtual Identities</TabsTrigger>
              <TabsTrigger value="cards">Virtual Cards</TabsTrigger>
              <TabsTrigger value="api">API Reference</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview">
              <Card className="bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>Trial Junkies Platform Overview</CardTitle>
                  <CardDescription>
                    Understand how our system works and how to use it effectively
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6 text-gray-300">
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-white">What is Trial Junkies?</h3>
                    <p>
                      Trial Junkies is an advanced platform that uses AI agents to automate the creation of free trials for various subscription services. 
                      Instead of paying for multiple subscriptions or manually creating new trial accounts, our system handles everything automatically for you.
                    </p>
                    
                    <div className="p-4 bg-black/30 rounded-md border border-white/10">
                      <h4 className="text-lg font-medium text-[#14F195] mb-2">Key Features</h4>
                      <ul className="list-disc pl-5 space-y-2">
                        <li>AI-powered trial creation for popular subscription services</li>
                        <li>Virtual identity generation to avoid detection</li>
                        <li>Temporary email services integration</li>
                        <li>Virtual cards for payment verification</li>
                        <li>Discord integration for notifications</li>
                        <li>API access for enterprise users</li>
                      </ul>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-white">How It Works</h3>
                    <p>
                      The Trial Junkies platform uses a combination of AI, automation, and virtual resources to create legitimate
                      free trial accounts on subscription services. Here's the basic workflow:
                    </p>
                    
                    <ol className="list-decimal pl-5 space-y-3">
                      <li>
                        <strong className="text-white">Request Creation:</strong> You specify which service you want a free trial for
                      </li>
                      <li>
                        <strong className="text-white">AI Analysis:</strong> Our AI agent analyzes the target website and identifies the requirements for sign-up
                      </li>
                      <li>
                        <strong className="text-white">Identity Selection:</strong> The system selects or creates a virtual identity profile to use
                      </li>
                      <li>
                        <strong className="text-white">Email Verification:</strong> A temporary email address is created and monitored for verification
                      </li>
                      <li>
                        <strong className="text-white">Payment Method:</strong> For trials requiring payment verification, a virtual card is provisioned
                      </li>
                      <li>
                        <strong className="text-white">Account Creation:</strong> The AI agent completes the sign-up process with the prepared credentials
                      </li>
                      <li>
                        <strong className="text-white">Notification:</strong> You receive the completed trial details in your dashboard and Discord (if connected)
                      </li>
                    </ol>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-white">Subscription Tiers</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-white mb-2">Casual User</h4>
                        <ul className="text-sm space-y-1">
                          <li>5 Automated Trials per Month</li>
                          <li>Basic Email Verification</li>
                          <li>Single identity profile</li>
                          <li>Discord Basic Role</li>
                        </ul>
                      </div>
                      
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-white mb-2">Junkie Mode</h4>
                        <ul className="text-sm space-y-1">
                          <li>25 Automated Trials per Month</li>
                          <li>Email & Phone Verification</li>
                          <li>Up to 5 Identity Profiles</li>
                          <li>Basic Virtual Cards</li>
                          <li>Discord Pro Role</li>
                        </ul>
                      </div>
                      
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-white mb-2">Overdose Plan</h4>
                        <ul className="text-sm space-y-1">
                          <li>Unlimited Automated Trials</li>
                          <li>Advanced Verification Methods</li>
                          <li>Unlimited Identity Profiles</li>
                          <li>Premium Virtual Cards</li>
                          <li>Custom Website Targeting</li>
                          <li>API Access</li>
                          <li>Discord Enterprise Role</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 pt-4">
                    <h3 className="text-xl font-medium text-white">Getting Started</h3>
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Sign up for an account on Trial Junkies</li>
                      <li>Subscribe to one of our membership tiers</li>
                      <li>Connect your Phantom wallet for payment processing</li>
                      <li>Create at least one virtual identity profile</li>
                      <li>Request your first automated trial from the dashboard</li>
                      <li>Optional: Connect your Discord account for notifications</li>
                    </ol>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="agents">
              <Card className="bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>AI Agents</CardTitle>
                  <CardDescription>
                    How our autonomous AI agents create and manage free trials
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6 text-gray-300">
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-white">AI Agent Architecture</h3>
                    <p>
                      The Trial Junkies platform employs advanced AI agents built on large language models and reinforcement learning.
                      These agents are trained to navigate websites, complete forms, solve CAPTCHAs, and handle verification processes.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-[#14F195] mb-2">Agent Capabilities</h4>
                        <ul className="list-disc pl-5 space-y-2">
                          <li><strong>Website Analysis:</strong> Analyze sign-up flows and requirements</li>
                          <li><strong>Form Completion:</strong> Automatically fill out registration forms</li>
                          <li><strong>CAPTCHA Solving:</strong> Bypass security checks and verifications</li>
                          <li><strong>Email Monitoring:</strong> Check temporary email for verification links</li>
                          <li><strong>Data Extraction:</strong> Retrieve login credentials and account details</li>
                          <li><strong>Error Recovery:</strong> Handle unexpected roadblocks during sign-up</li>
                        </ul>
                      </div>
                      
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-[#14F195] mb-2">Technical Components</h4>
                        <ul className="list-disc pl-5 space-y-2">
                          <li><strong>Browser Automation:</strong> Headless browser technology</li>
                          <li><strong>Computer Vision:</strong> For analyzing visual elements</li>
                          <li><strong>NLP Models:</strong> To understand website content and instructions</li>
                          <li><strong>Temporary Email API:</strong> Integration with disposable email services</li>
                          <li><strong>Virtual Card API:</strong> For payment method verification</li>
                          <li><strong>Anti-Detection:</strong> Browser fingerprinting protection</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mt-6">
                    <h3 className="text-xl font-medium text-white">Agent Workflow</h3>
                    <p>
                      When you request a new automated trial, our system follows these steps:
                    </p>
                    
                    <div className="relative space-y-8 before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-white/20 before:to-transparent">
                      <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-[#14F195] text-black group-[.is-active]:bg-[#14F195] shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                          1
                        </div>
                        <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-lg bg-black/30 border border-white/10">
                          <h4 className="text-white font-medium">Request Processing</h4>
                          <p className="text-sm mt-1">
                            The agent receives your trial request and prioritizes it in the queue based on your subscription tier.
                          </p>
                        </div>
                      </div>
                      
                      <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-[#14F195] text-black group-[.is-active]:bg-[#14F195] shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                          2
                        </div>
                        <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-lg bg-black/30 border border-white/10">
                          <h4 className="text-white font-medium">Website Research</h4>
                          <p className="text-sm mt-1">
                            The AI analyzes the target website to understand its sign-up flow, requirements, and potential obstacles.
                          </p>
                        </div>
                      </div>
                      
                      <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-[#14F195] text-black group-[.is-active]:bg-[#14F195] shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                          3
                        </div>
                        <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-lg bg-black/30 border border-white/10">
                          <h4 className="text-white font-medium">Resource Provisioning</h4>
                          <p className="text-sm mt-1">
                            The system selects or creates the necessary resources: identity profile, email address, and if needed, a virtual card.
                          </p>
                        </div>
                      </div>
                      
                      <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-[#14F195] text-black group-[.is-active]:bg-[#14F195] shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                          4
                        </div>
                        <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-lg bg-black/30 border border-white/10">
                          <h4 className="text-white font-medium">Trial Creation</h4>
                          <p className="text-sm mt-1">
                            The agent navigates to the target website and completes the sign-up process, handling forms, verification, and payment details.
                          </p>
                        </div>
                      </div>
                      
                      <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-[#14F195] text-black group-[.is-active]:bg-[#14F195] shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                          5
                        </div>
                        <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-lg bg-black/30 border border-white/10">
                          <h4 className="text-white font-medium">Verification Handling</h4>
                          <p className="text-sm mt-1">
                            The agent monitors the temporary email account for verification links and completes any necessary verification steps.
                          </p>
                        </div>
                      </div>
                      
                      <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                        <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white/10 bg-[#14F195] text-black group-[.is-active]:bg-[#14F195] shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                          6
                        </div>
                        <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] p-4 rounded-lg bg-black/30 border border-white/10">
                          <h4 className="text-white font-medium">Delivery</h4>
                          <p className="text-sm mt-1">
                            Once the trial is successfully created, the agent securely stores the credentials and delivers them to your dashboard and Discord.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mt-8">
                    <h3 className="text-xl font-medium text-white">Creating a Trial Request</h3>
                    <p>
                      To create a new automated trial, follow these steps:
                    </p>
                    
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Navigate to the "Automated Trials" tab in your dashboard</li>
                      <li>Click the "Create New Trial" button</li>
                      <li>Enter the service name (e.g., Netflix, Spotify)</li>
                      <li>Provide the website URL</li>
                      <li>Select the desired trial duration</li>
                      <li>Add any special notes or requirements (optional)</li>
                      <li>Submit the request</li>
                    </ol>
                    
                    <div className="p-4 bg-yellow-900/20 border border-yellow-700/30 rounded-md mt-4">
                      <h4 className="flex items-center text-yellow-500 font-medium mb-2">
                        <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"></path>
                        </svg>
                        Important Note
                      </h4>
                      <p className="text-sm text-gray-300">
                        Processing times vary based on complexity and queue status. Basic trials typically take 5-15 minutes, 
                        while more complex trials with advanced verification may take up to an hour.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="identity">
              <Card className="bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>Virtual Identities</CardTitle>
                  <CardDescription>
                    Creating and managing virtual identity profiles
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6 text-gray-300">
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-white">What Are Virtual Identities?</h3>
                    <p>
                      Virtual identities are sets of personal information used by our AI agents to create accounts on target websites. 
                      These identities include names, addresses, and other details needed for registration processes. Using different 
                      identities for different trials helps avoid detection and increases success rates.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-[#14F195] mb-2">Identity Components</h4>
                        <ul className="list-disc pl-5 space-y-2">
                          <li><strong>Profile Name:</strong> A label to identify this identity</li>
                          <li><strong>Personal Details:</strong> First name, last name, date of birth</li>
                          <li><strong>Contact Information:</strong> Email address, phone number</li>
                          <li><strong>Address Details:</strong> Street address, city, state, ZIP code, country</li>
                        </ul>
                      </div>
                      
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-[#14F195] mb-2">Identity Usage</h4>
                        <p className="mb-2">Identities are used in different scenarios:</p>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Creating new accounts on subscription services</li>
                          <li>Verifying payment methods</li>
                          <li>Completing profile information</li>
                          <li>Passing verification checks</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mt-6">
                    <h3 className="text-xl font-medium text-white">Managing Virtual Identities</h3>
                    <p>
                      Each subscription tier allows a different number of identity profiles:
                    </p>
                    
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>Casual User:</strong> 1 identity profile</li>
                      <li><strong>Junkie Mode:</strong> Up to 5 identity profiles</li>
                      <li><strong>Overdose Plan:</strong> Unlimited identity profiles</li>
                    </ul>
                    
                    <p className="mt-4">
                      To create and manage your virtual identities, follow these steps:
                    </p>
                    
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Navigate to the "Identity Profiles" tab in your dashboard</li>
                      <li>Click "Create New Identity" to add a new profile</li>
                      <li>Fill out the required information</li>
                      <li>Click "Create Identity" to save</li>
                    </ol>
                    
                    <p className="mt-2">
                      You can edit existing profiles by clicking the "Edit" button on any identity card.
                    </p>
                    
                    <div className="p-4 bg-green-900/20 border border-green-700/30 rounded-md mt-4">
                      <h4 className="flex items-center text-green-500 font-medium mb-2">
                        <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                        </svg>
                        Best Practice
                      </h4>
                      <p className="text-sm text-gray-300">
                        Create multiple identity profiles with different details for better success rates. Use realistic 
                        information that doesn't match your actual personal details. Our system automatically generates 
                        compliant and realistic identity information if you leave fields blank.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="cards">
              <Card className="bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>Virtual Cards</CardTitle>
                  <CardDescription>
                    Using virtual cards for trial verification
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6 text-gray-300">
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-white">What Are Virtual Cards?</h3>
                    <p>
                      Virtual cards are temporary payment methods used for verifying free trials that require a payment method.
                      These cards function like real credit cards but have spending limits and expiration dates specifically
                      designed for free trial verification without risk of unexpected charges.
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-[#14F195] mb-2">Virtual Card Features</h4>
                        <ul className="list-disc pl-5 space-y-2">
                          <li><strong>Zero Liability:</strong> Cards are configured to decline charges beyond the authorization</li>
                          <li><strong>Pre-set Expiration:</strong> Automatically expire before trial ends</li>
                          <li><strong>Compatible Format:</strong> Works with major subscription services</li>
                          <li><strong>Billing Address Support:</strong> Includes billing info matching your virtual identity</li>
                        </ul>
                      </div>
                      
                      <div className="p-4 bg-black/30 rounded-md border border-white/10">
                        <h4 className="text-lg font-medium text-[#14F195] mb-2">Card Types</h4>
                        <ul className="list-disc pl-5 space-y-2">
                          <li>
                            <strong>Basic Virtual Cards:</strong> Available with Pro tier subscription
                            <p className="text-xs mt-1">Limited monthly cards, basic verification support</p>
                          </li>
                          <li>
                            <strong>Premium Virtual Cards:</strong> Available with Enterprise tier subscription
                            <p className="text-xs mt-1">Unlimited cards, advanced verification support, higher success rate</p>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mt-6">
                    <h3 className="text-xl font-medium text-white">Managing Virtual Cards</h3>
                    <p>
                      Virtual cards are available for Pro and Enterprise subscription tiers only.
                      To create and manage your virtual cards:
                    </p>
                    
                    <ol className="list-decimal pl-5 space-y-2">
                      <li>Navigate to the "Virtual Cards" tab in your dashboard</li>
                      <li>Click "Create New Card" to generate a new virtual card</li>
                      <li>Fill out the required information (name, billing address)</li>
                      <li>Click "Create Card" to generate the virtual card</li>
                      <li>Your new card will appear in the cards list with its details</li>
                    </ol>
                    
                    <div className="p-4 bg-blue-900/20 border border-blue-700/30 rounded-md mt-4">
                      <h4 className="flex items-center text-blue-500 font-medium mb-2">
                        <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"></path>
                        </svg>
                        How It Works
                      </h4>
                      <p className="text-sm text-gray-300">
                        When creating an automated trial, the system automatically selects an appropriate virtual card from your
                        collection. The AI agent uses this card during the sign-up process for payment verification. These cards
                        are configured to pass initial authorization checks but decline actual charges, ensuring you never get billed.
                      </p>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mt-6">
                    <h3 className="text-xl font-medium text-white">Card Security</h3>
                    <p>
                      Our virtual card system is designed with security as a priority:
                    </p>
                    
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Cards are single-use and tied to specific trials</li>
                      <li>Card details are encrypted in our database</li>
                      <li>Automatic deactivation after trial creation</li>
                      <li>Zero-balance configuration prevents unexpected charges</li>
                      <li>Expiration dates set to occur before free trial period ends</li>
                      <li>No connection to your real financial accounts</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="api">
              <Card className="bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>API Reference</CardTitle>
                  <CardDescription>
                    Enterprise API for programmatic access to the Trial Junkies platform
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6 text-gray-300">
                  <div className="space-y-4">
                    <h3 className="text-xl font-medium text-white">API Overview</h3>
                    <p>
                      The Trial Junkies API allows Enterprise subscribers to programmatically create and manage automated trials,
                      virtual identities, and virtual cards. This API follows RESTful principles and uses JSON for data exchange.
                    </p>
                    
                    <div className="p-4 bg-black/30 rounded-md border border-white/10">
                      <h4 className="text-lg font-medium text-[#14F195] mb-2">API Access</h4>
                      <p className="mb-4">
                        API access is available exclusively to subscribers of the Overdose Plan (Enterprise tier).
                        To get started with the API:
                      </p>
                      <ol className="list-decimal pl-5 space-y-2">
                        <li>Navigate to the "API Access" tab in your dashboard</li>
                        <li>Click "Generate API Key" to create your unique API key</li>
                        <li>Store this key securely - it won't be displayed again</li>
                        <li>Use this key in the Authorization header for all API requests</li>
                      </ol>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mt-6">
                    <h3 className="text-xl font-medium text-white">Authentication</h3>
                    <p>
                      All API requests must include your API key in the Authorization header:
                    </p>
                    
                    <div className="bg-black font-mono text-sm p-4 rounded-md overflow-x-auto">
                      <pre>Authorization: Bearer YOUR_API_KEY</pre>
                    </div>
                    
                    <p className="mt-4">Example request using curl:</p>
                    
                    <div className="bg-black font-mono text-sm p-4 rounded-md overflow-x-auto">
                      <pre>{`curl -X GET "https://api.trialjunkies.com/v1/trials" \\
  -H "Authorization: Bearer tj_your_api_key_here"`}</pre>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mt-6">
                    <h3 className="text-xl font-medium text-white">API Endpoints</h3>
                    
                    <div className="space-y-6">
                      <div>
                        <h4 className="text-lg font-medium text-[#14F195] flex items-center">
                          <span className="bg-green-900/50 text-green-500 px-2 py-1 text-xs font-mono rounded mr-2">GET</span>
                          Automated Trials
                        </h4>
                        <div className="mt-2">
                          <p className="font-mono text-sm mb-2">/v1/trials</p>
                          <p>Retrieves a list of all your automated trials</p>
                          
                          <div className="mt-3 space-y-2">
                            <p className="font-medium text-white">Query Parameters:</p>
                            <ul className="list-disc pl-5 space-y-1 text-sm">
                              <li><code className="bg-black/50 px-1 rounded">status</code> - Filter by trial status (queued, in_progress, completed, failed)</li>
                              <li><code className="bg-black/50 px-1 rounded">limit</code> - Number of results to return (default: 20, max: 100)</li>
                              <li><code className="bg-black/50 px-1 rounded">offset</code> - Pagination offset (default: 0)</li>
                            </ul>
                          </div>
                          
                          <div className="mt-3">
                            <p className="font-medium text-white">Example Response:</p>
                            <div className="bg-black font-mono text-xs p-3 rounded-md mt-2 overflow-x-auto">
                              <pre>{`{
  "trials": [
    {
      "id": 12345,
      "user_id": 789,
      "target_website": "https://netflix.com",
      "service_name": "Netflix",
      "status": "completed",
      "trial_duration_days": 30,
      "created_at": "2025-03-15T10:30:00Z",
      "completed_at": "2025-03-15T10:45:22Z",
      "credentials": {
        "email": "temp-email@trialjunkies.io",
        "password": "securepass123"
      }
    },
    // More trials...
  ],
  "total": 42,
  "limit": 20,
  "offset": 0
}`}</pre>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-lg font-medium text-[#14F195] flex items-center">
                          <span className="bg-blue-900/50 text-blue-500 px-2 py-1 text-xs font-mono rounded mr-2">POST</span>
                          Create Trial
                        </h4>
                        <div className="mt-2">
                          <p className="font-mono text-sm mb-2">/v1/trials</p>
                          <p>Creates a new automated trial request</p>
                          
                          <div className="mt-3">
                            <p className="font-medium text-white">Request Body:</p>
                            <div className="bg-black font-mono text-xs p-3 rounded-md mt-2 overflow-x-auto">
                              <pre>{`{
  "target_website": "https://streaming-service.com",
  "service_name": "Streaming Service",
  "trial_duration_days": 14,
  "notes": "Optional notes about this request"
}`}</pre>
                            </div>
                          </div>
                          
                          <div className="mt-3">
                            <p className="font-medium text-white">Example Response:</p>
                            <div className="bg-black font-mono text-xs p-3 rounded-md mt-2 overflow-x-auto">
                              <pre>{`{
  "trial": {
    "id": 12346,
    "user_id": 789,
    "target_website": "https://streaming-service.com",
    "service_name": "Streaming Service",
    "status": "queued",
    "trial_duration_days": 14,
    "created_at": "2025-03-28T14:22:10Z",
    "notes": "Optional notes about this request"
  }
}`}</pre>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-lg font-medium text-[#14F195] flex items-center">
                          <span className="bg-green-900/50 text-green-500 px-2 py-1 text-xs font-mono rounded mr-2">GET</span>
                          Virtual Identities
                        </h4>
                        <div className="mt-2">
                          <p className="font-mono text-sm mb-2">/v1/identities</p>
                          <p>Retrieves a list of your virtual identity profiles</p>
                          
                          <div className="mt-3">
                            <p className="font-medium text-white">Example Response:</p>
                            <div className="bg-black font-mono text-xs p-3 rounded-md mt-2 overflow-x-auto">
                              <pre>{`{
  "identities": [
    {
      "id": 567,
      "user_id": 789,
      "profile_name": "Work Profile",
      "first_name": "John",
      "last_name": "Smith",
      "email": "jsmith@example.com",
      "phone_number": "+15551234567",
      "date_of_birth": "1985-06-15",
      "address": "123 Main St",
      "city": "New York",
      "state": "NY",
      "zip_code": "10001",
      "country": "USA",
      "created_at": "2025-02-10T08:15:30Z"
    },
    // More identities...
  ]
}`}</pre>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-lg font-medium text-[#14F195] flex items-center">
                          <span className="bg-blue-900/50 text-blue-500 px-2 py-1 text-xs font-mono rounded mr-2">POST</span>
                          Create Identity
                        </h4>
                        <div className="mt-2">
                          <p className="font-mono text-sm mb-2">/v1/identities</p>
                          <p>Creates a new virtual identity profile</p>
                          
                          <div className="mt-3">
                            <p className="font-medium text-white">Request Body:</p>
                            <div className="bg-black font-mono text-xs p-3 rounded-md mt-2 overflow-x-auto">
                              <pre>{`{
  "profile_name": "Gaming Profile",
  "first_name": "Jane",
  "last_name": "Doe",
  "email": "jane.doe@example.com",
  "phone_number": "+15557890123",
  "date_of_birth": "1990-03-20",
  "address": "456 Park Ave",
  "city": "Chicago",
  "state": "IL",
  "zip_code": "60601",
  "country": "USA"
}`}</pre>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-lg font-medium text-[#14F195] flex items-center">
                          <span className="bg-green-900/50 text-green-500 px-2 py-1 text-xs font-mono rounded mr-2">GET</span>
                          Virtual Cards
                        </h4>
                        <div className="mt-2">
                          <p className="font-mono text-sm mb-2">/v1/cards</p>
                          <p>Retrieves a list of your virtual cards</p>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-lg font-medium text-[#14F195] flex items-center">
                          <span className="bg-blue-900/50 text-blue-500 px-2 py-1 text-xs font-mono rounded mr-2">POST</span>
                          Create Card
                        </h4>
                        <div className="mt-2">
                          <p className="font-mono text-sm mb-2">/v1/cards</p>
                          <p>Creates a new virtual card</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mt-8">
                    <h3 className="text-xl font-medium text-white">Rate Limits</h3>
                    <p>
                      The API has the following rate limits for Enterprise subscribers:
                    </p>
                    
                    <ul className="list-disc pl-5 space-y-2">
                      <li>100 requests per minute</li>
                      <li>5,000 requests per day</li>
                      <li>100 trial creation requests per day</li>
                    </ul>
                    
                    <p className="mt-2">
                      Rate limit headers are included in all API responses:
                    </p>
                    
                    <div className="bg-black font-mono text-sm p-4 rounded-md overflow-x-auto">
                      <pre>{`X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1616357640`}</pre>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-900/50 border border-gray-700/30 rounded-md mt-6">
                    <h4 className="text-lg font-medium text-white mb-2">Need More Information?</h4>
                    <p className="text-sm">
                      For the complete API documentation including all endpoints, parameters, and response schemas,
                      please visit our 
                      <a href="#" className="text-[#14F195] hover:underline ml-1">Developer Portal</a>.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}