import React from 'react';
import SetupWizard from '../components/SetupWizard';

const SetupPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/90 py-10">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold tracking-tight mb-4">Environment Setup</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Configure your environment settings with our One-Click Setup Wizard. 
            This will help you quickly set up Solana payments, verification services, and more.
          </p>
        </div>
        
        <SetupWizard />
      </div>
    </div>
  );
};

export default SetupPage;