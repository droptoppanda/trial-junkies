import React, { useEffect, useState } from 'react';
import { useLocation, useRoute, useLocation as useWouterLocation } from 'wouter';
import { CryptoPayment } from '@/components/CryptoPayment';
import { Button } from "@/components/ui/button";
import { CheckIcon, ArrowLeftIcon, WalletIcon } from "lucide-react";
import NavBar from '@/components/NavBar';
import { queryClient } from '@/lib/queryClient';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Footer } from '@/components/Footer';

export default function Payment() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute('/payment/:tier');
  const tier = params?.tier || 'basic';
  const { toast } = useToast();
  const [isSuccess, setIsSuccess] = useState(false);
  
  // Get subscription tier data
  const { data: tierData } = useQuery({
    queryKey: ['/api/subscriptions/tiers'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/subscriptions/tiers');
      if (!res.ok) throw new Error('Failed to fetch subscription tiers');
      return res.json();
    }
  });

  // Check authentication status
  const { data: authData, isLoading: authLoading } = useQuery({
    queryKey: ['/api/auth/status'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/auth/status');
      if (!res.ok) throw new Error('Failed to check authentication status');
      return res.json();
    }
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && authData && !authData.authenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to subscribe to a plan",
        variant: "destructive",
      });
      setLocation("/login");
    }
  }, [authLoading, authData, setLocation, toast]);

  // Handle payment success
  const handlePaymentSuccess = (transactionId: string) => {
    // Subscribe the user to the selected plan
    const subscribeUser = async () => {
      try {
        const response = await apiRequest('POST', '/api/subscriptions/subscribe', {
          tier,
          payment_method: 'solana',
          transaction_id: transactionId,
          status: 'active',
          start_date: new Date().toISOString(),
          end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
        });
        
        if (!response.ok) {
          throw new Error('Failed to activate subscription');
        }
        
        // Invalidate queries to refresh data
        queryClient.invalidateQueries({ queryKey: ["/api/subscriptions/active"] });
        setIsSuccess(true);
      } catch (error) {
        console.error('Error activating subscription:', error);
        toast({
          title: "Subscription Error",
          description: "Your payment was processed, but we couldn't activate your subscription. Please contact support.",
          variant: "destructive",
        });
      }
    };
    
    subscribeUser();
  };

  const handleGoToDashboard = () => {
    setLocation("/dashboard");
  };

  const handleGoBack = () => {
    setLocation("/#pricing");
  };

  // If tier doesn't exist or is invalid, redirect to pricing
  useEffect(() => {
    if (tierData && !tierData[tier]) {
      toast({
        title: "Invalid Subscription Tier",
        description: "The selected subscription tier doesn't exist",
        variant: "destructive",
      });
      setLocation("/#pricing");
    }
  }, [tierData, tier, setLocation, toast]);

  // Loading state
  if (authLoading || !tierData) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <NavBar />
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
        <Footer />
      </div>
    );
  }

  // Successfully subscribed state
  if (isSuccess) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <NavBar />
        <div className="flex-1 container max-w-4xl mx-auto py-12 px-4 flex flex-col items-center justify-center space-y-8">
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-4">
            <CheckIcon className="w-10 h-10 text-green-500" />
          </div>
          
          <h1 className="text-3xl font-bold text-center">Subscription Activated!</h1>
          
          <p className="text-lg text-center text-muted-foreground max-w-lg">
            Thank you for subscribing to our {tier.charAt(0).toUpperCase() + tier.slice(1)} plan. 
            Your subscription is now active and you can start using all the features.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 mt-8">
            <Button 
              onClick={handleGoToDashboard} 
              className="bg-[#14F195] hover:bg-[#14F195]/90 text-black font-semibold"
            >
              Go to Dashboard
            </Button>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  // Main payment page
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <NavBar />
      <div className="flex-1 container max-w-4xl mx-auto py-12 px-4">
        <button 
          className="mb-8 flex items-center gap-2 hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2 text-sm font-medium" 
          onClick={handleGoBack}
        >
          <ArrowLeftIcon className="w-4 h-4" />
          Back to Pricing
        </button>
        
        <div className="mb-10">
          <h1 className="text-3xl font-bold mb-2">Subscribe to {tier.charAt(0).toUpperCase() + tier.slice(1)} Plan</h1>
          <p className="text-muted-foreground">Complete your payment to activate your subscription</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8">
          <div className="md:col-span-3">
            <CryptoPayment 
              amount={parseFloat(tierData[tier]?.price || "0.1")}
              onSuccess={handlePaymentSuccess}
              onCancel={handleGoBack}
            />
            
            <div className="mt-8 p-4 border border-[#14F195]/20 rounded-lg bg-card/50">
              <h3 className="font-medium flex items-center gap-2 mb-2">
                <WalletIcon className="w-4 h-4 text-[#14F195]" />
                Payment Information
              </h3>
              <p className="text-sm text-muted-foreground">
                Payments are processed securely via the Solana blockchain.
                Make sure you have enough SOL in your wallet to complete this transaction.
              </p>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <div className="sticky top-4 p-6 border border-[#14F195]/20 rounded-lg bg-card">
              <h3 className="text-lg font-semibold mb-4">Order Summary</h3>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Plan</span>
                  <span className="font-medium">{tier.charAt(0).toUpperCase() + tier.slice(1)}</span>
                </div>
                
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Duration</span>
                  <span className="font-medium">30 Days</span>
                </div>
                
                <div className="border-t border-border pt-4 flex justify-between">
                  <span className="font-medium">Total</span>
                  <span className="font-bold">{tierData[tier]?.price || "0.1"} SOL</span>
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="font-medium mb-2">What's included:</h4>
                <ul className="space-y-2">
                  {tierData[tier]?.features.map((feature: string, index: number) => (
                    <li key={index} className="flex items-start gap-2 text-sm">
                      <CheckIcon className="w-4 h-4 text-[#14F195] mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}