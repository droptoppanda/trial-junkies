import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import AdminLayout from "@/components/admin/AdminLayout";
import AdminDashboard from "@/components/admin/Dashboard";
import UsersTable from "@/components/admin/UsersTable";
import SubscriptionsTable from "@/components/admin/SubscriptionsTable";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Admin() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();

  // Check if user is authenticated and is an admin
  const { data: authData, isLoading: isAuthLoading } = useQuery({
    queryKey: ['/api/auth/status'],
  });

  // Redirect to home if not authenticated or not an admin
  useEffect(() => {
    if (!isAuthLoading && authData) {
      if (!authData.authenticated) {
        toast({
          title: "Authentication Required",
          description: "Please log in to access the admin panel.",
          variant: "destructive",
        });
        setLocation("/");
      } else if (!authData.user.is_admin) {
        toast({
          title: "Access Denied",
          description: "You do not have permission to access the admin panel.",
          variant: "destructive",
        });
        setLocation("/dashboard");
      }
    }
  }, [authData, isAuthLoading, setLocation, toast]);

  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-[#121212] text-white flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#8A2BE2]" />
      </div>
    );
  }

  if (!authData?.authenticated || !authData.user.is_admin) {
    return null;
  }

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-gray-400 mt-2">
          Manage users, subscriptions, and platform settings
        </p>
      </div>
      
      <Tabs defaultValue="dashboard" className="space-y-6">
        <TabsList className="bg-[#1E1E1E] border border-white/10">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
        </TabsList>
        
        <TabsContent value="dashboard">
          <AdminDashboard />
        </TabsContent>
        
        <TabsContent value="users">
          <UsersTable />
        </TabsContent>
        
        <TabsContent value="subscriptions">
          <SubscriptionsTable />
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
}
