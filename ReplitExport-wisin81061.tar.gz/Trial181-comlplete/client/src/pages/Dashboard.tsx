import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import NavBar from "@/components/NavBar";
import Footer from "@/components/Footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "@/lib/wallet";
import { useDiscord } from "@/lib/discord";
import SubscriptionCard from "@/components/dashboard/SubscriptionCard";
import AccountInfo from "@/components/dashboard/AccountInfo";
import ConnectDiscord from "@/components/dashboard/ConnectDiscord";
import TransactionHistory from "@/components/dashboard/TransactionHistory";
import TrialsManagement from "@/components/dashboard/TrialsManagement";
import IdentityProfiles from "@/components/dashboard/IdentityProfiles";
import VirtualCards from "@/components/dashboard/VirtualCards";
import ApiKeyManager from "@/components/dashboard/ApiKeyManager";
import RenewalReminders from "@/components/dashboard/RenewalReminders";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const [location, setLocation] = useLocation();
  const [, params] = useRoute("/dashboard");
  const { toast } = useToast();
  const { connected, publicKey, connect } = useWallet();
  const { isAuthenticated: discordConnected, discordUsername, getAuthUrl, handleCallback } = useDiscord();
  const [activeTab, setActiveTab] = useState("overview");

  // Check if user is authenticated
  const { data: authData, isLoading: isAuthLoading } = useQuery({
    queryKey: ['/api/auth/status'],
  });

  // Get user's active subscription
  const { data: subscriptionData, isLoading: isSubscriptionLoading } = useQuery({
    queryKey: ['/api/subscriptions/active'],
    enabled: authData?.authenticated,
  });
  
  // Get user's trials
  const { data: trialsData, isLoading: isTrialsLoading } = useQuery({
    queryKey: ['/api/trials'],
    enabled: authData?.authenticated,
  });

  // Parse Discord auth callback code from URL if present
  useEffect(() => {
    const url = new URL(window.location.href);
    const code = url.searchParams.get("code");

    if (code) {
      // Clean the URL
      window.history.replaceState({}, document.title, "/dashboard");

      // Handle Discord callback
      handleCallback(code);

      toast({
        title: "Discord Connected",
        description: "Your Discord account has been successfully linked.",
      });
    }
  }, [handleCallback, toast]);

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isAuthLoading && authData && !authData.authenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access the dashboard.",
        variant: "destructive",
      });
      setLocation("/");
    }
  }, [authData, isAuthLoading, setLocation, toast]);

  const handleConnectDiscord = () => {
    window.location.href = getAuthUrl();
  };

  const DiscordVerificationPlaceholder = () => (
    <div>
      <p>Email/Phone Verification (Implementation Pending)</p> 
      {/* Placeholder until full component is available */}
    </div>
  );


  if (isAuthLoading) {
    return (
      <div className="min-h-screen bg-[#121212] text-white flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#14F195]" />
      </div>
    );
  }

  if (!authData?.authenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-[#121212] text-white">
      <NavBar />

      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 pt-28">
        <div className="flex flex-col md:flex-row justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold">Dashboard</h1>
            <p className="text-gray-400 mt-2">
              Manage your subscription and account settings
            </p>
          </div>

          {!connected ? (
            <Button 
              onClick={connect}
              className="bg-[#14F195] hover:bg-[#14F195]/90 text-black mt-4 md:mt-0"
            >
              <svg 
                className="mr-2 h-4 w-4" 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <path d="M18 7v4c0 1.1-.9 2-2 2H4a2 2 0 01-2-2V7c0-1.1.9-2 2-2h12c1.1 0 2 .9 2 2z" />
                <path d="M16 21h2c1.1 0 2-.9 2-2v-5h-4v7z" />
                <path d="M10 21v-7H6v7" />
              </svg>
              Connect Wallet
            </Button>
          ) : (
            <div className="flex items-center mt-4 md:mt-0">
              <div className="bg-[#1E1E1E] px-4 py-2 rounded-md flex items-center">
                <span className="text-xs font-medium mr-2 text-[#14F195]">Connected:</span>
                <span className="text-sm">{publicKey?.slice(0, 6)}...{publicKey?.slice(-4)}</span>
              </div>
            </div>
          )}
        </div>

        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-[#1E1E1E] border border-white/10 flex flex-wrap">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="subscription">Subscription</TabsTrigger>
            <TabsTrigger value="trials">Automated Trials</TabsTrigger>
            <TabsTrigger value="identities">Identity Profiles</TabsTrigger>
            <TabsTrigger value="cards">Virtual Cards</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="api">API Access</TabsTrigger>
            <TabsTrigger value="account">Account</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="col-span-1 md:col-span-2 bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>Subscription Status</CardTitle>
                  <CardDescription>Your current subscription details</CardDescription>
                </CardHeader>
                <CardContent>
                  {isSubscriptionLoading ? (
                    <div className="flex justify-center py-6">
                      <Loader2 className="h-6 w-6 animate-spin text-[#14F195]" />
                    </div>
                  ) : subscriptionData?.subscription ? (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-400">Plan</p>
                          <p className="text-lg font-medium capitalize">{subscriptionData.subscription.tier}</p>
                        </div>
                        <div className="bg-[#14F195]/20 px-3 py-1 rounded-full">
                          <span className="text-[#14F195] text-sm font-medium">Active</span>
                        </div>
                      </div>

                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-400">Price</p>
                          <p className="text-lg font-medium">{subscriptionData.subscription.price} SOL/month</p>
                        </div>
                      </div>

                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-400">Next renewal</p>
                          <p className="text-lg font-medium">
                            {new Date(subscriptionData.subscription.end_date).toLocaleDateString()}
                          </p>
                        </div>
                      </div>

                      <Separator className="bg-white/10" />

                      <div className="flex justify-between items-center">
                        <div>
                          <p className="text-sm text-gray-400">Discord Role</p>
                          <p className="text-lg font-medium">
                            {discordConnected ? (
                              <span className="text-[#14F195]">Active</span>
                            ) : (
                              <span className="text-amber-400">Discord not connected</span>
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <p className="text-gray-400 mb-4">You don't have an active subscription</p>
                      <Button 
                        onClick={() => setActiveTab("subscription")}
                        className="bg-[#14F195] hover:bg-[#14F195]/90 text-black"
                      >
                        Choose a Plan
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>Connect Services</CardTitle>
                  <CardDescription>Link your accounts</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <span>Phantom Wallet</span>
                    </div>
                    <div>
                      {connected ? (
                        <div className="bg-[#14F195]/20 px-3 py-1 rounded-full">
                          <span className="text-[#14F195] text-xs">Connected</span>
                        </div>
                      ) : (
                        <Button 
                          onClick={connect} 
                          variant="outline" 
                          size="sm"
                          className="text-xs border-white/20"
                        >
                          Connect
                        </Button>
                      )}
                    </div>
                  </div>

                  <Separator className="bg-white/10" />

                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <img src="https://assets-global.website-files.com/6257adef93867e50d84d30e2/636e0a6cc3c481a15a141738_icon_clyde_white_RGB.png" alt="Discord" className="h-5 w-6 mr-3" />
                      <span>Discord</span>
                    </div>
                    <div>
                      {discordConnected ? (
                        <div className="bg-[#14F195]/20 px-3 py-1 rounded-full">
                          <span className="text-[#14F195] text-xs">Connected</span>
                        </div>
                      ) : (
                        <Button 
                          onClick={handleConnectDiscord}
                          variant="outline" 
                          size="sm"
                          className="text-xs border-white/20"
                        >
                          Connect
                        </Button>
                      )}
                    </div>
                  </div>
                  <Separator className="bg-white/10" />
                  <div>
                    <DiscordVerificationPlaceholder /> {/* Added Discord Verification Placeholder */}
                  </div>
                </CardContent>

                {discordConnected && (
                  <CardFooter className="border-t border-white/10 pt-4">
                    <p className="text-xs text-gray-400">
                      Logged in as <span className="text-white">{discordUsername}</span>
                    </p>
                  </CardFooter>
                )}
              </Card>
            </div>

            {/* Renewal Reminders Component */}
            <RenewalReminders subscriptionData={subscriptionData} trialsData={trialsData} />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>Recent Transactions</CardTitle>
                  <CardDescription>Your latest payment history</CardDescription>
                </CardHeader>
                <CardContent>
                  <TransactionHistory limit={3} />
                </CardContent>
                <CardFooter className="border-t border-white/10 pt-4">
                  <Button 
                    variant="link" 
                    onClick={() => setActiveTab("transactions")}
                    className="text-[#14F195] hover:text-[#14F195]/80 p-0"
                  >
                    View all transactions
                  </Button>
                </CardFooter>
              </Card>

              <Card className="bg-[#1E1E1E] border-white/10">
                <CardHeader>
                  <CardTitle>Automated Trials</CardTitle>
                  <CardDescription>AI-powered free trial automation</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!subscriptionData?.subscription ? (
                    <div className="text-center py-4">
                      <p className="text-gray-400 mb-4">Subscribe to access automated trials</p>
                      <Button 
                        onClick={() => setActiveTab("subscription")}
                        className="bg-[#14F195] hover:bg-[#14F195]/90 text-black"
                      >
                        Choose a Plan
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div className="flex justify-between items-center p-3 bg-black/30 rounded-md">
                        <div>
                          <p className="text-sm font-medium">Trial Creation</p>
                          <p className="text-xs text-gray-400">
                            {subscriptionData.subscription.tier === "basic" && "5 trials per month"}
                            {subscriptionData.subscription.tier === "pro" && "25 trials per month"}
                            {subscriptionData.subscription.tier === "enterprise" && "Unlimited trials"}
                          </p>
                        </div>
                        <Button 
                          onClick={() => setActiveTab("trials")}
                          size="sm"
                          className="bg-[#14F195] hover:bg-[#14F195]/90 text-black text-xs"
                        >
                          Create Trial
                        </Button>
                      </div>

                      <div className="flex justify-between items-center p-3 bg-black/30 rounded-md">
                        <div>
                          <p className="text-sm font-medium">Identity Profiles</p>
                          <p className="text-xs text-gray-400">
                            {subscriptionData.subscription.tier === "basic" && "1 identity profile"}
                            {subscriptionData.subscription.tier === "pro" && "Up to 5 profiles"}
                            {subscriptionData.subscription.tier === "enterprise" && "Unlimited profiles"}
                          </p>
                        </div>
                        <Button 
                          onClick={() => setActiveTab("identities")}
                          size="sm"
                          variant="outline"
                          className="border-[#14F195] text-[#14F195] hover:bg-[#14F195]/10 text-xs"
                        >
                          Manage
                        </Button>
                      </div>

                      {subscriptionData.subscription.tier !== "basic" && (
                        <div className="flex justify-between items-center p-3 bg-black/30 rounded-md">
                          <div>
                            <p className="text-sm font-medium">Virtual Cards</p>
                            <p className="text-xs text-gray-400">
                              {subscriptionData.subscription.tier === "pro" && "Basic virtual cards"}
                              {subscriptionData.subscription.tier === "enterprise" && "Premium virtual cards"}
                            </p>
                          </div>
                          <Button 
                            onClick={() => setActiveTab("cards")}
                            size="sm"
                            variant="outline"
                            className="border-[#14F195] text-[#14F195] hover:bg-[#14F195]/10 text-xs"
                          >
                            Manage
                          </Button>
                        </div>
                      )}
                    </>
                  )}
                </CardContent>
                <CardFooter className="border-t border-white/10 pt-4">
                  <Button 
                    variant="link" 
                    onClick={() => setActiveTab("trials")}
                    className="text-[#14F195] hover:text-[#14F195]/80 p-0"
                  >
                    View all automated trials
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="subscription">
            <SubscriptionCard />
          </TabsContent>

          <TabsContent value="transactions">
            <Card className="bg-[#1E1E1E] border-white/10">
              <CardHeader>
                <CardTitle>Transaction History</CardTitle>
                <CardDescription>Complete record of your payments</CardDescription>
              </CardHeader>
              <CardContent>
                <TransactionHistory />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trials">
            <Card className="bg-[#1E1E1E] border-white/10">
              <CardHeader>
                <CardTitle>Automated Trial Management</CardTitle>
                <CardDescription>Create and monitor your automated free trials</CardDescription>
              </CardHeader>
              <CardContent>
                {isSubscriptionLoading ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-[#14F195]" />
                  </div>
                ) : subscriptionData?.subscription ? (
                  <TrialsManagement />
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-400 mb-4">You need an active subscription to use automated trials</p>
                    <Button 
                      onClick={() => setActiveTab("subscription")}
                      className="bg-[#14F195] hover:bg-[#14F195]/90 text-black"
                    >
                      Choose a Plan
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="identities">
            <Card className="bg-[#1E1E1E] border-white/10">
              <CardHeader>
                <CardTitle>Identity Profile Management</CardTitle>
                <CardDescription>Create and manage virtual identity profiles for your automated trials</CardDescription>
              </CardHeader>
              <CardContent>
                {isSubscriptionLoading ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-[#14F195]" />
                  </div>
                ) : subscriptionData?.subscription ? (
                  <IdentityProfiles />
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-400 mb-4">You need an active subscription to create identity profiles</p>
                    <Button 
                      onClick={() => setActiveTab("subscription")}
                      className="bg-[#14F195] hover:bg-[#14F195]/90 text-black"
                    >
                      Choose a Plan
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cards">
            <Card className="bg-[#1E1E1E] border-white/10">
              <CardHeader>
                <CardTitle>Virtual Card Management</CardTitle>
                <CardDescription>Create and manage virtual cards for subscriptions and trials</CardDescription>
              </CardHeader>
              <CardContent>
                {isSubscriptionLoading ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-[#14F195]" />
                  </div>
                ) : subscriptionData?.subscription ? (
                  <VirtualCards />
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-400 mb-4">You need an active subscription to use virtual cards</p>
                    <Button 
                      onClick={() => setActiveTab("subscription")}
                      className="bg-[#14F195] hover:bg-[#14F195]/90 text-black"
                    >
                      Choose a Plan
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="api">
            <Card className="bg-[#1E1E1E] border-white/10">
              <CardHeader>
                <CardTitle>API Access</CardTitle>
                <CardDescription>Manage your API keys for programmatic access</CardDescription>
              </CardHeader>
              <CardContent>
                {isSubscriptionLoading ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-[#14F195]" />
                  </div>
                ) : (
                  <ApiKeyManager subscription={subscriptionData?.subscription} />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="col-span-1 md:col-span-2">
                <AccountInfo user={authData.user} />
              </div>

              <div>
                <ConnectDiscord 
                  isConnected={discordConnected} 
                  username={discordUsername}
                  onConnect={handleConnectDiscord}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <Footer />
    </div>
  );
}