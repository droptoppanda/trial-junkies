import { apiRequest } from "@/lib/queryClient";
import { create } from "zustand";

// Discord auth constants
const DISCORD_CLIENT_ID = import.meta.env.VITE_DISCORD_CLIENT_ID || "your_discord_client_id";
const REDIRECT_URI = typeof window !== "undefined" 
  ? `${window.location.origin}/dashboard` 
  : "http://localhost:5000/dashboard";

const SCOPES = ["identify", "guilds.join"];

// Discord store interface
interface DiscordState {
  isAuthenticated: boolean;
  discordId: string | null;
  discordUsername: string | null;
  loading: boolean;
  error: string | null;

  getAuthUrl: () => string;
  handleCallback: (code: string) => Promise<void>;
  checkAuthStatus: () => Promise<void>;
  disconnect: () => Promise<void>;
}

export const useDiscord = create<DiscordState>((set, get) => ({
  isAuthenticated: false,
  discordId: null,
  discordUsername: null,
  loading: false,
  error: null,

  getSolWalletAuthUrl: () => {
    const params = new URLSearchParams({
      client_id: DISCORD_CLIENT_ID,
      redirect_uri: REDIRECT_URI,
      response_type: "code",
      scope: SCOPES.join(" ")
    });

    return `https://discord.com/api/oauth2/authorize?${params.toString()}`;
  },

  handleCallback: async (code: string) => {
    try {
      set({ loading: true, error: null });

      // Mock implementation - in a real app, this would make a backend request
      // to exchange the code for tokens and user info
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Simulate successful connection
      set({
        isAuthenticated: true,
        discordId: "123456789012345678",
        discordUsername: "MockUser#1234",
        loading: false
      });

      // Link Discord account to user via backend
      await apiRequest("POST", "/api/discord/link", {
        discord_id: "123456789012345678",
        discord_username: "MockUser#1234",
        discord_access_token: "mock_access_token",
        discord_refresh_token: "mock_refresh_token",
        discord_token_expiry: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
      });

    } catch (error: any) {
      set({
        loading: false,
        error: error.message || "Failed to authenticate with Discord"
      });
    }
  },

  checkAuthStatus: async () => {
    try {
      set({ loading: true, error: null });

      // Mock implementation - in a real app, this would check with the backend
      await new Promise(resolve => setTimeout(resolve, 500));

      const response = await apiRequest("GET", "/api/auth/status", null);
      const data = await response.json();

      if (data.authenticated && data.user.discord_id) {
        set({
          isAuthenticated: true,
          discordId: data.user.discord_id,
          discordUsername: data.user.discord_username,
          loading: false
        });
      } else {
        set({
          isAuthenticated: false,
          discordId: null,
          discordUsername: null,
          loading: false
        });
      }

    } catch (error: any) {
      set({
        loading: false,
        error: error.message || "Failed to check Discord auth status"
      });
    }
  },

  disconnect: async () => {
    try {
      set({ loading: true, error: null });

      // Mock implementation - in a real app, this would revoke the token
      await new Promise(resolve => setTimeout(resolve, 500));

      set({
        isAuthenticated: false,
        discordId: null,
        discordUsername: null,
        loading: false
      });

    } catch (error: any) {
      set({
        loading: false,
        error: error.message || "Failed to disconnect from Discord"
      });
    }
  }
}));