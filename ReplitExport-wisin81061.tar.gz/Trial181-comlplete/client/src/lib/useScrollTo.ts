import { useCallback } from "react";

interface ScrollToOptions {
  offset?: number;
  behavior?: ScrollBehavior;
}

export function useScrollTo() {
  const scrollTo = useCallback((elementId: string, options: ScrollToOptions = {}) => {
    const { offset = 0, behavior = "smooth" } = options;
    
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const elementPosition = element.getBoundingClientRect().top;
    const offsetPosition = elementPosition + window.pageYOffset - offset;
    
    window.scrollTo({
      top: offsetPosition,
      behavior,
    });
  }, []);
  
  const scrollToNext = useCallback((currentSectionId: string) => {
    const sections = document.querySelectorAll('section');
    const sectionArray = Array.from(sections);
    const currentIndex = sectionArray.findIndex(section => section.id === currentSectionId);
    
    if (currentIndex >= 0 && currentIndex < sectionArray.length - 1) {
      const nextSection = sectionArray[currentIndex + 1];
      scrollTo(nextSection.id);
    }
  }, [scrollTo]);
  
  return { scrollTo, scrollToNext };
}
