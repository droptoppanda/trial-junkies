
# Discord Bot API Documentation

## Overview
The Trial Junkies Discord bot provides automated trial account generation, verification services, and management features directly through Discord commands.

## Prerequisites
- Active Trial Junkies subscription
- Discord account linked to your Trial Junkies profile
- Server with bot permissions enabled

## Command Reference

### Trial Management

#### `/create <service>`
Generates a trial account for the specified service.

**Parameters:**
- `<service>`: Name of the service (e.g., netflix, hulu, spotify)

**Example:**
```
/create spotify
```

**Response:**
```
✅ Creating trial for Spotify...
Request ID: trial_12345
You will be notified when your trial is ready.
```

#### `/status <request_id>`
Checks the status of a pending trial request.

**Parameters:**
- `<request_id>`: ID of the trial request

**Example:**
```
/status trial_12345
```

**Response:**
```
📋 Status for request trial_12345:
Service: Spotify
Status: In progress (verifying email)
Created: 10 minutes ago
```

#### `/cancel <request_id>`
Cancels an active trial generation request.

**Parameters:**
- `<request_id>`: ID of the trial request

**Example:**
```
/cancel trial_12345
```

**Response:**
```
❌ Request trial_12345 has been cancelled.
```

#### `/balance`
Displays your remaining trial credits for the current billing period.

**Example:**
```
/balance
```

**Response:**
```
💰 Trial Credits:
Available: 15 credits
Used this month: 10 credits
Plan: Junkie Mode (25 credits/month)
Resets on: April 30, 2023
```

### Configuration

#### `/proxy set <proxy>`
Sets a custom proxy for your trial requests.

**Parameters:**
- `<proxy>`: Proxy URL in format protocol://host:port or protocol://username:password@host:port

**Example:**
```
/proxy set http://192.168.1.1:8080
```

**Response:**
```
🔒 Proxy successfully configured.
```

#### `/proxy clear`
Clears your custom proxy setting and reverts to the system default.

**Example:**
```
/proxy clear
```

**Response:**
```
🔄 Proxy settings reset to default.
```

#### `/wallet <new_wallet>`
Updates the Solana wallet address for receiving trial subscription fees.

**Parameters:**
- `<new_wallet>`: Solana wallet address

**Example:**
```
/wallet FGv75UtMHPYJLB3YmPWLvuJNXZYTJrJKPMcM448CS9qr
```

**Response:**
```
💼 Wallet address updated successfully.
```

### Help

#### `/help`
Displays a list of all available commands with descriptions.

**Example:**
```
/help
```

**Response:**
```
📚 Available Commands:
/create <service> - Generate a trial account
/status <request_id> - Check trial request status
/cancel <request_id> - Cancel a trial request
/balance - Check available trial credits
/proxy set <proxy> - Configure custom proxy
/proxy clear - Reset proxy settings
/wallet <new_wallet> - Update Solana wallet
/help - Show this help message
```

## Notifications

The bot will send you notifications through DM and in the verification channel for:
- Trial creation confirmations
- Email/phone verification requests
- Trial completion with credentials
- Error notifications

## Error Handling

If a command fails, the bot will respond with an error message explaining the issue and suggest possible solutions.

## Rate Limits

To prevent abuse, the following rate limits apply:
- Maximum 5 concurrent trial requests per user
- Maximum 3 proxy changes per day
- Maximum 1 wallet update per day
