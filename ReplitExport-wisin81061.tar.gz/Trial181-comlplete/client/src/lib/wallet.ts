// This is a simplified mock version of Phantom wallet integration
// Real implementation would use @solana/web3.js and @solana/wallet-adapter-react

import { create } from 'zustand';

// Define wallet interfaces
export interface PhantomWallet {
  isPhantom: boolean;
  connect: () => Promise<{ publicKey: { toBase58: () => string } }>;
  disconnect: () => Promise<void>;
  signTransaction: (transaction: any) => Promise<any>;
  signAllTransactions: (transactions: any[]) => Promise<any[]>;
  signMessage: (message: Uint8Array) => Promise<{ signature: Uint8Array }>;
}

interface PhantomWindow extends Window {
  phantom?: {
    solana?: PhantomWallet;
  };
}

// Define wallet store
interface WalletState {
  wallet: PhantomWallet | null;
  connected: boolean;
  publicKey: string | null;
  connecting: boolean;
  error: string | null;
  
  checkForWallet: () => Promise<boolean>;
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  signTransaction: (transaction: any) => Promise<any>;
  signMessage: (message: string) => Promise<string>;
}

export const useWallet = create<WalletState>((set, get) => ({
  wallet: null,
  connected: false,
  publicKey: null,
  connecting: false,
  error: null,
  
  checkForWallet: async () => {
    try {
      // Reset previous state when checking
      set({
        wallet: null,
        connected: false,
        publicKey: null,
        error: null
      });
      
      const phantom = (window as PhantomWindow)?.phantom?.solana;
      
      if (phantom?.isPhantom) {
        set({ wallet: phantom });
        return true;
      }
      
      set({ error: "Phantom wallet not installed. Please install it from phantom.app" });
      return false;
    } catch (error) {
      console.error("Error checking for wallet:", error);
      return false;
    }
  },
  
  connect: async () => {
    try {
      const { wallet } = get();
      
      if (!wallet) {
        const hasWallet = await get().checkForWallet();
        if (!hasWallet) {
          // The error is already set in checkForWallet
          return;
        }
      }
      
      try {
        set({ connecting: true, error: null });
        
        // Try to connect to the wallet if available, otherwise use mock
        if (get().wallet) {
          // Attempt to connect to actual Phantom wallet
          try {
            const response = await get().wallet!.connect();
            const walletAddress = response.publicKey.toBase58();
            
            set({
              connected: true,
              publicKey: walletAddress,
              connecting: false
            });
            return;
          } catch (walletError: any) {
            console.error("Wallet connection error:", walletError);
            // If real wallet fails, fall back to mock below
          }
        }
        
        // For demo purposes, use a mock connection
        const mockAddress = "5tGnSL4wHcDfxUfQF54VqDpU1Hx3VnHzPU9ajTVEYv8P";
        
        // Simulate a slight delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        set({
          connected: true,
          publicKey: mockAddress,
          connecting: false
        });
        
        console.log("Connected to mock wallet with address:", mockAddress);
      } catch (error: any) {
        set({
          connected: false,
          publicKey: null,
          connecting: false,
          error: error.message || "Failed to connect wallet"
        });
      }
    } catch (error) {
      console.error("Error in connect:", error);
      set({
        connecting: false,
        error: "Unknown error occurred"
      });
    }
  },
  
  disconnect: async () => {
    try {
      // If we have a real wallet connected, try to disconnect it
      const { wallet, connected } = get();
      
      if (wallet && connected) {
        try {
          await wallet.disconnect();
        } catch (walletError) {
          console.error("Error disconnecting wallet:", walletError);
          // Continue with state reset even if wallet disconnect fails
        }
      }
      
      // Reset state regardless of whether we have a real wallet
      set({
        connected: false,
        publicKey: null,
        error: null
      });
    } catch (error) {
      console.error("Error in disconnect:", error);
      set({
        error: "Failed to disconnect"
      });
    }
  },
  
  signTransaction: async (transaction: any) => {
    try {
      const { wallet, connected } = get();
      
      if (!wallet || !connected) {
        throw new Error("Wallet not connected");
      }
      
      // If we have a real wallet, try to sign with it
      try {
        const signedTransaction = await wallet.signTransaction(transaction);
        return signedTransaction;
      } catch (error) {
        console.error("Error signing transaction with real wallet:", error);
        
        // For mock mode, return the original transaction
        // In a real implementation, this would include a valid signature
        console.log("Using mock transaction signing");
        return transaction;
      }
    } catch (error: any) {
      console.error("Error in signTransaction:", error);
      throw new Error(error.message || "Failed to sign transaction");
    }
  },
  
  signMessage: async (message: string) => {
    try {
      const { wallet, connected } = get();
      
      if (!wallet || !connected) {
        throw new Error("Wallet not connected");
      }
      
      // If we have a real wallet, try to sign with it
      try {
        // Convert message to Uint8Array
        const messageBytes = new TextEncoder().encode(message);
        const signedMessage = await wallet.signMessage(messageBytes);
        // Convert signature to string
        return Buffer.from(signedMessage.signature).toString('hex');
      } catch (error) {
        console.error("Error signing message with real wallet:", error);
        
        // For mock mode, return a fake signature
        const mockSignature = "mock_signature_" + Date.now();
        console.log("Using mock message signing:", mockSignature);
        return mockSignature;
      }
    } catch (error: any) {
      console.error("Error in signMessage:", error);
      throw new Error(error.message || "Failed to sign message");
    }
  }
}));

// Helper functions for wallet transactions
export const solToLamports = (sol: number): number => {
  return sol * 1_000_000_000;
};

export const lamportsToSol = (lamports: number): number => {
  return lamports / 1_000_000_000;
};

export const shortenAddress = (address: string, chars = 4): string => {
  return `${address.slice(0, chars)}...${address.slice(-chars)}`;
};
