# Trial Junkies Frontend

This directory contains the frontend code for the Trial Junkies application, built with React, TypeScript, and Tailwind CSS.

## Key Features

- **User Dashboard**: Comprehensive dashboard showing subscription details, trial management, and transaction history
- **Renewal Reminders**: Visual alerts for upcoming subscription renewals and trial expirations
- **Solana Cryptocurrency Integration**: Secure wallet connection and payment processing
- **Identity Management**: Create and manage virtual identities for trial automation
- **Virtual Card Management**: Generate virtual cards for service subscriptions

## Component Structure

### Dashboard Components

- **RenewalReminders**: Shows upcoming subscription renewals and trial expirations with color-coded alerts
- **SubscriptionCard**: Displays and manages user's subscription plans
- **TransactionHistory**: Lists payment history with status indicators
- **TrialsManagement**: Interface for creating and managing automated trials
- **IdentityProfiles**: Manages virtual identity information for trial registration
- **VirtualCards**: Handles virtual card generation and management
- **ApiKeyManager**: Manages API keys for programmatic access
- **AccountInfo**: Displays user account details and settings

### Payment Components

- **CryptoPayment**: Handles Solana-based cryptocurrency payments
- **WalletConnectionModal**: Provides secure wallet connection interface

## Design Features

- **Animation Effects**: Smooth transitions and animations using Framer Motion
- **Responsive Design**: Mobile-first approach with responsive layouts
- **Accessibility**: ARIA-compliant components and keyboard navigation
- **Dark Theme**: Modern dark theme with Solana brand colors