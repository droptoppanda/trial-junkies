// Configure workflow script
import fs from 'fs';
import path from 'path';

// Configuration for our solana server workflow
const workflowConfig = {
  run: ["bash", "-c", "MOCK_SOLANA_VERIFICATION=true node server.js"],
  language: "nodejs",
  persistent: true,
  hidden: false,
  entrypoint: "server.js"
};

// Write the workflow configuration to the .replit file
fs.writeFileSync('.replit', `run = ${JSON.stringify(workflowConfig.run)}
language = "${workflowConfig.language}"
hidden = ${workflowConfig.hidden}
persistent = ${workflowConfig.persistent}
entrypoint = "${workflowConfig.entrypoint}"
modules = ["nodejs-20"]

[env]
MOCK_SOLANA_VERIFICATION = "true"
SOLANA_NETWORK = "devnet"
SOLANA_MOCK_MODE = "true"

[deployment]
deploymentTarget = 'cloudrun'
build = ['npm install --omit=dev']
run = ['node server.js']

[nix]
channel = "stable-23_05"
`);

console.log('Workflow configuration updated. Please restart the Replit environment.');