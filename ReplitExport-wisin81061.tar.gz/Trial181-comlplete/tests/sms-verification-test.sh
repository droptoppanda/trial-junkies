#!/bin/bash

# SMS Verification Service Test
#
# This script tests the SMS verification service functionality

echo ""
echo "========== SMS VERIFICATION SERVICE TEST =========="
echo ""

# Use mock mode by default for testing
USE_MOCK=true
TESTS_PASSED=0
TESTS_FAILED=0
BASE_URL="http://localhost:5000/api"

# Function to test a specific sms verification feature
test_feature() {
  FEATURE_NAME="$1"
  TEST_FN="$2"
  
  echo ""
  echo "Testing feature: $FEATURE_NAME"
  
  if $TEST_FN; then
    echo "✅ Feature passed: $FEATURE_NAME"
    TESTS_PASSED=$((TESTS_PASSED + 1))
    return 0
  else
    echo "❌ Feature failed: $FEATURE_NAME"
    TESTS_FAILED=$((TESTS_FAILED + 1))
    return 1
  fi
}

# Mock response functions
mock_request_sms() {
  echo '{"success":true,"verificationId":"mock_sms_123","phone":"+1234567890","provider":"mock"}'
  return 0
}

mock_verify_sms() {
  echo '{"success":true,"verified":true,"verificationId":"mock_sms_123"}'
  return 0
}

mock_cancel_sms() {
  echo '{"success":true,"cancelled":true,"verificationId":"mock_sms_123"}'
  return 0
}

mock_providers_list() {
  echo '{"success":true,"providers":["twilio","nexmo","sinch","mock"]}'
  return 0
}

mock_provider_status() {
  echo '{"success":true,"provider":"mock","status":"active","quotaRemaining":100}'
  return 0
}

# Function to make HTTP requests (mocked or real)
make_request() {
  METHOD="$1"
  ENDPOINT="$2"
  DATA="$3"
  
  if [ "$USE_MOCK" == "true" ]; then
    # Return mock response based on endpoint
    if [[ "$ENDPOINT" == *"sms/request"* ]]; then
      mock_request_sms
    elif [[ "$ENDPOINT" == *"sms/verify"* ]]; then
      mock_verify_sms
    elif [[ "$ENDPOINT" == *"sms/cancel"* ]]; then
      mock_cancel_sms
    elif [[ "$ENDPOINT" == *"sms/providers"* ]]; then
      mock_providers_list
    elif [[ "$ENDPOINT" == *"sms/provider-status"* ]]; then
      mock_provider_status
    else
      echo '{"success":true}'
    fi
    return 0
  else
    # Make an actual HTTP request
    if [ "$METHOD" == "GET" ]; then
      if command -v curl >/dev/null 2>&1; then
        curl -s -X GET "$BASE_URL$ENDPOINT"
        return $?
      else
        echo "Error: curl not available"
        return 1
      fi
    elif [ "$METHOD" == "POST" ]; then
      if command -v curl >/dev/null 2>&1; then
        curl -s -X POST -H "Content-Type: application/json" -d "$DATA" "$BASE_URL$ENDPOINT"
        return $?
      else
        echo "Error: curl not available"
        return 1
      fi
    fi
  fi
}

# Test SMS request feature
test_sms_request() {
  echo "Requesting SMS verification code..."
  
  # Create test data for different services
  declare -a services=("Netflix" "Hulu" "Disney+" "Amazon" "Spotify")
  local service=${services[$RANDOM % ${#services[@]}]}
  
  SMS_DATA="{\"phone\":\"+1234567890\",\"serviceName\":\"$service\"}"
  RESPONSE=$(make_request "POST" "/sms/request" "$SMS_DATA")
  
  # Check if SMS request was successful
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"verificationId"* ]]; then
    # Extract verification ID for later use
    VERIFICATION_ID=$(echo "$RESPONSE" | grep -o '"verificationId":"[^"]*"' | cut -d'"' -f4)
    export VERIFICATION_ID
    echo "SMS verification requested for $service with ID: $VERIFICATION_ID"
    return 0
  else
    echo "Failed to request SMS verification"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test SMS verification feature
test_sms_verification() {
  echo "Verifying SMS code..."
  
  VERIFICATION_ID=${VERIFICATION_ID:-"mock_sms_123"}
  
  # Generate random 6-digit code
  CODE=$(printf "%06d" $((RANDOM % 1000000)))
  
  SMS_VERIFY_DATA="{\"verificationId\":\"$VERIFICATION_ID\",\"code\":\"$CODE\"}"
  RESPONSE=$(make_request "POST" "/sms/verify" "$SMS_VERIFY_DATA")
  
  # Check if verification was successful
  if [[ "$RESPONSE" == *"\"verified\":true"* ]]; then
    echo "SMS verification successful with code: $CODE"
    return 0
  else
    echo "SMS verification failed"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test SMS cancellation feature
test_sms_cancellation() {
  echo "Cancelling SMS verification..."
  
  VERIFICATION_ID=${VERIFICATION_ID:-"mock_sms_123"}
  
  SMS_CANCEL_DATA="{\"verificationId\":\"$VERIFICATION_ID\"}"
  RESPONSE=$(make_request "POST" "/sms/cancel" "$SMS_CANCEL_DATA")
  
  # Check if cancellation was successful
  if [[ "$RESPONSE" == *"\"cancelled\":true"* ]]; then
    echo "SMS verification cancelled successfully"
    return 0
  else
    echo "Failed to cancel SMS verification"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test providers list feature
test_providers_list() {
  echo "Getting SMS providers list..."
  
  RESPONSE=$(make_request "GET" "/sms/providers" "")
  
  # Check if providers list was retrieved successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"providers"* ]]; then
    echo "SMS providers list retrieved successfully"
    return 0
  else
    echo "Failed to retrieve SMS providers list"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test provider status feature
test_provider_status() {
  echo "Checking SMS provider status..."
  
  PROVIDER="mock"
  
  RESPONSE=$(make_request "GET" "/sms/provider-status/$PROVIDER" "")
  
  # Check if provider status was retrieved successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"status"* ]]; then
    echo "SMS provider status retrieved successfully"
    return 0
  else
    echo "Failed to retrieve SMS provider status"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Run all SMS verification tests
test_feature "SMS Request" test_sms_request
test_feature "SMS Verification" test_sms_verification
test_feature "SMS Cancellation" test_sms_cancellation
test_feature "SMS Providers List" test_providers_list
test_feature "SMS Provider Status" test_provider_status

# Summarize test results
echo ""
echo "SMS Verification Tests Completed"
echo "Passed: $TESTS_PASSED"
echo "Failed: $TESTS_FAILED"
echo "Total: $((TESTS_PASSED + TESTS_FAILED))"

if [ $TESTS_FAILED -gt 0 ]; then
  exit 1
else
  exit 0
fi