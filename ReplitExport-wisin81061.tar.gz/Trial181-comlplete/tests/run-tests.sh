#!/bin/bash

# Comprehensive Test Runner
#
# This script runs all the test modules for the application
# and provides a summary of results.

echo ""
echo "========== TRIAL JUNKIES TEST SUITE =========="
echo ""

# Load environment variables from .env
ENV_FILE="../.env"
if [ -f "$ENV_FILE" ]; then
  echo "Loading environment from .env file..."
  while IFS= read -r line || [[ -n "$line" ]]; do
    # Skip comments and empty lines
    [[ "$line" =~ ^#.*$ ]] && continue
    [[ -z "$line" ]] && continue
    
    # Extract variable name and value
    if [[ "$line" =~ ^([A-Za-z0-9_]+)=(.*)$ ]]; then
      name="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"
      # Remove quotes if present
      value="${value%\"}"
      value="${value#\"}"
      value="${value%\'}"
      value="${value#\'}"
      # Export the variable
      export "$name"="$value"
    fi
  done < "$ENV_FILE"
  echo "Environment variables loaded successfully."
else
  echo "Warning: .env file not found. Using default environment."
  
  # Set default environment variables for testing
  export MOCK_SOLANA_VERIFICATION="true"
  export SOLANA_MOCK_MODE="true"
  export SOLANA_NETWORK="devnet"
fi

# Force mock mode for testing
export MOCK_SOLANA_VERIFICATION="true"
export SOLANA_MOCK_MODE="true"
export MOCK_SMS_VERIFICATION="true"
export MOCK_CAPTCHA_SOLVER="true"
export NODE_ENV="test"

# Initialize test results
PASSED=0
FAILED=0
SKIPPED=0

# Function to run a test and track results
run_test() {
  TEST_NAME="$1"
  TEST_CMD="$2"
  
  echo ""
  echo "--- Running $TEST_NAME ---"
  
  if [ -n "$3" ] && [ "$3" == "skip" ]; then
    echo "SKIPPED: $TEST_NAME (disabled)"
    SKIPPED=$((SKIPPED + 1))
    return
  fi
  
  $TEST_CMD
  RESULT=$?
  
  if [ $RESULT -eq 0 ]; then
    echo "PASSED: $TEST_NAME"
    PASSED=$((PASSED + 1))
  else
    echo "FAILED: $TEST_NAME (exit code: $RESULT)"
    FAILED=$((FAILED + 1))
  fi
}

# Create directory for test results
mkdir -p test-results
rm -f test-results/*.log

# Run environment check test
run_test "Environment Check" "../test-scripts/check-solana-setup.sh > test-results/env-check.log 2>&1"

# Run Solana payment test
run_test "Solana Payment Module" "../test-scripts/test-solana-module.sh > test-results/solana-module.log 2>&1"

# Run API tests (we use bash for this to avoid Node.js dependency)
run_test "API Endpoints Test" "./api-test.sh > test-results/api-test.log 2>&1"

# Run trial creation test
run_test "Trial Creation Flow" "./trial-creation-test.sh > test-results/trial-creation.log 2>&1" 

# Run SMS verification test
run_test "SMS Verification" "./sms-verification-test.sh > test-results/sms-verification.log 2>&1"

# Run captcha solver test
run_test "Captcha Solver" "./captcha-test.sh > test-results/captcha-test.log 2>&1"

# Run database test
run_test "Database Operations" "./database-test.sh > test-results/database-test.log 2>&1"

# Display test summary
echo ""
echo "--- Test Summary ---"
echo "PASSED: $PASSED"
echo "FAILED: $FAILED"
echo "SKIPPED: $SKIPPED"
echo "TOTAL: $((PASSED + FAILED + SKIPPED))"
echo ""

# Set exit code based on test results
if [ $FAILED -gt 0 ]; then
  echo "Some tests failed. Check test-results directory for logs."
  exit 1
else
  echo "All tests passed successfully!"
  exit 0
fi