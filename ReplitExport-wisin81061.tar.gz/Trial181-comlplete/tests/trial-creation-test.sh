#!/bin/bash

# Trial Creation Flow Test
#
# This script tests the trial creation workflow from end to end

echo ""
echo "========== TRIAL CREATION FLOW TEST =========="
echo ""

# Use mock mode by default for testing
USE_MOCK=true
TESTS_PASSED=0
TESTS_FAILED=0
BASE_URL="http://localhost:5000/api"

# Function to test a step in the trial creation flow
test_step() {
  STEP_NAME="$1"
  TEST_FN="$2"
  
  echo ""
  echo "Testing step: $STEP_NAME"
  
  if $TEST_FN; then
    echo "✅ Step passed: $STEP_NAME"
    TESTS_PASSED=$((TESTS_PASSED + 1))
    return 0
  else
    echo "❌ Step failed: $STEP_NAME"
    TESTS_FAILED=$((TESTS_FAILED + 1))
    return 1
  fi
}

# Mock response functions
mock_create_payment() {
  echo '{"success":true,"paymentRequest":{"paymentId":"mock_payment_123","amount":1.0,"receiverAddress":"mockAddress","network":"devnet","mockMode":true,"instructions":["Send 1.0 SOL to mockAddress","Copy the transaction ID","Verify the transaction using the transaction ID"]}}'
  return 0
}

mock_verify_payment() {
  echo '{"success":true,"verified":true,"amount":1.0,"timestamp":"2025-03-30T12:00:00Z"}'
  return 0
}

mock_get_email() {
  echo '{"success":true,"email":"mock_email@example.com","verificationId":"mock_email_123"}'
  return 0
}

mock_request_sms() {
  echo '{"success":true,"verificationId":"mock_sms_123","phone":"+1234567890"}'
  return 0
}

mock_verify_sms() {
  echo '{"success":true,"verified":true,"verificationId":"mock_sms_123"}'
  return 0
}

mock_solve_captcha() {
  echo '{"success":true,"solution":"ABCDEF"}'
  return 0
}

mock_create_trial() {
  echo '{"success":true,"trialId":"mock_trial_123","status":"pending","createdAt":"2025-03-30T12:00:00Z"}'
  return 0
}

# Function to make HTTP requests (mocked or real)
make_request() {
  METHOD="$1"
  ENDPOINT="$2"
  DATA="$3"
  
  if [ "$USE_MOCK" == "true" ]; then
    # Return mock response based on endpoint
    if [[ "$ENDPOINT" == *"payments/create"* ]]; then
      mock_create_payment
    elif [[ "$ENDPOINT" == *"payments/verify"* ]]; then
      mock_verify_payment
    elif [[ "$ENDPOINT" == *"email/get"* ]]; then
      mock_get_email
    elif [[ "$ENDPOINT" == *"sms/request"* ]]; then
      mock_request_sms
    elif [[ "$ENDPOINT" == *"sms/verify"* ]]; then
      mock_verify_sms
    elif [[ "$ENDPOINT" == *"captcha/solve"* ]]; then
      mock_solve_captcha
    elif [[ "$ENDPOINT" == *"trials/create"* ]]; then
      mock_create_trial
    else
      echo '{"success":true}'
    fi
    return 0
  else
    # Make an actual HTTP request
    if [ "$METHOD" == "GET" ]; then
      if command -v curl >/dev/null 2>&1; then
        curl -s -X GET "$BASE_URL$ENDPOINT"
        return $?
      else
        echo "Error: curl not available"
        return 1
      fi
    elif [ "$METHOD" == "POST" ]; then
      if command -v curl >/dev/null 2>&1; then
        curl -s -X POST -H "Content-Type: application/json" -d "$DATA" "$BASE_URL$ENDPOINT"
        return $?
      else
        echo "Error: curl not available"
        return 1
      fi
    fi
  fi
}

# Step 1: Create a payment
test_payment_creation() {
  echo "Creating payment for subscription..."
  
  PAYMENT_DATA='{"amount":1.0,"metadata":{"userId":"test_user","purpose":"subscription"}}'
  RESPONSE=$(make_request "POST" "/payments/create" "$PAYMENT_DATA")
  
  # Check if payment was created successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"paymentId"* ]]; then
    # Extract payment ID for later use
    PAYMENT_ID=$(echo "$RESPONSE" | grep -o '"paymentId":"[^"]*"' | cut -d'"' -f4)
    export PAYMENT_ID
    echo "Payment created with ID: $PAYMENT_ID"
    return 0
  else
    echo "Failed to create payment"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Step 2: Verify the payment
test_payment_verification() {
  echo "Verifying payment transaction..."
  
  PAYMENT_ID=${PAYMENT_ID:-"mock_payment_123"}
  TX_ID="mock_tx_$(date +%s)"
  
  VERIFICATION_DATA="{\"transactionId\":\"$TX_ID\",\"amount\":1.0,\"paymentId\":\"$PAYMENT_ID\"}"
  RESPONSE=$(make_request "POST" "/payments/verify" "$VERIFICATION_DATA")
  
  # Check if verification was successful
  if [[ "$RESPONSE" == *"\"verified\":true"* ]]; then
    echo "Payment verified successfully"
    return 0
  else
    echo "Payment verification failed"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Step 3: Get a disposable email
test_email_acquisition() {
  echo "Getting disposable email for verification..."
  
  EMAIL_DATA='{"service":"Netflix"}'
  RESPONSE=$(make_request "POST" "/email/get" "$EMAIL_DATA")
  
  # Check if email was acquired successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"email"* ]]; then
    # Extract email verification ID
    EMAIL_VERIFICATION_ID=$(echo "$RESPONSE" | grep -o '"verificationId":"[^"]*"' | cut -d'"' -f4)
    export EMAIL_VERIFICATION_ID
    echo "Email verification ID: $EMAIL_VERIFICATION_ID"
    return 0
  else
    echo "Failed to acquire email"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Step 4: Request SMS verification
test_sms_request() {
  echo "Requesting SMS verification..."
  
  SMS_DATA='{"phone":"+1234567890","serviceName":"Netflix"}'
  RESPONSE=$(make_request "POST" "/sms/request" "$SMS_DATA")
  
  # Check if SMS request was successful
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"verificationId"* ]]; then
    # Extract SMS verification ID
    SMS_VERIFICATION_ID=$(echo "$RESPONSE" | grep -o '"verificationId":"[^"]*"' | cut -d'"' -f4)
    export SMS_VERIFICATION_ID
    echo "SMS verification ID: $SMS_VERIFICATION_ID"
    return 0
  else
    echo "Failed to request SMS verification"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Step 5: Verify SMS code
test_sms_verification() {
  echo "Verifying SMS code..."
  
  SMS_VERIFICATION_ID=${SMS_VERIFICATION_ID:-"mock_sms_123"}
  
  SMS_VERIFY_DATA="{\"verificationId\":\"$SMS_VERIFICATION_ID\",\"code\":\"123456\"}"
  RESPONSE=$(make_request "POST" "/sms/verify" "$SMS_VERIFY_DATA")
  
  # Check if SMS verification was successful
  if [[ "$RESPONSE" == *"\"verified\":true"* ]]; then
    echo "SMS verification successful"
    return 0
  else
    echo "SMS verification failed"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Step 6: Solve captcha
test_captcha_solving() {
  echo "Solving captcha..."
  
  CAPTCHA_DATA='{"imageUrl":"https://example.com/captcha.jpg","siteKey":"","pageUrl":""}'
  RESPONSE=$(make_request "POST" "/captcha/solve" "$CAPTCHA_DATA")
  
  # Check if captcha solving was successful
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"solution"* ]]; then
    # Extract captcha solution
    CAPTCHA_SOLUTION=$(echo "$RESPONSE" | grep -o '"solution":"[^"]*"' | cut -d'"' -f4)
    export CAPTCHA_SOLUTION
    echo "Captcha solution: $CAPTCHA_SOLUTION"
    return 0
  else
    echo "Failed to solve captcha"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Step 7: Create trial
test_trial_creation() {
  echo "Creating streaming service trial..."
  
  TRIAL_DATA='{
    "userId": "test_user",
    "serviceName": "Netflix",
    "serviceUrl": "https://netflix.com",
    "credentials": {
      "email": "test@example.com",
      "password": "password123"
    },
    "verifications": {
      "email": "mock_email_123",
      "sms": "mock_sms_123",
      "captcha": "ABCDEF"
    }
  }'
  
  RESPONSE=$(make_request "POST" "/trials/create" "$TRIAL_DATA")
  
  # Check if trial creation was successful
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"trialId"* ]]; then
    # Extract trial ID
    TRIAL_ID=$(echo "$RESPONSE" | grep -o '"trialId":"[^"]*"' | cut -d'"' -f4)
    export TRIAL_ID
    echo "Trial created with ID: $TRIAL_ID"
    return 0
  else
    echo "Failed to create trial"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Run the trial creation flow tests
test_step "Payment Creation" test_payment_creation
test_step "Payment Verification" test_payment_verification
test_step "Email Acquisition" test_email_acquisition
test_step "SMS Verification Request" test_sms_request
test_step "SMS Code Verification" test_sms_verification
test_step "Captcha Solving" test_captcha_solving
test_step "Trial Creation" test_trial_creation

# Summarize test results
echo ""
echo "Trial Creation Flow Tests Completed"
echo "Passed: $TESTS_PASSED"
echo "Failed: $TESTS_FAILED"
echo "Total: $((TESTS_PASSED + TESTS_FAILED))"

if [ $TESTS_FAILED -gt 0 ]; then
  exit 1
else
  exit 0
fi