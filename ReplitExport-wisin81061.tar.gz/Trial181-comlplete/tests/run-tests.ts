import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';

const TEST_SCRIPTS = [
  { name: 'Trial Delivery Test', file: 'trial-delivery-test.ts' },
  { name: 'API Flow Test', file: 'api-flow-test.ts' },
  { name: 'Solana Payment Test', file: 'solana-payment-test.ts' }
];

// Create a directory for test logs
const LOG_DIR = path.join(__dirname, 'logs');
if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true });
}

// Function to run a single test with colorized output
async function runTest(testName: string, filePath: string): Promise<boolean> {
  return new Promise((resolve) => {
    const logFile = path.join(LOG_DIR, `${path.basename(filePath, '.ts')}.log`);
    const logStream = fs.createWriteStream(logFile, { flags: 'w' });
    
    console.log(`\n\n${'-'.repeat(80)}`);
    console.log(`Running test: ${testName} (${filePath})`);
    console.log(`${'-'.repeat(80)}\n`);
    
    // Using tsx to run TypeScript files directly
    const child = spawn('npx', ['tsx', filePath], {
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env }
    });
    
    // Capture and colorize stdout
    child.stdout.on('data', (data) => {
      const output = data.toString();
      logStream.write(output);
      
      // Add color to the console output based on content
      const colorized = output
        .replace(/Success|Completed|Created|Verified/gi, '\x1b[32m$&\x1b[0m') // Green
        .replace(/Error|Failed|Exception/gi, '\x1b[31m$&\x1b[0m') // Red
        .replace(/Warning/gi, '\x1b[33m$&\x1b[0m') // Yellow
        .replace(/Processing|Starting|Waiting/gi, '\x1b[36m$&\x1b[0m'); // Cyan
      
      process.stdout.write(colorized);
    });
    
    // Capture and colorize stderr
    child.stderr.on('data', (data) => {
      const output = data.toString();
      logStream.write(output);
      process.stderr.write(`\x1b[31m${output}\x1b[0m`); // Red for all errors
    });
    
    // Handle test completion
    child.on('close', (code) => {
      logStream.end();
      const passed = code === 0;
      console.log(`\n${'-'.repeat(80)}`);
      console.log(`Test ${passed ? '\x1b[32mPASSED' : '\x1b[31mFAILED'}\x1b[0m: ${testName}`);
      console.log(`Exit code: ${code}`);
      console.log(`Log file: ${logFile}`);
      console.log(`${'-'.repeat(80)}\n`);
      resolve(passed);
    });
  });
}

// Main function to run all tests
async function runAllTests() {
  console.log('\x1b[1m\x1b[34m');
  console.log('*'.repeat(80));
  console.log('*', ' '.repeat(30), 'TRIAL JUNKIES TEST SUITE', ' '.repeat(30), '*');
  console.log('*'.repeat(80));
  console.log('\x1b[0m');
  
  const results: { name: string; passed: boolean }[] = [];
  
  for (const test of TEST_SCRIPTS) {
    const filePath = path.join(__dirname, test.file);
    if (!fs.existsSync(filePath)) {
      console.log(`\x1b[33mWarning: Test file not found: ${filePath}\x1b[0m`);
      results.push({ name: test.name, passed: false });
      continue;
    }
    
    const passed = await runTest(test.name, filePath);
    results.push({ name: test.name, passed });
  }
  
  // Print summary
  console.log('\n\n\x1b[1m\x1b[34m');
  console.log('*'.repeat(80));
  console.log('*', ' '.repeat(34), 'TEST SUMMARY', ' '.repeat(34), '*');
  console.log('*'.repeat(80));
  console.log('\x1b[0m');
  
  for (const result of results) {
    const status = result.passed ? '\x1b[32mPASSED' : '\x1b[31mFAILED';
    console.log(`${result.name}: ${status}\x1b[0m`);
  }
  
  const passedCount = results.filter(r => r.passed).length;
  const totalCount = results.length;
  
  console.log(`\nTotal: ${passedCount}/${totalCount} tests passed\n`);
  
  // Exit with appropriate code
  process.exit(passedCount === totalCount ? 0 : 1);
}

// Run all tests
runAllTests().catch(error => {
  console.error('\x1b[31mTest runner error:', error, '\x1b[0m');
  process.exit(1);
});