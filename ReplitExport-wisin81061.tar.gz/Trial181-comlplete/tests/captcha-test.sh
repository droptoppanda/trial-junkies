#!/bin/bash

# Captcha Solver Service Test
#
# This script tests the captcha solver service functionality

echo ""
echo "========== CAPTCHA SOLVER SERVICE TEST =========="
echo ""

# Use mock mode by default for testing
USE_MOCK=true
TESTS_PASSED=0
TESTS_FAILED=0
BASE_URL="http://localhost:5000/api"

# Function to test a specific captcha solver feature
test_feature() {
  FEATURE_NAME="$1"
  TEST_FN="$2"
  
  echo ""
  echo "Testing feature: $FEATURE_NAME"
  
  if $TEST_FN; then
    echo "✅ Feature passed: $FEATURE_NAME"
    TESTS_PASSED=$((TESTS_PASSED + 1))
    return 0
  else
    echo "❌ Feature failed: $FEATURE_NAME"
    TESTS_FAILED=$((TESTS_FAILED + 1))
    return 1
  fi
}

# Mock response functions
mock_solve_image_captcha() {
  echo '{"success":true,"solution":"ABC123","confidence":0.97}'
  return 0
}

mock_solve_recaptcha() {
  echo '{"success":true,"solution":"03AOLTBLSIm99Cf4KvUb8NrI3_HPtYbkOY2HBAYJm","confidence":0.95}'
  return 0
}

mock_solve_hcaptcha() {
  echo '{"success":true,"solution":"P0_eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9","confidence":0.92}'
  return 0
}

mock_get_providers() {
  echo '{"success":true,"providers":["2captcha","anti-captcha","capsolver","local"]}'
  return 0
}

mock_check_provider_balance() {
  echo '{"success":true,"provider":"mock","balance":10.5,"unit":"USD"}'
  return 0
}

# Function to make HTTP requests (mocked or real)
make_request() {
  METHOD="$1"
  ENDPOINT="$2"
  DATA="$3"
  
  if [ "$USE_MOCK" == "true" ]; then
    # Return mock response based on endpoint
    if [[ "$ENDPOINT" == *"captcha/solve-image"* ]]; then
      mock_solve_image_captcha
    elif [[ "$ENDPOINT" == *"captcha/solve-recaptcha"* ]]; then
      mock_solve_recaptcha
    elif [[ "$ENDPOINT" == *"captcha/solve-hcaptcha"* ]]; then
      mock_solve_hcaptcha
    elif [[ "$ENDPOINT" == *"captcha/providers"* ]]; then
      mock_get_providers
    elif [[ "$ENDPOINT" == *"captcha/provider-balance"* ]]; then
      mock_check_provider_balance
    else
      echo '{"success":true}'
    fi
    return 0
  else
    # Make an actual HTTP request
    if [ "$METHOD" == "GET" ]; then
      if command -v curl >/dev/null 2>&1; then
        curl -s -X GET "$BASE_URL$ENDPOINT"
        return $?
      else
        echo "Error: curl not available"
        return 1
      fi
    elif [ "$METHOD" == "POST" ]; then
      if command -v curl >/dev/null 2>&1; then
        curl -s -X POST -H "Content-Type: application/json" -d "$DATA" "$BASE_URL$ENDPOINT"
        return $?
      else
        echo "Error: curl not available"
        return 1
      fi
    fi
  fi
}

# Test image captcha solving feature
test_image_captcha() {
  echo "Solving image captcha..."
  
  # Sample image URL
  IMAGE_URL="https://example.com/captcha.jpg"
  
  CAPTCHA_DATA="{\"imageUrl\":\"$IMAGE_URL\"}"
  RESPONSE=$(make_request "POST" "/captcha/solve-image" "$CAPTCHA_DATA")
  
  # Check if captcha was solved successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"solution"* ]]; then
    # Extract solution
    SOLUTION=$(echo "$RESPONSE" | grep -o '"solution":"[^"]*"' | cut -d'"' -f4)
    echo "Image captcha solved with solution: $SOLUTION"
    return 0
  else
    echo "Failed to solve image captcha"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test reCAPTCHA solving feature
test_recaptcha() {
  echo "Solving reCAPTCHA..."
  
  # Sample site key and page URL
  SITE_KEY="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"
  PAGE_URL="https://example.com/login"
  
  CAPTCHA_DATA="{\"siteKey\":\"$SITE_KEY\",\"pageUrl\":\"$PAGE_URL\"}"
  RESPONSE=$(make_request "POST" "/captcha/solve-recaptcha" "$CAPTCHA_DATA")
  
  # Check if captcha was solved successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"solution"* ]]; then
    # Extract solution
    SOLUTION=$(echo "$RESPONSE" | grep -o '"solution":"[^"]*"' | cut -d'"' -f4)
    echo "reCAPTCHA solved with token (truncated): ${SOLUTION:0:20}..."
    return 0
  else
    echo "Failed to solve reCAPTCHA"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test hCaptcha solving feature
test_hcaptcha() {
  echo "Solving hCaptcha..."
  
  # Sample site key and page URL
  SITE_KEY="10000000-ffff-ffff-ffff-000000000001"
  PAGE_URL="https://example.com/signup"
  
  CAPTCHA_DATA="{\"siteKey\":\"$SITE_KEY\",\"pageUrl\":\"$PAGE_URL\"}"
  RESPONSE=$(make_request "POST" "/captcha/solve-hcaptcha" "$CAPTCHA_DATA")
  
  # Check if captcha was solved successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"solution"* ]]; then
    # Extract solution
    SOLUTION=$(echo "$RESPONSE" | grep -o '"solution":"[^"]*"' | cut -d'"' -f4)
    echo "hCaptcha solved with token (truncated): ${SOLUTION:0:20}..."
    return 0
  else
    echo "Failed to solve hCaptcha"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test get providers feature
test_get_providers() {
  echo "Getting captcha service providers..."
  
  RESPONSE=$(make_request "GET" "/captcha/providers" "")
  
  # Check if providers were retrieved successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"providers"* ]]; then
    echo "Captcha service providers retrieved successfully"
    return 0
  else
    echo "Failed to retrieve captcha service providers"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test provider balance check feature
test_provider_balance() {
  echo "Checking captcha service provider balance..."
  
  PROVIDER="mock"
  
  RESPONSE=$(make_request "GET" "/captcha/provider-balance/$PROVIDER" "")
  
  # Check if balance was retrieved successfully
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"balance"* ]]; then
    # Extract balance
    BALANCE=$(echo "$RESPONSE" | grep -o '"balance":[^,}]*' | cut -d':' -f2)
    UNIT=$(echo "$RESPONSE" | grep -o '"unit":"[^"]*"' | cut -d'"' -f4)
    echo "Provider $PROVIDER balance: $BALANCE $UNIT"
    return 0
  else
    echo "Failed to retrieve provider balance"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Run all captcha solver tests
test_feature "Image Captcha Solving" test_image_captcha
test_feature "reCAPTCHA Solving" test_recaptcha
test_feature "hCaptcha Solving" test_hcaptcha
test_feature "Get Captcha Service Providers" test_get_providers
test_feature "Check Provider Balance" test_provider_balance

# Summarize test results
echo ""
echo "Captcha Solver Tests Completed"
echo "Passed: $TESTS_PASSED"
echo "Failed: $TESTS_FAILED"
echo "Total: $((TESTS_PASSED + TESTS_FAILED))"

if [ $TESTS_FAILED -gt 0 ]; then
  exit 1
else
  exit 0
fi