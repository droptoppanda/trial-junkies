#!/bin/bash

# Database Operations Test
#
# This script tests database operations and schema validation

echo ""
echo "========== DATABASE OPERATIONS TEST =========="
echo ""

TESTS_PASSED=0
TESTS_FAILED=0
BASE_URL="http://localhost:5000/api"

# Function to test database operations
test_operation() {
  OP_NAME="$1"
  TEST_FN="$2"
  
  echo ""
  echo "Testing operation: $OP_NAME"
  
  if $TEST_FN; then
    echo "✅ Operation passed: $OP_NAME"
    TESTS_PASSED=$((TESTS_PASSED + 1))
    return 0
  else
    echo "❌ Operation failed: $OP_NAME"
    TESTS_FAILED=$((TESTS_FAILED + 1))
    return 1
  fi
}

# Function to make HTTP requests to database-related endpoints
make_request() {
  METHOD="$1"
  ENDPOINT="$2"
  DATA="$3"
  
  if [ "$METHOD" == "GET" ]; then
    if command -v curl >/dev/null 2>&1; then
      curl -s -X GET "$BASE_URL$ENDPOINT"
      return $?
    else
      echo "Error: curl not available"
      return 1
    fi
  elif [ "$METHOD" == "POST" ]; then
    if command -v curl >/dev/null 2>&1; then
      curl -s -X POST -H "Content-Type: application/json" -d "$DATA" "$BASE_URL$ENDPOINT"
      return $?
    else
      echo "Error: curl not available"
      return 1
    fi
  fi
}

# Test database connection
test_db_connection() {
  echo "Testing database connection..."
  
  # Using the health check endpoint that should verify DB connection
  RESPONSE=$(make_request "GET" "/health" "")
  
  # Check if health check reports database as connected
  if [[ "$RESPONSE" == *"\"status\":\"ok\""* ]]; then
    echo "Database connection verified via health check"
    return 0
  else
    echo "Database connection check failed"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test user operations
test_user_operations() {
  echo "Testing user operations..."
  
  # Generate a unique user for testing
  USER_ID="test_user_$(date +%s)"
  
  # 1. Create user
  USER_DATA="{\"id\":\"$USER_ID\",\"email\":\"$USER_ID@example.com\",\"name\":\"Test User\"}"
  CREATE_RESPONSE=$(make_request "POST" "/users/create" "$USER_DATA")
  
  # Check if user was created successfully
  if [[ "$CREATE_RESPONSE" != *"\"success\":true"* ]]; then
    echo "Failed to create user"
    echo "Response: $CREATE_RESPONSE"
    return 1
  fi
  
  # 2. Get user
  GET_RESPONSE=$(make_request "GET" "/users/$USER_ID" "")
  
  # Check if user can be retrieved
  if [[ "$GET_RESPONSE" != *"\"email\":\"$USER_ID@example.com\""* ]]; then
    echo "Failed to retrieve user"
    echo "Response: $GET_RESPONSE"
    return 1
  fi
  
  # 3. Update user
  UPDATE_DATA="{\"id\":\"$USER_ID\",\"name\":\"Updated Test User\"}"
  UPDATE_RESPONSE=$(make_request "POST" "/users/update" "$UPDATE_DATA")
  
  # Check if user was updated successfully
  if [[ "$UPDATE_RESPONSE" != *"\"success\":true"* ]]; then
    echo "Failed to update user"
    echo "Response: $UPDATE_RESPONSE"
    return 1
  fi
  
  echo "User operations completed successfully"
  return 0
}

# Test subscription operations
test_subscription_operations() {
  echo "Testing subscription operations..."
  
  # Generate a unique user for testing
  USER_ID="test_user_$(date +%s)"
  
  # 1. Create subscription
  SUB_DATA="{\"userId\":\"$USER_ID\",\"tierId\":\"basic\",\"startDate\":\"$(date +%Y-%m-%d)\",\"paymentId\":\"mock_payment_123\"}"
  CREATE_RESPONSE=$(make_request "POST" "/subscriptions/create" "$SUB_DATA")
  
  # Check if subscription was created successfully
  if [[ "$CREATE_RESPONSE" != *"\"success\":true"* ]]; then
    echo "Failed to create subscription"
    echo "Response: $CREATE_RESPONSE"
    return 1
  fi
  
  # 2. Get user's subscription
  GET_RESPONSE=$(make_request "GET" "/subscriptions/user/$USER_ID" "")
  
  # Check if subscription can be retrieved
  if [[ "$GET_RESPONSE" != *"\"userId\":\"$USER_ID\""* ]]; then
    echo "Failed to retrieve subscription"
    echo "Response: $GET_RESPONSE"
    return 1
  fi
  
  # 3. Update subscription
  UPDATE_DATA="{\"userId\":\"$USER_ID\",\"tierId\":\"pro\"}"
  UPDATE_RESPONSE=$(make_request "POST" "/subscriptions/update" "$UPDATE_DATA")
  
  # Check if subscription was updated successfully
  if [[ "$UPDATE_RESPONSE" != *"\"success\":true"* ]]; then
    echo "Failed to update subscription"
    echo "Response: $UPDATE_RESPONSE"
    return 1
  fi
  
  echo "Subscription operations completed successfully"
  return 0
}

# Test trial operations
test_trial_operations() {
  echo "Testing trial operations..."
  
  # Generate unique IDs for testing
  USER_ID="test_user_$(date +%s)"
  TRIAL_ID="test_trial_$(date +%s)"
  
  # 1. Create trial
  TRIAL_DATA="{\"id\":\"$TRIAL_ID\",\"userId\":\"$USER_ID\",\"serviceName\":\"Netflix\",\"status\":\"pending\",\"createdAt\":\"$(date +%Y-%m-%dT%H:%M:%S.%3NZ)\"}"
  CREATE_RESPONSE=$(make_request "POST" "/trials/create" "$TRIAL_DATA")
  
  # Check if trial was created successfully
  if [[ "$CREATE_RESPONSE" != *"\"success\":true"* ]]; then
    echo "Failed to create trial"
    echo "Response: $CREATE_RESPONSE"
    return 1
  fi
  
  # 2. Get trial
  GET_RESPONSE=$(make_request "GET" "/trials/$TRIAL_ID" "")
  
  # Check if trial can be retrieved
  if [[ "$GET_RESPONSE" != *"\"id\":\"$TRIAL_ID\""* ]]; then
    echo "Failed to retrieve trial"
    echo "Response: $GET_RESPONSE"
    return 1
  fi
  
  # 3. Update trial status
  UPDATE_DATA="{\"id\":\"$TRIAL_ID\",\"status\":\"completed\"}"
  UPDATE_RESPONSE=$(make_request "POST" "/trials/update" "$UPDATE_DATA")
  
  # Check if trial was updated successfully
  if [[ "$UPDATE_RESPONSE" != *"\"success\":true"* ]]; then
    echo "Failed to update trial"
    echo "Response: $UPDATE_RESPONSE"
    return 1
  fi
  
  # 4. Get user's trials
  USER_TRIALS_RESPONSE=$(make_request "GET" "/trials/user/$USER_ID" "")
  
  # Check if user's trials can be retrieved
  if [[ "$USER_TRIALS_RESPONSE" != *"\"userId\":\"$USER_ID\""* ]]; then
    echo "Failed to retrieve user's trials"
    echo "Response: $USER_TRIALS_RESPONSE"
    return 1
  fi
  
  echo "Trial operations completed successfully"
  return 0
}

# Test payment operations
test_payment_operations() {
  echo "Testing payment operations..."
  
  # Generate unique IDs for testing
  USER_ID="test_user_$(date +%s)"
  PAYMENT_ID="test_payment_$(date +%s)"
  
  # 1. Create payment
  PAYMENT_DATA="{\"id\":\"$PAYMENT_ID\",\"userId\":\"$USER_ID\",\"amount\":1.0,\"status\":\"pending\",\"createdAt\":\"$(date +%Y-%m-%dT%H:%M:%S.%3NZ)\"}"
  CREATE_RESPONSE=$(make_request "POST" "/payments/create" "$PAYMENT_DATA")
  
  # Check if payment was created successfully
  if [[ "$CREATE_RESPONSE" != *"\"success\":true"* ]]; then
    echo "Failed to create payment"
    echo "Response: $CREATE_RESPONSE"
    return 1
  fi
  
  # 2. Get payment
  GET_RESPONSE=$(make_request "GET" "/payments/$PAYMENT_ID" "")
  
  # Check if payment can be retrieved
  if [[ "$GET_RESPONSE" != *"\"id\":\"$PAYMENT_ID\""* ]]; then
    echo "Failed to retrieve payment"
    echo "Response: $GET_RESPONSE"
    return 1
  fi
  
  # 3. Update payment status
  UPDATE_DATA="{\"id\":\"$PAYMENT_ID\",\"status\":\"completed\",\"transactionId\":\"mock_tx_123\"}"
  UPDATE_RESPONSE=$(make_request "POST" "/payments/update" "$UPDATE_DATA")
  
  # Check if payment was updated successfully
  if [[ "$UPDATE_RESPONSE" != *"\"success\":true"* ]]; then
    echo "Failed to update payment"
    echo "Response: $UPDATE_RESPONSE"
    return 1
  fi
  
  # 4. Get user's payments
  USER_PAYMENTS_RESPONSE=$(make_request "GET" "/payments/user/$USER_ID" "")
  
  # Check if user's payments can be retrieved
  if [[ "$USER_PAYMENTS_RESPONSE" != *"\"userId\":\"$USER_ID\""* ]]; then
    echo "Failed to retrieve user's payments"
    echo "Response: $USER_PAYMENTS_RESPONSE"
    return 1
  fi
  
  echo "Payment operations completed successfully"
  return 0
}

# Run database tests
test_operation "Database Connection" test_db_connection
test_operation "User Operations" test_user_operations
test_operation "Subscription Operations" test_subscription_operations
test_operation "Trial Operations" test_trial_operations
test_operation "Payment Operations" test_payment_operations

# Summarize test results
echo ""
echo "Database Tests Completed"
echo "Passed: $TESTS_PASSED"
echo "Failed: $TESTS_FAILED"
echo "Total: $((TESTS_PASSED + TESTS_FAILED))"

if [ $TESTS_FAILED -gt 0 ]; then
  exit 1
else
  exit 0
fi