/**
 * Solana Payment Server Deployment Script
 * This script is designed to start the simplified Express server for deployment
 */

import { spawn } from 'child_process';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

console.log('Starting Solana Payment Server...');
console.log('Environment:', process.env.NODE_ENV || 'development');
console.log('Mock Mode:', process.env.SOLANA_MOCK_MODE === 'true' ? 'Enabled' : 'Disabled');

// Start the server
const server = spawn('node', ['server-express.js'], { 
  stdio: 'inherit',
  env: {
    ...process.env,
    PORT: process.env.PORT || '3000',
    SOLANA_MOCK_MODE: process.env.SOLANA_MOCK_MODE || 'true'
  }
});

server.on('error', (err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

process.on('SIGINT', () => {
  console.log('Shutting down server...');
  server.kill();
  process.exit(0);
});