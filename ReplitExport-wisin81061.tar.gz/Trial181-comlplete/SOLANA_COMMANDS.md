# Solana Payment System - Quick Reference

## Key Files

| File | Description |
|------|-------------|
| `ultra-minimal-server.js` | Standalone ES Module HTTP server |
| `ultra-minimal-test.js` | Standalone ES Module test script |
| `run-minimal-solana-esm.js` | Runner script for both server and tests |
| `run-server-esm.js` | Runner script for server only |
| `run-tests-esm.js` | Runner script for tests only |
| `setup-solana-payment.js` | Setup script to verify and configure the system |
| `solana-payment.sh` | Interactive shell script for managing the system |
| `SOLANA_PAYMENT_README.md` | Detailed documentation |

## Quick Commands

### Setup & Configuration

```bash
# Run the setup script
node setup-solana-payment.js

# Use the interactive shell menu
./solana-payment.sh
```

### Running Components

```bash
# Run server and tests together
node run-minimal-solana-esm.js

# Run server only
node run-server-esm.js

# Run tests only (with server already running)
node run-tests-esm.js
```

## Running with Node.js

If the node command is not in PATH, use the full path:

```bash
/nix/store/0akvkk9k1a7z5vjp34yz6dr91j776jhv-nodejs-20.11.1/bin/node run-minimal-solana-esm.js
```

## API Examples (curl)

### Health check
```bash
curl http://localhost:3000/health
```

### Process payment
```bash
curl -X POST http://localhost:3000/api/payment/process \
  -H "Content-Type: application/json" \
  -d '{"amount": 1.0}'
```

### Verify transaction
```bash
curl -X POST http://localhost:3000/api/payment/verify \
  -H "Content-Type: application/json" \
  -d '{"transactionId": "mock-tx-123456"}'
```

## Environment Variables

Set these in the `.env` file:

| Variable | Description | Default |
|----------|-------------|---------|
| `SOLANA_RECEIVER_PUBLIC_KEY` | Wallet to receive payments | `DUMMY_SOLANA_ADDRESS_FOR_TESTING_PURPOSES_ONLY` |
| `SOLANA_NETWORK` | Solana network | `devnet` |
| `SOLANA_MOCK_MODE` | Use mock implementation | `true` |
| `PORT` | Server port | `3000` |