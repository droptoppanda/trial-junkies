/**
 * Run minimal Solana test with server
 * This script starts the server and then runs the tests
 */

const { spawn } = require('child_process');
const path = require('path');

// Environment variables for the server
const serverEnv = {
  ...process.env,
  MOCK_SOLANA_VERIFICATION: 'true',
  SOLANA_NETWORK: 'devnet',
  SOLANA_MOCK_MODE: 'true',
  SOLANA_RECEIVER_PUBLIC_KEY: process.env.SOLANA_RECEIVER_PUBLIC_KEY || 'DUMMY_SOLANA_ADDRESS_FOR_TESTING_PURPOSES_ONLY'
};

// Start the server
console.log('Starting server...');
const server = spawn('node', ['ultra-minimal-server.js'], { 
  env: serverEnv,
  stdio: 'inherit'
});

// Handle server errors
server.on('error', (error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Wait a bit for the server to start, then run tests
console.log('Waiting for server to initialize...');
setTimeout(() => {
  console.log('Running tests...');
  const tester = spawn('node', ['ultra-minimal-test.js'], { 
    stdio: 'inherit'
  });

  // Handle test errors
  tester.on('error', (error) => {
    console.error('Failed to start tests:', error);
    server.kill();
    process.exit(1);
  });

  // Handle test completion
  tester.on('exit', (code) => {
    console.log(`Tests completed with code ${code}`);
    // Kill the server
    server.kill();
    process.exit(code);
  });
}, 2000);

// Handle process termination
process.on('SIGINT', () => {
  console.log('Process interrupted');
  server.kill();
  process.exit(1);
});