# GitHub Repository Setup Instructions

Follow these steps to connect your Replit project to GitHub:

## 1. Create a New Repository on GitHub

1. Go to [GitHub](https://github.com) and log in to your account
2. Click on the "+" icon in the top-right corner and select "New repository"
3. Enter a repository name (e.g., "solana-payment-system")
4. Add an optional description
5. Choose the repository visibility (public or private)
6. Do NOT initialize the repository with a README, .gitignore, or license
7. Click "Create repository"

## 2. Connect Your Replit Project to GitHub

After creating the repository, GitHub will show commands to connect an existing repository. Follow these steps:

### Option 1: Using GitHub CLI (if available on Replit)

```bash
gh auth login
gh repo create --source=. --public --push
```

### Option 2: Using HTTPS (Recommended)

Copy these commands from GitHub and run them in your Replit shell:

```bash
git remote add origin https://github.com/yourusername/solana-payment-system.git
git branch -M main
git push -u origin main
```

Replace `yourusername/solana-payment-system.git` with your actual GitHub repository URL.

## 3. Set Up GitHub Secrets for Deployment

For automatic deployment using GitHub Actions, set up these secrets:

1. Go to your GitHub repository
2. Click "Settings" -> "Secrets and variables" -> "Actions"
3. Click "New repository secret"
4. Add the following secrets:
   - Name: `SOLANA_RECEIVER_PUBLIC_KEY`
   - Value: Your Solana wallet public key

## 4. Verify GitHub Actions Workflow

1. Go to the "Actions" tab in your GitHub repository
2. You should see the workflow "Deploy" listed
3. The workflow will run automatically on every push to the main branch

## 5. Enable GitHub Pages (Optional)

To host the static frontend:

1. Go to "Settings" -> "Pages"
2. Under "Source", select the `gh-pages` branch
3. Click "Save"
4. Wait a few minutes and your site will be published at the URL shown

## 6. Ongoing Development

For future changes:

1. Make your changes in Replit
2. Commit the changes:
   ```bash
   git add .
   git commit -m "Description of changes"
   ```
3. Push to GitHub:
   ```bash
   git push
   ```

## Troubleshooting

- **Authentication issues**: GitHub may ask for a username and password. Use a personal access token as the password.
- **Push rejection**: If GitHub rejects your push, try `git pull --rebase origin main` first, then push again.
- **Workflow failures**: Check the Actions tab for detailed error messages.

For more help, visit [GitHub Documentation](https://docs.github.com/).