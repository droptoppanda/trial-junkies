// server.js - Express server with Solana payment integration

import express from 'express';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { registerSolanaRoutes } from './server/solanaPaymentRoutes.js';
import { solanaPaymentService } from './server/solanaPaymentService.js';

// Load environment variables
dotenv.config();

// Setup for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express application
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set environment variables if not already set
if (!process.env.SOLANA_NETWORK) {
  process.env.SOLANA_NETWORK = 'devnet';
  console.log('SOLANA_NETWORK not set, defaulting to devnet');
}

if (!process.env.MOCK_SOLANA_VERIFICATION) {
  process.env.MOCK_SOLANA_VERIFICATION = 'true';
  console.log('MOCK_SOLANA_VERIFICATION not set, enabling mock mode');
}

// Register Solana payment routes
registerSolanaRoutes(app);

// Define routes
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Solana Trial Automation System</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        h1 { color: #333; }
        .container { max-width: 800px; margin: 0 auto; }
        .card { border: 1px solid #ddd; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
        .status { display: inline-block; padding: 5px 10px; border-radius: 3px; font-size: 14px; }
        .status.ok { background: #d4edda; color: #155724; }
        .status.error { background: #f8d7da; color: #721c24; }
        .code { font-family: monospace; background: #f8f9fa; padding: 2px 5px; border-radius: 3px; }
        button { 
          background: #4CAF50; color: white; border: none; padding: 10px 15px; 
          border-radius: 4px; cursor: pointer; font-size: 16px; 
        }
        button:hover { background: #45a049; }
        input { padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; width: 100px; }
        #paymentForm { margin-bottom: 20px; }
        #paymentResults { display: none; margin-top: 20px; background: #f8f9fa; padding: 15px; border-radius: 5px; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Solana Trial Automation System</h1>
        
        <div class="card">
          <h2>System Status</h2>
          <p><strong>Server:</strong> <span class="status ok">Running</span></p>
          <p><strong>Environment:</strong> ${process.env.NODE_ENV || 'development'}</p>
          <p><strong>Solana Network:</strong> ${process.env.SOLANA_NETWORK || 'Not configured'}</p>
          <p><strong>Mock Mode:</strong> ${process.env.MOCK_SOLANA_VERIFICATION === 'true' ? 'Enabled' : 'Disabled'}</p>
          <p><strong>Receiver Address:</strong> <span class="code">${solanaPaymentService.maskAddress(solanaPaymentService.receiverPublicKey)}</span></p>
        </div>
        
        <div class="card">
          <h2>Test Payment</h2>
          <div id="paymentForm">
            <label for="amount">Amount (SOL):</label>
            <input type="number" id="amount" value="0.01" min="0.001" step="0.001" />
            <button onclick="processPayment()">Process Payment</button>
          </div>
          <div id="paymentResults"></div>
        </div>
        
        <div class="card">
          <h2>Configuration</h2>
          <p><strong>Node.js Version:</strong> ${process.version}</p>
          <p><strong>Platform:</strong> ${process.platform}</p>
          <p><strong>Port:</strong> ${process.env.PORT || 3000}</p>
        </div>
        
        <div class="card">
          <h2>Available API Endpoints</h2>
          <ul>
            <li><code>/api/health</code> - Check system health</li>
            <li><code>/api/info</code> - Server information</li>
            <li><code>/api/payment/health</code> - Payment service health</li>
            <li><code>/api/payment/instructions</code> - Get payment instructions</li>
            <li><code>/api/payment/process</code> - Process a payment</li>
            <li><code>/api/payment/verify/:transactionId</code> - Verify a transaction</li>
          </ul>
        </div>
      </div>

      <script>
        async function processPayment() {
          const amount = document.getElementById('amount').value;
          const resultsDiv = document.getElementById('paymentResults');
          
          resultsDiv.innerHTML = 'Processing payment...';
          resultsDiv.style.display = 'block';
          
          try {
            // Process payment
            const paymentResponse = await fetch('/api/payment/process', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ amount })
            });
            
            const paymentData = await paymentResponse.json();
            
            if (paymentData.success) {
              resultsDiv.innerHTML = '<h3>Payment Initiated</h3>' +
                '<p><strong>Transaction ID:</strong> ' + paymentData.transactionId + '</p>' +
                '<p><strong>Amount:</strong> ' + paymentData.amount + ' SOL</p>' +
                '<p><strong>Status:</strong> ' + paymentData.status + '</p>' +
                '<button onclick="verifyTransaction(\'' + paymentData.transactionId + '\')">Verify Transaction</button>';
            } else {
              resultsDiv.innerHTML = '<h3>Payment Failed</h3>' +
                '<p><strong>Error:</strong> ' + paymentData.error + '</p>';
            }
          } catch (error) {
            resultsDiv.innerHTML = '<h3>Error</h3>' +
              '<p><strong>Error:</strong> ' + error.message + '</p>';
          }
        }
        
        async function verifyTransaction(transactionId) {
          const resultsDiv = document.getElementById('paymentResults');
          
          resultsDiv.innerHTML = 'Verifying transaction...';
          
          try {
            // Verify transaction
            const verifyResponse = await fetch('/api/payment/verify/' + transactionId);
            const verifyData = await verifyResponse.json();
            
            if (verifyData.success) {
              resultsDiv.innerHTML = '<h3>Transaction Verified</h3>' +
                '<p><strong>Transaction ID:</strong> ' + verifyData.transactionId + '</p>' +
                '<p><strong>Confirmed:</strong> ' + (verifyData.confirmed ? 'Yes' : 'No') + '</p>' +
                '<p><strong>Confirmations:</strong> ' + verifyData.confirmations + '</p>' +
                '<p><strong>Timestamp:</strong> ' + verifyData.timestamp + '</p>' +
                '<button onclick="processPayment()">New Payment</button>';
            } else {
              resultsDiv.innerHTML = '<h3>Verification Failed</h3>' +
                '<p><strong>Error:</strong> ' + verifyData.error + '</p>' +
                '<button onclick="verifyTransaction(\'' + transactionId + '\')">Try Again</button>';
            }
          } catch (error) {
            resultsDiv.innerHTML = '<h3>Error</h3>' +
              '<p><strong>Error:</strong> ' + error.message + '</p>' +
              '<button onclick="verifyTransaction(\'' + transactionId + '\')">Try Again</button>';
          }
        }
      </script>
    </body>
    </html>
  `);
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV || 'development',
    solanaNetwork: process.env.SOLANA_NETWORK || 'Not configured',
    mockMode: process.env.MOCK_SOLANA_VERIFICATION === 'true'
  });
});

// Server info endpoint
app.get('/api/info', (req, res) => {
  res.json({
    nodejs: process.version,
    platform: process.platform,
    env: process.env.NODE_ENV || 'development',
    port: process.env.PORT || 3000
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`Solana Network: ${process.env.SOLANA_NETWORK || 'devnet'}`);
  console.log(`Mock Mode: ${process.env.MOCK_SOLANA_VERIFICATION === 'true' ? 'Enabled' : 'Disabled'}`);
});