#!/bin/bash
export NODE_PATH="/mnt/nixmodules/nix/store/wfxq6w9bkp5dcfr8yb6789b0w7128gnb-nodejs-20.18.1/bin/node"
$NODE_PATH simple-server.js