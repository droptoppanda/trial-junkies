# Solana Payment System

A modern blockchain payment solution that provides a simple way to accept and verify Solana cryptocurrency payments. This project includes a comprehensive web interface and API endpoints for payment processing.

## Features

- **Payment Creation**: Generate payment instructions with Solana wallet addresses
- **Transaction Verification**: Check the status of payments
- **Mock Mode**: Test the system without real blockchain transactions
- **Interactive UI**: User-friendly interface for testing payments
- **RESTful API**: Easy integration with other applications

## Technology Stack

- **Backend**: Node.js with Express
- **Frontend**: HTML, CSS, JavaScript
- **Blockchain**: Solana integration
- **Storage**: In-memory transaction storage (can be extended for database persistence)

## Demo

![Solana Payment Demo](https://via.placeholder.com/800x400?text=Solana+Payment+System)

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Check server health |
| GET | `/api/config` | Get system configuration |
| POST | `/api/payment/create` | Create a new payment |
| GET | `/api/payment/verify/:transactionId` | Verify payment status |
| GET | `/api/transactions` | List all transactions |

## Quick Start

### Prerequisites

- Node.js (v18+)
- npm or yarn

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/solana-payment-system.git
   cd solana-payment-system
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Configure environment variables:
   - Copy `.env.example` to `.env`
   - Adjust settings as needed (see Environment Variables section)

4. Start the server:
   ```
   node server-express.js
   ```

5. Open your browser to `http://localhost:3000`

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `PORT` | Port number for the server | `3000` |
| `NODE_ENV` | Environment (development/production) | `development` |
| `SOLANA_NETWORK` | Solana network (devnet/testnet/mainnet) | `devnet` |
| `SOLANA_MOCK_MODE` | Enable mock mode (no real transactions) | `true` |
| `SOLANA_RECEIVER_PUBLIC_KEY` | Your Solana wallet address | - |

## Deployment

For detailed deployment instructions, please see [DEPLOYMENT.md](DEPLOYMENT.md).

## Development

### Project Structure

```
/
├── public/             # Static files
│   └── index.html      # Main web interface
├── server-express.js   # Express server and API
├── run-deploy.sh       # Deployment script
└── .env.example        # Example environment configuration
```

### Mock Mode

In development, you can use mock mode to simulate transactions without connecting to the Solana blockchain. Set `SOLANA_MOCK_MODE=true` in your `.env` file.

When mock mode is enabled:
- The system generates random transaction IDs
- Verification has an 80% chance of confirming a pending transaction
- No real blockchain interactions occur

### Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Solana Blockchain
- Express.js Team
- All open-source contributors

---

For more information on Solana development, visit [Solana Documentation](https://docs.solana.com/).