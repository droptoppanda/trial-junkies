# Solana Payment Integration

This document provides technical details about the Solana payment integration in this application.

## Overview

The Solana payment system enables cryptocurrency payments using the Solana blockchain. The system supports:

- Payment creation with specific amounts
- Transaction verification
- Mock mode for testing without real blockchain interactions
- Support for multiple Solana networks (devnet, testnet, mainnet)

## API Endpoints

### Create Payment

```
POST /api/payment/create
```

Request body:
```json
{
  "amount": 1.5,
  "currency": "SOL",
  "metadata": {
    "orderId": "12345",
    "description": "Subscription payment"
  }
}
```

Response:
```json
{
  "success": true,
  "transaction": {
    "id": "tx_123456789",
    "receiverAddress": "your_solana_wallet_address",
    "amount": 1.5,
    "status": "pending",
    "currency": "SOL",
    "createdAt": "2023-05-01T12:34:56Z",
    "metadata": {
      "orderId": "12345",
      "description": "Subscription payment"
    }
  }
}
```

### Verify Transaction

```
GET /api/payment/verify/:transactionId
```

Response:
```json
{
  "success": true,
  "transaction": {
    "id": "tx_123456789",
    "receiverAddress": "your_solana_wallet_address",
    "amount": 1.5,
    "status": "confirmed",
    "currency": "SOL",
    "createdAt": "2023-05-01T12:34:56Z",
    "confirmedAt": "2023-05-01T12:36:45Z",
    "metadata": {
      "orderId": "12345",
      "description": "Subscription payment"
    }
  }
}
```

### List Transactions

```
GET /api/transactions
```

Response:
```json
{
  "success": true,
  "transactions": [
    {
      "id": "tx_123456789",
      "receiverAddress": "your_solana_wallet_address",
      "amount": 1.5,
      "status": "confirmed",
      "currency": "SOL",
      "createdAt": "2023-05-01T12:34:56Z",
      "confirmedAt": "2023-05-01T12:36:45Z",
      "metadata": {
        "orderId": "12345",
        "description": "Subscription payment"
      }
    },
    {
      "id": "tx_987654321",
      "receiverAddress": "your_solana_wallet_address",
      "amount": 2.0,
      "status": "pending",
      "currency": "SOL",
      "createdAt": "2023-05-01T13:00:00Z",
      "metadata": {
        "orderId": "12346",
        "description": "One-time payment"
      }
    }
  ]
}
```

## Configuration

### Environment Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| `SOLANA_NETWORK` | Solana network (devnet/testnet/mainnet) | Yes | devnet |
| `SOLANA_MOCK_MODE` | Enable mock mode (no real transactions) | No | true |
| `SOLANA_RECEIVER_PUBLIC_KEY` | Your Solana wallet address | Yes* | - |

*Required in production, optional in development with mock mode enabled

### Mock Mode

When `SOLANA_MOCK_MODE=true`:

- The system generates random transaction IDs
- No real blockchain interactions occur
- Verification has an 80% chance of confirming a pending transaction
- Useful for testing without real SOL tokens

## Integration Example

### Frontend JavaScript

```javascript
// Create a payment
async function createPayment() {
  const response = await fetch('/api/payment/create', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      amount: 1.5,
      currency: 'SOL',
      metadata: {
        orderId: '12345',
        description: 'Subscription payment'
      }
    })
  });
  
  const data = await response.json();
  return data.transaction;
}

// Verify a transaction
async function verifyTransaction(transactionId) {
  const response = await fetch(`/api/payment/verify/${transactionId}`);
  const data = await response.json();
  return data.transaction;
}
```

### Node.js Backend

```javascript
import express from 'express';
import fetch from 'node-fetch';

const app = express();
app.use(express.json());

// Create a payment
app.post('/create-payment', async (req, res) => {
  try {
    const { amount } = req.body;
    
    const response = await fetch('https://your-app-url/api/payment/create', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ amount, currency: 'SOL' })
    });
    
    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Verify a transaction
app.get('/verify-payment/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const response = await fetch(`https://your-app-url/api/payment/verify/${id}`);
    const data = await response.json();
    
    res.json(data);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
```

## Production Considerations

1. **Security**
   - Always use HTTPS in production
   - Validate payment amounts to prevent fraud
   - Implement rate limiting to prevent abuse

2. **Wallet Management**
   - Secure your wallet private key
   - Consider using a hardware wallet for large transactions
   - Regularly check wallet activity

3. **Error Handling**
   - Implement proper error handling for blockchain interactions
   - Handle network failures gracefully
   - Monitor transaction confirmations

4. **Scaling**
   - Implement a database for transaction storage in production
   - Use a queue system for transaction processing
   - Consider a dedicated server for high-volume applications