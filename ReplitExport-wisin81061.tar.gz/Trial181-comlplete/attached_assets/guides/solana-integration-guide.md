# Solana Payment Integration Guide

This guide explains how to set up and use the Solana payment integration in the application.

## Overview

The Solana payment module allows users to pay for subscriptions and services using Solana (SOL) cryptocurrency. The module supports both real Solana blockchain transactions and a mock mode for testing without real cryptocurrency.

## Configuration

### Environment Variables

Set the following environment variables in your `.env` file:

```
# Solana Configuration
SOLANA_RECEIVER_PUBLIC_KEY=yourWalletAddress    # Your Solana wallet address
SOLANA_NETWORK=devnet                           # Network: mainnet, devnet, testnet 
SOLANA_MOCK_MODE=false                          # Enable mock mode (true/false)
MOCK_SOLANA_VERIFICATION=false                  # Mock transaction verification (true/false)
```

### Testing Configuration

For development and testing, use these settings:

```
SOLANA_NETWORK=devnet
SOLANA_MOCK_MODE=true
MOCK_SOLANA_VERIFICATION=true
```

This allows you to test the payment flow without real cryptocurrency.

## Architecture

The Solana payment module consists of three main components:

1. **Server: SolanaPaymentService** - Core functionality for creating and verifying payments
2. **Server: SolanaPaymentRoutes** - API endpoints for payment operations
3. **Client: CryptoPayment Component** - User interface for cryptocurrency payments

### Payment Flow

1. User initiates payment from the frontend
2. Backend creates a payment request with unique ID
3. User sends the specified amount of SOL to the receiver address
4. User submits the transaction ID for verification
5. Backend verifies the transaction details
6. Payment is marked as confirmed if verification succeeds

## API Endpoints

### Create Payment Request

```
POST /api/payments/create
```

**Request Body**:
```json
{
  "amount": 1.0,
  "metadata": {
    "userId": "user123",
    "purpose": "subscription"
  }
}
```

**Response**:
```json
{
  "success": true,
  "paymentRequest": {
    "paymentId": "payment_1234567890",
    "amount": 1.0,
    "receiverAddress": "YourSolanaWalletAddress",
    "network": "devnet",
    "mockMode": false,
    "instructions": [
      "Send 1.0 SOL to YourSolanaWalletAddress",
      "Copy your transaction ID",
      "Submit the transaction ID for verification"
    ]
  }
}
```

### Verify Transaction

```
POST /api/payments/verify
```

**Request Body**:
```json
{
  "transactionId": "solana_tx_id_here",
  "amount": 1.0,
  "paymentId": "payment_1234567890"
}
```

**Response**:
```json
{
  "success": true,
  "verified": true,
  "amount": 1.0,
  "timestamp": "2023-04-15T12:34:56Z"
}
```

### Check Payment Status

```
GET /api/payments/status/:paymentId
```

**Response**:
```json
{
  "success": true,
  "paymentId": "payment_1234567890",
  "status": "confirmed",
  "amount": 1.0,
  "createdAt": "2023-04-15T12:30:00Z",
  "verifiedAt": "2023-04-15T12:35:00Z",
  "transactionId": "solana_tx_id_here"
}
```

## Using the Solana Payment Service

### Server-side Usage

```typescript
import { solanaPaymentService } from './solanaPaymentService';

// Create a payment request
const paymentRequest = solanaPaymentService.createPaymentRequest(1.0, {
  userId: 'user123',
  purpose: 'subscription'
});

// Verify a transaction
const verificationResult = await solanaPaymentService.verifyTransaction(
  'transaction_id_here',
  1.0,
  'payment_id_here'
);

// Check payment status
const status = solanaPaymentService.getPaymentStatus('payment_id_here');
```

### Client-side Usage

```typescript
// Make API request to create payment
const response = await fetch('/api/payments/create', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ 
    amount: 1.0,
    metadata: { userId: 'user123' } 
  })
});

const { paymentRequest } = await response.json();

// After user completes payment, verify it
const verifyResponse = await fetch('/api/payments/verify', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    transactionId: 'user_provided_tx_id',
    amount: paymentRequest.amount,
    paymentId: paymentRequest.paymentId
  })
});
```

## Troubleshooting

### Common Issues

1. **Wallet Address Not Set**
   - Error: "Solana receiver address is not configured"
   - Solution: Set the SOLANA_RECEIVER_PUBLIC_KEY environment variable

2. **Transaction Verification Failed**
   - Error: "Transaction verification failed"
   - Solutions:
     - Check if the transaction exists on the blockchain
     - Verify the correct amount was sent
     - Ensure the receiver address matches

3. **Network Connectivity**
   - Error: "Failed to connect to Solana network"
   - Solutions:
     - Check internet connectivity
     - Verify the SOLANA_NETWORK setting is correct

### Diagnostic Tool

Use the included diagnostic script to check your Solana configuration:

```bash
chmod +x test-scripts/check-solana-setup.sh
./test-scripts/check-solana-setup.sh
```

This will verify your environment variables and configuration.

## Security Considerations

1. Always verify transaction amounts match expected values
2. Use HTTPS for all API endpoints
3. Implement rate limiting to prevent payment verification abuse
4. Store payment records securely in the database

## Mock Mode vs. Real Mode

### Mock Mode

- Enabled by setting `SOLANA_MOCK_MODE=true` or `MOCK_SOLANA_VERIFICATION=true`
- No real cryptocurrency is transferred
- Transaction verification always succeeds
- Useful for development and testing

### Real Mode

- Enabled by setting both mock flags to `false`
- Requires a valid Solana wallet address
- Performs actual blockchain verification
- Should be used in production with mainnet

## Support

For questions about the Solana payment integration, contact the development team or check the internal documentation.