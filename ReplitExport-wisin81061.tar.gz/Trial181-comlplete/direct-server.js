/**
 * Direct Server Runner
 * This script directly imports and runs the server code
 */

import fs from 'fs';
import http from 'http';
import { parse as parseUrl } from 'url';

// Load environment variables from .env file if available
try {
  const envFile = fs.readFileSync('.env', 'utf8');
  const envVars = envFile.split('\n');
  
  for (const line of envVars) {
    if (line.trim() && !line.startsWith('#')) {
      const [key, value] = line.split('=');
      if (key && value) {
        process.env[key.trim()] = value.trim().replace(/^["'](.*)["']$/, '$1');
      }
    }
  }
} catch (error) {
  console.log('No .env file found or error reading it, using default values');
}

// Environment variables check
const requiredEnvVars = [
  'SOLANA_RECEIVER_PUBLIC_KEY',
  'SOLANA_NETWORK',
  'SOLANA_MOCK_MODE'
];

const missingEnvVars = requiredEnvVars.filter(varName => !process.env[varName]);
if (missingEnvVars.length > 0) {
  console.warn(`Warning: Missing environment variables: ${missingEnvVars.join(', ')}`);
  console.warn('Using mock mode for all services');
  process.env.SOLANA_MOCK_MODE = 'true';
  process.env.SOLANA_NETWORK = 'devnet';
  if (!process.env.SOLANA_RECEIVER_PUBLIC_KEY) {
    process.env.SOLANA_RECEIVER_PUBLIC_KEY = 'DUMMY_SOLANA_ADDRESS_FOR_TESTING_PURPOSES_ONLY';
  }
}

// Mock Solana payment service
const solanaPaymentService = {
  processPayment: async (amount) => {
    console.log(`[MOCK] Processing payment of ${amount} SOL`);
    // Simulate a successful transaction
    return {
      success: true,
      transactionId: 'mock-tx-' + Math.random().toString(36).substring(2, 15),
      amount: amount
    };
  },
  
  verifyTransaction: async (transactionId) => {
    console.log(`[MOCK] Verifying transaction ${transactionId}`);
    // Simulate transaction verification
    return {
      success: true,
      verified: true,
      amount: 1.0,
      timestamp: new Date().toISOString()
    };
  }
};

// Simple JSON request body parser
const parseRequestBody = (req) => {
  return new Promise((resolve, reject) => {
    let body = '';
    
    req.on('data', (chunk) => {
      body += chunk.toString();
    });
    
    req.on('end', () => {
      try {
        const data = body ? JSON.parse(body) : {};
        resolve(data);
      } catch (error) {
        reject(error);
      }
    });
  });
};

// Handle HTTP requests
const requestHandler = async (req, res) => {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return;
  }
  
  // Parse the URL
  const parsedUrl = parseUrl(req.url, true);
  const path = parsedUrl.pathname;
  
  // Set default content type
  res.setHeader('Content-Type', 'application/json');
  
  try {
    // Route handling
    if (path === '/' && req.method === 'GET') {
      res.statusCode = 200;
      res.end('Ultra Minimal Solana Payment Server Running');
      return;
    }
    
    if (path === '/health' && req.method === 'GET') {
      const healthData = {
        status: 'ok',
        environment: {
          solanaNetwork: process.env.SOLANA_NETWORK || 'devnet',
          mockMode: process.env.SOLANA_MOCK_MODE === 'true',
          receiverPublicKey: process.env.SOLANA_RECEIVER_PUBLIC_KEY ? 
            process.env.SOLANA_RECEIVER_PUBLIC_KEY.substring(0, 4) + '...' : 'not set'
        },
        time: new Date().toISOString()
      };
      
      res.statusCode = 200;
      res.end(JSON.stringify(healthData));
      return;
    }
    
    if (path === '/api/payment/process' && req.method === 'POST') {
      const body = await parseRequestBody(req);
      
      if (!body.amount || isNaN(parseFloat(body.amount))) {
        res.statusCode = 400;
        res.end(JSON.stringify({
          success: false,
          error: 'Invalid amount. Please provide a valid number.'
        }));
        return;
      }
      
      const result = await solanaPaymentService.processPayment(parseFloat(body.amount));
      res.statusCode = 200;
      res.end(JSON.stringify(result));
      return;
    }
    
    if (path === '/api/payment/verify' && req.method === 'POST') {
      const body = await parseRequestBody(req);
      
      if (!body.transactionId) {
        res.statusCode = 400;
        res.end(JSON.stringify({
          success: false,
          error: 'Missing transaction ID'
        }));
        return;
      }
      
      const result = await solanaPaymentService.verifyTransaction(body.transactionId);
      res.statusCode = 200;
      res.end(JSON.stringify(result));
      return;
    }
    
    // Route not found
    res.statusCode = 404;
    res.end(JSON.stringify({
      success: false,
      error: 'Not found'
    }));
    
  } catch (error) {
    console.error('Server error:', error);
    res.statusCode = 500;
    res.end(JSON.stringify({
      success: false,
      error: 'Internal server error'
    }));
  }
};

// Create and start the server
const PORT = process.env.PORT || 3000;
const server = http.createServer(requestHandler);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Direct Solana server running on port ${PORT}`);
  console.log(`Server mode: ${process.env.SOLANA_MOCK_MODE === 'true' ? 'MOCK' : 'PRODUCTION'}`);
  console.log(`Solana network: ${process.env.SOLANA_NETWORK || 'devnet'}`);
});

// Handle process termination
process.on('SIGINT', () => {
  console.log('\nReceived SIGINT. Shutting down server...');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

console.log("Server started. Press Ctrl+C to stop.");