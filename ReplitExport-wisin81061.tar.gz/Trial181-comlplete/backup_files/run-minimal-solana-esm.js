/**
 * Run Minimal Solana Test (ESM version)
 * This script starts the server and then runs the tests
 */

import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

// Get the directory name of the current module (equivalent to __dirname in CommonJS)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Set environment variables
process.env.SOLANA_NETWORK = 'devnet';
process.env.SOLANA_MOCK_MODE = 'true';
process.env.SOLANA_RECEIVER_PUBLIC_KEY = 'DRQgX8fNwNkAyHjvYyVmG3gB9MjSVSCKYxdrKAWvfKrV'; // Example address

// Start the server
console.log('Starting minimal server...');
const serverProcess = spawn(process.execPath, [path.join(__dirname, 'ultra-minimal-server.js')], {
  stdio: 'inherit',
  detached: false
});

// Wait for the server to start
console.log('Waiting for server to start...');
setTimeout(() => {
  console.log('Starting tests...');
  
  // Start the test process
  const testProcess = spawn(process.execPath, [path.join(__dirname, 'ultra-minimal-test.js')], {
    stdio: 'inherit',
    detached: false
  });
  
  // Handle test process exit
  testProcess.on('exit', (code) => {
    console.log(`Test process exited with code ${code}`);
    
    // Kill the server process when tests are done
    if (serverProcess) {
      console.log('Shutting down server...');
      serverProcess.kill('SIGTERM');
    }
    
    // Exit with the same code as the test process
    process.exit(code);
  });
}, 3000); // Wait 3 seconds for the server to start

// Handle server process exit
serverProcess.on('exit', (code) => {
  console.log(`Server process exited with code ${code}`);
  process.exit(code);
});

// Handle process termination
process.on('SIGINT', () => {
  console.log('Received SIGINT. Cleaning up...');
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
  }
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('Received SIGTERM. Cleaning up...');
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
  }
  process.exit(0);
});