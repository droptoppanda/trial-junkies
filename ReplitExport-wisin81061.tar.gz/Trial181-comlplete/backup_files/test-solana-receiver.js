/**
 * Test script for Solana receiver wallet address configuration
 * 
 * This script tests whether the SOLANA_RECEIVER_PUBLIC_KEY environment variable
 * is properly set and valid.
 */

import bs58 from 'bs58';

/**
 * Validate Solana public key format
 * @param {string} publicKeyString - Public key to validate
 * @returns {boolean} - Whether the key is valid
 */
function isValidSolanaPublicKey(publicKeyString) {
  if (!publicKeyString || typeof publicKeyString !== 'string') {
    return false;
  }
  
  // Solana addresses are base58 encoded and 32-44 characters long
  if (publicKeyString.length < 32 || publicKeyString.length > 44) {
    return false;
  }
  
  try {
    // Try to decode the base58 string
    const decoded = bs58.decode(publicKeyString);
    
    // Valid Solana public keys are 32 bytes
    return decoded.length === 32;
  } catch (error) {
    return false;
  }
}

/**
 * Test Solana receiver configuration
 */
async function testSolanaReceiver() {
  console.log('======= Testing Solana Receiver Configuration =======');
  
  const receiverPublicKey = process.env.SOLANA_RECEIVER_PUBLIC_KEY;
  console.log(`SOLANA_RECEIVER_PUBLIC_KEY: ${receiverPublicKey || 'Not set'}`);
  
  if (!receiverPublicKey) {
    console.error('ERROR: SOLANA_RECEIVER_PUBLIC_KEY environment variable is not set');
    console.error('Set a valid Solana public key as the SOLANA_RECEIVER_PUBLIC_KEY environment variable');
    return false;
  }
  
  const isValid = isValidSolanaPublicKey(receiverPublicKey);
  console.log(`Is valid Solana public key: ${isValid ? 'YES' : 'NO'}`);
  
  if (!isValid) {
    console.error('ERROR: The provided public key is not a valid Solana address');
    console.error('Please set a valid Solana public key as the SOLANA_RECEIVER_PUBLIC_KEY environment variable');
    return false;
  }
  
  // Simulate a payment endpoint
  console.log('\nSimulating payment endpoint...');
  const result = await simulatePaymentEndpoint({
    transactionId: 'mock_test_transaction',
    amount: 1.5
  });
  
  console.log(`Endpoint simulation: ${result.success ? 'SUCCESS' : 'FAILED'}`);
  if (!result.success) {
    console.error(`Error: ${result.error}`);
  }
  
  console.log('\n======= Solana Receiver Configuration Test Complete =======');
  return isValid && result.success;
}

/**
 * Simulate payment endpoint to test configuration
 * @param {Object} transaction - Transaction data
 * @returns {Object} - Simulation result
 */
async function simulatePaymentEndpoint(transaction) {
  const receiverPublicKey = process.env.SOLANA_RECEIVER_PUBLIC_KEY;
  
  // Check configuration
  if (!receiverPublicKey || !isValidSolanaPublicKey(receiverPublicKey)) {
    return {
      success: false,
      error: 'Solana payment service is not properly configured'
    };
  }
  
  // Check transaction format
  if (!transaction.transactionId || !transaction.transactionId.startsWith('mock_')) {
    return {
      success: false,
      error: 'Invalid transaction ID format for mock verification'
    };
  }
  
  return {
    success: true,
    verified: true,
    message: 'Payment endpoint is correctly configured'
  };
}

// Run the test
testSolanaReceiver()
  .then(success => {
    if (success) {
      console.log('\nSolana receiver configuration is valid and working correctly.');
    } else {
      console.error('\nSolana receiver configuration has issues that need to be addressed.');
    }
  })
  .catch(error => {
    console.error('Test failed with error:', error);
  });