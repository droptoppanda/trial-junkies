// Using CommonJS for debugging
const express = require('express');
const app = express();

// Set up middleware
app.use(express.json());

// Basic routes
app.get('/', (req, res) => {
  res.send('Server is running!');
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Start server
const PORT = process.env.PORT || 3000;
try {
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Debug server listening at http://localhost:${PORT}`);
  });
} catch (error) {
  console.error('Failed to start server:', error);
}