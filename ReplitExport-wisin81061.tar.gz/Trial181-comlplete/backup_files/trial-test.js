// Simple trial automation test
import puppeteer from 'puppeteer';

async function testTrialAutomation() {
  console.log('=== Starting Trial Automation Test ===');
  
  let browser;
  
  try {
    // 1. Launch browser for testing
    console.log('1. Launching browser for testing...');
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
    });
    
    const page = await browser.newPage();
    
    // Enable console log collection
    page.on('console', (msg) => console.log('BROWSER:', msg.text()));
    
    console.log('✅ Browser launched successfully');
    
    // 2. Load a test page
    console.log('\n2. Loading test page...');
    await page.goto('https://example.com', { waitUntil: 'networkidle2' });
    
    const pageTitle = await page.title();
    console.log(`   Loaded page: ${pageTitle}`);
    
    console.log('✅ Test page loaded successfully');
    
    // 3. Test form filling
    console.log('\n3. Testing form filling capability...');
    
    // Create a test form on the page
    await page.evaluate(() => {
      const form = document.createElement('form');
      form.innerHTML = `
        <input type="text" id="username" placeholder="Username">
        <input type="email" id="email" placeholder="Email">
        <button type="submit" id="submit">Submit</button>
      `;
      document.body.appendChild(form);
      
      // Add form submission handler
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const result = document.createElement('div');
        result.id = 'form-result';
        result.textContent = 'Form submitted successfully!';
        document.body.appendChild(result);
      });
    });
    
    // Fill out the form fields
    await page.type('#username', 'testuser');
    await page.type('#email', 'test@example.com');
    
    // Submit the form
    await Promise.all([
      page.waitForSelector('#form-result'),
      page.click('#submit')
    ]);
    
    // Verify form submission
    const formResult = await page.evaluate(() => {
      const result = document.querySelector('#form-result');
      return result ? result.textContent : null;
    });
    
    if (formResult === 'Form submitted successfully!') {
      console.log('✅ Form automation test passed');
    } else {
      console.error('❌ Form automation test failed');
    }
    
    // Clean up
    await browser.close();
    console.log('\n=== Trial Automation Test Completed ===');
    return true;
  } catch (error) {
    console.error('Error during test:', error);
    if (browser) await browser.close();
    return false;
  }
}

// Run the test
testTrialAutomation().then(success => {
  if (success) {
    console.log('✅ All tests passed!');
  } else {
    console.error('❌ Test failed!');
    process.exit(1);
  }
}).catch(err => {
  console.error('Fatal error during test execution:', err);
  process.exit(1);
});