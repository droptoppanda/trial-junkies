// Enhanced Express server with Solana payment and SMS verification integration
const express = require('express');
const path = require('path');
const { registerSolanaRoutes } = require('./server/solanaPaymentRoutes');
const { registerSmsRoutes } = require('./server/smsVerificationRoutes');
const solanaPaymentService = require('./server/solanaPaymentService');
const smsVerificationService = require('./server/smsVerificationService');
const app = express();
const PORT = process.env.PORT || 5000;

// Set mock mode for testing in non-production environments
if (process.env.NODE_ENV !== 'production') {
  process.env.MOCK_SOLANA_VERIFICATION = 'true';
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Serve static files
app.use(express.static(path.join(__dirname, 'client/dist')));

// API endpoints
app.get('/api/health', (req, res) => {
  // Include service configuration status in health check
  const solanaStatus = solanaPaymentService.isConfigured() 
    ? 'configured' 
    : 'not-configured';
  
  res.json({ 
    status: 'ok', 
    time: new Date().toISOString(),
    services: {
      solana: solanaStatus,
      sms: 'configured' // SMS always works in mock mode
    }
  });
});

// Register API Routes
registerSolanaRoutes(app);
registerSmsRoutes(app);

// Trial creation endpoint
app.post('/api/trials/create', (req, res) => {
  const { userId, serviceName, serviceUrl, credentials } = req.body;
  
  if (!serviceName || !serviceUrl) {
    return res.status(400).json({ success: false, error: 'Service information is required' });
  }
  
  const trialId = Date.now().toString();
  
  res.json({
    success: true,
    trialId,
    status: 'pending',
    createdAt: new Date().toISOString()
  });
});

// Subscription tier information endpoint
app.get('/api/subscription/tiers', (req, res) => {
  res.json({
    success: true,
    tiers: [
      {
        id: 'basic',
        name: 'Basic',
        price: 1.0,
        currency: 'SOL',
        trialsPerMonth: 5,
        features: [
          'Basic trial automation',
          'Single provider SMS verification',
          'Standard CAPTCHA solving',
          'Email verification'
        ]
      },
      {
        id: 'pro',
        name: 'Pro',
        price: 5.0,
        currency: 'SOL',
        trialsPerMonth: 25,
        features: [
          'Advanced trial automation',
          'Multi-provider SMS verification',
          'Premium CAPTCHA solving',
          'Email verification with custom domains',
          'Priority proxy access'
        ]
      },
      {
        id: 'enterprise',
        name: 'Enterprise',
        price: 10.0,
        currency: 'SOL',
        trialsPerMonth: 'Unlimited',
        features: [
          'Full-featured trial automation',
          'Multi-provider SMS with automatic fallback',
          'Enterprise CAPTCHA solving',
          'Custom domain emails with DKIM/SPF',
          'Dedicated residential proxies',
          'Bulk trial execution',
          'API access'
        ]
      }
    ]
  });
});

// Serve the React app for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'client/dist/index.html'));
});

// Check for Solana configuration and notify on startup
if (!solanaPaymentService.isConfigured()) {
  console.warn('WARNING: Solana payment service is not properly configured.');
  console.warn('Set SOLANA_RECEIVER_PUBLIC_KEY environment variable to enable payments.');
} else {
  console.log('Solana payment service configured successfully.');
}

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});