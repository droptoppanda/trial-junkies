// Minimal Express server with Solana payment integration
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');

// Load environment variables from .env file
dotenv.config();

const app = express();

// Basic middleware
app.use(express.json());
app.use(cors());

// Environment variables check
const requiredEnvVars = [
  'SOLANA_RECEIVER_PUBLIC_KEY',
  'SOLANA_NETWORK',
  'SOLANA_MOCK_MODE'
];

const missingEnvVars = requiredEnvVars.filter(varName => !process.env[varName]);
if (missingEnvVars.length > 0) {
  console.warn(`Warning: Missing environment variables: ${missingEnvVars.join(', ')}`);
  console.warn('Using mock mode for all services');
  process.env.SOLANA_MOCK_MODE = 'true';
  process.env.SOLANA_NETWORK = 'devnet';
  if (!process.env.SOLANA_RECEIVER_PUBLIC_KEY) {
    process.env.SOLANA_RECEIVER_PUBLIC_KEY = 'DUMMY_SOLANA_ADDRESS_FOR_TESTING_PURPOSES_ONLY';
  }
}

// Mock Solana payment service
const solanaPaymentService = {
  processPayment: async (amount) => {
    console.log(`[MOCK] Processing payment of ${amount} SOL`);
    // Simulate a successful transaction
    return {
      success: true,
      transactionId: 'mock-tx-' + Math.random().toString(36).substring(2, 15),
      amount: amount
    };
  },
  
  verifyTransaction: async (transactionId) => {
    console.log(`[MOCK] Verifying transaction ${transactionId}`);
    // Simulate transaction verification
    return {
      success: true,
      verified: true,
      amount: 1.0,
      timestamp: new Date().toISOString()
    };
  }
};

// Basic routes
app.get('/', (req, res) => {
  res.send('Minimal Solana Payment Server Running');
});

app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    environment: {
      solanaNetwork: process.env.SOLANA_NETWORK || 'devnet',
      mockMode: process.env.SOLANA_MOCK_MODE === 'true',
      receiverPublicKey: process.env.SOLANA_RECEIVER_PUBLIC_KEY ? 
        process.env.SOLANA_RECEIVER_PUBLIC_KEY.substring(0, 4) + '...' : 'not set'
    },
    time: new Date().toISOString() 
  });
});

// Payment routes
app.post('/api/payment/process', async (req, res) => {
  try {
    const { amount } = req.body;
    
    if (!amount || isNaN(parseFloat(amount))) {
      return res.status(400).json({ 
        success: false, 
        error: 'Invalid amount. Please provide a valid number.' 
      });
    }
    
    const result = await solanaPaymentService.processPayment(parseFloat(amount));
    res.json(result);
  } catch (error) {
    console.error('Error processing payment:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Payment processing failed. Please try again later.' 
    });
  }
});

app.post('/api/payment/verify', async (req, res) => {
  try {
    const { transactionId } = req.body;
    
    if (!transactionId) {
      return res.status(400).json({ 
        success: false, 
        error: 'Missing transaction ID' 
      });
    }
    
    const result = await solanaPaymentService.verifyTransaction(transactionId);
    res.json(result);
  } catch (error) {
    console.error('Error verifying transaction:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Transaction verification failed. Please try again later.' 
    });
  }
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Minimal server running on port ${PORT}`);
  console.log(`Server mode: ${process.env.SOLANA_MOCK_MODE === 'true' ? 'MOCK' : 'PRODUCTION'}`);
  console.log(`Solana network: ${process.env.SOLANA_NETWORK || 'devnet'}`);
});