/**
 * Test script for Trial Junkies full service integration
 * 
 * This script tests the core functionality of the Trial Junkies service:
 * 1. SMS verification
 * 2. Solana payment verification
 * 3. Trial creation workflow
 */

// Use CommonJS require instead of ES modules
const smsVerificationService = require('./server/smsVerificationService');
const solanaPaymentService = require('./server/solanaPaymentService');

// Set up mock mode
process.env.MOCK_SOLANA_VERIFICATION = 'true';

/**
 * Utility function to wait for a specified time
 * @param {number} ms - Milliseconds to wait
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Test the full service integration
 */
async function testFullServiceIntegration() {
  try {
    console.log('======= Testing Full Service Integration =======\n');
    
    // 1. Test SMS verification
    console.log('--- Testing SMS verification ---');
    
    // Request a phone number
    const phoneRequest = await smsVerificationService.requestPhoneNumber('netflix', 'US');
    console.log('Phone request result:', phoneRequest);
    
    if (!phoneRequest.success) {
      throw new Error('Failed to request phone number');
    }
    
    const verificationId = phoneRequest.verificationId;
    console.log(`Successfully requested phone number: ${phoneRequest.phoneNumber}`);
    console.log(`Verification ID: ${verificationId}`);
    
    // Wait for SMS code
    console.log('\nWaiting for SMS code (this may take a few seconds)...');
    let smsCode = null;
    
    for (let i = 0; i < 5; i++) {
      await sleep(500);
      process.stdout.write('.');
      
      try {
        const codeResult = await smsVerificationService.getVerificationCode(verificationId);
        
        if (codeResult.success && codeResult.code) {
          smsCode = codeResult.code;
          console.log(`\nReceived SMS code: ${smsCode}`);
          break;
        }
      } catch (error) {
        // Continue waiting
      }
    }
    
    if (!smsCode) {
      console.log('\nNo SMS code received within timeout');
    } else {
      // Verify the code
      const verificationResult = smsVerificationService.verifyCode(verificationId, smsCode);
      console.log('Verification result:', verificationResult);
    }
    
    // 2. Test Solana payment
    console.log('\n--- Testing Solana payment ---');
    
    // Check configuration status
    const networkInfo = solanaPaymentService.getNetworkInfo();
    console.log('Network info:', networkInfo);
    
    console.log(`Receiver configured: ${solanaPaymentService.isConfigured()}`);
    
    // Create a payment request
    const paymentRequest = solanaPaymentService.createPaymentRequest(1.5, {
      userId: 'test_user_123',
      purpose: 'subscription'
    });
    
    console.log('Payment request created:', paymentRequest);
    
    // Verify a mock transaction
    const mockTransactionId = 'mock_validtransaction12345';
    console.log(`\nVerifying mock transaction: ${mockTransactionId}`);
    
    const verificationResult = await solanaPaymentService.verifyTransaction(
      mockTransactionId,
      1.5
    );
    
    console.log('Transaction verification result:', verificationResult);
    
    // 3. Simulate trial creation
    console.log('\n--- Simulating trial creation workflow ---');
    
    console.log('1. User requests SMS verification');
    console.log('2. User makes Solana payment');
    console.log('3. System verifies payment and creates trial');
    
    const mockTrialData = {
      id: `trial_${Date.now()}`,
      userId: 'test_user_123',
      serviceName: 'Netflix',
      serviceUrl: 'https://netflix.com',
      phoneNumber: phoneRequest.phoneNumber,
      verificationCode: smsCode,
      paymentId: paymentRequest.paymentId,
      transactionId: mockTransactionId,
      amount: 1.5,
      status: 'active',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days
    };
    
    console.log('Trial created:', mockTrialData);
    
    console.log('\n======= Full Service Integration Test Complete =======');
  } catch (error) {
    console.error('Error during integration test:', error);
  }
}

// Run the test
testFullServiceIntegration()
  .then(() => {
    console.log('Integration test completed.');
  })
  .catch(error => {
    console.error('Integration test failed with error:', error);
  });