// Simplest possible HTTP server with plain Node.js - ES Module version
import http from 'http';

const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Basic HTTP Server</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h1 { color: #333; }
      </style>
    </head>
    <body>
      <h1>Basic HTTP Server Running</h1>
      <p>Server started at: ${new Date().toISOString()}</p>
      <p>Server endpoint: ${req.url}</p>
      <p>Try visiting: <a href="/health">/health</a> for a JSON response</p>
    </body>
    </html>
  `);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://localhost:${PORT}`);
});