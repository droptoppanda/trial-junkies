// simple-express-server.cjs
const express = require('express');
const app = express();

// Configure Express
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Root endpoint
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Solana Payment Test Server</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
        h1 { color: #333; }
      </style>
    </head>
    <body>
      <h1>Solana Payment Test Server</h1>
      <p>Server is running!</p>
      <p>Time: ${new Date().toISOString()}</p>
      <p>To test the API, send a POST request to /api/test with a JSON body.</p>
    </body>
    </html>
  `);
});

// Test API endpoint
app.post('/api/test', (req, res) => {
  const { message } = req.body;
  res.json({ 
    success: true, 
    received: message || 'No message provided',
    timestamp: new Date().toISOString()
  });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString()
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://localhost:${PORT}`);
});