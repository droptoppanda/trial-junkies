// Test script for the modified SetupService without dotenv dependency
import { setupService } from './server/setupService.js';
import fs from 'fs';
import path from 'path';

async function testSetupService() {
  console.log('Testing setup service with .env file parsing...');
  
  // Create a test .env file
  const envPath = path.resolve(process.cwd(), '.test-env');
  const envContent = `
SOLANA_RECEIVER_PUBLIC_KEY=test123456789test123456789test123456789
MOCK_SOLANA_VERIFICATION=true
ENABLE_SMS_VERIFICATION=false
ENABLE_EMAIL_VERIFICATION=false
ENABLE_PROXY=false
DEVELOPMENT_MODE=true
`;
  
  fs.writeFileSync(envPath, envContent);
  
  try {
    // Get the current configuration
    const config = await setupService.getConfiguration();
    console.log('Current configuration:', config);
    
    // Test configuration validation
    const testResult = await setupService.testConfiguration(config);
    console.log('Configuration test results:', testResult);
    
    // Test saving configuration
    await setupService.saveConfiguration({
      ...config,
      development_mode: !config.development_mode
    });
    
    // Verify the changes
    const updatedConfig = await setupService.getConfiguration();
    console.log('Updated configuration:', updatedConfig);
    
    console.log('Setup service test completed successfully!');
  } catch (error) {
    console.error('Error testing setup service:', error);
  } finally {
    // Clean up test env file
    if (fs.existsSync(envPath)) {
      fs.unlinkSync(envPath);
    }
  }
}

// Run the test
testSetupService();