#!/usr/bin/env python3
"""
Simple Solana integration test script
Uses the requests library to call our API endpoints directly
"""

import os
import json
import time
import random
import requests
from urllib.parse import urljoin

# Configuration
API_BASE_URL = "http://localhost:3000/api"  # Adjust to your API server
MOCK_TRANSACTION_ID = f"mock_valid_{int(time.time())}"
TEST_AMOUNT = 0.1

def test_env_variables():
    """Check if environment variables are set correctly"""
    print("\n🧪 Testing environment variables...")
    
    solana_key = os.environ.get("SOLANA_RECEIVER_PUBLIC_KEY")
    mock_mode = os.environ.get("MOCK_SOLANA_VERIFICATION")
    
    if not solana_key:
        print("❌ SOLANA_RECEIVER_PUBLIC_KEY not set")
        return False
    
    print(f"✅ SOLANA_RECEIVER_PUBLIC_KEY: {solana_key[:4]}...{solana_key[-4:]}")
    print(f"✅ MOCK_SOLANA_VERIFICATION: {mock_mode}")
    return True

def is_valid_solana_key(key):
    """Validate Solana public key format"""
    if not key or not isinstance(key, str):
        return False
    
    # Solana public keys are 32-44 characters, alphanumeric
    import re
    return bool(re.match(r'^[a-zA-Z0-9]{32,44}$', key))

def test_payment_flow():
    """Test the complete payment flow"""
    print("\n🧪 Testing payment flow...")
    
    # Step 1: Create payment request
    print("Step 1: Creating payment request...")
    create_url = urljoin(API_BASE_URL, "/payments/create")
    
    try:
        create_response = requests.post(
            create_url,
            json={"amount": TEST_AMOUNT}
        )
        
        if create_response.status_code != 200:
            print(f"❌ Failed to create payment: {create_response.status_code}")
            print(create_response.text)
            return False
        
        payment_data = create_response.json()
        payment_id = payment_data.get("paymentId")
        receiver_address = payment_data.get("receiverAddress")
        
        if not payment_id or not receiver_address:
            print("❌ Invalid payment response data")
            print(payment_data)
            return False
        
        print(f"✅ Payment request created: {payment_id}")
        print(f"✅ Receiver address: {receiver_address[:4]}...{receiver_address[-4:]}")
        
        # Step 2: Verify transaction
        print("\nStep 2: Verifying transaction...")
        verify_url = urljoin(API_BASE_URL, "/payments/verify")
        
        verify_response = requests.post(
            verify_url,
            json={
                "transactionId": MOCK_TRANSACTION_ID,
                "amount": TEST_AMOUNT,
                "paymentId": payment_id
            }
        )
        
        if verify_response.status_code != 200:
            print(f"❌ Failed to verify payment: {verify_response.status_code}")
            print(verify_response.text)
            return False
        
        verify_data = verify_response.json()
        
        if not verify_data.get("success"):
            print(f"❌ Verification failed: {verify_data.get('error')}")
            return False
        
        print(f"✅ Transaction verified: {MOCK_TRANSACTION_ID}")
        
        # Step 3: Check payment status
        print("\nStep 3: Checking payment status...")
        status_url = urljoin(API_BASE_URL, f"/payments/status/{payment_id}")
        
        status_response = requests.get(status_url)
        
        if status_response.status_code != 200:
            print(f"❌ Failed to get payment status: {status_response.status_code}")
            print(status_response.text)
            return False
        
        status_data = status_response.json()
        
        if not status_data.get("success"):
            print(f"❌ Status check failed: {status_data.get('error')}")
            return False
        
        payment_status = status_data.get("status")
        print(f"✅ Payment status: {payment_status}")
        
        if payment_status != "confirmed":
            print(f"❌ Unexpected payment status: {payment_status}")
            return False
        
        print("✅ Payment flow test passed!")
        return True
        
    except Exception as e:
        print(f"❌ Error testing payment flow: {str(e)}")
        return False

def test_direct_service():
    """Test the payment service directly without API"""
    print("\n🧪 Testing direct service integration...")
    
    try:
        # For this test, we'd need to import our service directly
        # Since we can't do that easily in Python, we'll skip and suggest using the API test
        print("ℹ️ Direct service testing from Python is not available")
        print("ℹ️ Use the API test or run the JavaScript test directly")
        return True
    except Exception as e:
        print(f"❌ Error testing direct service: {str(e)}")
        return False

def run_all_tests():
    """Run all Solana integration tests"""
    print("🚀 Starting Solana Integration Tests")
    
    env_test = test_env_variables()
    if not env_test:
        print("❌ Environment test failed, stopping tests")
        return False
    
    api_test = test_payment_flow()
    
    print("\n📊 Test Results:")
    print(f"Environment Variables: {'✅ PASSED' if env_test else '❌ FAILED'}")
    print(f"Payment Flow:          {'✅ PASSED' if api_test else '❌ FAILED'}")
    
    print("\n🏁 Solana Integration Tests Completed")
    return env_test and api_test

if __name__ == "__main__":
    run_all_tests()