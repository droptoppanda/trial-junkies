// test-solana-payment.js
import { solanaPaymentService } from './server/solanaPaymentService.js';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

/**
 * Test the Solana payment service
 */
async function testSolanaPaymentService() {
  console.log('=== Testing Solana Payment Service ===');
  
  try {
    // Check environment configuration
    console.log('\n[1] Environment Configuration:');
    console.log(`Network: ${process.env.SOLANA_NETWORK || 'Not configured'}`);
    console.log(`Mock Mode: ${process.env.MOCK_SOLANA_VERIFICATION === 'true' ? 'Enabled' : 'Disabled'}`);
    console.log(`Receiver Address: ${solanaPaymentService.maskAddress(solanaPaymentService.receiverPublicKey)}`);

    // Validate receiver address format
    console.log('\n[2] Validating Receiver Address Format:');
    const isValidFormat = solanaPaymentService.isValidPublicKeyFormat(solanaPaymentService.receiverPublicKey);
    console.log(`Address Format Valid: ${isValidFormat ? 'Yes ✓' : 'No ✗'}`);
    
    if (!isValidFormat) {
      throw new Error('Invalid Solana public key format.');
    }

    // Process a test payment
    console.log('\n[3] Processing Test Payment:');
    const testAmount = 0.01;
    const paymentResult = await solanaPaymentService.processPayment(testAmount);
    console.log('Payment Result:', JSON.stringify(paymentResult, null, 2));

    if (!paymentResult.success) {
      throw new Error('Payment processing failed.');
    }

    // Verify the transaction
    console.log('\n[4] Verifying Transaction:');
    const verificationResult = await solanaPaymentService.verifyTransaction(paymentResult.transactionId);
    console.log('Verification Result:', JSON.stringify(verificationResult, null, 2));

    if (!verificationResult.success) {
      throw new Error('Transaction verification failed.');
    }

    console.log('\n✅ All tests passed successfully!');

  } catch (error) {
    console.error('\n❌ Test failed with error:', error.message);
    process.exit(1);
  }
}

// Run the test
testSolanaPaymentService();