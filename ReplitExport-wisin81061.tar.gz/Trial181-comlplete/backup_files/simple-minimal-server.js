// Simple Minimal Server for Solana Payment System
// This file provides a minimal version of the server
// with no external dependencies other than the built-in Node.js HTTP module

import http from 'http';
import { URL } from 'url';

// Mock payment data
const mockDataStore = {
  transactions: new Map(),
  nextTransactionId: 1
};

// Helper to generate transaction IDs
function generateTransactionId() {
  const txId = `tx-${Date.now()}-${mockDataStore.nextTransactionId}`;
  mockDataStore.nextTransactionId++;
  return txId;
}

// Helper to generate mock transactions
function createMockTransaction(amount) {
  const transactionId = generateTransactionId();
  const transaction = {
    id: transactionId,
    amount: parseFloat(amount),
    timestamp: new Date().toISOString(),
    status: 'pending',
    confirmed: false,
    confirmations: 0
  };
  
  mockDataStore.transactions.set(transactionId, transaction);
  
  // Simulate transaction confirmation after a delay
  setTimeout(() => {
    const tx = mockDataStore.transactions.get(transactionId);
    if (tx) {
      tx.status = 'confirmed';
      tx.confirmed = true;
      tx.confirmations = 1;
      mockDataStore.transactions.set(transactionId, tx);
      
      console.log(`Transaction ${transactionId} confirmed`);
    }
  }, 5000); // 5 second delay for confirmation
  
  return transaction;
}

// Create HTTP server
const server = http.createServer((req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  // Handle OPTIONS (preflight) requests
  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }
  
  // Parse URL
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
  const pathname = parsedUrl.pathname;
  
  // Simple routing
  if (pathname === '/' || pathname === '/index.html') {
    // Serve home page
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Minimal Solana Payment Server</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
          h1 { color: #333; }
          .container { max-width: 800px; margin: 0 auto; }
          .card { border: 1px solid #ddd; padding: 20px; border-radius: 5px; margin-bottom: 20px; }
          button { 
            background: #4CAF50; color: white; border: none; padding: 10px 15px; 
            border-radius: 4px; cursor: pointer; font-size: 16px; 
          }
          button:hover { background: #45a049; }
          input { padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; width: 100px; }
          #results { display: none; margin-top: 20px; background: #f8f9fa; padding: 15px; border-radius: 5px; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>Minimal Solana Payment Server</h1>
          
          <div class="card">
            <h2>Server Status</h2>
            <p><strong>Status:</strong> Running</p>
            <p><strong>Mode:</strong> Mock/Simulation</p>
            <p><strong>Time:</strong> ${new Date().toISOString()}</p>
          </div>
          
          <div class="card">
            <h2>Test Payment</h2>
            <label for="amount">Amount (SOL):</label>
            <input type="number" id="amount" value="0.01" min="0.001" step="0.001" />
            <button onclick="processPayment()">Process Payment</button>
            <div id="results"></div>
          </div>
          
          <div class="card">
            <h2>API Endpoints</h2>
            <ul>
              <li><code>/health</code> - Server health check</li>
              <li><code>/api/payment/process</code> - Process a payment (POST)</li>
              <li><code>/api/payment/verify/:id</code> - Verify transaction status</li>
            </ul>
          </div>
        </div>
        
        <script>
          async function processPayment() {
            const amount = document.getElementById('amount').value;
            const resultsDiv = document.getElementById('results');
            
            resultsDiv.innerHTML = 'Processing payment...';
            resultsDiv.style.display = 'block';
            
            try {
              const response = await fetch('/api/payment/process', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({ amount })
              });
              
              const data = await response.json();
              
              if (data.success) {
                resultsDiv.innerHTML = 
                  '<h3>Payment Initiated</h3>' +
                  '<p><strong>Transaction ID:</strong> ' + data.transactionId + '</p>' +
                  '<p><strong>Amount:</strong> ' + data.amount + ' SOL</p>' +
                  '<p><strong>Status:</strong> ' + data.status + '</p>' +
                  '<button onclick="verifyTransaction(\'' + data.transactionId + '\')">Verify Transaction</button>';
              } else {
                resultsDiv.innerHTML = 
                  '<h3>Payment Failed</h3>' +
                  '<p><strong>Error:</strong> ' + data.error + '</p>';
              }
            } catch (error) {
              resultsDiv.innerHTML = 
                '<h3>Error</h3>' +
                '<p><strong>Error:</strong> ' + error.message + '</p>';
            }
          }
          
          async function verifyTransaction(transactionId) {
            const resultsDiv = document.getElementById('results');
            
            resultsDiv.innerHTML = 'Verifying transaction...';
            
            try {
              const response = await fetch('/api/payment/verify/' + transactionId);
              const data = await response.json();
              
              if (data.success) {
                resultsDiv.innerHTML = 
                  '<h3>Transaction Verified</h3>' +
                  '<p><strong>Transaction ID:</strong> ' + data.transactionId + '</p>' +
                  '<p><strong>Confirmed:</strong> ' + (data.confirmed ? 'Yes' : 'No') + '</p>' +
                  '<p><strong>Confirmations:</strong> ' + data.confirmations + '</p>' +
                  '<p><strong>Status:</strong> ' + data.status + '</p>' +
                  '<button onclick="processPayment()">New Payment</button>';
              } else {
                resultsDiv.innerHTML = 
                  '<h3>Verification Failed</h3>' +
                  '<p><strong>Error:</strong> ' + data.error + '</p>' +
                  '<button onclick="verifyTransaction(\'' + transactionId + '\')">Try Again</button>';
              }
            } catch (error) {
              resultsDiv.innerHTML = 
                '<h3>Error</h3>' +
                '<p><strong>Error:</strong> ' + error.message + '</p>' +
                '<button onclick="verifyTransaction(\'' + transactionId + '\')">Try Again</button>';
            }
          }
        </script>
      </body>
      </html>
    `);
  } 
  else if (pathname === '/health') {
    // Health check endpoint
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'ok',
      timestamp: new Date().toISOString(),
      mode: 'mock',
      version: '1.0.0'
    }));
  } 
  else if (pathname === '/api/payment/process' && req.method === 'POST') {
    // Process payment endpoint
    let body = '';
    
    req.on('data', chunk => {
      body += chunk.toString();
    });
    
    req.on('end', () => {
      try {
        const data = JSON.parse(body);
        const amount = parseFloat(data.amount) || 0.01;
        
        if (amount <= 0) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            success: false,
            error: 'Invalid amount'
          }));
          return;
        }
        
        // Create mock transaction
        const transaction = createMockTransaction(amount);
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: true,
          transactionId: transaction.id,
          amount: transaction.amount,
          status: transaction.status,
          timestamp: transaction.timestamp
        }));
      } catch (error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          success: false,
          error: 'Invalid request data'
        }));
      }
    });
  } 
  else if (pathname.startsWith('/api/payment/verify/') && req.method === 'GET') {
    // Verify transaction endpoint
    const transactionId = pathname.replace('/api/payment/verify/', '');
    const transaction = mockDataStore.transactions.get(transactionId);
    
    if (!transaction) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: false,
        error: 'Transaction not found'
      }));
      return;
    }
    
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      success: true,
      transactionId: transaction.id,
      amount: transaction.amount,
      status: transaction.status,
      confirmed: transaction.confirmed,
      confirmations: transaction.confirmations,
      timestamp: transaction.timestamp
    }));
  } 
  else {
    // 404 - Not found
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      error: 'Not found',
      path: pathname
    }));
  }
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Simple Minimal Server running at http://localhost:${PORT}`);
  console.log(`Started at: ${new Date().toISOString()}`);
  console.log(`Mode: Mock/Simulation`);
});