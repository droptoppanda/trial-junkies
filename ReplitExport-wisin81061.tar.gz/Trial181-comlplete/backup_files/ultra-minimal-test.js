/**
 * Ultra Minimal Solana Payment Test Script
 * No dependencies required - only Node.js built-in modules
 */

import http from 'http';

// Function to make HTTP requests
function makeRequest(options, data = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsedData = JSON.parse(responseData);
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            data: parsedData
          });
        } catch (e) {
          resolve({
            statusCode: res.statusCode,
            headers: res.headers,
            data: responseData
          });
        }
      });
    });
    
    req.on('error', (error) => {
      reject(error);
    });
    
    if (data) {
      req.write(JSON.stringify(data));
    }
    
    req.end();
  });
}

// Test server health
async function testServerHealth() {
  console.log('Testing server health...');
  
  try {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/health',
      method: 'GET'
    };
    
    const response = await makeRequest(options);
    
    if (response.statusCode === 200 && response.data.status === 'ok') {
      console.log('✅ Server is healthy');
      console.log('Environment:');
      console.log(`  - Solana Network: ${response.data.environment.solanaNetwork}`);
      console.log(`  - Mock Mode: ${response.data.environment.mockMode}`);
      console.log(`  - Receiver Key: ${response.data.environment.receiverPublicKey}`);
      return true;
    } else {
      console.error('❌ Server health check failed');
      console.error('Response:', response);
      return false;
    }
  } catch (error) {
    console.error('❌ Server health check failed with error:', error.message);
    return false;
  }
}

// Test payment processing
async function testPaymentProcessing() {
  console.log('\nTesting payment processing...');
  
  try {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/api/payment/process',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    };
    
    const paymentData = {
      amount: 1.0
    };
    
    const response = await makeRequest(options, paymentData);
    
    if (response.statusCode === 200 && response.data.success) {
      console.log('✅ Payment processing successful');
      console.log(`Transaction ID: ${response.data.transactionId}`);
      console.log(`Amount: ${response.data.amount} SOL`);
      return {
        success: true,
        transactionId: response.data.transactionId
      };
    } else {
      console.error('❌ Payment processing failed');
      console.error('Response:', response);
      return { success: false };
    }
  } catch (error) {
    console.error('❌ Payment processing failed with error:', error.message);
    return { success: false };
  }
}

// Test transaction verification
async function testTransactionVerification(transactionId) {
  console.log('\nTesting transaction verification...');
  
  try {
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/api/payment/verify',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    };
    
    const verificationData = {
      transactionId: transactionId
    };
    
    const response = await makeRequest(options, verificationData);
    
    if (response.statusCode === 200 && response.data.success && response.data.verified) {
      console.log('✅ Transaction verification successful');
      console.log(`Amount: ${response.data.amount} SOL`);
      console.log(`Timestamp: ${response.data.timestamp}`);
      return true;
    } else {
      console.error('❌ Transaction verification failed');
      console.error('Response:', response);
      return false;
    }
  } catch (error) {
    console.error('❌ Transaction verification failed with error:', error.message);
    return false;
  }
}

// Run all tests
async function runAllTests() {
  console.log('=== RUNNING SOLANA PAYMENT TESTS ===');
  
  // 1. Test server health
  const isServerHealthy = await testServerHealth();
  if (!isServerHealthy) {
    console.error('⛔ Server health check failed. Stopping tests.');
    process.exit(1);
  }
  
  // 2. Test payment processing
  const paymentResult = await testPaymentProcessing();
  if (!paymentResult.success) {
    console.error('⛔ Payment processing test failed. Stopping tests.');
    process.exit(1);
  }
  
  // 3. Test transaction verification
  const isVerified = await testTransactionVerification(paymentResult.transactionId);
  if (!isVerified) {
    console.error('⛔ Transaction verification test failed.');
    process.exit(1);
  }
  
  console.log('\n=== ALL TESTS PASSED SUCCESSFULLY ===');
}

// Run tests (in ESM, we can just call it directly)
// Wait a bit to make sure the server is running
console.log('Waiting for server to start...');
setTimeout(() => {
  runAllTests().catch(error => {
    console.error('Test suite failed with error:', error);
    process.exit(1);
  });
}, 2000);