/**
 * Test Solana Integration
 * 
 * This script checks whether the Solana payment integration is correctly set up
 * and functioning properly.
 */

// Set up mock mode for testing
process.env.MOCK_SOLANA_VERIFICATION = 'true';

// Import required modules using CommonJS
const solanaPaymentService = require('./server/solanaPaymentService.cjs');

// Test the Solana configuration
async function testSolanaConfig() {
  console.log('Testing Solana Payment Service Configuration...');
  console.log('-'.repeat(50));
  
  // Check if the service is configured
  const isConfigured = solanaPaymentService.isConfigured();
  console.log(`Service configured: ${isConfigured ? 'Yes' : 'No'}`);
  
  // Get network information
  const networkInfo = solanaPaymentService.getNetworkInfo();
  console.log(`Network: ${networkInfo.name}`);
  console.log(`Endpoint: ${networkInfo.endpoint}`);
  console.log(`Mock mode: ${networkInfo.mockMode ? 'Enabled' : 'Disabled'}`);
  
  console.log('-'.repeat(50));
  return isConfigured;
}

// Test the payment flow
async function testPaymentFlow() {
  console.log('Testing Solana Payment Flow...');
  console.log('-'.repeat(50));
  
  // Create a payment request
  const amount = 1.5; // SOL
  const metadata = { reason: 'test_payment', user: 'test_user' };
  
  console.log(`Creating payment request for ${amount} SOL...`);
  const paymentRequest = solanaPaymentService.createPaymentRequest(amount, metadata);
  
  console.log(`Payment ID: ${paymentRequest.paymentId}`);
  console.log(`Receiver Address: ${paymentRequest.receiverAddress}`);
  
  // Check payment status
  console.log('\nChecking initial payment status...');
  const initialStatus = solanaPaymentService.getPaymentStatus(paymentRequest.paymentId);
  console.log(`Status: ${initialStatus.status}`);
  
  // Simulate a transaction verification
  console.log('\nSimulating transaction verification...');
  // Use a mock transaction ID that will be considered valid
  const mockTransactionId = 'mock_valid_transaction_123456789';
  
  const verificationResult = await solanaPaymentService.verifyTransaction(
    mockTransactionId,
    amount,
    paymentRequest.paymentId
  );
  
  console.log(`Verification success: ${verificationResult.success}`);
  console.log(`Verified: ${verificationResult.verified}`);
  
  // Check the updated payment status
  console.log('\nChecking updated payment status...');
  const updatedStatus = solanaPaymentService.getPaymentStatus(paymentRequest.paymentId);
  console.log(`Status: ${updatedStatus.status}`);
  console.log(`Transaction ID: ${updatedStatus.transactionId}`);
  
  console.log('-'.repeat(50));
  return verificationResult.success;
}

// Run all tests
async function runTests() {
  try {
    const configResult = await testSolanaConfig();
    if (!configResult) {
      console.error('Solana configuration test failed!');
      return false;
    }
    
    console.log('\n');
    
    const paymentResult = await testPaymentFlow();
    if (!paymentResult) {
      console.error('Solana payment flow test failed!');
      return false;
    }
    
    console.log('\nAll Solana integration tests passed successfully!');
    return true;
  } catch (error) {
    console.error('Tests failed with error:', error);
    return false;
  }
}

// Run the tests
runTests().then((success) => {
  console.log(`\nTest result: ${success ? 'SUCCESS' : 'FAILURE'}`);
  // Use non-zero exit code on failure
  process.exit(success ? 0 : 1);
});