/**
 * Test SMS Verification Integration
 * 
 * This script checks whether the SMS verification integration is correctly set up
 * and functioning properly.
 */

// Import required modules using CommonJS
const smsVerificationService = require('./server/smsVerificationService.cjs');

// Test SMS verification configuration
async function testSmsConfig() {
  console.log('Testing SMS Verification Service Configuration...');
  console.log('-'.repeat(50));
  
  // Check available providers
  const providers = smsVerificationService.getProviders();
  console.log(`Available providers: ${providers.join(', ')}`);
  
  // Always at least the mock provider should be available
  const hasProviders = providers.length > 0;
  console.log(`Service has providers: ${hasProviders ? 'Yes' : 'No'}`);
  
  console.log('-'.repeat(50));
  return hasProviders;
}

// Test SMS verification flow
async function testVerificationFlow() {
  console.log('Testing SMS Verification Flow...');
  console.log('-'.repeat(50));
  
  // Request a phone number for a test service
  const service = 'netflix';
  const country = 'US';
  
  console.log(`Requesting phone number for ${service} in ${country}...`);
  const phoneRequest = await smsVerificationService.requestPhoneNumber(service, country);
  
  if (!phoneRequest.success) {
    console.error(`Failed to request phone number: ${phoneRequest.error}`);
    return false;
  }
  
  console.log(`Verification ID: ${phoneRequest.verificationId}`);
  console.log(`Phone Number: ${phoneRequest.phoneNumber}`);
  console.log(`Provider: ${phoneRequest.provider}`);
  
  // Get verification code - in mock mode, this should succeed immediately
  console.log('\nRequesting verification code...');
  const codeResult = await smsVerificationService.getVerificationCode(phoneRequest.verificationId);
  
  if (!codeResult.success) {
    console.error(`Failed to get verification code: ${codeResult.error}`);
    return false;
  }
  
  console.log(`SMS Code: ${codeResult.code}`);
  console.log(`Received at: ${codeResult.receivedAt}`);
  
  // Verify the code
  console.log('\nVerifying the SMS code...');
  const verificationResult = smsVerificationService.verifyCode(phoneRequest.verificationId, codeResult.code);
  
  if (!verificationResult.success) {
    console.error(`Failed to verify code: ${verificationResult.error}`);
    return false;
  }
  
  console.log(`Verification success: ${verificationResult.success}`);
  console.log(`Verified: ${verificationResult.verified}`);
  
  // Cancel the verification (cleanup)
  console.log('\nCanceling the verification...');
  const cancelResult = await smsVerificationService.cancelVerification(phoneRequest.verificationId);
  
  console.log(`Cancellation success: ${cancelResult.success}`);
  
  console.log('-'.repeat(50));
  return verificationResult.success;
}

// Run all tests
async function runTests() {
  try {
    const configResult = await testSmsConfig();
    if (!configResult) {
      console.error('SMS verification configuration test failed!');
      return false;
    }
    
    console.log('\n');
    
    const flowResult = await testVerificationFlow();
    if (!flowResult) {
      console.error('SMS verification flow test failed!');
      return false;
    }
    
    console.log('\nAll SMS verification integration tests passed successfully!');
    return true;
  } catch (error) {
    console.error('Tests failed with error:', error);
    return false;
  }
}

// Run the tests
runTests().then((success) => {
  console.log(`\nTest result: ${success ? 'SUCCESS' : 'FAILURE'}`);
  // Use non-zero exit code on failure
  process.exit(success ? 0 : 1);
});