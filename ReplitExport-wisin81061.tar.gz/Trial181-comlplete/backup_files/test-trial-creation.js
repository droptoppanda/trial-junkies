// Test for Trial Creation functionality
console.log('=== Starting Trial Creation Test ===');

// Mock data for trial creation
const mockTrialData = {
  name: "Test Subscription Trial",
  website: "https://example.com",
  email: "test@example.com",
  password: "password123",
  steps: [
    { type: "navigate", url: "https://example.com/login" },
    { type: "input", selector: "#email", value: "{{email}}" },
    { type: "input", selector: "#password", value: "{{password}}" },
    { type: "click", selector: "#submit" },
    { type: "wait", selector: ".dashboard", timeout: 5000 }
  ],
  custom_fields: {
    service: "example_service",
    category: "streaming"
  }
};

// Mock simple database storage for testing
class MockStorage {
  constructor() {
    this.trials = [];
    this.users = [{ id: 1, email: "test@example.com" }];
    this.subscriptions = [{ 
      id: 1, 
      user_id: 1, 
      tier: "pro", 
      active: true, 
      end_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) 
    }];
  }
  
  async createTrial(data) {
    const newTrial = {
      id: this.trials.length + 1,
      ...data,
      status: "queued",
      created_at: new Date(),
      updated_at: new Date()
    };
    
    this.trials.push(newTrial);
    return newTrial;
  }
  
  async getTrialsByUserId(userId) {
    return this.trials.filter(trial => trial.user_id === userId);
  }
  
  async getUserSubscription(userId) {
    return this.subscriptions.find(sub => sub.user_id === userId && sub.active);
  }
}

// Mock Trial service
class TrialService {
  constructor(storage) {
    this.storage = storage;
    this.MAX_TRIALS = {
      free: 1,
      basic: 5,
      pro: 25,
      enterprise: 100
    };
  }
  
  async createTrial(userId, trialData) {
    try {
      // Check if user exists
      const userSubscription = await this.storage.getUserSubscription(userId);
      
      if (!userSubscription) {
        return {
          success: false,
          error: "No active subscription found"
        };
      }
      
      // Check if user has reached their trial limit
      const userTrials = await this.storage.getTrialsByUserId(userId);
      const tier = userSubscription.tier;
      
      if (userTrials.length >= this.MAX_TRIALS[tier]) {
        return {
          success: false,
          error: `Trial limit reached for ${tier} tier`
        };
      }
      
      // Create the trial
      const newTrial = await this.storage.createTrial({
        ...trialData,
        user_id: userId,
        status: "queued"
      });
      
      return {
        success: true,
        trial: newTrial
      };
    } catch (error) {
      return {
        success: false,
        error: error.message
      };
    }
  }
}

// Test the trial creation functionality
async function testTrialCreation() {
  console.log('1. Setting up mock environment...');
  const mockStorage = new MockStorage();
  const trialService = new TrialService(mockStorage);
  
  console.log('2. Testing trial creation...');
  
  // Test creating a trial for a user with a pro subscription
  const userId = 1;
  const result = await trialService.createTrial(userId, mockTrialData);
  
  if (result.success) {
    console.log('✅ Trial created successfully');
    console.log(`   Trial ID: ${result.trial.id}`);
    console.log(`   Status: ${result.trial.status}`);
    
    // Verify the trial data
    const trial = result.trial;
    if (trial.name === mockTrialData.name && 
        trial.website === mockTrialData.website &&
        trial.status === "queued") {
      console.log('✅ Trial data verified');
    } else {
      console.error('❌ Trial data verification failed');
      return false;
    }
    
    // Test subscription tier limits
    console.log('\n3. Testing subscription tier limits...');
    
    // Add more trials to reach the limit
    for (let i = 0; i < 25; i++) {
      await trialService.createTrial(userId, {
        ...mockTrialData,
        name: `Test Trial ${i + 2}`
      });
    }
    
    // This should exceed the pro tier limit
    const limitResult = await trialService.createTrial(userId, {
      ...mockTrialData,
      name: "Limit Exceeding Trial"
    });
    
    if (!limitResult.success && limitResult.error.includes("limit reached")) {
      console.log('✅ Trial limit enforcement working correctly');
      console.log(`   Error: ${limitResult.error}`);
    } else {
      console.error('❌ Trial limit enforcement failed');
      return false;
    }
    
    return true;
  } else {
    console.error(`❌ Trial creation failed: ${result.error}`);
    return false;
  }
}

// Run the test
testTrialCreation().then(success => {
  if (success) {
    console.log('\n=== Trial Creation Test Successful ===');
  } else {
    console.error('\n=== Trial Creation Test Failed ===');
    process.exit(1);
  }
});