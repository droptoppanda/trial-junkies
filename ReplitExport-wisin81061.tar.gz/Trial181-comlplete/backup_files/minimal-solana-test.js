// Minimal Solana test using the web3.js library
console.log('=== Starting Minimal Solana Test ===');

// Function to validate Solana public key format
function isValidSolanaPublicKeyFormat(publicKeyString) {
  if (typeof publicKeyString !== 'string') {
    return false;
  }
  
  // Base58 check (only contains characters in the Base58 alphabet)
  const base58Regex = /^[1-9A-HJ-NP-Za-km-z]+$/;
  return base58Regex.test(publicKeyString) && publicKeyString.length >= 32 && publicKeyString.length <= 48;
}

// Check if we have the required environment variable
async function testSolanaReceiverFormat() {
  try {
    const receiverPublicKey = process.env.SOLANA_RECEIVER_PUBLIC_KEY;
    
    if (!receiverPublicKey) {
      console.error('❌ SOLANA_RECEIVER_PUBLIC_KEY environment variable is missing');
      return false;
    }
    
    if (!isValidSolanaPublicKeyFormat(receiverPublicKey)) {
      console.error(`❌ SOLANA_RECEIVER_PUBLIC_KEY has invalid format: ${receiverPublicKey}`);
      return false;
    }
    
    console.log(`✅ SOLANA_RECEIVER_PUBLIC_KEY has valid format: ${receiverPublicKey.substring(0, 4)}...${receiverPublicKey.substring(receiverPublicKey.length - 4)}`);
    
    // Additional checks here in a full implementation
    return true;
  } catch (error) {
    console.error('Error during Solana test:', error);
    return false;
  }
}

// Run the test
testSolanaReceiverFormat().then(success => {
  if (success) {
    console.log('\n=== Minimal Solana Test Successful ===');
  } else {
    console.error('\n=== Minimal Solana Test Failed ===');
    process.exit(1);
  }
});