// Start the application server
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

console.log('Starting Trial Junkies Application...');

// Run the direct server
const server = spawn('node', ['direct-server.js'], { 
  stdio: 'inherit', 
  cwd: __dirname
});

// Handle server exit
server.on('close', (code) => {
  console.log(`Server process exited with code ${code}`);
});

// Handle server errors
server.on('error', (err) => {
  console.error('Failed to start server process:', err);
});

// Handle process termination signals
process.on('SIGINT', () => {
  console.log('Shutting down server...');
  server.kill('SIGINT');
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('Shutting down server...');
  server.kill('SIGTERM');
  process.exit(0);
});

console.log('Server startup complete - press Ctrl+C to stop');