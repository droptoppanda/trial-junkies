/**
 * Test Solana Payment Diagnostics
 * 
 * This script tests the enhanced diagnostic reporting capabilities
 * of the Solana payment system.
 */

import solanaPaymentService from '../server/solanaPaymentService';

async function testSolanaDiagnostics() {
  console.log('=== Solana Payment Service Diagnostic Test ===\n');

  // Step 1: Check configuration status
  console.log('Step 1: Configuration Status');
  const configStatus = solanaPaymentService.getConfigStatus();
  console.log(JSON.stringify(configStatus, null, 2));
  console.log('\n');

  // Step 2: Check network information
  console.log('Step 2: Network Information');
  const networkInfo = solanaPaymentService.getNetworkInfo();
  console.log(JSON.stringify(networkInfo, null, 2));
  console.log('\n');

  // Step 3: Check wallet information
  console.log('Step 3: Receiver Wallet Information');
  const walletInfo = solanaPaymentService.getReceiverWallet();
  console.log(JSON.stringify(walletInfo, null, 2));
  console.log('\n');

  // Step 4: Get service health
  console.log('Step 4: Service Health Check');
  try {
    const healthInfo = await solanaPaymentService.checkHealth();
    console.log(JSON.stringify(healthInfo, null, 2));
  } catch (error) {
    console.error('Health check failed:', error);
  }
  console.log('\n');

  // Step 5: Test different verification scenarios
  console.log('Step 5: Testing Verification Scenarios');
  
  // Create a payment request
  const paymentRequest = solanaPaymentService.createPaymentRequest(1.0, {
    test: true,
    timestamp: new Date().toISOString()
  });
  console.log('Created payment request:', paymentRequest.paymentId);
  
  // Test successful verification
  console.log('\nScenario: Successful verification');
  const validResult = await solanaPaymentService.verifyTransaction(
    `mock_valid_${Date.now()}`,
    1.0,
    paymentRequest.paymentId
  );
  console.log(JSON.stringify(validResult, null, 2));
  
  // Test pending verification
  console.log('\nScenario: Pending verification');
  const pendingResult = await solanaPaymentService.verifyTransaction(
    `mock_pending_${Date.now()}`,
    1.0,
    null
  );
  console.log(JSON.stringify(pendingResult, null, 2));
  
  // Test invalid verification
  console.log('\nScenario: Invalid verification');
  const invalidResult = await solanaPaymentService.verifyTransaction(
    `mock_invalid_${Date.now()}`,
    1.0,
    null
  );
  console.log(JSON.stringify(invalidResult, null, 2));
  
  // Test error during verification
  console.log('\nScenario: Error during verification');
  const errorResult = await solanaPaymentService.verifyTransaction(
    `mock_error_${Date.now()}`,
    1.0,
    null
  );
  console.log(JSON.stringify(errorResult, null, 2));

  // Final report
  console.log('\n=== Diagnostic Test Complete ===');
  console.log(`Mock Mode: ${configStatus.mockMode ? 'Enabled' : 'Disabled'}`);
  console.log(`Configuration Status: ${configStatus.isConfigured ? 'Valid' : 'Invalid'}`);
  console.log(`Receiver address valid: ${configStatus.receiverAddressValid ? 'Yes' : 'No'}`);
  console.log(`Network: ${networkInfo.name}`);
}

// Run the test
testSolanaDiagnostics()
  .then(() => console.log('Test completed successfully'))
  .catch(err => console.error('Test failed:', err));