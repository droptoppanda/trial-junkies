/**
 * Plain JavaScript test for Solana Payment Service
 * 
 * This script provides a NodeJS test for the Solana payment service
 * without requiring TypeScript compilation.
 */

// Load environment variables from .env manually
const fs = require('fs');
const path = require('path');

function loadEnvVars() {
  try {
    const envPath = path.resolve(process.cwd(), '.env');
    const envContent = fs.readFileSync(envPath, 'utf8');
    const envVars = envContent.split('\n');
    
    for (const line of envVars) {
      // Skip comments and empty lines
      if (line.startsWith('#') || !line.trim()) continue;
      
      // Parse key-value pairs
      const [key, ...valueParts] = line.split('=');
      if (key && valueParts.length) {
        let value = valueParts.join('=').trim();
        
        // Remove quotes if present
        if ((value.startsWith('"') && value.endsWith('"')) || 
            (value.startsWith("'") && value.endsWith("'"))) {
          value = value.substring(1, value.length - 1);
        }
        
        process.env[key.trim()] = value;
      }
    }
    console.log("Environment variables loaded from .env file");
  } catch (error) {
    console.warn("Warning: Failed to load .env file", error.message);
  }
}

// Load environment variables
loadEnvVars();

// Set mock mode for testing if not already set
process.env.MOCK_SOLANA_VERIFICATION = process.env.MOCK_SOLANA_VERIFICATION || "true";
process.env.SOLANA_MOCK_MODE = process.env.SOLANA_MOCK_MODE || "true";

/**
 * Validates a Solana address format
 * @param {string} address - Solana address to validate
 * @returns {boolean} - Whether the address is valid
 */
function validateSolanaAddress(address) {
  if (!address) return false;
  // Basic validation - should be 32-44 characters, base58 encoding
  return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address);
}

/**
 * Mock a Solana transaction verification
 * @param {string} txId - Transaction ID
 * @param {number} amount - Expected amount
 * @returns {object} - Verification result
 */
function mockVerifyTransaction(txId, amount) {
  // Generate a mock verification result
  return {
    success: true,
    verified: true,
    amount: amount,
    receiverAddress: process.env.SOLANA_RECEIVER_PUBLIC_KEY || "mockAddress123456789",
    transactionId: txId || `mock_tx_${Date.now()}`,
    timestamp: new Date().toISOString(),
    mockMode: true
  };
}

/**
 * Simple implementation of SolanaPaymentService for testing
 */
class TestSolanaPaymentService {
  constructor() {
    this.receiverAddress = process.env.SOLANA_RECEIVER_PUBLIC_KEY;
    this.network = process.env.SOLANA_NETWORK || 'devnet';
    this.mockMode = process.env.SOLANA_MOCK_MODE === 'true';
    this.transactions = new Map();
  }

  /**
   * Check if the service is properly configured
   * @returns {boolean} - Whether it's configured
   */
  isConfigured() {
    return this.mockMode || validateSolanaAddress(this.receiverAddress);
  }

  /**
   * Create a payment request
   * @param {number} amount - Amount in SOL
   * @param {object} metadata - Payment metadata
   * @returns {object} - Payment request info
   */
  createPaymentRequest(amount, metadata = {}) {
    const paymentId = `payment_${Date.now()}`;
    
    const paymentRequest = {
      paymentId,
      amount,
      receiverAddress: this.receiverAddress,
      status: 'pending',
      createdAt: Date.now(),
      metadata,
      network: this.network,
      mockMode: this.mockMode
    };
    
    this.transactions.set(paymentId, paymentRequest);
    
    return {
      paymentId,
      amount,
      receiverAddress: this.receiverAddress,
      network: this.network,
      mockMode: this.mockMode,
      instructions: [
        `Send ${amount} SOL to ${this.receiverAddress}`,
        'Copy the transaction ID',
        'Verify the transaction using the transaction ID'
      ]
    };
  }

  /**
   * Verify a transaction
   * @param {string} transactionId - Transaction ID 
   * @param {number} expectedAmount - Expected amount
   * @param {string} paymentId - Payment ID
   * @returns {object} - Verification result
   */
  async verifyTransaction(transactionId, expectedAmount, paymentId) {
    if (this.mockMode) {
      const result = mockVerifyTransaction(transactionId, expectedAmount);
      
      if (paymentId && this.transactions.has(paymentId)) {
        const payment = this.transactions.get(paymentId);
        payment.status = 'confirmed';
        payment.verifiedAt = Date.now();
        payment.transactionId = transactionId;
        this.transactions.set(paymentId, payment);
      }
      
      return result;
    }
    
    // In a real implementation, this would verify on-chain
    console.log('Error: Real transaction verification not implemented');
    return {
      success: false,
      error: 'Real transaction verification not implemented'
    };
  }

  /**
   * Get payment status
   * @param {string} paymentId - Payment ID
   * @returns {object} - Payment status
   */
  getPaymentStatus(paymentId) {
    if (!this.transactions.has(paymentId)) {
      return {
        success: false,
        error: 'Payment not found'
      };
    }
    
    const payment = this.transactions.get(paymentId);
    return {
      success: true,
      paymentId: payment.paymentId,
      status: payment.status,
      amount: payment.amount,
      createdAt: new Date(payment.createdAt).toISOString(),
      verifiedAt: payment.verifiedAt ? new Date(payment.verifiedAt).toISOString() : null,
      transactionId: payment.transactionId || null
    };
  }
}

/**
 * Run test for Solana payment service
 */
async function runSolanaPaymentTest() {
  console.log("\n===== SOLANA PAYMENT SERVICE TEST =====\n");
  
  try {
    // Create payment service
    const paymentService = new TestSolanaPaymentService();
    
    // Check configuration
    const isConfigured = paymentService.isConfigured();
    console.log(`Service configured: ${isConfigured ? 'Yes' : 'No'}`);
    console.log(`Network: ${paymentService.network}`);
    console.log(`Mock mode: ${paymentService.mockMode ? 'Yes' : 'No'}`);
    
    if (!isConfigured) {
      console.log("ERROR: Solana payment service is not properly configured");
      process.exit(1);
    }
    
    // Create payment request
    console.log("\n--- Creating payment request ---");
    const amount = 0.01; // 0.01 SOL
    const paymentRequest = paymentService.createPaymentRequest(amount, {
      userId: 'test-user-123',
      purpose: 'test-payment'
    });
    
    console.log(`Payment ID: ${paymentRequest.paymentId}`);
    console.log(`Amount: ${paymentRequest.amount} SOL`);
    console.log(`Receiver: ${paymentRequest.receiverAddress}`);
    console.log("Payment instructions:");
    paymentRequest.instructions.forEach((instruction, i) => {
      console.log(`  ${i+1}. ${instruction}`);
    });
    
    // Check payment status before verification
    console.log("\n--- Payment status before verification ---");
    const statusBefore = paymentService.getPaymentStatus(paymentRequest.paymentId);
    console.log(`Status: ${statusBefore.status}`);
    console.log(`Created at: ${statusBefore.createdAt}`);
    
    // Generate mock transaction ID
    const mockTxId = `mock_tx_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    
    // Verify payment
    console.log("\n--- Verifying payment ---");
    console.log(`Using transaction ID: ${mockTxId}`);
    const verificationResult = await paymentService.verifyTransaction(
      mockTxId, 
      amount,
      paymentRequest.paymentId
    );
    
    console.log(`Verification successful: ${verificationResult.success ? 'Yes' : 'No'}`);
    console.log(`Verified amount: ${verificationResult.amount} SOL`);
    
    // Check payment status after verification
    console.log("\n--- Payment status after verification ---");
    const statusAfter = paymentService.getPaymentStatus(paymentRequest.paymentId);
    console.log(`Status: ${statusAfter.status}`);
    console.log(`Created at: ${statusAfter.createdAt}`);
    console.log(`Verified at: ${statusAfter.verifiedAt}`);
    console.log(`Transaction ID: ${statusAfter.transactionId}`);
    
    // Test result
    if (statusAfter.status === 'confirmed') {
      console.log("\n✅ Test passed: Payment flow works correctly");
    } else {
      console.log("\n❌ Test failed: Payment not confirmed");
    }
    
  } catch (error) {
    console.error('Error during test:', error);
    process.exit(1);
  }
  
  console.log("\n=======================================");
}

// Run the test
runSolanaPaymentTest().catch(console.error);