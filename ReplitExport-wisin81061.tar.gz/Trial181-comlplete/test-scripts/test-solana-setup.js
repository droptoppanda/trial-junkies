/**
 * Simple Solana payment service test
 * 
 * This script tests the Solana payment service configuration
 * and provides feedback on setup issues.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import our Solana Payment Service (assuming ESM)
// Will implement alternative import below if this fails
let solanaPaymentService;

/**
 * Set environment variables from .env file
 */
function loadEnvFile() {
  try {
    const envPath = path.resolve(process.cwd(), '.env');
    if (fs.existsSync(envPath)) {
      const envContent = fs.readFileSync(envPath, 'utf8');
      
      // Parse variables and set them in process.env
      envContent.split('\n').forEach(line => {
        const match = line.match(/^([^=]+)=(.*)$/);
        if (match) {
          const [, key, value] = match;
          if (!process.env[key.trim()]) {
            process.env[key.trim()] = value.trim();
          }
        }
      });
    }
  } catch (error) {
    console.error('Error loading .env file:', error);
  }
}

/**
 * Display current Solana environment variables
 */
function displayEnvironmentVariables() {
  console.log("\n--- Solana Environment Variables ---");
  console.log("SOLANA_RECEIVER_PUBLIC_KEY:", process.env.SOLANA_RECEIVER_PUBLIC_KEY || 'Not set');
  console.log("SOLANA_NETWORK:", process.env.SOLANA_NETWORK || 'Not set (defaults to devnet)');
  console.log("SOLANA_RPC_URL:", process.env.SOLANA_RPC_URL || 'Not set');
  console.log("SOLANA_USE_DEVNET:", process.env.SOLANA_USE_DEVNET || 'Not set');
  console.log("SOLANA_MOCK_MODE:", process.env.SOLANA_MOCK_MODE || 'Not set');
  console.log("MOCK_SOLANA_VERIFICATION:", process.env.MOCK_SOLANA_VERIFICATION || 'Not set');
}

/**
 * Fallback validator for Solana addresses
 */
function validateSolanaAddress(address) {
  if (!address || typeof address !== 'string') {
    return false;
  }
  
  // Basic format check: 32-44 characters, alphanumeric
  return /^[a-zA-Z0-9]{32,44}$/.test(address);
}

/**
 * Test the Solana setup
 */
async function testSolanaSetup() {
  console.log("\n--- Testing Solana Setup ---");
  
  // Check if payment service was loaded
  if (!solanaPaymentService) {
    console.log("❌ Could not load Solana payment service");
    console.log("Required actions:");
    console.log("- Make sure server/solanaPaymentService.ts is properly implemented");
    return false;
  }
  
  // Get network info
  const networkInfo = solanaPaymentService.getNetworkInfo();
  console.log("\nNetwork Information:");
  console.log("- Network:", networkInfo.name);
  console.log("- Endpoint:", networkInfo.endpoint);
  console.log("- Mock Mode:", networkInfo.mockMode ? "Enabled" : "Disabled");
  
  // Get receiver wallet info
  const walletInfo = solanaPaymentService.getReceiverWallet();
  console.log("\nReceiver Wallet:");
  console.log("- Address:", walletInfo.address || 'Not set');
  console.log("- Valid format:", walletInfo.isValid ? "Yes" : "No");
  
  // Check configuration
  const isConfigured = solanaPaymentService.isConfigured();
  console.log("\nConfiguration Status:");
  console.log("- Service configured:", isConfigured ? "Yes" : "No");
  
  // Test mock verification if in mock mode
  if (networkInfo.mockMode) {
    console.log("\nTesting Mock Transaction Verification:");
    const mockTransactionId = `mock_valid_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
    const amount = 0.05;
    
    try {
      // Create a payment request
      const paymentRequest = solanaPaymentService.createPaymentRequest(amount);
      console.log("- Created payment request with ID:", paymentRequest.paymentId);
      
      // Verify with mock transaction
      const verificationResult = await solanaPaymentService.verifyTransaction(
        mockTransactionId,
        amount, 
        paymentRequest.paymentId
      );
      
      console.log("- Verification result:", verificationResult.success ? "Success" : "Failed");
      if (verificationResult.success && verificationResult.verified) {
        console.log("✅ Mock transaction verification working correctly");
      } else {
        console.log("❌ Mock transaction verification failed");
        console.log("- Error:", verificationResult.error || 'Unknown error');
      }
    } catch (error) {
      console.error("Error during mock verification:", error);
      console.log("❌ Mock transaction verification failed due to error");
    }
  }
  
  // Assessment
  console.log("\nOverall Assessment:");
  if (isConfigured) {
    console.log("✅ Solana payment service is configured and ready");
    return true;
  } else {
    console.log("❌ Solana payment service needs configuration");
    console.log("Required actions:");
    console.log("- Set SOLANA_RECEIVER_PUBLIC_KEY to a valid Solana wallet address"); 
    console.log("- Or set MOCK_SOLANA_VERIFICATION=true for testing");
    return false;
  }
}

/**
 * Main test function
 */
async function runTests() {
  console.log("\n========== SOLANA PAYMENT SERVICE TEST ==========");
  
  // Load env variables
  loadEnvFile();
  
  // Force mock mode for testing
  process.env.MOCK_SOLANA_VERIFICATION = 'true';
  process.env.SOLANA_MOCK_MODE = 'true';
  
  // Display environment
  displayEnvironmentVariables();
  
  try {
    // Try to import the Solana payment service
    const servicePath = '../server/solanaPaymentService.js';
    try {
      const serviceModule = await import(servicePath);
      solanaPaymentService = serviceModule.default;
      console.log("✅ Successfully imported Solana payment service");
    } catch (err) {
      console.error("Could not import Solana payment service:", err.message);
      console.log("❌ Failed to load payment service module");
      console.log("Will skip detailed tests");
      return;
    }
    
    // Run setup test
    await testSolanaSetup();
    
  } catch (error) {
    console.error("Error during tests:", error);
    console.log("❌ Tests failed due to unexpected error");
  }
  
  console.log("\n==============================================");
}

// Run the tests
runTests().catch(console.error);