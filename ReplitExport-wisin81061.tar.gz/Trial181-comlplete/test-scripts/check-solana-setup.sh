#!/bin/bash

# Solana Setup Check Script
#
# This script checks the Solana configuration to ensure it's properly set up

echo ""
echo "========== SOLANA SETUP CHECK =========="
echo ""

# Load environment variables from .env file if it exists
if [ -f "../.env" ]; then
  echo "Loading environment variables from .env file..."
  
  # Export environment variables from .env file
  while IFS= read -r line || [[ -n "$line" ]]; do
    # Skip comments and empty lines
    [[ "$line" =~ ^#.*$ ]] && continue
    [[ -z "$line" ]] && continue
    
    # Extract variable name and value
    if [[ "$line" =~ ^([A-Za-z0-9_]+)=(.*)$ ]]; then
      name="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"
      # Remove quotes if present
      value="${value%\"}"
      value="${value#\"}"
      value="${value%\'}"
      value="${value#\'}"
      # Export the variable
      export "$name"="$value"
    fi
  done < "../.env"
else
  echo "Warning: .env file not found."
fi

# Track check results
CHECKS_PASSED=0
CHECKS_FAILED=0

# Function to check if a required environment variable is set
check_env_var() {
  VAR_NAME="$1"
  DEFAULT_VALUE="$2"
  REQUIRED="${3:-true}"
  
  if [ -n "${!VAR_NAME}" ]; then
    echo "✅ $VAR_NAME is set to: ${!VAR_NAME}"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
    return 0
  elif [ -n "$DEFAULT_VALUE" ]; then
    echo "⚠️ $VAR_NAME is not set, using default: $DEFAULT_VALUE"
    export "$VAR_NAME"="$DEFAULT_VALUE"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
    return 0
  elif [ "$REQUIRED" == "false" ]; then
    echo "⚠️ $VAR_NAME is not set (optional)"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
    return 0
  else
    echo "❌ $VAR_NAME is not set but required"
    CHECKS_FAILED=$((CHECKS_FAILED + 1))
    return 1
  fi
}

# Function to validate Solana public key format
validate_solana_key() {
  KEY="$1"
  
  # Solana public keys are base58-encoded and typically 32-44 characters
  if [[ "$KEY" =~ ^[1-9A-HJ-NP-Za-km-z]{32,44}$ ]]; then
    echo "✅ Solana public key format is valid"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
    return 0
  else
    echo "❌ Invalid Solana public key format: $KEY"
    echo "   Solana public keys should be base58-encoded and 32-44 characters long"
    CHECKS_FAILED=$((CHECKS_FAILED + 1))
    return 1
  fi
}

# Function to mask sensitive data for display
mask_data() {
  DATA="$1"
  
  if [ ${#DATA} -lt 8 ]; then
    echo "$DATA"
  else
    echo "${DATA:0:4}...${DATA: -4}"
  fi
}

echo "Checking Solana environment configuration..."
echo ""

# Check required environment variables
check_env_var "SOLANA_RECEIVER_PUBLIC_KEY"
check_env_var "SOLANA_NETWORK" "devnet"
check_env_var "SOLANA_MOCK_MODE" "true"
check_env_var "MOCK_SOLANA_VERIFICATION" "true" "false"

echo ""
echo "Validating configuration values..."

# Validate receiver public key format
if [ -n "$SOLANA_RECEIVER_PUBLIC_KEY" ]; then
  validate_solana_key "$SOLANA_RECEIVER_PUBLIC_KEY"
  # Display masked key for security
  echo "   Receiver address: $(mask_data "$SOLANA_RECEIVER_PUBLIC_KEY")"
fi

# Validate network value
if [ -n "$SOLANA_NETWORK" ]; then
  if [[ "$SOLANA_NETWORK" =~ ^(mainnet-beta|testnet|devnet)$ ]]; then
    echo "✅ Solana network value is valid: $SOLANA_NETWORK"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
  else
    echo "❌ Invalid Solana network value: $SOLANA_NETWORK"
    echo "   Valid values are: mainnet-beta, testnet, devnet"
    CHECKS_FAILED=$((CHECKS_FAILED + 1))
  fi
fi

# Check mock mode configuration
if [ "$SOLANA_MOCK_MODE" == "true" ]; then
  echo "✅ Solana mock mode is enabled"
  
  if [ "$MOCK_SOLANA_VERIFICATION" == "true" ]; then
    echo "✅ Mock verification is enabled"
  else
    echo "⚠️ Mock verification is disabled, but mock mode is enabled"
    echo "   Consider enabling MOCK_SOLANA_VERIFICATION for consistent testing"
  fi
else
  echo "⚠️ Solana mock mode is disabled"
  echo "   For testing purposes, consider enabling SOLANA_MOCK_MODE"
  
  if [ "$SOLANA_NETWORK" == "mainnet-beta" ]; then
    echo "⚠️ Using mainnet-beta with mock mode disabled may incur real costs"
    echo "   Consider using testnet or devnet for testing"
  fi
fi

echo ""
echo "Checking dependencies..."

# Check for Node.js and npm
if command -v node >/dev/null 2>&1; then
  NODE_VERSION=$(node -v)
  echo "✅ Node.js is installed: $NODE_VERSION"
  CHECKS_PASSED=$((CHECKS_PASSED + 1))
  
  if command -v npm >/dev/null 2>&1; then
    NPM_VERSION=$(npm -v)
    echo "✅ npm is installed: $NPM_VERSION"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
  else
    echo "❌ npm not found"
    CHECKS_FAILED=$((CHECKS_FAILED + 1))
  fi
else
  echo "❌ Node.js not found"
  CHECKS_FAILED=$((CHECKS_FAILED + 1))
fi

# Check for required Node.js packages
echo ""
echo "Checking required packages..."

# List of packages to check
PACKAGES=(
  "@solana/web3.js"
  "dotenv"
)

for pkg in "${PACKAGES[@]}"; do
  if npm list "$pkg" 2>/dev/null | grep -q "$pkg"; then
    echo "✅ $pkg is installed"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
  else
    echo "❌ $pkg is not installed"
    CHECKS_FAILED=$((CHECKS_FAILED + 1))
  fi
done

# Summarize check results
echo ""
echo "Solana Setup Check Completed"
echo "Passed: $CHECKS_PASSED"
echo "Failed: $CHECKS_FAILED"
echo "Total: $((CHECKS_PASSED + CHECKS_FAILED))"

if [ $CHECKS_FAILED -gt 0 ]; then
  echo ""
  echo "❌ Solana setup has issues. Please fix them before running tests."
  exit 1
else
  echo ""
  echo "✅ Solana setup is valid."
  exit 0
fi