/**
 * Solana Test Runner
 * 
 * This script runs the comprehensive Solana test suite
 */

import { execSync } from 'child_process';
import * as dotenv from 'dotenv';
import * as fs from 'fs';
import * as path from 'path';

// Load environment variables
dotenv.config();

// Set up test environment
const setupTestEnvironment = () => {
  console.log('Setting up test environment...');
  
  // Ensure we're using mock mode for tests
  process.env.SOLANA_MOCK_MODE = 'true';
  process.env.MOCK_SOLANA_VERIFICATION = 'true';
  process.env.SOLANA_NETWORK = 'devnet';
  
  // If no receiver key is set, use a test key
  if (!process.env.SOLANA_RECEIVER_PUBLIC_KEY) {
    process.env.SOLANA_RECEIVER_PUBLIC_KEY = 'Ey9MqEpP5QzBjStfNV1Z2Jj7WEnzQ5j8t2Wtg8fgGcHa';
    console.log('Using test receiver key for Solana tests.');
  }
  
  console.log('Test environment configured.');
};

// Run TypeScript test file
const runTypeScriptTest = async (testFile: string) => {
  console.log(`\nRunning TypeScript test: ${testFile}`);
  console.log('-'.repeat(40));
  
  try {
    // Use ts-node to run the TypeScript test directly
    execSync(`npx ts-node ${testFile}`, { stdio: 'inherit' });
    console.log(`\n✅ Test passed: ${testFile}`);
    return true;
  } catch (error) {
    console.error(`\n❌ Test failed: ${testFile}`);
    console.error(error);
    return false;
  }
};

// Run shell script test
const runShellTest = async (testFile: string) => {
  console.log(`\nRunning shell test: ${testFile}`);
  console.log('-'.repeat(40));
  
  try {
    // Make sure the shell script is executable
    fs.chmodSync(testFile, '755');
    
    // Execute the shell script
    execSync(`bash ${testFile}`, { stdio: 'inherit' });
    console.log(`\n✅ Test passed: ${testFile}`);
    return true;
  } catch (error) {
    console.error(`\n❌ Test failed: ${testFile}`);
    console.error(error);
    return false;
  }
};

// Run all Solana tests
const runSolanaTests = async () => {
  console.log('======= SOLANA TEST SUITE =======\n');
  
  // Set up the test environment
  setupTestEnvironment();
  
  // Define test files to run
  const testScripts = [
    { file: path.join(__dirname, 'check-solana-setup.sh'), type: 'shell' },
    { file: path.join(__dirname, 'solana-tests.ts'), type: 'ts' },
    { file: path.join(__dirname, 'test-solana-module.sh'), type: 'shell' },
  ];
  
  // Track test results
  let passed = 0;
  let failed = 0;
  
  // Run each test
  for (const test of testScripts) {
    try {
      let success = false;
      
      if (test.type === 'ts') {
        success = await runTypeScriptTest(test.file);
      } else if (test.type === 'shell') {
        success = await runShellTest(test.file);
      }
      
      if (success) {
        passed++;
      } else {
        failed++;
      }
    } catch (error) {
      console.error(`Error running test ${test.file}: ${error}`);
      failed++;
    }
  }
  
  // Summary
  console.log('\n======= TEST SUMMARY =======');
  console.log(`Total tests: ${testScripts.length}`);
  console.log(`Passed: ${passed}`);
  console.log(`Failed: ${failed}`);
  
  if (failed > 0) {
    console.error('\n❌ Some tests failed. Please check the logs above.');
    process.exit(1);
  } else {
    console.log('\n✅ All tests passed successfully!');
    process.exit(0);
  }
};

// Run the tests
runSolanaTests().catch(error => {
  console.error('Test suite failed with error:', error);
  process.exit(1);
});