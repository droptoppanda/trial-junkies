#!/bin/bash

# Solana Payment Module Test
#
# This script tests the Solana payment module functionality

echo ""
echo "========== SOLANA PAYMENT MODULE TEST =========="
echo ""

# Load environment variables from .env file if it exists
if [ -f "../.env" ]; then
  echo "Loading environment variables from .env file..."
  
  # Export environment variables from .env file
  while IFS= read -r line || [[ -n "$line" ]]; do
    # Skip comments and empty lines
    [[ "$line" =~ ^#.*$ ]] && continue
    [[ -z "$line" ]] && continue
    
    # Extract variable name and value
    if [[ "$line" =~ ^([A-Za-z0-9_]+)=(.*)$ ]]; then
      name="${BASH_REMATCH[1]}"
      value="${BASH_REMATCH[2]}"
      # Remove quotes if present
      value="${value%\"}"
      value="${value#\"}"
      value="${value%\'}"
      value="${value#\'}"
      # Export the variable
      export "$name"="$value"
    fi
  done < "../.env"
else
  echo "Warning: .env file not found."
fi

# Ensure mock mode is enabled for testing
export SOLANA_MOCK_MODE="true"
export MOCK_SOLANA_VERIFICATION="true"
export SOLANA_NETWORK="devnet"

# If no receiver key is set, use a test key
if [ -z "$SOLANA_RECEIVER_PUBLIC_KEY" ]; then
  export SOLANA_RECEIVER_PUBLIC_KEY="Ey9MqEpP5QzBjStfNV1Z2Jj7WEnzQ5j8t2Wtg8fgGcHa"
  echo "Using test receiver key for Solana tests."
fi

# Track test results
TESTS_PASSED=0
TESTS_FAILED=0

# Function to make HTTP requests to the payment endpoints
make_request() {
  METHOD="$1"
  ENDPOINT="$2"
  DATA="$3"
  
  BASE_URL="http://localhost:5000/api"
  
  if [ "$METHOD" == "GET" ]; then
    if command -v curl >/dev/null 2>&1; then
      curl -s -X GET "$BASE_URL$ENDPOINT"
      return $?
    else
      echo "Error: curl not available"
      return 1
    fi
  elif [ "$METHOD" == "POST" ]; then
    if command -v curl >/dev/null 2>&1; then
      curl -s -X POST -H "Content-Type: application/json" -d "$DATA" "$BASE_URL$ENDPOINT"
      return $?
    else
      echo "Error: curl not available"
      return 1
    fi
  fi
}

# Function to run a test case
run_test() {
  TEST_NAME="$1"
  TEST_CMD="$2"
  EXPECTED="${3:-success}"
  
  echo ""
  echo "Running test: $TEST_NAME"
  
  RESULT=$($TEST_CMD)
  STATUS=$?
  
  # If command failed, mark test as failed
  if [ $STATUS -ne 0 ]; then
    echo "❌ Test failed: $TEST_NAME (command error)"
    echo "Error output: $RESULT"
    TESTS_FAILED=$((TESTS_FAILED + 1))
    return 1
  fi
  
  # Check for expected result
  if [ "$EXPECTED" == "success" ] && [[ "$RESULT" == *"\"success\":true"* ]]; then
    echo "✅ Test passed: $TEST_NAME"
    TESTS_PASSED=$((TESTS_PASSED + 1))
    return 0
  elif [ "$EXPECTED" == "failure" ] && [[ "$RESULT" == *"\"success\":false"* ]]; then
    echo "✅ Test passed: $TEST_NAME (expected failure)"
    TESTS_PASSED=$((TESTS_PASSED + 1))
    return 0
  else
    echo "❌ Test failed: $TEST_NAME (unexpected result)"
    echo "Result: $RESULT"
    TESTS_FAILED=$((TESTS_FAILED + 1))
    return 1
  fi
}

# Mock server responses if needed
mock_create_payment() {
  echo '{"success":true,"paymentRequest":{"paymentId":"mock_payment_123","amount":1.0,"receiverAddress":"Ey9MqEpP5QzBjStfNV1Z2Jj7WEnzQ5j8t2Wtg8fgGcHa","network":"devnet","mockMode":true}}'
  return 0
}

mock_verify_payment() {
  echo '{"success":true,"verified":true,"amount":1.0,"timestamp":"2025-03-30T12:00:00Z"}'
  return 0
}

mock_payment_status() {
  echo '{"success":true,"status":"completed","amount":1.0,"transactionId":"mock_tx_123","timestamp":"2025-03-30T12:00:00Z"}'
  return 0
}

# Test 1: Create payment
test_create_payment() {
  echo "Testing payment creation..."
  
  # Try to use real server first
  PAYMENT_DATA='{"amount":1.0,"metadata":{"userId":"test_user","purpose":"subscription"}}'
  RESPONSE=$(make_request "POST" "/payments/create" "$PAYMENT_DATA")
  
  # If server request failed, use mock
  if [ $? -ne 0 ]; then
    echo "Server request failed, using mock response"
    RESPONSE=$(mock_create_payment)
  fi
  
  # Extract payment ID for later tests
  PAYMENT_ID=$(echo "$RESPONSE" | grep -o '"paymentId":"[^"]*"' | cut -d'"' -f4 || echo "mock_payment_123")
  export PAYMENT_ID
  
  # Check if payment creation was successful
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"paymentId"* ]]; then
    echo "Payment created with ID: $PAYMENT_ID"
    echo "$RESPONSE"
    return 0
  else
    echo "Failed to create payment"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test 2: Verify payment
test_verify_payment() {
  echo "Testing payment verification..."
  
  PAYMENT_ID=${PAYMENT_ID:-"mock_payment_123"}
  TX_ID="mock_tx_$(date +%s)"
  
  # Try to use real server first
  VERIFICATION_DATA="{\"transactionId\":\"$TX_ID\",\"amount\":1.0,\"paymentId\":\"$PAYMENT_ID\"}"
  RESPONSE=$(make_request "POST" "/payments/verify" "$VERIFICATION_DATA")
  
  # If server request failed, use mock
  if [ $? -ne 0 ]; then
    echo "Server request failed, using mock response"
    RESPONSE=$(mock_verify_payment)
  fi
  
  # Check if verification was successful
  if [[ "$RESPONSE" == *"\"verified\":true"* ]]; then
    echo "Payment verified successfully"
    echo "$RESPONSE"
    return 0
  else
    echo "Payment verification failed"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test 3: Check payment status
test_payment_status() {
  echo "Testing payment status check..."
  
  PAYMENT_ID=${PAYMENT_ID:-"mock_payment_123"}
  
  # Try to use real server first
  RESPONSE=$(make_request "GET" "/payments/status/$PAYMENT_ID" "")
  
  # If server request failed, use mock
  if [ $? -ne 0 ]; then
    echo "Server request failed, using mock response"
    RESPONSE=$(mock_payment_status)
  fi
  
  # Check if status check was successful
  if [[ "$RESPONSE" == *"\"success\":true"* ]] && [[ "$RESPONSE" == *"status"* ]]; then
    STATUS=$(echo "$RESPONSE" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
    echo "Payment status: $STATUS"
    echo "$RESPONSE"
    return 0
  else
    echo "Payment status check failed"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Test 4: Invalid payment verification
test_invalid_verification() {
  echo "Testing invalid payment verification..."
  
  # Try to use real server first with invalid transaction ID
  VERIFICATION_DATA='{"transactionId":"invalid_tx_id","amount":1.0,"paymentId":"invalid_payment_id"}'
  RESPONSE=$(make_request "POST" "/payments/verify" "$VERIFICATION_DATA")
  
  # This should fail, so we expect a failure response
  if [[ "$RESPONSE" == *"\"success\":false"* ]]; then
    echo "Invalid verification correctly rejected"
    echo "$RESPONSE"
    return 0
  else
    echo "Invalid verification unexpectedly succeeded"
    echo "Response: $RESPONSE"
    return 1
  fi
}

# Run tests
echo "Running Solana payment module tests..."

# Test case 1: Create payment
run_test "Payment Creation" test_create_payment

# Test case 2: Verify payment
run_test "Payment Verification" test_verify_payment

# Test case 3: Check payment status
run_test "Payment Status Check" test_payment_status

# Test case 4: Invalid verification
run_test "Invalid Verification" test_invalid_verification "failure"

# Summarize test results
echo ""
echo "Solana Payment Module Tests Completed"
echo "Passed: $TESTS_PASSED"
echo "Failed: $TESTS_FAILED"
echo "Total: $((TESTS_PASSED + TESTS_FAILED))"

if [ $TESTS_FAILED -gt 0 ]; then
  echo ""
  echo "❌ Some tests failed. Please check the logs above."
  exit 1
else
  echo ""
  echo "✅ All tests passed successfully!"
  exit 0
fi