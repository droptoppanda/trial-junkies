#!/bin/bash

echo "=== Solana Payment Service Diagnostic Test ==="
echo 

# Read environment variables
if [ -f .env ]; then
  echo "Loading .env file..."
  export $(cat .env | grep -v ^# | xargs)
fi

# Check Solana configuration
echo "Checking Solana configuration..."
echo "SOLANA_RECEIVER_PUBLIC_KEY: ${SOLANA_RECEIVER_PUBLIC_KEY:-Not set}"
echo "SOLANA_NETWORK: ${SOLANA_NETWORK:-Not set (default: devnet)}"
echo "MOCK_SOLANA_VERIFICATION: ${MOCK_SOLANA_VERIFICATION:-Not set (default: false)}"
echo "SOLANA_MOCK_MODE: ${SOLANA_MOCK_MODE:-Not set (default: false)}"

# Validate Solana public key format
validate_solana_key() {
  local key="$1"
  if [[ -z "$key" ]]; then
    echo "Invalid: empty key"
    return 1
  fi
  
  # Basic validation - check if it's alphanumeric and correct length (32-44 chars)
  if [[ "$key" =~ ^[a-zA-Z0-9]{32,44}$ ]]; then
    echo "Valid format"
    return 0
  else
    echo "Invalid format"
    return 1
  fi
}

echo
echo "Validating receiver public key..."
if [ -n "$SOLANA_RECEIVER_PUBLIC_KEY" ]; then
  result=$(validate_solana_key "$SOLANA_RECEIVER_PUBLIC_KEY")
  echo "Format validation: $result"
else
  echo "No receiver key configured"
fi

# Mask the address for display
mask_address() {
  local address="$1"
  if [ -z "$address" ] || [ ${#address} -lt 8 ]; then
    echo "$address"
    return
  fi
  
  local start="${address:0:4}"
  local end="${address: -4}"
  echo "${start}...${end}"
}

if [ -n "$SOLANA_RECEIVER_PUBLIC_KEY" ]; then
  masked=$(mask_address "$SOLANA_RECEIVER_PUBLIC_KEY")
  echo "Masked address: $masked"
fi

# Determine if mock mode is enabled
mock_enabled="false"
if [ "$MOCK_SOLANA_VERIFICATION" = "true" ] || [ "$SOLANA_MOCK_MODE" = "true" ]; then
  mock_enabled="true"
fi

echo
echo "Configuration status:"
echo "- Mock mode: $mock_enabled"
echo "- Network: ${SOLANA_NETWORK:-devnet}"
if [ "$mock_enabled" = "true" ]; then
  echo "- Valid configuration: $([ -n "$SOLANA_RECEIVER_PUBLIC_KEY" ] && echo "Yes" || echo "No (receiver key missing)")"
else
  # In non-mock mode, receiver key is mandatory
  if [ -n "$SOLANA_RECEIVER_PUBLIC_KEY" ] && validate_solana_key "$SOLANA_RECEIVER_PUBLIC_KEY" > /dev/null; then
    echo "- Valid configuration: Yes"
  else
    echo "- Valid configuration: No (valid receiver key required for non-mock mode)"
  fi
fi

echo
echo "=== Diagnostic Test Complete ==="