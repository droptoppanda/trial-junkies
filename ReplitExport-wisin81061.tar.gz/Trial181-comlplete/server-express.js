import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { randomUUID } from 'crypto';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// Get directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Store transactions in memory for demo purposes
const transactions = new Map();

// Environment configuration
const SOLANA_RECEIVER_PUBLIC_KEY = process.env.SOLANA_RECEIVER_PUBLIC_KEY || 'demo123456789abcdefghijklmnopqrstuvwxyz123456789';
const SOLANA_NETWORK = process.env.SOLANA_NETWORK || 'devnet';
const SOLANA_MOCK_MODE = process.env.SOLANA_MOCK_MODE === 'true';

// Utility functions
function isValidSolanaPublicKeyFormat(publicKeyString) {
  // Basic validation for Solana public key format
  return typeof publicKeyString === 'string' && 
         /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(publicKeyString);
}

function generateTransactionId() {
  return randomUUID();
}

function createMockTransaction(amount) {
  const transactionId = generateTransactionId();
  
  transactions.set(transactionId, {
    id: transactionId,
    amount: parseFloat(amount),
    receiverAddress: SOLANA_RECEIVER_PUBLIC_KEY,
    status: 'pending',
    createdAt: new Date().toISOString(),
    network: SOLANA_NETWORK,
    confirmations: 0,
    signature: null
  });
  
  return transactionId;
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    serverTime: new Date().toISOString(),
    message: 'Solana Payment API is running',
    environment: {
      network: SOLANA_NETWORK,
      mockMode: SOLANA_MOCK_MODE
    }
  });
});

// Get configuration endpoint
app.get('/api/config', (req, res) => {
  res.json({
    receiverAddress: SOLANA_RECEIVER_PUBLIC_KEY,
    network: SOLANA_NETWORK,
    mockMode: SOLANA_MOCK_MODE
  });
});

// Create payment endpoint
app.post('/api/payment/create', (req, res) => {
  try {
    const { amount } = req.body;
    
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      return res.status(400).json({ 
        error: 'Invalid amount. Please provide a positive number.' 
      });
    }
    
    if (!isValidSolanaPublicKeyFormat(SOLANA_RECEIVER_PUBLIC_KEY)) {
      return res.status(500).json({ 
        error: 'Invalid receiver address configuration.' 
      });
    }
    
    // Create the transaction
    const transactionId = createMockTransaction(amount);
    
    // Return payment instructions
    res.status(201).json({
      transactionId,
      receiverAddress: SOLANA_RECEIVER_PUBLIC_KEY,
      amount: parseFloat(amount),
      network: SOLANA_NETWORK,
      instructions: `Send ${amount} SOL to ${SOLANA_RECEIVER_PUBLIC_KEY} on the ${SOLANA_NETWORK} network.`
    });
  } catch (error) {
    console.error('Error creating payment:', error);
    res.status(500).json({ error: 'Failed to create payment' });
  }
});

// Verify payment endpoint
app.get('/api/payment/verify/:transactionId', (req, res) => {
  try {
    const { transactionId } = req.params;
    
    if (!transactionId) {
      return res.status(400).json({ error: 'Transaction ID is required' });
    }
    
    // Check if transaction exists
    if (!transactions.has(transactionId)) {
      return res.status(404).json({ error: 'Transaction not found' });
    }
    
    const transaction = transactions.get(transactionId);
    
    // In mock mode, simulate transaction confirmation
    if (SOLANA_MOCK_MODE) {
      // Randomly confirm the transaction if it's pending
      if (transaction.status === 'pending') {
        // 80% chance of confirming the transaction
        if (Math.random() < 0.8) {
          transaction.status = 'confirmed';
          transaction.confirmations = Math.floor(Math.random() * 32) + 1;
          transaction.signature = 'mock_' + randomUUID().replace(/-/g, '');
          transactions.set(transactionId, transaction);
        }
      }
    }
    
    // Return transaction details
    res.json({
      ...transaction,
      mockMode: SOLANA_MOCK_MODE
    });
  } catch (error) {
    console.error('Error verifying payment:', error);
    res.status(500).json({ error: 'Failed to verify payment' });
  }
});

// List all transactions (for demo purposes)
app.get('/api/transactions', (req, res) => {
  res.json(Array.from(transactions.values()));
});

// Catch-all route to serve the main HTML
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://localhost:${PORT}`);
  console.log(`Solana receiver address: ${SOLANA_RECEIVER_PUBLIC_KEY}`);
  console.log(`Solana network: ${SOLANA_NETWORK}`);
  console.log(`Mock mode: ${SOLANA_MOCK_MODE ? 'Enabled' : 'Disabled'}`);
});